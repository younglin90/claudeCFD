"""Temporary torch shim for validation-only imports.

This exists only to satisfy legacy verifier imports that reference the older
five-equation code path during denner validation.  It is intentionally tiny
and only aims to be import-compatible for the code paths used here.
"""
from __future__ import annotations

import types
from typing import Any

import numpy as _np

float64 = _np.float64
float32 = _np.float32
int64 = _np.int64
bool = _np.bool_


def _to_array(x: Any, dtype=None):
    return _np.asarray(x, dtype=dtype)


def as_tensor(x: Any, dtype=None, device=None):  # noqa: ARG001
    return _to_array(x, dtype=dtype)


def tensor(x: Any, dtype=None, device=None):  # noqa: ARG001
    return _to_array(x, dtype=dtype)


def zeros_like(x: Any, dtype=None, device=None):  # noqa: ARG001
    return _np.zeros_like(_to_array(x), dtype=dtype)


def ones_like(x: Any, dtype=None, device=None):  # noqa: ARG001
    return _np.ones_like(_to_array(x), dtype=dtype)


def zeros(shape, dtype=None, device=None):  # noqa: ARG001
    return _np.zeros(shape, dtype=dtype)


def ones(shape, dtype=None, device=None):  # noqa: ARG001
    return _np.ones(shape, dtype=dtype)


def full(shape, fill_value, dtype=None, device=None):  # noqa: ARG001
    return _np.full(shape, fill_value, dtype=dtype)


def minimum(a, b):
    return _np.minimum(a, b)


def maximum(a, b):
    return _np.maximum(a, b)


def abs(x):  # noqa: A001
    return _np.abs(x)


def sign(x):
    return _np.sign(x)


def where(condition, x, y):
    return _np.where(condition, x, y)


def clamp(x, min=None, max=None):  # noqa: A002
    out = _np.asarray(x)
    if min is not None:
        out = _np.maximum(out, min)
    if max is not None:
        out = _np.minimum(out, max)
    return out


def stack(seq, dim=0):  # noqa: ARG001
    return _np.stack(tuple(seq), axis=dim)


def cat(seq, dim=0):  # noqa: ARG001
    return _np.concatenate(tuple(seq), axis=dim)


def sqrt(x):
    return _np.sqrt(x)


def maximum_reduce(x):
    return _np.max(x)


def minimum_reduce(x):
    return _np.min(x)


def __getattr__(name: str):
    if name == "func":
        import importlib

        return importlib.import_module("torch.func")
    raise AttributeError(f"torch shim has no attribute {name!r}")


class _TensorNamespace(types.SimpleNamespace):
    pass


Tensor = _TensorNamespace

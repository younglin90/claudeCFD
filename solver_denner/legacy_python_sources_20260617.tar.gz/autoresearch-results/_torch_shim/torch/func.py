"""Validation-only shim for ``torch.func``."""
from __future__ import annotations

from typing import Any, Callable


def jacrev(fn: Callable[..., Any], argnums=0):  # noqa: ARG001
    def _wrapped(*args, **kwargs):
        raise RuntimeError("torch.func.jacrev is unavailable in the validation shim")

    return _wrapped


def vmap(fn: Callable[..., Any], in_dims=0, out_dims=0):  # noqa: ARG001
    def _wrapped(*args, **kwargs):
        raise RuntimeError("torch.func.vmap is unavailable in the validation shim")

    return _wrapped

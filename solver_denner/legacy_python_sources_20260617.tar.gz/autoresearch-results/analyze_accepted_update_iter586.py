import json, math, statistics
from pathlib import Path
from collections import Counter, defaultdict
p=Path('autoresearch-results/accepted_update_iter586_N200.jsonl')
print('exists', p.exists(), 'size', p.stat().st_size if p.exists() else None)
rows=[]; bad=0
if p.exists():
    for line in p.open():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
print('rows', len(rows), 'bad', bad)
keys=sorted({k for r in rows for k in r.keys()})
print('accepted_keys', [k for k in keys if any(s in k.lower() for s in ['accepted','wplus','wminus','amp','old','nm1','cfl','temporal','spatial','source','projection','alignment','missing','supported','window'])][:500])
for key in ['step','window','row_type','accepted_update_supported','acoustic_accepted_update_supported','accepted_update_missing_fields','accepted_update_window','accepted_update_face_class','face_class']:
    if any(key in r for r in rows): print('HIST', key, Counter(str(r.get(key)) for r in rows).most_common(80))
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
fields=[k for k in keys if any(s in k.lower() for s in ['wplus_amp','wminus_amp','amp_ratio','old_over_nm1','n_over_old','acoustic_cfl','temporal','spatial','source','projection','alignment','supported'])]
print('FIELD_STATS')
for f in fields:
    s=stats([r.get(f) for r in rows]); null=sum(1 for r in rows if r.get(f) is None)
    if s or null < len(rows): print(f, s, 'null', null)
# group by step/window
for groupname, maker in [('step_window', lambda r:(r.get('step'), r.get('window'))), ('window', lambda r:(r.get('window'),)), ('step', lambda r:(r.get('step'),))]:
    print('GROUPS', groupname)
    groups=defaultdict(list)
    for r in rows: groups[maker(r)].append(r)
    for k,rs in sorted(groups.items(), key=lambda kv:str(kv[0]))[:200]:
        print('GROUP', k, 'n', len(rs), 'supported', Counter(str(rr.get('accepted_update_supported', rr.get('acoustic_accepted_update_supported'))) for rr in rs).most_common(10), 'missing', Counter(str(rr.get('accepted_update_missing_fields')) for rr in rs).most_common(10))
        for f in ['wplus_amp_ratio_n_over_old','wplus_amp_ratio_old_over_nm1','wminus_amp_ratio_n_over_old','wminus_amp_ratio_old_over_nm1','accepted_update_wplus_amp_ratio_n_over_old','accepted_update_wplus_amp_ratio_old_over_nm1','acoustic_cfl','accepted_update_acoustic_cfl','temporal_projection_ratio','spatial_projection_ratio','source_projection_ratio','accepted_update_temporal_projection_ratio','accepted_update_spatial_projection_ratio','accepted_update_source_projection_ratio','temporal_alignment','spatial_alignment','source_alignment','accepted_update_temporal_alignment','accepted_update_spatial_alignment','accepted_update_source_alignment']:
            s=stats([rr.get(f) for rr in rs])
            if s: print(' ', f, s)
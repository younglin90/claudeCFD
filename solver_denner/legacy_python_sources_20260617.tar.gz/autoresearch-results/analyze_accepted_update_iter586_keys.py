import json
from collections import Counter
rows=[json.loads(l) for l in open('autoresearch-results/accepted_update_iter586_N200.jsonl') if l.strip()]
keys=sorted({k for r in rows for k in r})
for substr in ['accepted_update','acoustic_accepted','amp_ratio','n_over_old','old_over_nm1','projection','alignment','cfl','missing_fields','supported']:
    print(substr, [k for k in keys if substr in k.lower()])
print('first keys', list(rows[0].keys())[:80])
print('has step?', any('step' in r for r in rows), 'sample step vals', Counter(str(r.get('step')) for r in rows).most_common(5))
PY
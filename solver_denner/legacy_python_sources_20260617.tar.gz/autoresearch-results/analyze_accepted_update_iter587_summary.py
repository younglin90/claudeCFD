import json, math, statistics
from collections import Counter,defaultdict
rows=[json.loads(l) for l in open('autoresearch-results/acoustic_accepted_update_iter587_N200.jsonl') if l.strip()]
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
print('support', Counter(r.get('accepted_update_audit_supported') for r in rows))
print('missing', Counter(str(r.get('accepted_update_missing_fields')) for r in rows))
print('face_class', Counter(r.get('accepted_update_face_class') for r in rows))
agg=[r for r in rows if r.get('row_type')=='acoustic_accepted_update_aggregate']
print('agg', len(agg), 'sample', len(rows)-len(agg))
for win in ['interface','right_lobe']:
    rs=[r for r in agg if r.get('window')==win]
    print('WIN', win, 'n', len(rs), 'supported_cells', stats([r.get('supported_cell_count') for r in rs]), 'unsupported', stats([r.get('unsupported_cell_count') for r in rs]))
    for f in ['temporal_alignment_with_wplus','spatial_alignment_with_wplus','source_alignment_with_wplus','proj_temporal_over_abs_wplus','proj_spatial_over_abs_wplus','proj_source_over_abs_wplus','same_sign_temporal_count','anti_sign_temporal_count','same_sign_spatial_count','anti_sign_spatial_count','same_sign_source_count','anti_sign_source_count']:
        print(' ', f, stats([r.get(f) for r in rs]))
for step in [609,650,700,760,800,810]:
    for win in ['interface','right_lobe']:
        rs=[r for r in agg if r.get('step')==step and r.get('window')==win]
        if rs:
            print('STEPWIN', step, win, 'n', len(rs), 'temporal_align', stats([r.get('temporal_alignment_with_wplus') for r in rs]), 'spatial_align', stats([r.get('spatial_alignment_with_wplus') for r in rs]), 'source_align', stats([r.get('source_alignment_with_wplus') for r in rs]), 'temporal_ratio', stats([r.get('proj_temporal_over_abs_wplus') for r in rs]), 'source_ratio', stats([r.get('proj_source_over_abs_wplus') for r in rs]), 'supported', stats([r.get('supported_cell_count') for r in rs]))
PY
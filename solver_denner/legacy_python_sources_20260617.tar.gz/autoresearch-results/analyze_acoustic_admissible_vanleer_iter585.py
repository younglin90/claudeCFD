import json, math, statistics
from pathlib import Path
from collections import Counter, defaultdict
p=Path('autoresearch-results/acoustic_admissible_vanleer_iter585_N50.jsonl')
print('exists', p.exists(), 'size', p.stat().st_size if p.exists() else None)
rows=[]; bad=0
if p.exists():
    for line in p.open():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
print('rows', len(rows), 'bad', bad)
keys=sorted({k for r in rows for k in r.keys()})
print('vanleer_keys', [k for k in keys if any(s in k.lower() for s in ['admiss','vanleer','active','fallback','reject','minmax','opposite','delta','material','bound','selected'])][:500])
for key in ['step','window','row_type','acoustic_limiter_face_class','acoustic_limiter_candidate','acoustic_limiter_aggregate','admissible_selected_candidate','admissible_selected_current','acoustic_admissible_vanleer_active','admissible_vanleer_active','vanleer_active','material_active','admissible_material_active','candidate_material_fallback','candidate_minmax_violation','candidate_bound_ok','candidate_opposite_non_growth']:
    if any(key in r for r in rows): print('HIST', key, Counter(r.get(key) for r in rows).most_common(60))
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
fields=[k for k in keys if any(s in k.lower() for s in ['active_count','fallback_count','material_active','reject','post','minmax','opposite','delta','bound','selected','nonzero'])]
print('FIELD_STATS')
for f in fields:
    s=stats([r.get(f) for r in rows]); null=sum(1 for r in rows if r.get(f) is None)
    if s or null < len(rows): print(f, s, 'null', null)
# group aggregate rows if present
for aggkey in ['acoustic_limiter_aggregate','acoustic_limiter_admissible_aggregate']:
    agg=[r for r in rows if r.get(aggkey)]
    if agg:
        print('AGGKEY', aggkey, len(agg))
        groups=defaultdict(list)
        for r in agg: groups[(r.get('step'),r.get('window'),r.get('acoustic_limiter_face_class'),r.get('acoustic_limiter_candidate'))].append(r)
        for k,rs in sorted(groups.items(), key=lambda kv:str(kv[0]))[:100]:
            print('GROUP', k, 'n', len(rs))
            for f in fields:
                s=stats([r.get(f) for r in rs])
                if s: print(' ', f, s)
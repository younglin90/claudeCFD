import json, math, statistics, os, time
from collections import Counter
path='autoresearch-results/acoustic_dispersion_iter590_N200.jsonl'
rows=[]; bad=0
with open(path) as f:
    for line in f:
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except Exception:
            bad += 1

def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stat(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals:
        return None
    vals.sort()
    return {'n':len(vals),'min':vals[0],'med':statistics.median(vals),'max':vals[-1],'mean':sum(vals)/len(vals)}
def fmt(s):
    if s is None:
        return 'NA'
    return f"n={s['n']} min={s['min']:.6g} med={s['med']:.6g} max={s['max']:.6g} mean={s['mean']:.6g}"
print('ROWS',len(rows),'BAD',bad)
print('ROW_TYPES',Counter(r.get('row_type') for r in rows))
print('STEPS',Counter(r.get('step') for r in rows))
for key in ['group','window','energy_group','dispersion_group','packet_group','face_class','acoustic_group']:
    c=Counter(r.get(key) for r in rows if key in r)
    if c:
        print('KEYCOUNT',key,c)
for key in ['dispersion_supported','acoustic_dispersion_supported','supported','energy_supported']:
    c=Counter(r.get(key) for r in rows if key in r)
    if c:
        print('SUPPORT',key,c)
for key in ['dispersion_missing_fields','acoustic_dispersion_missing_fields','missing_fields']:
    c=Counter(str(r.get(key)) for r in rows if key in r)
    if c:
        print('MISSING',key,c)
for key in ['previous_sample_centroid','prev_sample_centroid','previous_centroid','centroid_previous']:
    n=sum(1 for r in rows if key in r)
    if n:
        print('PREVKEY',key,'present',n,'finite',sum(1 for r in rows if isnum(r.get(key))))
fields=['centroid','energy_centroid','pressure_centroid','velocity_centroid','wplus_centroid','p_centroid','u_centroid','width_sigma','energy_width_sigma','sigma','width','energy_width_sqrt','skewness','local_c','p_u_centroid_separation','high_wavenumber_energy_fraction','tail_energy_fraction','opposite_energy_ratio','wplus_amp','wplus_energy','E_wplus','E_total']
print('FIELD_STATS')
for f in fields:
    s=stat([r.get(f) for r in rows])
    if s:
        print(f,fmt(s))
for gkey in ['dispersion_group','group','window','energy_group','packet_group']:
    if any(gkey in r for r in rows):
        group_key=gkey
        break
else:
    group_key=None
print('GROUP_KEY',group_key)
print('BY_STEP_GROUP')
steps=sorted(set(r.get('step') for r in rows if isinstance(r.get('step'), int)))
groups=sorted(set(r.get(group_key) for r in rows if group_key and r.get(group_key) is not None)) if group_key else [None]
for step in steps:
    for group in groups:
        rs=[r for r in rows if r.get('step')==step and (group_key is None or r.get(group_key)==group)]
        if not rs:
            continue
        print('STEPGROUP',step,group,'n',len(rs))
        for f in fields:
            s=stat([r.get(f) for r in rs])
            if s:
                print(' FIELD',f,fmt(s))
print('KEYS_SAMPLE')
for r in rows[:3]:
    print(sorted(r.keys()))
for p in ['autoresearch-results/pytest_acoustic_dispersion_iter590.log','autoresearch-results/acoustic_dispersion_iter590_N200.log','autoresearch-results/acoustic_dispersion_iter590_N200.jsonl','results/1D/07_B/diff_vs_exact.png']:
    st=os.stat(p)
    print('ARTIFACT',p,'size',st.st_size,'mtime',time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(st.st_mtime)))
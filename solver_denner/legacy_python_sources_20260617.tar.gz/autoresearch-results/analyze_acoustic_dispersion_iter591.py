import json, math, statistics, os, time
from collections import Counter
path='autoresearch-results/acoustic_dispersion_iter591_N200.jsonl'
rows=[]; bad=0
with open(path) as f:
    for line in f:
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except Exception:
            bad += 1

def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stat(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals:
        return None
    vals.sort()
    return {'n':len(vals),'min':vals[0],'med':statistics.median(vals),'max':vals[-1],'mean':sum(vals)/len(vals)}
def med(vals):
    s=stat(vals)
    return None if s is None else s['med']
def fmt(x): return 'NA' if x is None else f'{x:.6g}'
def fmts(s):
    if s is None:
        return 'NA'
    return f"n={s['n']} min={s['min']:.6g} med={s['med']:.6g} max={s['max']:.6g} mean={s['mean']:.6g}"
print('ROWS',len(rows),'BAD',bad)
print('ROW_TYPES',Counter(r.get('row_type') for r in rows))
print('STEPS',Counter(r.get('step') for r in rows))
print('GROUPS',Counter(r.get('dispersion_group') for r in rows))
print('MISSING',Counter(str(r.get('missing_fields')) for r in rows))
print('PREVIOUS_SAMPLE_CENTROID_MISSING_ROWS',sum(1 for r in rows if 'previous_sample_centroid' in (r.get('missing_fields') or [])))
fields=['energy_centroid_x','p_centroid_x','u_centroid_x','wplus_centroid_x','energy_width_sigma','wplus_width_sigma','energy_skewness','local_c_energy_weighted','centroid_speed_from_prev_sample','speed_ratio_to_local_c','p_u_centroid_separation','high_wavenumber_energy_fraction','tail_energy_fraction','opposite_energy_ratio','support_count','unsupported_count','finite_count']
print('FIELD_RANGES')
for f in fields:
    s=stat([r.get(f) for r in rows])
    if s:
        print(f,fmts(s))
print('GROUP_STEP_MEDIANS')
for step in [609,650,700,760,800,810]:
    print('STEP', step)
    for group in ['right_material_side','right_lobe_expanded','right_lobe','right_packet_energy_core','right_packet_energy_tails']:
        rs=[r for r in rows if r.get('step')==step and r.get('dispersion_group')==group]
        if not rs:
            continue
        parts=[]
        for f in fields[:14]:
            parts.append(f + '=' + fmt(med([r.get(f) for r in rs])))
        print(' ',group,'n',len(rs),' '.join(parts))
for p in ['autoresearch-results/pytest_acoustic_dispersion_iter591.log','autoresearch-results/acoustic_dispersion_iter591_N200.log','autoresearch-results/acoustic_dispersion_iter591_N200.jsonl','results/1D/07_B/diff_vs_exact.png']:
    st=os.stat(p)
    print('ARTIFACT',p,'size',st.st_size,'mtime',time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(st.st_mtime)))
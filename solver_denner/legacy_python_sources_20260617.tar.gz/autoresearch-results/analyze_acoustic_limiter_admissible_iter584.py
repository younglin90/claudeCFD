import json, math, statistics
from pathlib import Path
from collections import Counter, defaultdict
p=Path('autoresearch-results/acoustic_limiter_admissible_iter584_N200.jsonl')
print('exists', p.exists(), 'size', p.stat().st_size if p.exists() else None)
rows=[]; bad=0
if p.exists():
    for line in p.open():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
print('rows', len(rows), 'bad', bad)
keys=sorted({k for r in rows for k in r.keys()})
print('admissible_keys', [k for k in keys if any(s in k.lower() for s in ['admiss','selected','reject','nonzero','candidate','opposite','face_delta','wplus','wminus','bound','minmax','fallback','window','face_class'])][:500])
for key in ['step','window','acoustic_limiter_candidate','acoustic_limiter_face_class','acoustic_limiter_aggregate','admissible_selected','admissible_candidate','admissible_reject_reason','admissible_current_selected','admissible_vanleer_selected','admissible_mc_selected','admissible_nonzero_delta','admissible_opposite_ok','admissible_minmax_ok','admissible_bound_ok','admissible_material_fallback']:
    if any(key in r for r in rows): print('HIST', key, Counter(r.get(key) for r in rows).most_common(80))
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
# global stats for fields containing admissible/candidate deltas
fields=[k for k in keys if any(s in k.lower() for s in ['admissible','candidate_face_delta','candidate_wplus','candidate_wminus','candidate_local_bv','candidate_opposite','max_abs_delta','median_abs_delta','nonzero_delta','opposite_ratio','opposite_characteristic'])]
print('FIELD_STATS')
for f in fields:
    s=stats([r.get(f) for r in rows]); null=sum(1 for r in rows if r.get(f) is None)
    if s or null < len(rows): print(f, s, 'null', null)
agg=[r for r in rows if r.get('acoustic_limiter_aggregate')]
print('agg_rows', len(agg))
count_fields=[k for k in keys if any(s in k.lower() for s in ['selected_current','selected_vanleer','selected_mc','reject','nonzero','material_fallback_count','bound_ok_count','minmax_violation_count','admissible'])]
print('COUNT_FIELDS', count_fields)
# group aggregates by step/window/face/candidate if present
for groupname, maker in [
    ('step_window_face_candidate', lambda r:(r.get('step'),r.get('window'),r.get('acoustic_limiter_face_class'),r.get('acoustic_limiter_candidate'))),
    ('window_candidate', lambda r:(r.get('window'),r.get('acoustic_limiter_candidate'))),
    ('window_face', lambda r:(r.get('window'),r.get('acoustic_limiter_face_class'))),
]:
    print('GROUPS', groupname)
    groups=defaultdict(list)
    for r in agg: groups[maker(r)].append(r)
    for k,rs in sorted(groups.items(), key=lambda kv:str(kv[0]))[:300]:
        print('GROUP', k, 'n', len(rs))
        for cf in count_fields:
            s=stats([r.get(cf) for r in rs])
            if s: print(' ', cf, s)
        for f in ['admissible_face_delta_p','admissible_face_delta_u','admissible_face_delta_T','admissible_wplus_delta','admissible_wminus_delta','admissible_opposite_characteristic_preview','admissible_opposite_ratio','admissible_alignment_with_packet','max_admissible_abs_delta_p','max_admissible_abs_delta_u','max_admissible_abs_wplus_delta','max_admissible_abs_wminus_delta','max_admissible_opposite_characteristic_preview']:
            s=stats([r.get(f) for r in rs])
            if s: print(' ', f, s)
# selected rows non-agg by window/candidate
sel=[r for r in rows if not r.get('acoustic_limiter_aggregate')]
for cand in sorted(set(r.get('acoustic_limiter_candidate') for r in sel)):
    rs=[r for r in sel if r.get('acoustic_limiter_candidate')==cand]
    print('ROWCAND', cand, 'n', len(rs))
    for k in ['admissible_selected','admissible_candidate','admissible_reject_reason','admissible_nonzero_delta','admissible_material_fallback','candidate_minmax_violation','candidate_bound_ok','candidate_material_fallback']:
        if any(k in r for r in rs): print(' ', k, Counter(r.get(k) for r in rs).most_common(20))
    for f in ['candidate_face_delta_p','candidate_face_delta_u','candidate_wplus_delta','candidate_wminus_delta','candidate_opposite_characteristic_preview','admissible_face_delta_p','admissible_face_delta_u','admissible_wplus_delta','admissible_wminus_delta','admissible_opposite_characteristic_preview']:
        s=stats([r.get(f) for r in rs])
        if s: print(' ', f, s)
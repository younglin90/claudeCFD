import json, math, statistics
from collections import Counter,defaultdict
rows=[json.loads(l) for l in open('autoresearch-results/acoustic_limiter_admissible_iter584_N200.jsonl') if l.strip()]
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
print('selected_candidate', Counter(str(r.get('admissible_selected_candidate')) for r in rows).most_common(20))
print('selected_current_bool', Counter(r.get('admissible_selected_current') for r in rows).most_common(20))
for k in ['admissible_selected_current_count','admissible_selected_vanleer_count','admissible_selected_mc_count','clean_candidate_nonzero_delta_count','rejected_opposite_growth_count','rejected_minmax_count','rejected_characteristic_minmax_count','material_fallback_count']:
    print(k, stats([r.get(k) for r in rows]))
agg=[r for r in rows if r.get('acoustic_limiter_admissible_aggregate')]
for win in ['interface','right_lobe']:
    rs=[r for r in agg if r.get('window')==win]
    print('WIN', win, 'n', len(rs))
    for k in ['admissible_selected_current_count','admissible_selected_vanleer_count','admissible_selected_mc_count','clean_candidate_nonzero_delta_count','rejected_opposite_growth_count','rejected_minmax_count','rejected_characteristic_minmax_count','material_fallback_count']:
        print(' ', k, stats([r.get(k) for r in rs]))
    for f in ['clean_candidate_p_delta_norm','clean_candidate_u_delta_norm','clean_candidate_T_delta_norm','clean_candidate_wplus_delta_norm','clean_candidate_wminus_delta_norm','clean_candidate_predicted_opposite_ratio','current_opposite_ratio','clean_candidate_local_BV']:
        print(' ', f, stats([r.get(f) for r in rs]))
for step in [609,650,700,760,800,810]:
    for win in ['interface','right_lobe']:
        rs=[r for r in agg if r.get('step')==step and r.get('window')==win]
        if rs:
            print('STEPWIN', step, win, 'n', len(rs), 'current', stats([r.get('admissible_selected_current_count') for r in rs]), 'vanleer', stats([r.get('admissible_selected_vanleer_count') for r in rs]), 'mc', stats([r.get('admissible_selected_mc_count') for r in rs]), 'nonzero', stats([r.get('clean_candidate_nonzero_delta_count') for r in rs]), 'opp', stats([r.get('clean_candidate_predicted_opposite_ratio') for r in rs]))
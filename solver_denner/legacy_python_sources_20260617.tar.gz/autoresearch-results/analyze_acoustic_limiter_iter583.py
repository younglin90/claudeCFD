import json, math, statistics
from pathlib import Path
from collections import Counter, defaultdict
p=Path('autoresearch-results/acoustic_limiter_iter583_N200.jsonl')
print('exists', p.exists(), 'size', p.stat().st_size if p.exists() else None)
rows=[]; bad=0
if p.exists():
    for line in p.open():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
print('rows', len(rows), 'bad', bad)
keys=sorted({k for r in rows for k in r.keys()})
print('limiter_keys', [k for k in keys if any(s in k.lower() for s in ['limiter','candidate','koren','vanleer','mc','opposite','wplus','wminus','local_bv','fallback','bound','minmax','face_class','window'])][:400])
for key in ['step','window','row_type','face_class','candidate','limiter_candidate','acoustic_limiter_candidate','acoustic_limiter_candidate_name','acoustic_limiter_supported','acoustic_limiter_bounded','acoustic_limiter_minmax_ok','acoustic_limiter_material_fallback','acoustic_limiter_opposite_warning','acoustic_limiter_face_class']:
    if any(key in r for r in rows): print('HIST', key, Counter(r.get(key) for r in rows).most_common(60))
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
# infer candidate key
cand_keys=[k for k in ['candidate','limiter_candidate','acoustic_limiter_candidate','acoustic_limiter_candidate_name','limiter','acoustic_limiter_name'] if any(k in r for r in rows)]
print('cand_keys', cand_keys)
num_fields=[k for k in keys if any(s in k.lower() for s in ['delta_p','delta_u','delta_t','face_delta','wplus','wminus','local_bv','opposite','alignment','bound_ratio','minmax','fallback','clip'])]
print('NUM_FIELD_STATS')
for f in num_fields:
    s=stats([r.get(f) for r in rows]); null=sum(1 for r in rows if r.get(f) is None)
    if s or null < len(rows): print(f, s, 'null', null)
# group by candidate/window/face class
cand_key=cand_keys[0] if cand_keys else None
for groupname, maker in [
    ('candidate_window_face', lambda r:(r.get(cand_key) if cand_key else None, r.get('window'), r.get('face_class') or r.get('acoustic_limiter_face_class'))),
    ('candidate', lambda r:(r.get(cand_key) if cand_key else None,)),
    ('window_face', lambda r:(r.get('window'), r.get('face_class') or r.get('acoustic_limiter_face_class'))),
]:
    print('GROUPS', groupname)
    groups=defaultdict(list)
    for r in rows: groups[maker(r)].append(r)
    for k,rs in sorted(groups.items(), key=lambda kv: str(kv[0]))[:200]:
        print('GROUP', k, 'n', len(rs))
        for ck in ['acoustic_limiter_supported','acoustic_limiter_bounded','acoustic_limiter_minmax_ok','acoustic_limiter_material_fallback','acoustic_limiter_opposite_warning']:
            if any(ck in rr for rr in rs): print(' ', ck, Counter(rr.get(ck) for rr in rs).most_common(10))
        for f in ['candidate_face_delta_p','candidate_face_delta_u','candidate_face_delta_T','acoustic_limiter_candidate_face_delta_p','acoustic_limiter_candidate_face_delta_u','acoustic_limiter_candidate_face_delta_T','wplus_delta','wminus_delta','acoustic_limiter_wplus_delta','acoustic_limiter_wminus_delta','local_BV','acoustic_limiter_local_BV','opposite_characteristic_preview','acoustic_limiter_opposite_characteristic_preview','alignment_with_packet','acoustic_limiter_alignment_with_packet','bound_ratio','acoustic_limiter_bound_ratio']:
            s=stats([rr.get(f) for rr in rs])
            if s: print(' ', f, s)
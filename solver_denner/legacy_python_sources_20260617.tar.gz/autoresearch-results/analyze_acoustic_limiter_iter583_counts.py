import json, math, statistics
from collections import defaultdict,Counter
rows=[json.loads(l) for l in open('autoresearch-results/acoustic_limiter_iter583_N200.jsonl') if l.strip()]
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
agg=[r for r in rows if r.get('acoustic_limiter_aggregate')]
print('agg_rows', len(agg))
for k in ['candidate_supported','candidate_bound_ok','candidate_minmax_violation','candidate_material_fallback']:
    print(k, Counter(r.get(k) for r in rows).most_common(20))
print('aggregate count fields')
fields=['supported_count','unsupported_count','bound_ok_count','minmax_violation_count','material_fallback_count','max_abs_delta_p','median_abs_delta_p','max_abs_delta_u','median_abs_delta_u','max_abs_delta_T','median_abs_delta_T','max_abs_wplus_delta','median_abs_wplus_delta','max_abs_wminus_delta','median_abs_wminus_delta','max_candidate_local_BV','median_candidate_local_BV','max_candidate_opposite_characteristic_preview','median_candidate_local_BV']
for cand in sorted(set(r.get('acoustic_limiter_candidate') for r in rows)):
    for win in sorted(set(r.get('window') for r in rows)):
        rs=[r for r in agg if r.get('acoustic_limiter_candidate')==cand and r.get('window')==win]
        if not rs: continue
        print('AGG', cand, win, 'n', len(rs), 'steps', Counter(r.get('step') for r in rs))
        for f in fields:
            s=stats([r.get(f) for r in rs])
            if s: print(' ', f, s)
# selected row booleans by cand/window/class
for cand in sorted(set(r.get('acoustic_limiter_candidate') for r in rows)):
    rs=[r for r in rows if r.get('acoustic_limiter_candidate')==cand and not r.get('acoustic_limiter_aggregate')]
    print('ROW', cand, 'n', len(rs), 'supported', Counter(r.get('candidate_supported') for r in rs), 'bound', Counter(r.get('candidate_bound_ok') for r in rs), 'minmax', Counter(r.get('candidate_minmax_violation') for r in rs), 'fallback', Counter(r.get('candidate_material_fallback') for r in rs))
PY
import json, math, statistics
from pathlib import Path
from collections import Counter, defaultdict
p=Path('autoresearch-results/alpha_mstacs_iter582_N50.jsonl')
print('exists', p.exists(), 'size', p.stat().st_size if p.exists() else None)
rows=[]; bad=0
if p.exists():
    for line in p.open():
        if not line.strip():
            continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
print('rows', len(rows), 'bad', bad)
keys=sorted({k for r in rows for k in r.keys()})
print('mstacs_keys', [k for k in keys if 'mstacs' in k.lower() or 'cicsam' in k.lower() or 'alpha' in k.lower() or 'acid' in k.lower()][:300])
for key in ['step','window','row_type','alpha_mstacs_active','alpha_mstacs_selected','alpha_mstacs_face_transport_active','alpha_mstacs_face_count','alpha_mstacs_clip_count','alpha_mstacs_selected_count','alpha_mstacs_reject_reason','alpha_mstacs_face_class','alpha_mstacs_branch','alpha_mstacs_interface_width']:
    if any(key in r for r in rows): print('HIST', key, Counter(r.get(key) for r in rows).most_common(40))
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
fields=[k for k in keys if any(s in k.lower() for s in ['mstacs','cicsam','delta_vs_production','acid_rho','acid_h','interface_width','clip_count','selected_count'])]
print('FIELD_STATS')
for f in fields:
    s=stats([r.get(f) for r in rows]); null=sum(1 for r in rows if r.get(f) is None)
    if s or null < len(rows): print(f, s, 'null', null)
# top-level diagnostics from final details not in JSONL not parsed here
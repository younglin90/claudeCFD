import json, os, time, math, statistics
from collections import Counter
path='autoresearch-results/face_context_cache_iter597_N50.jsonl'
rows=[]; bad=0
with open(path) as f:
    for line in f:
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
print('ROWS',len(rows),'BAD',bad)
print('ROW_TYPES',Counter(r.get('row_type') for r in rows))
if rows:
    last=rows[-1]
    print('LAST_CALLS',last.get('profile_calls'))
    print('KEYS_SAMPLE',sorted(last.keys()))
    cats=last.get('categories',{})
    for name,data in sorted(cats.items(), key=lambda kv: kv[1].get('wall',0), reverse=True):
        print('CAT',name,'calls',data.get('calls'),'wall',data.get('wall'),'extra',{k:v for k,v in data.items() if k not in ('calls','wall')})
    prof=last.get('profile',{})
    for k in sorted(prof):
        if 'cache' in k.lower() or 'face' in k.lower() or 'context' in k.lower() or k in ['assemble_newton_3N_wall','assemble_newton_3N_preloop_wall','assemble_newton_3N_cell_loop_wall','solve_linear_system_wall','sparse_tocsr_wall']:
            print('PROFILE',k,prof.get(k))
for p in ['autoresearch-results/pytest_face_context_cache_iter597.log','autoresearch-results/face_context_cache_iter597_N50.log','autoresearch-results/face_context_cache_iter597_N50.jsonl','results/1D/07_B/diff_vs_exact.png']:
    if os.path.exists(p):
        st=os.stat(p)
        print('ARTIFACT',p,'size',st.st_size,'mtime',time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(st.st_mtime)))
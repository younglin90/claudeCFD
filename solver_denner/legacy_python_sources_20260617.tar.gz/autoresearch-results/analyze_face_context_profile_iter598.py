import json, os, time, math, statistics
from collections import Counter
path='autoresearch-results/face_context_profile_iter598_N50.jsonl'
rows=[]; bad=0
with open(path) as f:
    for line in f:
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
print('ROWS',len(rows),'BAD',bad)
print('ROW_TYPES',Counter(r.get('row_type') for r in rows))
last=rows[-1]
print('LAST_CALLS',last.get('profile_calls'))
print('TOP_KEYS',sorted(last.keys()))
print('CATEGORY_KEYS',sorted(last.get('categories',{}).keys()))
for name,data in sorted(last.get('categories',{}).items(), key=lambda kv: (kv[1].get('wall') if isinstance(kv[1],dict) and isinstance(kv[1].get('wall'),(int,float)) else -1), reverse=True):
    print('CAT',name,'calls',data.get('calls') if isinstance(data,dict) else None,'wall',data.get('wall') if isinstance(data,dict) else None,'extra',{k:v for k,v in data.items() if k not in ('calls','wall')} if isinstance(data,dict) else data)
prof=last.get('profile',{})
print('PROFILE_SELECTED')
for k in sorted(prof):
    if any(tok in k.lower() for tok in ['exclusive','cache','face_context','effective','pface','face_state','mwi','acid','acoustic','assemble_newton_3n_wall','preloop','cell_loop','linear','sparse']):
        print(k,prof.get(k))
# simple plausibility sums if present
for p in ['autoresearch-results/pytest_face_context_profile_iter598.log','autoresearch-results/face_context_profile_iter598_N50.log','autoresearch-results/face_context_profile_iter598_N50.jsonl','results/1D/07_B/diff_vs_exact.png']:
    st=os.stat(p)
    print('ARTIFACT',p,'size',st.st_size,'mtime',time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(st.st_mtime)))
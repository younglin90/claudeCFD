import glob
import json
import os
import re


ROOT = "/home/younglin90/work/claude_code/claudeCFD/solver_denner"
required = [
    "corr_p",
    "corr_u",
    "p_peak_amp_ratio",
    "u_peak_amp_ratio",
    "p_abs_delta_cells",
    "u_abs_delta_cells",
    "air_water_p_packet_shape_ok",
    "air_water_u_packet_shape_ok",
    "air_water_p_packet_secondary_extrema",
    "air_water_u_packet_secondary_extrema",
    "p_smooth_local_tv_excess",
    "u_smooth_local_tv_excess",
    "p_hf_ok",
    "hf_oscillation_ok",
    "wall",
    "N",
    "pass",
    "subcase",
]

analysis = {}
for tag in ["N50", "N200"]:
    path = f"{ROOT}/autoresearch-results/fast_packet_metrics_iter610_validator_{tag}.jsonl"
    rows = []
    bad = 0
    with open(path) as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except Exception:
                bad += 1
    first = rows[0] if rows else {}
    log_path = f"{ROOT}/autoresearch-results/fast_packet_metrics_iter610_validator_{tag}.log"
    text = open(log_path, errors="replace").read()
    metric_match = re.search(r"AUTORESEARCH_METRIC pass_count=(\d+) total=(\d+)", text)
    analysis[tag] = {
        "path": path,
        "log_path": log_path,
        "exists": os.path.exists(path),
        "size_bytes": os.path.getsize(path),
        "rows": len(rows),
        "bad_json": bad,
        "keys": sorted(first.keys()),
        "required_missing": [key for key in required if key not in first],
        "summary": {key: first.get(key) for key in required if key in first},
        "pass_count": int(metric_match.group(1)) if metric_match else None,
        "total": int(metric_match.group(2)) if metric_match else None,
    }

analysis["iter610_files"] = [
    {"name": os.path.basename(path), "size_bytes": os.path.getsize(path)}
    for path in sorted(glob.glob(f"{ROOT}/autoresearch-results/*iter610*"))
]

out = f"{ROOT}/autoresearch-results/fast_packet_metrics_iter610_validator_analysis.json"
with open(out, "w") as f:
    json.dump(analysis, f, indent=2, sort_keys=True)
print(json.dumps(analysis, indent=2, sort_keys=True))

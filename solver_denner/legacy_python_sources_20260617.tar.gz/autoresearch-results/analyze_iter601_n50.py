﻿import json, math, statistics, collections
from pathlib import Path
base=Path('/home/younglin90/work/claude_code/claudeCFD/solver_denner')
p=base/'autoresearch-results/pface_vector_cache_disabled_iter601_N50.jsonl'
rows=[]; bad=0
if p.exists():
    for line in p.read_text(errors='replace').splitlines():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad+=1

def finite(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stat(k):
    v=[float(r[k]) for r in rows if finite(r.get(k))]
    if not v: return None
    return {'count':len(v),'min':min(v),'median':statistics.median(v),'max':max(v)}
keys=set().union(*(r.keys() for r in rows)) if rows else set()
interesting=sorted([k for k in keys if 'pface_vector' in k or 'cache' in k or 'disabled' in k or 'reason' in k])
out={
 'exists':p.exists(), 'size':p.stat().st_size if p.exists() else 0,
 'rows':len(rows), 'bad_json':bad,
 'row_types':dict(collections.Counter(r.get('row_type') for r in rows)),
 'steps':sorted(set(r.get('step_index') for r in rows if r.get('step_index') is not None)),
 'interesting_keys':interesting,
 'stats':{k:stat(k) for k in interesting if any(s in k for s in ['count','delta','supported'])},
 'disabled_reason_counts':dict(collections.Counter(str(r.get('pface_vector_cache_disabled_reason')) for r in rows if 'pface_vector_cache_disabled_reason' in r)),
 'cache_enabled_counts':dict(collections.Counter(str(r.get('pface_vector_cache_enabled')) for r in rows if 'pface_vector_cache_enabled' in r)),
 'cache_requested_counts':dict(collections.Counter(str(r.get('pface_vector_cache_requested')) for r in rows if 'pface_vector_cache_requested' in r)),
 'unsupported_reasons':dict(sum((collections.Counter(r.get('pface_vector_unsupported_reason_counts',{})) for r in rows), collections.Counter())),
 'supported_branches':dict(sum((collections.Counter(r.get('pface_vector_supported_branch_counts',{})) for r in rows), collections.Counter())),
 'measured_remainder':sum(1 for r in rows if r.get('pface_vector_used_measured_remainder')),
 'first_rows':rows[:2],
}
# metrics
log=base/'autoresearch-results/pface_vector_cache_disabled_iter601_N50.log'
if log.exists():
    for line in log.read_text(errors='replace').splitlines():
        if line.startswith('AUTORESEARCH_METRIC'): out['metric']=line
        if line.startswith('DETAILS_JSON'):
            arr=json.loads(line.split(' ',1)[1]); sub=arr[0]['subcases'][0]
            out['wall']=arr[0].get('wall')
            out['metrics']={k:sub.get(k) for k in ['corr_p','corr_u','p_peak_amp_ratio','u_peak_amp_ratio','p_abs_delta_cells','u_abs_delta_cells','air_water_p_packet_shape_ok','air_water_u_packet_shape_ok','air_water_p_packet_secondary_extrema','p_hf_ok','hf_oscillation_ok']}
print(json.dumps(out, indent=2, sort_keys=True))

import collections
import json
import math
import re
import statistics
from pathlib import Path


ROOT = Path("/home/younglin90/work/claude_code/claudeCFD/solver_denner")
JSONL = ROOT / "autoresearch-results/keep_pep_split_iter608_N200.jsonl"
LOG = ROOT / "autoresearch-results/keep_pep_split_iter608_N200.log"
OUT = ROOT / "autoresearch-results/keep_pep_split_iter608_N200_analysis.json"


rows = []
bad = 0
bad_examples = []
with JSONL.open() as f:
    for i, line in enumerate(f, 1):
        try:
            rows.append(json.loads(line))
        except Exception as exc:
            bad += 1
            if len(bad_examples) < 5:
                bad_examples.append({"line": i, "error": str(exc), "text": line[:200]})


def finite(value):
    return isinstance(value, (int, float)) and math.isfinite(value)


def values(field, subset=None):
    sample = rows if subset is None else subset
    return [r[field] for r in sample if finite(r.get(field))]


def stats(field, subset=None):
    sample = rows if subset is None else subset
    vals = values(field, sample)
    if not vals:
        return {
            "count": 0,
            "finite_count": 0,
            "missing_or_nonfinite": len(sample),
        }
    vals_sorted = sorted(vals)
    return {
        "count": len(vals),
        "finite_count": len(vals),
        "min": vals_sorted[0],
        "median": statistics.median(vals_sorted),
        "mean": sum(vals_sorted) / len(vals_sorted),
        "max": vals_sorted[-1],
        "missing_or_nonfinite": len(sample) - len(vals),
    }


def count(field, subset=None):
    sample = rows if subset is None else subset
    c = collections.Counter()
    for r in sample:
        value = r.get(field, "<missing>")
        if value is None:
            value = "<null>"
        c[str(value)] += 1
    return dict(c.most_common())


fields = [
    "keep_pep_split_delta_F_mass",
    "keep_pep_split_delta_F_momentum",
    "keep_pep_split_delta_F_energy",
    "keep_pep_split_pressure_equilibrium_compat_defect",
    "keep_pep_split_kinetic_energy_compat_defect",
    "keep_pep_split_internal_energy_static_thermal_defect",
    "keep_pep_split_highk_ratio_vs_production",
    "keep_pep_split_mass_bound_ratio",
    "keep_pep_split_momentum_bound_ratio",
    "keep_pep_split_energy_bound_ratio",
    "keep_pep_split_F_mass_candidate",
    "keep_pep_split_F_momentum_candidate",
    "keep_pep_split_F_energy_candidate",
    "prod_F_mass",
    "prod_F_mom",
    "prod_F_energy",
]


def step_value(row):
    return row.get("keep_pep_split_flux_step", row.get("step"))


def window_value(row):
    return row.get("keep_pep_split_window", row.get("window"))


def class_value(row):
    return row.get("keep_pep_split_face_class", row.get("keep_pep_split_flux_face_class", "<missing>"))


classes = sorted({str(class_value(r)) for r in rows})
windows = sorted({str(window_value(r)) for r in rows})
steps = sorted({step_value(r) for r in rows if step_value(r) is not None})

analysis = {
    "jsonl_path": str(JSONL),
    "log_path": str(LOG),
    "rows": len(rows),
    "bad_json": bad,
    "bad_examples": bad_examples,
    "size_bytes": JSONL.stat().st_size if JSONL.exists() else None,
    "cap_config": 4096,
    "cap_hit": len(rows) >= 4096,
    "row_type_counts": count("row_type"),
    "steps": steps,
    "windows": windows,
    "face_classes": classes,
    "coverage_counts": {
        "by_step": dict(collections.Counter(str(step_value(r)) for r in rows).most_common()),
        "by_window": dict(collections.Counter(str(window_value(r)) for r in rows).most_common()),
        "by_face_class": dict(collections.Counter(str(class_value(r)) for r in rows).most_common()),
        "by_step_window": dict(
            collections.Counter(f"{step_value(r)}:{window_value(r)}" for r in rows).most_common()
        ),
    },
    "support_counts": {
        "candidate_supported": count("keep_pep_split_candidate_supported"),
        "candidate_finite": count("keep_pep_split_candidate_finite"),
        "measured_remainder": count("keep_pep_split_measured_remainder"),
        "primitive_admissible": count("keep_pep_split_primitive_admissible"),
        "thermo_admissible": count("keep_pep_split_thermo_admissible"),
        "mass_flux_sign_change": count("keep_pep_split_mass_flux_sign_change"),
        "fallback_reason": count("keep_pep_split_fallback_reason"),
    },
    "overall_stats": {field: stats(field) for field in fields},
    "by_face_class": {},
    "by_window": {},
    "nonzero_delta_counts": {},
    "top_abs_rows": {},
}

for cls in classes:
    subset = [r for r in rows if str(class_value(r)) == cls]
    analysis["by_face_class"][cls] = {
        "rows": len(subset),
        "support": count("keep_pep_split_candidate_supported", subset),
        "finite": count("keep_pep_split_candidate_finite", subset),
        "fallback_reason": count("keep_pep_split_fallback_reason", subset),
        "measured_remainder": count("keep_pep_split_measured_remainder", subset),
        "primitive_admissible": count("keep_pep_split_primitive_admissible", subset),
        "thermo_admissible": count("keep_pep_split_thermo_admissible", subset),
        "mass_flux_sign_change": count("keep_pep_split_mass_flux_sign_change", subset),
        "stats": {field: stats(field, subset) for field in fields},
    }

for win in windows:
    subset = [r for r in rows if str(window_value(r)) == win]
    analysis["by_window"][win] = {
        "rows": len(subset),
        "support": count("keep_pep_split_candidate_supported", subset),
        "face_class": count("keep_pep_split_face_class", subset),
        "fallback_reason": count("keep_pep_split_fallback_reason", subset),
        "measured_remainder": count("keep_pep_split_measured_remainder", subset),
        "stats": {field: stats(field, subset) for field in fields},
    }

for field in [
    "keep_pep_split_delta_F_mass",
    "keep_pep_split_delta_F_momentum",
    "keep_pep_split_delta_F_energy",
]:
    nonzero = [r for r in rows if finite(r.get(field)) and abs(r[field]) > 0.0]
    analysis["nonzero_delta_counts"][field] = len(nonzero)
    top = sorted(
        [r for r in rows if finite(r.get(field))],
        key=lambda r: abs(r[field]),
        reverse=True,
    )[:10]
    analysis["top_abs_rows"][field] = [
        {
            key: r.get(key)
            for key in [
                "step",
                "keep_pep_split_flux_step",
                "keep_pep_split_window",
                "keep_pep_split_face_class",
                "face",
                "cell_left",
                "cell_right",
                field,
                "keep_pep_split_candidate_supported",
                "keep_pep_split_fallback_reason",
                "keep_pep_split_pressure_equilibrium_compat_defect",
                "keep_pep_split_highk_ratio_vs_production",
                "keep_pep_split_mass_flux_sign_change",
            ]
        }
        for r in top
    ]

metrics = {}
text = LOG.read_text(errors="replace") if LOG.exists() else ""
match = re.search(r"AUTORESEARCH_METRIC pass_count=(\d+) total=(\d+)", text)
if match:
    metrics["pass_count"] = int(match.group(1))
    metrics["total"] = int(match.group(2))
details_match = re.search(r"DETAILS_JSON (\[.*\])", text)
if details_match:
    try:
        details = json.loads(details_match.group(1))
        metrics["details_json"] = details
        sub = details[0]["subcases"][0]
        for key in [
            "corr_p",
            "corr_u",
            "p_peak_amp_ratio",
            "u_peak_amp_ratio",
            "p_abs_delta_cells",
            "u_abs_delta_cells",
            "air_water_p_packet_min_corr",
            "air_water_u_packet_min_corr",
            "p_smooth_local_tv_excess",
            "u_smooth_local_tv_excess",
            "air_water_p_packet_shape_ok",
            "air_water_u_packet_shape_ok",
            "air_water_p_packet_secondary_extrema",
            "air_water_u_packet_secondary_extrema",
        ]:
            metrics[key] = sub.get(key)
    except Exception as exc:
        metrics["details_parse_error"] = str(exc)
analysis["metrics"] = metrics

OUT.write_text(json.dumps(analysis, indent=2, sort_keys=True))

summary = {
    "out": str(OUT),
    "rows": analysis["rows"],
    "bad_json": bad,
    "cap_hit": analysis["cap_hit"],
    "steps": steps,
    "windows": windows,
    "face_classes": classes,
    "support": analysis["support_counts"],
    "overall_stats": {field: analysis["overall_stats"][field] for field in fields[:10]},
    "by_face_class_summary": {
        key: {
            "rows": value["rows"],
            "support": value["support"],
            "fallback_reason": value["fallback_reason"],
            "measured_remainder": value["measured_remainder"],
        }
        for key, value in analysis["by_face_class"].items()
    },
    "metrics": {
        key: metrics.get(key)
        for key in [
            "pass_count",
            "total",
            "corr_p",
            "corr_u",
            "p_peak_amp_ratio",
            "u_peak_amp_ratio",
            "p_abs_delta_cells",
            "u_abs_delta_cells",
        ]
    },
}
print(json.dumps(summary, indent=2, sort_keys=True))

import json, math, statistics, os, time
from collections import Counter
path='autoresearch-results/acoustic_mp3_survivor_iter595_N50.jsonl'
rows=[]; bad=0
with open(path) as f:
    for line in f:
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1

def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stat(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    vals.sort(); return (len(vals), min(vals), statistics.median(vals), max(vals), sum(vals)/len(vals))
def fmt(s):
    if not s: return 'NA'
    return f'n={s[0]} min={s[1]:.6g} med={s[2]:.6g} max={s[3]:.6g} mean={s[4]:.6g}'
print('ROWS',len(rows),'BAD',bad)
print('ROW_TYPES',Counter(r.get('row_type') for r in rows))
for key in ['step','window','smooth_extrema_window','candidate_name','face_class']:
    c=Counter(r.get(key) for r in rows if key in r)
    if c: print('KEYCOUNT',key,c)
for key in ['mp3_survivor_active','acoustic_mp3_survivor_active','active','candidate_supported','all_gates_ok','highk_not_worse_ok','opposite_growth_ok','primitive_minmax_ok','characteristic_minmax_ok']:
    c=Counter(r.get(key) for r in rows if key in r)
    if c: print('COUNT',key,c)
for key in ['mp3_survivor_reject_reason','active_reject_reason','candidate_fallback_reason','candidate_unavailable_reason','missing_fields']:
    c=Counter(str(r.get(key)) for r in rows if key in r)
    if c: print('REASON',key,c)
for key in ['active_count','mp3_survivor_active_count','material_active_candidate_count','special_active_count','post_minmax_violation_count','post_opposite_violation_count','survivor_face_count','survivor_nonzero_delta_count','selected_candidate_count','fallback_count','rejected_minmax_count','rejected_characteristic_minmax_count','rejected_opposite_growth_count']:
    print(key,fmt(stat([r.get(key) for r in rows])))
for key in ['highk_preview_ratio_vs_current','candidate_face_delta_norm','opposite_characteristic_preview_vs_current','second_difference_preview_current','second_difference_preview_candidate']:
    print(key,fmt(stat([r.get(key) for r in rows])))
print('KEYS_SAMPLE')
for r in rows[:5]: print(sorted(r.keys()))
for p in ['autoresearch-results/pytest_mp3_survivor_iter595.log','autoresearch-results/acoustic_mp3_survivor_iter595_N50.log','autoresearch-results/acoustic_mp3_survivor_iter595_N50.jsonl','results/1D/07_B/diff_vs_exact.png']:
    if os.path.exists(p):
        st=os.stat(p)
        print('ARTIFACT',p,'size',st.st_size,'mtime',time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(st.st_mtime)))
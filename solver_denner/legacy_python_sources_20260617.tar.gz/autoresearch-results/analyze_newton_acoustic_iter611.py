import collections
import json
import math
import os
import re
import statistics
import sys
from pathlib import Path


ROOT = Path("/home/younglin90/work/claude_code/claudeCFD/solver_denner")


def finite(value):
    return isinstance(value, (int, float)) and math.isfinite(value)


def load_jsonl(path):
    rows = []
    bad = 0
    if not path.exists():
        return rows, 0, False
    with path.open() as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except Exception:
                bad += 1
    return rows, bad, True


def stats(rows, field):
    vals = [r[field] for r in rows if finite(r.get(field))]
    if not vals:
        return {"finite_count": 0, "missing_or_nonfinite": len(rows)}
    vals = sorted(vals)
    return {
        "finite_count": len(vals),
        "missing_or_nonfinite": len(rows) - len(vals),
        "min": vals[0],
        "median": statistics.median(vals),
        "max": vals[-1],
        "mean": sum(vals) / len(vals),
    }


def counts(rows, field):
    c = collections.Counter()
    for row in rows:
        value = row.get(field, "<missing>")
        if value is None:
            value = "<null>"
        c[str(value)] += 1
    return dict(c.most_common())


def parse_metrics(tag):
    log = ROOT / f"autoresearch-results/newton_acoustic_iter611_validator_{tag}.log"
    result = {"log_path": str(log), "exists": log.exists()}
    if not log.exists():
        return result
    text = log.read_text(errors="replace")
    metric = re.search(r"AUTORESEARCH_METRIC pass_count=(\d+) total=(\d+)", text)
    if metric:
        result["pass_count"] = int(metric.group(1))
        result["total"] = int(metric.group(2))
    details = re.search(r"DETAILS_JSON (\[.*\])", text)
    if details:
        try:
            parsed = json.loads(details.group(1))
            sub = parsed[0]["subcases"][0]
            for key in [
                "corr_p",
                "corr_u",
                "p_peak_amp_ratio",
                "u_peak_amp_ratio",
                "p_abs_delta_cells",
                "u_abs_delta_cells",
                "air_water_p_packet_shape_ok",
                "air_water_u_packet_shape_ok",
                "air_water_p_packet_secondary_extrema",
                "air_water_u_packet_secondary_extrema",
                "p_hf_ok",
                "hf_oscillation_ok",
            ]:
                result[key] = sub.get(key)
            result["wall"] = parsed[0].get("wall")
        except Exception as exc:
            result["details_error"] = str(exc)
    return result


def analyze(tag):
    audit_path = ROOT / f"autoresearch-results/newton_acoustic_iter611_validator_{tag}.jsonl"
    fast_path = ROOT / f"autoresearch-results/fast_packet_metrics_iter611_validator_{tag}.jsonl"
    rows, bad, exists = load_jsonl(audit_path)
    fast_rows, fast_bad, fast_exists = load_jsonl(fast_path)
    keys = sorted({key for row in rows for key in row})
    numeric_fields = [
        field
        for field in keys
        if any(finite(row.get(field)) for row in rows)
        and any(token in field.lower() for token in [
            "iter",
            "res",
            "norm",
            "corr",
            "correction",
            "acoustic",
            "packet",
            "opposite",
            "adx",
            "a_dx",
            "dx_b",
            "scale",
            "rel",
        ])
    ]
    return {
        "tag": tag,
        "audit_path": str(audit_path),
        "audit_exists": exists,
        "audit_size_bytes": audit_path.stat().st_size if exists else None,
        "audit_rows": len(rows),
        "audit_bad_json": bad,
        "fast_path": str(fast_path),
        "fast_exists": fast_exists,
        "fast_size_bytes": fast_path.stat().st_size if fast_exists else None,
        "fast_rows": len(fast_rows),
        "fast_bad_json": fast_bad,
        "row_type_counts": counts(rows, "row_type"),
        "stopping_reason_counts": counts(rows, "newton_stopping_reason"),
        "reason_counts_alt": counts(rows, "stopping_reason"),
        "measured_remainder_counts": {
            field: counts(rows, field)
            for field in keys
            if "measured_remainder" in field
        },
        "keys": keys,
        "numeric_stats": {field: stats(rows, field) for field in numeric_fields},
        "metrics": parse_metrics(tag),
        "fast_first_row": fast_rows[0] if fast_rows else None,
    }


tag = sys.argv[1] if len(sys.argv) > 1 else "N50"
analysis = analyze(tag)
out = ROOT / f"autoresearch-results/newton_acoustic_iter611_validator_{tag}_analysis.json"
out.write_text(json.dumps(analysis, indent=2, sort_keys=True))
print(json.dumps({
    "out": str(out),
    "audit_rows": analysis["audit_rows"],
    "audit_bad_json": analysis["audit_bad_json"],
    "fast_rows": analysis["fast_rows"],
    "row_type_counts": analysis["row_type_counts"],
    "stopping_reason_counts": analysis["stopping_reason_counts"],
    "reason_counts_alt": analysis["reason_counts_alt"],
    "measured_remainder_counts": analysis["measured_remainder_counts"],
    "metrics": analysis["metrics"],
    "numeric_stats": analysis["numeric_stats"],
}, indent=2, sort_keys=True))

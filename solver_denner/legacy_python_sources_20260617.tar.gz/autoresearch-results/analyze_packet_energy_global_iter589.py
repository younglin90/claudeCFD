import json, math, statistics
from pathlib import Path
from collections import Counter, defaultdict
p=Path('autoresearch-results/acoustic_packet_energy_global_iter589_N200.jsonl')
print('exists', p.exists(), 'size', p.stat().st_size if p.exists() else None)
rows=[]; bad=0
if p.exists():
    for line in p.open():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
print('rows', len(rows), 'bad', bad)
keys=sorted({k for r in rows for k in r.keys()})
print('global_keys', [k for k in keys if any(s in k.lower() for s in ['global','packet','energy','fraction','material','tail','group','centroid','width','opposite','partition','supported','missing','row_type','window'])][:900])
for key in ['row_type','step','group','window','energy_group','packet_group','packet_energy_global_supported','energy_supported','missing_fields','energy_missing_fields']:
    if any(key in r for r in rows): print('HIST', key, Counter(str(r.get(key)) for r in rows).most_common(120))
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
fields=[k for k in keys if any(s in k.lower() for s in ['e_total','e_wplus','e_wminus','fraction','material_side','tail','centroid','width','opposite','partition','global','energy'])]
print('FIELD_STATS')
for f in fields:
    s=stats([r.get(f) for r in rows]); null=sum(1 for r in rows if r.get(f) is None)
    if s or null < len(rows): print(f, s, 'null', null)
# determine group key
gkey='group' if any('group' in r for r in rows) else ('packet_group' if any('packet_group' in r for r in rows) else 'window')
for groupname, maker in [('step_group', lambda r:(r.get('step'), r.get(gkey))), ('group', lambda r:(r.get(gkey),)), ('step', lambda r:(r.get('step'),))]:
    print('GROUPS', groupname)
    groups=defaultdict(list)
    for r in rows: groups[maker(r)].append(r)
    for k,rs in sorted(groups.items(), key=lambda kv:str(kv[0]))[:300]:
        print('GROUP', k, 'n', len(rs), 'support', Counter(str(rr.get('packet_energy_global_supported', rr.get('energy_supported'))) for rr in rs).most_common(10), 'missing', Counter(str(rr.get('missing_fields', rr.get('energy_missing_fields'))) for rr in rs).most_common(10))
        for f in ['E_total','E_wplus','E_wminus','E_fraction_of_global','E_fraction_of_material_side','right_lobe_fraction_of_expanded','tail_energy_fraction','centroid','width','packet_centroid','packet_width_second_moment','opposite_energy_ratio','p_u_partition_ratio','global_E_total','global_E_wplus','global_E_wminus','material_side_E_total']:
            s=stats([rr.get(f) for rr in rs])
            if s: print(' ', f, s)
import json, math, statistics
from pathlib import Path
from collections import Counter, defaultdict
p=Path('autoresearch-results/acoustic_packet_energy_iter588_N200.jsonl')
print('exists', p.exists(), 'size', p.stat().st_size if p.exists() else None)
rows=[]; bad=0
if p.exists():
    for line in p.open():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
print('rows', len(rows), 'bad', bad)
keys=sorted({k for r in rows for k in r.keys()})
print('energy_keys', [k for k in keys if any(s in k.lower() for s in ['packet','energy','e_','wplus','wminus','opposite','partition','centroid','width','fraction','supported','missing','window','row_type'])][:700])
for key in ['row_type','step','window','face_class','packet_energy_supported','acoustic_packet_energy_supported','packet_energy_missing_fields','packet_energy_window','packet_energy_face_class']:
    if any(key in r for r in rows): print('HIST', key, Counter(str(r.get(key)) for r in rows).most_common(100))
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
fields=[k for k in keys if any(s in k.lower() for s in ['e_total','e_wplus','e_wminus','opposite_energy','partition','centroid','width','window_energy_fraction','energy_fraction','packet_energy','wplus_energy','wminus_energy'])]
print('FIELD_STATS')
for f in fields:
    s=stats([r.get(f) for r in rows]); null=sum(1 for r in rows if r.get(f) is None)
    if s or null < len(rows): print(f, s, 'null', null)
# group by step/window
for groupname, maker in [('step_window', lambda r:(r.get('step'), r.get('window'))), ('window', lambda r:(r.get('window'),)), ('step', lambda r:(r.get('step'),))]:
    print('GROUPS', groupname)
    groups=defaultdict(list)
    for r in rows: groups[maker(r)].append(r)
    for k,rs in sorted(groups.items(), key=lambda kv:str(kv[0]))[:200]:
        print('GROUP', k, 'n', len(rs), 'supported', Counter(str(rr.get('packet_energy_supported', rr.get('acoustic_packet_energy_supported'))) for rr in rs).most_common(10), 'missing', Counter(str(rr.get('packet_energy_missing_fields')) for rr in rs).most_common(10))
        for f in ['E_total','E_wplus','E_wminus','opposite_energy_ratio','p_u_partition_ratio','centroid','width','window_energy_fraction','packet_E_total','packet_E_wplus','packet_E_wminus','packet_opposite_energy_ratio','packet_p_u_partition_ratio','packet_centroid','packet_width','packet_window_energy_fraction','acoustic_packet_E_total','acoustic_packet_E_wplus','acoustic_packet_E_wminus','acoustic_packet_opposite_energy_ratio','acoustic_packet_p_u_partition_ratio','acoustic_packet_centroid','acoustic_packet_width','acoustic_packet_window_energy_fraction']:
            s=stats([rr.get(f) for rr in rs])
            if s: print(' ', f, s)
import json, math, statistics
from pathlib import Path
from collections import Counter, defaultdict
p=Path('autoresearch-results/pep_flux_targeted_iter580_N200.jsonl')
print('exists', p.exists(), 'size', p.stat().st_size if p.exists() else None)
rows=[]; bad=0
if p.exists():
    with p.open() as f:
        for line in f:
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                bad += 1
print('rows', len(rows), 'bad', bad)
for key in ['step','accepted_step','window','pep_window','row_type','face_class']:
    c=Counter(r.get(key) for r in rows)
    print('HIST', key, c.most_common(30))
keys=sorted({k for r in rows for k in r.keys()})
print('pep_keys', [k for k in keys if 'pep' in k.lower()][:250])
print('target_keys', [k for k in keys if 'target' in k.lower() or 'window' in k.lower()][:120])
for key in ['pep_flux_compat_audit_enabled','pep_candidate_supported','pep_candidate_source','pep_missing_reason','pep_flux_delta_alpha_missing_reason','pep_targeted_packet_audit','pep_targeted_packet_window','pep_targeted_packet_step']:
    if any(key in r for r in rows):
        print('HIST', key, Counter(r.get(key) for r in rows).most_common(30))
for groupkey in ['window','pep_window','material_jump','face_material_jump','pep_targeted_packet_window']:
    if any(groupkey in r for r in rows):
        d=defaultdict(Counter)
        for r in rows:
            d[r.get(groupkey)][r.get('pep_candidate_supported')] += 1
        print('SUPPORT_BY', groupkey, {k:dict(v) for k,v in d.items()})
fields=['pep_pressure_equilibrium_defect','pep_velocity_equilibrium_defect','pep_energy_compat_defect','pep_flux_delta_alpha','pep_flux_delta_rho','pep_flux_delta_rhoh','pep_flux_delta_rhou','pep_bound_ratio','pep_delta_bound_ratio','pep_F_alpha_candidate','pep_F_rho_candidate','pep_F_rhoh_candidate','pep_F_rhou_candidate']
def isnum(x):
    return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals:
        return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
print('GLOBAL_STATS')
for f in fields:
    s=stats([r.get(f) for r in rows])
    null=sum(1 for r in rows if r.get(f) is None)
    if s or null:
        print(f, s, 'null', null)
target={609,650,700,760,800,810}
for skey in ['step','accepted_step']:
    if any(r.get(skey) in target for r in rows):
        print('PER', skey)
        groups=defaultdict(list)
        for r in rows:
            if r.get(skey) in target:
                groups[(r.get(skey), r.get('window') or r.get('pep_window') or r.get('pep_targeted_packet_window'))].append(r)
        for k,rs in sorted(groups.items(), key=lambda x:(x[0][0], str(x[0][1]))):
            print('GROUP', k, 'n', len(rs), 'support', Counter(rr.get('pep_candidate_supported') for rr in rs), 'missing', Counter(rr.get('pep_missing_reason') for rr in rs).most_common(8))
            for f in ['pep_energy_compat_defect','pep_flux_delta_rhoh','pep_flux_delta_rhou','pep_pressure_equilibrium_defect','pep_velocity_equilibrium_defect','pep_bound_ratio','pep_delta_bound_ratio']:
                print(' ', f, stats([rr.get(f) for rr in rs]))
for mkey in ['material_jump','face_material_jump']:
    if any(mkey in r for r in rows):
        print('MAT_SPLIT', mkey)
        groups=defaultdict(list)
        for r in rows:
            groups[r.get(mkey)].append(r)
        for k,rs in groups.items():
            print(' ', k, 'n', len(rs), 'support', Counter(rr.get('pep_candidate_supported') for rr in rs), 'missing', Counter(rr.get('pep_missing_reason') for rr in rs).most_common(10))
            for f in ['pep_energy_compat_defect','pep_flux_delta_rhoh','pep_flux_delta_rhou','pep_bound_ratio','pep_delta_bound_ratio']:
                print('   ', f, stats([rr.get(f) for rr in rs]))
import json
from collections import Counter, defaultdict
rows=[json.loads(l) for l in open('autoresearch-results/pep_flux_targeted_iter580_N200.jsonl') if l.strip()]
for k in ['pep_aggregate','aggregate','is_aggregate','pep_targeted_packet_selected','pep_target_step','pep_target_window','pep_target_face_class']:
    print(k, Counter(r.get(k) for r in rows).most_common(20))
g=defaultdict(int)
for r in rows:
    if r.get('pep_aggregate') is True or r.get('pep_candidate_supported') is None:
        g[(r.get('step'),r.get('window'),r.get('pep_aggregate'))]+=1
print('aggregate_by_step_window')
for k,v in sorted(g.items(), key=lambda x:(x[0][0] or -1, str(x[0][1]), str(x[0][2]))):
    print(k,v)
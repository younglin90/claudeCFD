import json, math, statistics
from pathlib import Path
from collections import Counter, defaultdict
p=Path('autoresearch-results/pep_material_acid_iter581_N200.jsonl')
print('exists', p.exists(), 'size', p.stat().st_size if p.exists() else None)
rows=[]; bad=0
if p.exists():
    with p.open() as f:
        for line in f:
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                bad += 1
print('rows', len(rows), 'bad', bad)
keys=sorted({k for r in rows for k in r.keys()})
print('all_keys_count', len(keys))
print('material_keys', [k for k in keys if 'material' in k.lower() or 'acid' in k.lower() or 'carrier' in k.lower() or 'rhoh' in k.lower()][:300])
for key in ['step','window','pep_window','pep_aggregate','pep_targeted_packet_selected','pep_target_step','pep_target_window','material_jump','pep_material_jump','pep_material_supported','pep_material_missing_reason','pep_material_nonfinite_input_name','pep_candidate_supported','pep_missing_reason','pep_candidate_source','pep_material_branch','pep_material_acid_branch','pep_material_carrier_branch','pep_material_H_acid_branch','pep_H_acid_carrier_kind','pep_rhoh_carrier_kind','pep_alpha_face_source','pep_flux_delta_alpha_missing_reason']:
    if any(key in r for r in rows):
        print('HIST', key, Counter(r.get(key) for r in rows).most_common(40))
# support by step/window/material
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
fields=['rho_face_acid','H_acid_face','hacid_face','pep_rho_face_acid','pep_H_acid_face','pep_hacid_face','rhoh_face_candidate','pep_rhoh_face_candidate','F_rhoh_candidate','F_rhoh_prod','delta_F_rhoh_material','pep_F_rhoh_candidate','pep_F_rhoh_prod','pep_delta_F_rhoh_material','pep_energy_compat_defect','pep_flux_delta_rhoh','pep_bound_ratio','pep_pressure_equilibrium_defect','pep_velocity_equilibrium_defect']
print('GLOBAL_STATS')
for f in fields:
    s=stats([r.get(f) for r in rows])
    null=sum(1 for r in rows if r.get(f) is None)
    if s or null < len(rows): print(f, s, 'null', null)
# grouped stats
for groupname, maker in [
    ('step_window_mat', lambda r:(r.get('step'), r.get('window') or r.get('pep_window'), r.get('material_jump'))),
    ('step_window', lambda r:(r.get('step'), r.get('window') or r.get('pep_window'))),
    ('mat', lambda r:(r.get('material_jump'),)),
]:
    print('GROUPS', groupname)
    groups=defaultdict(list)
    for r in rows: groups[maker(r)].append(r)
    for k,rs in sorted(groups.items(), key=lambda kv: tuple(str(x) for x in kv[0])):
        print('GROUP', k, 'n', len(rs), 'pep_support', Counter(rr.get('pep_candidate_supported') for rr in rs), 'mat_support', Counter(rr.get('pep_material_supported') for rr in rs), 'missing', Counter(rr.get('pep_material_missing_reason') for rr in rs).most_common(8), 'nonfinite', Counter(rr.get('pep_material_nonfinite_input_name') for rr in rs).most_common(8))
        for f in ['pep_rho_face_acid','pep_H_acid_face','pep_rhoh_face_candidate','pep_F_rhoh_candidate','pep_F_rhoh_prod','pep_delta_F_rhoh_material','pep_energy_compat_defect','pep_bound_ratio']:
            s=stats([rr.get(f) for rr in rs])
            if s: print(' ', f, s)
# ratios to infer carrier scale
for fH in ['pep_H_acid_face','H_acid_face']:
    if any(isnum(r.get(fH)) for r in rows):
        vals=[]
        for r in rows:
            H=r.get(fH); rho=r.get('pep_rho_face_acid') or r.get('rho_face_acid'); rhoh=r.get('pep_rhoh_face_candidate') or r.get('rhoh_face_candidate')
            if isnum(H) and isnum(rho) and isnum(rhoh) and abs(H)>1e-300 and abs(rho)>1e-300:
                vals.append((rhoh/H, H/rho, rhoh/(rho*H) if abs(rho*H)>1e-300 else None))
        print('RATIO_FOR', fH, 'count', len(vals))
        for i,name in enumerate(['rhoh_over_H','H_over_rho','rhoh_over_rhoH']):
            print(' ', name, stats([v[i] for v in vals if v[i] is not None]))
# aggregate row counts
print('agg_count', sum(1 for r in rows if r.get('pep_aggregate') is True))
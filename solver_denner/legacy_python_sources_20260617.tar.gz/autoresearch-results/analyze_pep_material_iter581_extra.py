import json, math, statistics
from pathlib import Path
from collections import Counter, defaultdict
rows=[json.loads(l) for l in open('autoresearch-results/pep_material_acid_iter581_N200.jsonl') if l.strip()]
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    return {'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals),'mean':sum(vals)/len(vals)}
for key in ['material_carrier_branch','pep_material_missing_fields','material_missing_reason_counts','missing_H_acid_face','same_material','prod_material_jump','prod_flux_uses_acid_density']:
    if any(key in r for r in rows):
        print('HIST', key, Counter(str(r.get(key)) for r in rows).most_common(30))
fields=['rho_face_acid','H_acid_face','rhoh_face_candidate','F_rhoh_candidate','F_rhoh_prod','delta_F_rhoh_material','pep_F_rhoh_candidate','pep_flux_delta_rhoh','pep_bound_ratio']
for mat in [True, False]:
    rs=[r for r in rows if r.get('material_jump') is mat]
    print('MAT', mat, 'n', len(rs))
    for f in fields:
        print(f, stats([r.get(f) for r in rs]), 'null', sum(1 for r in rs if r.get(f) is None))
# direct candidate-prod diffs for material rows
rs=[r for r in rows if r.get('material_jump') is True]
d=[]
for r in rs:
    a=r.get('F_rhoh_candidate'); b=r.get('F_rhoh_prod')
    if isnum(a) and isnum(b): d.append(a-b)
print('material candidate_minus_prod direct', stats(d))
for key in [('step','window')]:
    groups=defaultdict(list)
    for r in rs: groups[(r.get('step'),r.get('window'))].append(r)
    for k,gr in sorted(groups.items()):
        print('MATGROUP', k, 'n', len(gr))
        for f in fields:
            print(' ', f, stats([r.get(f) for r in gr]))
PY
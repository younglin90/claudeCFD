﻿import json, math, os, statistics, collections, re
from pathlib import Path
base=Path('/home/younglin90/work/claude_code/claudeCFD/solver_denner')
jsonl=base/'autoresearch-results/pface_vector_iter599_N50.jsonl'
log=base/'autoresearch-results/pface_vector_iter599_N50.log'
rows=[]; bad=0
if jsonl.exists():
    with jsonl.open() as f:
        for line in f:
            line=line.strip()
            if not line: continue
            try: rows.append(json.loads(line))
            except Exception: bad+=1
size=jsonl.stat().st_size if jsonl.exists() else 0

def finite(x): return isinstance(x,(int,float)) and math.isfinite(x)
def vals(keys):
    out=[]
    for r in rows:
        for k in keys:
            if finite(r.get(k)):
                out.append(float(r[k])); break
    return out

def stat(keys):
    v=vals(keys)
    if not v: return None
    av=[abs(x) for x in v]
    return {'count':len(v),'max_abs':max(av),'median_abs':statistics.median(av),'min':min(v),'median':statistics.median(v),'max':max(v)}

keyset=collections.Counter()
for r in rows: keyset.update(r.keys())
row_types=collections.Counter(r.get('row_type','<missing>') for r in rows)
face_classes=collections.Counter(r.get('face_class','<missing>') for r in rows)
steps=sorted({r.get('step') for r in rows if isinstance(r.get('step'), int)})
# support-like fields
support_fields=[k for k in keyset if 'pface' in k.lower() and 'support' in k.lower()]
missing_fields=[k for k in keyset if 'missing' in k.lower() or 'reason' in k.lower() or 'blocker' in k.lower()]
field_counts={k:collections.Counter(str(r.get(k)) for r in rows) for k in support_fields[:30]}
# reason histograms
reason_hist=collections.Counter()
for r in rows:
    for k in missing_fields:
        v=r.get(k)
        if v in (None, '', [], {}):
            continue
        if isinstance(v, list):
            for item in v: reason_hist[f'{k}:{item}'] += 1
        else:
            reason_hist[f'{k}:{v}'] += 1
# candidate delta key discovery
delta_keys=[k for k in keyset if ('delta' in k.lower() or 'relerr' in k.lower() or 'rel_delta' in k.lower())]
coef_keys=[k for k in delta_keys if 'coef' in k.lower()]
corr_keys=[k for k in delta_keys if 'corr' in k.lower()]
final_keys=[k for k in delta_keys if any(s in k.lower() for s in ['final','contribution','pface'])]
# explicit likely keys first
stats={
 'coef': stat(['pface_coef_vector_coef_max_abs_delta','pface_vector_coef_max_abs_delta','pface_coef_max_abs_delta','coef_abs_delta','coef_delta']),
 'coef_rel': stat(['pface_coef_vector_coef_max_rel_delta','pface_vector_coef_max_rel_delta','pface_coef_max_rel_delta','coef_rel_delta','coef_relerr']),
 'corr': stat(['pface_coef_vector_corr_max_abs_delta','pface_vector_corr_max_abs_delta','pface_corr_max_abs_delta','corr_abs_delta','corr_delta']),
 'corr_rel': stat(['pface_coef_vector_corr_max_rel_delta','pface_vector_corr_max_rel_delta','pface_corr_max_rel_delta','corr_rel_delta','corr_relerr']),
 'final': stat(['pface_coef_vector_final_max_abs_delta','pface_vector_final_max_abs_delta','pface_final_contribution_abs_delta','pface_contribution_abs_delta','momentum_pressure_face_abs_delta','pface_abs_delta']),
 'final_rel': stat(['pface_coef_vector_final_max_rel_delta','pface_vector_final_max_rel_delta','pface_final_contribution_rel_delta','pface_contribution_rel_delta','momentum_pressure_face_rel_delta','pface_rel_delta']),
}
# stats for discovered delta keys individually
indiv={k:stat([k]) for k in sorted(delta_keys)[:200]}
# mismatch counts
mismatch_rows=[]
for i,r in enumerate(rows):
    maxd=0.0; found=False
    for k in delta_keys:
        if finite(r.get(k)):
            found=True; maxd=max(maxd, abs(float(r[k])))
    if found and maxd>1e-12:
        mismatch_rows.append((i,r.get('step'),r.get('face'),r.get('cell'),r.get('face_class'),maxd,r))
mismatch_by_class=collections.Counter(str(x[4]) for x in mismatch_rows)
first_mismatch=None
if mismatch_rows:
    i,step,face,cell,fc,maxd,r=mismatch_rows[0]
    reasons=[]
    for k in missing_fields:
        if r.get(k) not in (None,'',[],{}): reasons.append(f'{k}={r.get(k)}')
    first_mismatch={'idx':i,'step':step,'face':face,'cell':cell,'face_class':fc,'max_delta':maxd,'reasons':reasons[:8]}
# parse metrics from log
metric_line=''; details_line=''
if log.exists():
    text=log.read_text(errors='replace')
    for line in text.splitlines():
        if line.startswith('AUTORESEARCH_METRIC'): metric_line=line
        if line.startswith('DETAILS_JSON'): details_line=line
# png mtime
png=base/'results/1D/07_B/diff_vs_exact.png'
png_mtime=png.stat().st_mtime if png.exists() else None
out={
 'jsonl_exists':jsonl.exists(),'jsonl_size':size,'rows':len(rows),'bad_json':bad,
 'row_types':row_types,'face_classes':face_classes,'steps_first_last':(steps[:5], steps[-5:] if steps else []),
 'key_count':len(keyset),'sample_keys':sorted(keyset)[:80],
 'support_fields':support_fields,'support_counts':field_counts,
 'reason_hist_top':reason_hist.most_common(30),
 'delta_keys':sorted(delta_keys),
 'coef_keys':coef_keys,'corr_keys':corr_keys,'final_keys':final_keys,
 'stats':stats,'individual_delta_stats':indiv,
 'mismatch_count_gt_1e_12':len(mismatch_rows),'mismatch_by_class':mismatch_by_class,
 'first_mismatch':first_mismatch,'metric_line':metric_line,'details_line_prefix':details_line[:1000],
 'png_path':str(png),'png_mtime':png_mtime,
}
# Convert Counters for JSON
class Enc(json.JSONEncoder):
    def default(self,o):
        if isinstance(o, collections.Counter): return dict(o)
        return super().default(o)
print(json.dumps(out,cls=Enc,indent=2,sort_keys=True))

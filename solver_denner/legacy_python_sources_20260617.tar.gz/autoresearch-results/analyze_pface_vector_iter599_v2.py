﻿import json, math, statistics, collections, os
from pathlib import Path
base=Path('/home/younglin90/work/claude_code/claudeCFD/solver_denner')
files=[('requested',base/'autoresearch-results/pface_vector_iter599_N50.jsonl'),('steps1_5',base/'autoresearch-results/pface_vector_iter599_N50_steps1_5.jsonl')]

def parse(p):
    rows=[]; bad=0
    if p.exists():
        with p.open() as f:
            for line in f:
                line=line.strip()
                if not line: continue
                try: rows.append(json.loads(line))
                except Exception: bad+=1
    return rows,bad,(p.stat().st_size if p.exists() else 0)

def finite(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stats(rows,key):
    v=[float(r[key]) for r in rows if finite(r.get(key))]
    if not v: return None
    return {'count':len(v),'min':min(v),'median':statistics.median(v),'max':max(v)}

def analyze(label,p):
    rows,bad,size=parse(p)
    c=collections.Counter
    out={'path':str(p),'exists':p.exists(),'size':size,'rows':len(rows),'bad_json':bad}
    out['row_type_counts']=dict(c(r.get('row_type','<missing>') for r in rows))
    out['steps']=sorted(set(r.get('step_index') for r in rows if r.get('step_index') is not None))
    keys=set().union(*(r.keys() for r in rows)) if rows else set()
    out['keys']=sorted(keys)
    scalar_keys=['pface_vector_supported_count','pface_vector_unsupported_count','pface_vector_max_abs_delta_coef','pface_vector_median_abs_delta_coef','pface_vector_max_abs_delta_corr','pface_vector_median_abs_delta_corr','pface_vector_max_rel_delta_coef','pface_vector_max_rel_delta_corr','pface_vector_max_abs_delta_pressure_face','pface_vector_max_rel_delta_pressure_face','pface_vector_mismatch_count','pface_vector_mismatch_count_same_material_acoustic','pface_vector_mismatch_count_material','pface_vector_mismatch_count_boundary','pface_vector_mismatch_count_special_hllc']
    out['scalar_stats']={k:stats(rows,k) for k in scalar_keys if k in keys}
    out['unsupported_reasons']=dict(sum((c(r.get('pface_vector_unsupported_reason_counts',{})) for r in rows), c()))
    out['supported_branches']=dict(sum((c(r.get('pface_vector_supported_branch_counts',{})) for r in rows), c()))
    out['first_unsupported']=[]
    out['first_mismatch']=[]
    for r in rows:
        if r.get('pface_vector_first_unsupported_face') is not None:
            out['first_unsupported'].append({'step':r.get('step_index'),'face':r.get('pface_vector_first_unsupported_face'),'reason':r.get('pface_vector_first_unsupported_reason')})
        if r.get('pface_vector_first_mismatch_face') is not None:
            out['first_mismatch'].append({'step':r.get('step_index'),'face':r.get('pface_vector_first_mismatch_face'),'reason':r.get('pface_vector_first_mismatch_reason')})
    out['used_measured_remainder_count']=sum(1 for r in rows if r.get('pface_vector_used_measured_remainder'))
    return out
result={label:analyze(label,p) for label,p in files}
# parse metrics from both logs
for label, logname in [('requested','pface_vector_iter599_N50.log'),('steps1_5','pface_vector_iter599_N50_steps1_5.log')]:
    log=base/'autoresearch-results'/logname
    metric=''; details={}
    if log.exists():
        for line in log.read_text(errors='replace').splitlines():
            if line.startswith('AUTORESEARCH_METRIC'): metric=line
            if line.startswith('DETAILS_JSON'):
                arr=json.loads(line.split(' ',1)[1])
                sub=arr[0]['subcases'][0]
                details={k:sub.get(k) for k in ['corr_p','corr_u','p_peak_amp_ratio','u_peak_amp_ratio','p_abs_delta_cells','u_abs_delta_cells','p_packet_peak_amp_min','u_packet_peak_amp_min','air_water_p_packet_shape_ok','air_water_u_packet_shape_ok','air_water_p_packet_secondary_extrema','p_hf_ok','hf_oscillation_ok']}
                details['wall']=arr[0].get('wall')
    result[label+'_metric']={'metric':metric,'details':details}
png=base/'results/1D/07_B/diff_vs_exact.png'
result['png']={'path':str(png),'exists':png.exists(),'mtime':png.stat().st_mtime if png.exists() else None}
print(json.dumps(result,indent=2,sort_keys=True))

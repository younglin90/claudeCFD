import collections
import json
import math
import os
import re
import statistics
import sys


ROOT = "/home/younglin90/work/claude_code/claudeCFD/solver_denner"


def load_jsonl(path):
    rows = []
    bad = 0
    if not os.path.exists(path):
        return rows, bad
    with open(path) as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except Exception:
                bad += 1
    return rows, bad


def finite(value):
    return isinstance(value, (int, float)) and math.isfinite(value)


def count(rows, field):
    c = collections.Counter()
    for row in rows:
        value = row.get(field, "<missing>")
        if value is None:
            value = "<null>"
        c[str(value)] += 1
    return dict(c.most_common())


def stats(rows, field):
    vals = sorted([row[field] for row in rows if finite(row.get(field))])
    if not vals:
        return {"finite_count": 0, "missing_or_nonfinite": len(rows)}
    return {
        "finite_count": len(vals),
        "missing_or_nonfinite": len(rows) - len(vals),
        "min": vals[0],
        "median": statistics.median(vals),
        "mean": sum(vals) / len(vals),
        "max": vals[-1],
    }


def analyze(tag):
    audit = f"{ROOT}/autoresearch-results/pressure_compress_residual_preview_iter617_{tag}.jsonl"
    fast = f"{ROOT}/autoresearch-results/fast_packet_metrics_iter617_validator_{tag}.jsonl"
    log = f"{ROOT}/autoresearch-results/pressure_compress_residual_preview_iter617_{tag}.log"
    out = f"{ROOT}/autoresearch-results/pressure_compress_residual_preview_iter617_{tag}_analysis.json"
    rows, bad = load_jsonl(audit)
    fast_rows, fast_bad = load_jsonl(fast)
    keys = sorted({key for row in rows for key in row})
    interesting = [
        key
        for key in keys
        if any(
            token in key.lower()
            for token in [
                "residual",
                "preview",
                "compress",
                "delta",
                "ratio",
                "rhs",
                "separ",
                "support",
                "missing",
                "fallback",
                "step",
                "window",
                "class",
                "material",
                "packet",
                "scale",
                "jac",
                "coef",
            ]
        )
    ]
    text = open(log, errors="replace").read() if os.path.exists(log) else ""
    metric_match = re.search(r"AUTORESEARCH_METRIC pass_count=(\d+) total=(\d+)", text)
    analysis = {
        "audit_path": audit,
        "audit_exists": os.path.exists(audit),
        "audit_size_bytes": os.path.getsize(audit) if os.path.exists(audit) else None,
        "audit_rows": len(rows),
        "audit_bad_json": bad,
        "fast_path": fast,
        "fast_rows": len(fast_rows),
        "fast_bad_json": fast_bad,
        "keys": keys,
        "row_type_counts": count(rows, "row_type"),
        "counts": {field: count(rows, field) for field in interesting},
        "stats": {
            field: stats(rows, field)
            for field in interesting
            if any(finite(row.get(field)) for row in rows)
        },
        "fast_first_row": fast_rows[0] if fast_rows else None,
        "pass_metric": {
            "pass_count": int(metric_match.group(1)) if metric_match else None,
            "total": int(metric_match.group(2)) if metric_match else None,
        },
    }
    with open(out, "w") as f:
        json.dump(analysis, f, indent=2, sort_keys=True)
    summary_stats = {
        key: value
        for key, value in analysis["stats"].items()
        if any(token in key.lower() for token in ["delta", "ratio", "scale", "residual", "jac", "coef"])
    }
    summary = {
        "out": out,
        "audit_rows": len(rows),
        "audit_bad_json": bad,
        "row_type_counts": analysis["row_type_counts"],
        "fast_metrics": {
            key: (fast_rows[0].get(key) if fast_rows else None)
            for key in [
                "corr_p",
                "corr_u",
                "p_peak_amp_ratio",
                "u_peak_amp_ratio",
                "p_abs_delta_cells",
                "u_abs_delta_cells",
            ]
        },
        "coverage_counts": {
            key: analysis["counts"].get(key)
            for key in ["step", "window", "face_class", "pressure_compressibility_residual_window", "pressure_compressibility_residual_face_class"]
            if key in analysis["counts"]
        },
        "support_counts": {
            key: analysis["counts"].get(key)
            for key in interesting
            if any(token in key.lower() for token in ["support", "missing", "fallback", "separ"])
        },
        "selected_stats": summary_stats,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))
    return analysis


if __name__ == "__main__":
    analyze(sys.argv[1] if len(sys.argv) > 1 else "N50")

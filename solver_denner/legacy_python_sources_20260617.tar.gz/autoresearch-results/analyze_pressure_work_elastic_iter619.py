import collections
import json
import math
import os
import re
import statistics


ROOT = "/home/younglin90/work/claude_code/claudeCFD/solver_denner"
AUDIT = f"{ROOT}/autoresearch-results/pressure_work_elastic_iter619_N200.jsonl"
FAST = f"{ROOT}/autoresearch-results/fast_packet_metrics_iter619_validator_N200.jsonl"
LOG = f"{ROOT}/autoresearch-results/pressure_work_elastic_iter619_N200.log"
OUT = f"{ROOT}/autoresearch-results/pressure_work_elastic_iter619_N200_analysis.json"


def load_jsonl(path):
    rows = []
    bad = 0
    if not os.path.exists(path):
        return rows, bad
    with open(path) as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except Exception:
                bad += 1
    return rows, bad


def finite(value):
    return isinstance(value, (int, float)) and math.isfinite(value)


def count(rows, field):
    c = collections.Counter()
    for row in rows:
        value = row.get(field, "<missing>")
        if value is None:
            value = "<null>"
        c[str(value)] += 1
    return dict(c.most_common())


def stats(rows, field):
    vals = sorted([row[field] for row in rows if finite(row.get(field))])
    if not vals:
        return {"finite_count": 0, "missing_or_nonfinite": len(rows)}
    return {
        "finite_count": len(vals),
        "missing_or_nonfinite": len(rows) - len(vals),
        "min": vals[0],
        "median": statistics.median(vals),
        "mean": sum(vals) / len(vals),
        "max": vals[-1],
    }


rows, bad = load_jsonl(AUDIT)
fast_rows, fast_bad = load_jsonl(FAST)
keys = sorted({key for row in rows for key in row})
interesting = [
    key
    for key in keys
    if any(
        token in key.lower()
        for token in [
            "elastic",
            "pressure_work",
            "pwork",
            "defect",
            "ratio",
            "alignment",
            "wplus",
            "temporal",
            "energy",
            "residual",
            "support",
            "missing",
            "fallback",
            "step",
            "window",
            "class",
            "material",
            "packet",
            "scale",
        ]
    )
]

text = open(LOG, errors="replace").read() if os.path.exists(LOG) else ""
metric_match = re.search(r"AUTORESEARCH_METRIC pass_count=(\d+) total=(\d+)", text)
analysis = {
    "audit_path": AUDIT,
    "audit_exists": os.path.exists(AUDIT),
    "audit_size_bytes": os.path.getsize(AUDIT) if os.path.exists(AUDIT) else None,
    "audit_rows": len(rows),
    "audit_bad_json": bad,
    "cap_config": 4096,
    "cap_hit": len(rows) >= 4096,
    "fast_path": FAST,
    "fast_rows": len(fast_rows),
    "fast_bad_json": fast_bad,
    "keys": keys,
    "row_type_counts": count(rows, "row_type"),
    "counts": {field: count(rows, field) for field in interesting},
    "stats": {
        field: stats(rows, field)
        for field in interesting
        if any(finite(row.get(field)) for row in rows)
    },
    "fast_first_row": fast_rows[0] if fast_rows else None,
    "pass_metric": {
        "pass_count": int(metric_match.group(1)) if metric_match else None,
        "total": int(metric_match.group(2)) if metric_match else None,
    },
}
with open(OUT, "w") as f:
    json.dump(analysis, f, indent=2, sort_keys=True)

summary = {
    "out": OUT,
    "audit_rows": len(rows),
    "audit_bad_json": bad,
    "cap_hit": analysis["cap_hit"],
    "row_type_counts": analysis["row_type_counts"],
    "fast_metrics": {
        key: (fast_rows[0].get(key) if fast_rows else None)
        for key in [
            "corr_p",
            "corr_u",
            "p_peak_amp_ratio",
            "u_peak_amp_ratio",
            "p_abs_delta_cells",
            "u_abs_delta_cells",
        ]
    },
    "coverage_counts": {
        key: analysis["counts"].get(key)
        for key in ["step", "window", "face_class", "pressure_work_elastic_window", "pressure_work_elastic_face_class"]
        if key in analysis["counts"]
    },
    "support_counts": {
        key: analysis["counts"].get(key)
        for key in interesting
        if any(token in key.lower() for token in ["support", "missing", "fallback"])
    },
    "selected_stats": {
        key: value
        for key, value in analysis["stats"].items()
        if any(token in key.lower() for token in ["defect", "ratio", "alignment", "elastic", "pressure_work", "pwork"])
    },
}
print(json.dumps(summary, indent=2, sort_keys=True))

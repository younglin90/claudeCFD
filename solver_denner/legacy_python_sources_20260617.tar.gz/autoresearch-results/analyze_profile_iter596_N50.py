import json, math, statistics, os, time
from collections import Counter, defaultdict
path='autoresearch-results/assembly_profile_iter596_N50.jsonl'
rows=[]; bad=0
if os.path.exists(path):
    with open(path) as f:
        for line in f:
            if not line.strip(): continue
            try: rows.append(json.loads(line))
            except Exception: bad += 1
print('ROWS',len(rows),'BAD',bad)
print('ROW_TYPES',Counter(r.get('row_type') for r in rows))
print('KEYS_SAMPLE')
for r in rows[:3]: print(sorted(r.keys()))
# accumulate any numeric time-like fields by key and category fields
for key in ['category','name','section','phase','timer','label','assembly_profile_section']:
    c=Counter(r.get(key) for r in rows if key in r)
    if c: print('KEYCOUNT',key,c)
# print all rows if small; else aggregate numeric fields
numkeys=defaultdict(list)
for r in rows:
    for k,v in r.items():
        if isinstance(v,(int,float)) and math.isfinite(v):
            numkeys[k].append(float(v))
print('NUMERIC_FIELDS')
for k,vals in sorted(numkeys.items()):
    vals.sort()
    print(k,'n',len(vals),'min',vals[0],'median',statistics.median(vals),'max',vals[-1],'sum',sum(vals))
print('ROWS_HEAD')
for r in rows[:20]: print(r)
for p in ['autoresearch-results/assembly_profile_iter596_N50.jsonl','autoresearch-results/assembly_profile_iter596_N50.log','results/1D/07_B/diff_vs_exact.png']:
    if os.path.exists(p):
        st=os.stat(p)
        print('ARTIFACT',p,'size',st.st_size,'mtime',time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(st.st_mtime)))
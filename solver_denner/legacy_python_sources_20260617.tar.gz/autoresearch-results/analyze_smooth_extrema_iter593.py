import json, math, statistics, os, time
from collections import Counter, defaultdict
path='autoresearch-results/acoustic_smooth_extrema_iter593_N200.jsonl'
rows=[]; bad=0
with open(path) as f:
    for line in f:
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1

def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stat(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    vals.sort()
    return {'n':len(vals),'min':vals[0],'med':statistics.median(vals),'max':vals[-1],'mean':sum(vals)/len(vals)}
def fmt(s):
    if s is None: return 'NA'
    return f"n={s['n']} min={s['min']:.6g} med={s['med']:.6g} max={s['max']:.6g} mean={s['mean']:.6g}"
print('ROWS',len(rows),'BAD',bad)
print('ROW_TYPES',Counter(r.get('row_type') for r in rows))
for key in ['step','window','candidate','candidate_kind','face_class','smooth_extrema_window','smooth_extrema_candidate','smooth_extrema_group']:
    c=Counter(r.get(key) for r in rows if key in r)
    if c: print('KEYCOUNT',key,c)
for key in ['candidate_supported','smooth_extrema_supported','weno_z3_supported','candidate_admissible','smooth_extrema_admissible','candidate_fallback','material_fallback','minmax_ok','minmax_failed','post_minmax_violation']:
    c=Counter(r.get(key) for r in rows if key in r)
    if c: print('COUNT',key,c)
for key in ['missing_fields','fallback_reason','reject_reason','candidate_reject_reason','smooth_extrema_reject_reason']:
    c=Counter(str(r.get(key)) for r in rows if key in r)
    if c: print('REASON',key,c)
fields=['highk_preview_ratio_vs_current','highk_ratio_vs_current','second_difference_current','second_difference_candidate','second_difference_ratio','opposite_preview_ratio','opposite_characteristic_preview','candidate_delta_norm','candidate_face_delta_norm','candidate_delta_p','candidate_delta_u','candidate_delta_T','local_BV','smooth_extrema_delta_norm']
print('FIELD_STATS')
for f in fields:
    s=stat([r.get(f) for r in rows])
    if s: print(f,fmt(s))
# by candidate/window/step if keys exist
cand_key = next((k for k in ['candidate','smooth_extrema_candidate','candidate_kind'] if any(k in r for r in rows)), None)
win_key = next((k for k in ['window','smooth_extrema_window','smooth_extrema_group'] if any(k in r for r in rows)), None)
print('CAND_KEY',cand_key,'WIN_KEY',win_key)
if cand_key or win_key:
    print('BY_CAND_WINDOW_STEP')
    buckets=defaultdict(list)
    for r in rows:
        buckets[(r.get('step'), r.get(win_key) if win_key else None, r.get(cand_key) if cand_key else None)].append(r)
    for key in sorted(buckets, key=lambda x: (str(x[0]), str(x[1]), str(x[2]))):
        rs=buckets[key]
        print('BUCKET',key,'n',len(rs), 'supported', Counter(r.get('candidate_supported', r.get('smooth_extrema_supported')) for r in rs), 'admissible', Counter(r.get('candidate_admissible', r.get('smooth_extrema_admissible')) for r in rs))
        for f in fields[:8]:
            s=stat([r.get(f) for r in rs])
            if s: print(' FIELD',f,fmt(s))
print('KEYS_SAMPLE')
for r in rows[:5]: print(sorted(r.keys()))
for p in ['autoresearch-results/pytest_smooth_extrema_iter593.log','autoresearch-results/acoustic_smooth_extrema_iter593_N200.log','autoresearch-results/acoustic_smooth_extrema_iter593_N200.jsonl','results/1D/07_B/diff_vs_exact.png']:
    st=os.stat(p)
    print('ARTIFACT',p,'size',st.st_size,'mtime',time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(st.st_mtime)))
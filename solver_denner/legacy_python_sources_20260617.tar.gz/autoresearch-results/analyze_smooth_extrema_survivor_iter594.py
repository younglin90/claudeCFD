import json, math, statistics, os, time
from collections import Counter, defaultdict
path='autoresearch-results/acoustic_smooth_extrema_survivor_iter594_N200.jsonl'
rows=[]; bad=0
with open(path) as f:
    for line in f:
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1

def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stat(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    vals.sort(); return (len(vals), min(vals), statistics.median(vals), max(vals), sum(vals)/len(vals))
def fmt(s):
    if not s: return 'NA'
    return f'n={s[0]} min={s[1]:.6g} med={s[2]:.6g} max={s[3]:.6g} mean={s[4]:.6g}'
print('ROWS',len(rows),'BAD',bad)
print('ROW_TYPES',Counter(r.get('row_type') for r in rows))
for key in ['step','window','smooth_extrema_window','candidate_name','candidate','face_class']:
    c=Counter(r.get(key) for r in rows if key in r)
    if c: print('KEYCOUNT',key,c)
for key in ['candidate_supported','all_gates_ok','highk_not_worse_ok','opposite_growth_ok','primitive_minmax_ok','characteristic_minmax_ok','candidate_available']:
    c=Counter(r.get(key) for r in rows if key in r)
    if c: print('COUNT',key,c)
for key in ['candidate_unavailable_reason','unavailable_reason','candidate_fallback_reason','reject_reason','missing_fields']:
    c=Counter(str(r.get(key)) for r in rows if key in r)
    if c: print('REASON',key,c)
for key in ['survivor_face_count','survivor_nonzero_delta_count','selected_candidate_count','supported_count','fallback_count','material_active_candidate_count','rejected_minmax_count','rejected_characteristic_minmax_count','rejected_opposite_growth_count','rejected_highk_count','rejected_nonfinite_count']:
    print(key, fmt(stat([r.get(key) for r in rows])))
for key in ['highk_preview_ratio_vs_current','opposite_characteristic_preview_vs_current','opposite_preview_ratio','candidate_face_delta_norm','candidate_delta_norm','second_difference_preview_current','second_difference_preview_candidate']:
    print(key, fmt(stat([r.get(key) for r in rows])))
print('BY_CAND_WINDOW')
for cand in sorted(set(r.get('candidate_name') for r in rows)):
    for win in sorted(set(r.get('window') for r in rows)):
        rs=[r for r in rows if r.get('candidate_name')==cand and r.get('window')==win]
        if not rs: continue
        print('BUCKET',cand,win,'n',len(rs),'support',Counter(r.get('candidate_supported') for r in rs),'all',Counter(r.get('all_gates_ok') for r in rs),'highk',Counter(r.get('highk_not_worse_ok') for r in rs),'opp',Counter(r.get('opposite_growth_ok') for r in rs),'unavail',Counter(str(r.get('candidate_unavailable_reason')) for r in rs))
        for key in ['survivor_face_count','survivor_nonzero_delta_count','highk_preview_ratio_vs_current','opposite_characteristic_preview_vs_current','candidate_face_delta_norm']:
            print(' FIELD',key,fmt(stat([r.get(key) for r in rs])))
print('BY_STEP_WINDOW_CAND')
for step in [609,650,700,760,800,810]:
    for win in sorted(set(r.get('window') for r in rows)):
        for cand in sorted(set(r.get('candidate_name') for r in rows)):
            rs=[r for r in rows if r.get('step')==step and r.get('window')==win and r.get('candidate_name')==cand]
            if not rs: continue
            print('BUCKET',step,win,cand,'n',len(rs),'all',Counter(r.get('all_gates_ok') for r in rs),'surv',fmt(stat([r.get('survivor_face_count') for r in rs])),'nonzero',fmt(stat([r.get('survivor_nonzero_delta_count') for r in rs])),'highk',fmt(stat([r.get('highk_preview_ratio_vs_current') for r in rs])),'delta',fmt(stat([r.get('candidate_face_delta_norm') for r in rs])))
print('KEYS_SAMPLE')
for r in rows[:5]: print(sorted(r.keys()))
for p in ['autoresearch-results/pytest_smooth_extrema_survivor_iter594.log','autoresearch-results/acoustic_smooth_extrema_survivor_iter594_N200.log','autoresearch-results/acoustic_smooth_extrema_survivor_iter594_N200.jsonl','results/1D/07_B/diff_vs_exact.png']:
    st=os.stat(p)
    print('ARTIFACT',p,'size',st.st_size,'mtime',time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(st.st_mtime)))
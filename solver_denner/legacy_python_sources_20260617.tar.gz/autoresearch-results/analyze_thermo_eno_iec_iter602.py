﻿import json, math, statistics, collections
from pathlib import Path
from datetime import datetime
base=Path('/home/younglin90/work/claude_code/claudeCFD/solver_denner')
p=base/'autoresearch-results/thermo_eno_iec_iter602_N200.jsonl'
rows=[]; bad=0
if p.exists():
    for line in p.read_text(errors='replace').splitlines():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
keys=set().union(*(r.keys() for r in rows)) if rows else set()

def finite(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stat_for(patterns):
    out={}
    for k in sorted(keys):
        lk=k.lower()
        if any(pat in lk for pat in patterns):
            vals=[float(r[k]) for r in rows if finite(r.get(k))]
            if vals:
                out[k]={'count':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals)}
    return out
out={
 'jsonl_exists':p.exists(), 'jsonl_size':p.stat().st_size if p.exists() else 0,
 'rows':len(rows), 'bad_json':bad,
 'row_types':dict(collections.Counter(r.get('row_type','<missing>') for r in rows)),
 'steps':sorted(set(r.get('step') or r.get('step_index') for r in rows if (r.get('step') or r.get('step_index')) is not None)),
 'windows':dict(collections.Counter(str(r.get('window') or r.get('group') or r.get('window_name') or '<missing>') for r in rows)),
 'face_classes':dict(collections.Counter(str(r.get('face_class') or '<missing>') for r in rows)),
 'support_keys':sorted([k for k in keys if 'support' in k.lower() or 'fallback' in k.lower() or 'reason' in k.lower() or 'missing' in k.lower()])[:120],
 'support_counts':{},
 'delta_stats':stat_for(['delta','defect','highk','rhoh','rho','h_acid','temp','pressure','eos']),
 'sample_rows':rows[:3],
}
for k in out['support_keys']:
    vals=[]
    for r in rows:
        if k in r:
            v=r.get(k)
            if isinstance(v, (list,dict)): v=json.dumps(v, sort_keys=True)
            vals.append(str(v))
    if vals:
        out['support_counts'][k]=dict(collections.Counter(vals).most_common(20))
# logs
log=base/'autoresearch-results/thermo_eno_iec_iter602_N200.log'
out['log_exists']=log.exists()
if log.exists():
    text=log.read_text(errors='replace')
    out['nameerror_H_acid_face']='H_acid_face' in text
    for line in text.splitlines():
        if line.startswith('AUTORESEARCH_METRIC'): out['metric']=line
        if line.startswith('DETAILS_JSON'):
            out['details_prefix']=line[:1200]
png=base/'results/1D/07_B/diff_vs_exact.png'
out['png']={'exists':png.exists(),'mtime':datetime.fromtimestamp(png.stat().st_mtime).isoformat() if png.exists() else None,'path':str(png)}
print(json.dumps(out, indent=2, sort_keys=True))

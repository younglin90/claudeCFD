﻿import json, math, statistics, collections
from pathlib import Path
base=Path('/home/younglin90/work/claude_code/claudeCFD/solver_denner')
p=base/'autoresearch-results/thermo_eno_iec_iter602_fix_N50.jsonl'
rows=[]; bad=0
if p.exists():
    for line in p.read_text(errors='replace').splitlines():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad+=1
keys=set().union(*(r.keys() for r in rows)) if rows else set()

def finite(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stat_keys(patterns):
    out={}
    for k in sorted(keys):
        lk=k.lower()
        if any(p in lk for p in patterns):
            v=[float(r[k]) for r in rows if finite(r.get(k))]
            if v: out[k]={'count':len(v),'min':min(v),'median':statistics.median(v),'max':max(v)}
    return out
out={
 'exists':p.exists(),'size':p.stat().st_size if p.exists() else 0,'rows':len(rows),'bad_json':bad,
 'row_types':dict(collections.Counter(r.get('row_type','<missing>') for r in rows)),
 'steps':sorted(set(r.get('step') or r.get('step_index') for r in rows if (r.get('step') or r.get('step_index')) is not None)),
 'windows':dict(collections.Counter(str(r.get('window') or r.get('window_name') or r.get('group') or '<missing>') for r in rows)),
 'face_classes':dict(collections.Counter(str(r.get('face_class') or '<missing>') for r in rows)),
 'support_keys':sorted([k for k in keys if any(s in k.lower() for s in ['support','fallback','reason','missing','admiss','violation'])]),
 'support_counts':{},
 'stats':stat_keys(['delta','defect','highk','rhoh','rho','h_acid','temp','pressure','eos','candidate']),
 'sample':rows[:2],
}
for k in out['support_keys']:
    vals=[]
    for r in rows:
        if k in r:
            v=r.get(k)
            if isinstance(v,(list,dict)): v=json.dumps(v,sort_keys=True)
            vals.append(str(v))
    if vals: out['support_counts'][k]=dict(collections.Counter(vals).most_common(30))
log=base/'autoresearch-results/thermo_eno_iec_iter602_fix_N50.log'
if log.exists():
    text=log.read_text(errors='replace')
    out['nameerror']=('NameError' in text or 'H_acid_face' in text)
    for line in text.splitlines():
        if line.startswith('AUTORESEARCH_METRIC'): out['metric']=line
        if line.startswith('DETAILS_JSON'):
            arr=json.loads(line.split(' ',1)[1]); sub=arr[0]['subcases'][0]
            out['wall']=arr[0].get('wall')
            out['metrics']={k:sub.get(k) for k in ['corr_p','corr_u','p_peak_amp_ratio','u_peak_amp_ratio','p_abs_delta_cells','u_abs_delta_cells','air_water_p_packet_shape_ok','air_water_u_packet_shape_ok','air_water_p_packet_secondary_extrema','p_hf_ok','hf_oscillation_ok']}
print(json.dumps(out,indent=2,sort_keys=True))

﻿import json, math, statistics, collections
from pathlib import Path
from datetime import datetime
base=Path('/home/younglin90/work/claude_code/claudeCFD/solver_denner')
p=base/'autoresearch-results/thermo_eno_iec_iter603_N200.jsonl'
rows=[]; bad=0
if p.exists():
    for line in p.read_text(errors='replace').splitlines():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
keys=set().union(*(r.keys() for r in rows)) if rows else set()

def finite(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stat(vals):
    vals=[float(v) for v in vals if finite(v)]
    if not vals: return None
    return {'count':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals)}
def stat_key(k, filt=lambda r: True): return stat([r.get(k) for r in rows if filt(r)])
def group_stats(group_key, stat_keys):
    out={}
    groups=collections.defaultdict(list)
    for r in rows:
        groups[str(r.get(group_key,'<missing>'))].append(r)
    for g,rs in groups.items():
        out[g]={k:stat([r.get(k) for r in rs]) for k in stat_keys if k in keys}
        out[g]['count']=len(rs)
    return out
support_keys=[k for k in keys if any(s in k.lower() for s in ['support','fallback','reason','missing','admiss','violation','source'])]
support_counts={}
for k in sorted(support_keys):
    vals=[]
    for r in rows:
        if k in r:
            v=r.get(k)
            if isinstance(v,(list,dict)): v=json.dumps(v,sort_keys=True)
            vals.append(str(v))
    if vals: support_counts[k]=dict(collections.Counter(vals).most_common(50))
stat_keys=['delta_rho_face','median_delta_rho_face','delta_H_face','median_delta_H_face','delta_rhoh_face','median_delta_rhoh_face','pressure_equilibrium_defect_preview','temperature_eos_consistency_defect','highk_localization_preview_ratio_vs_current','primitive_admissible_count','thermo_admissible_count','boundedness_minmax_violation','current_rho_face_acid','current_H_acid_face','rho_face_candidate','H_face_candidate','rhoh_face_candidate','T_face_candidate','p_face_candidate']
out={
 'exists':p.exists(),'size':p.stat().st_size if p.exists() else 0,'rows':len(rows),'bad_json':bad,
 'row_types':dict(collections.Counter(r.get('row_type','<missing>') for r in rows)),
 'steps':sorted(set(r.get('step') or r.get('step_index') for r in rows if (r.get('step') or r.get('step_index')) is not None)),
 'windows':dict(collections.Counter(str(r.get('window') or r.get('thermo_window') or '<missing>') for r in rows)),
 'face_classes':dict(collections.Counter(str(r.get('thermo_face_class') or r.get('face_class') or '<missing>') for r in rows)),
 'support_counts':support_counts,
 'overall_stats':{k:stat_key(k) for k in stat_keys if k in keys},
 'by_window':group_stats('thermo_window', stat_keys),
 'by_face_class':group_stats('thermo_face_class', stat_keys),
 'by_step':group_stats('step', stat_keys),
 'nonzero_counts':{},
 'sample_supported':[r for r in rows if r.get('thermo_candidate_supported')][:3],
 'sample_fallback':[r for r in rows if not r.get('thermo_candidate_supported')][:3],
}
for k in ['delta_rho_face','delta_H_face','delta_rhoh_face','median_delta_rho_face','median_delta_H_face','median_delta_rhoh_face']:
    if k in keys:
        out['nonzero_counts'][k]=sum(1 for r in rows if finite(r.get(k)) and abs(float(r[k]))>1e-14)
# logs
log=base/'autoresearch-results/thermo_eno_iec_iter603_N200.log'
if log.exists():
    text=log.read_text(errors='replace')
    out['nameerror']='NameError' in text or 'H_acid_face' in text
    for line in text.splitlines():
        if line.startswith('AUTORESEARCH_METRIC'): out['metric']=line
        if line.startswith('DETAILS_JSON'):
            arr=json.loads(line.split(' ',1)[1]); sub=arr[0]['subcases'][0]
            out['wall']=arr[0].get('wall')
            out['metrics']={k:sub.get(k) for k in ['corr_p','corr_u','p_peak_amp_ratio','u_peak_amp_ratio','p_abs_delta_cells','u_abs_delta_cells','air_water_p_packet_shape_ok','air_water_u_packet_shape_ok','air_water_p_packet_secondary_extrema','air_water_u_packet_secondary_extrema','air_water_p_packet_min_corr','air_water_u_packet_min_corr','p_smooth_local_tv_excess','u_smooth_local_tv_excess','p_hf_ok','hf_oscillation_ok']}
png=base/'results/1D/07_B/diff_vs_exact.png'
out['png']={'exists':png.exists(),'path':str(png),'mtime':datetime.fromtimestamp(png.stat().st_mtime).isoformat() if png.exists() else None}
print(json.dumps(out,indent=2,sort_keys=True))

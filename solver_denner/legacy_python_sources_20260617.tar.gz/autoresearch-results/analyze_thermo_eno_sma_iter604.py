﻿import json, math, statistics, collections
from pathlib import Path
from datetime import datetime
base=Path('/home/younglin90/work/claude_code/claudeCFD/solver_denner')
p=base/'autoresearch-results/thermo_eno_sma_iter604_N50.jsonl'
rows=[]; bad=0
if p.exists():
    for line in p.read_text(errors='replace').splitlines():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
keys=set().union(*(r.keys() for r in rows)) if rows else set()

def finite(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stat(vals):
    vals=[float(v) for v in vals if finite(v)]
    if not vals: return None
    return {'count':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals)}
def stat_key(k): return stat([r.get(k) for r in rows])
interesting=[k for k in sorted(keys) if any(s in k.lower() for s in ['thermo','active','fallback','material','boundary','special','violation','highk','delta','support','admiss','reason','post','candidate','rho','h_face','rhoh','source'])]
counts={}
for k in interesting:
    vals=[]
    for r in rows:
        if k in r:
            v=r.get(k)
            if isinstance(v,(list,dict)): v=json.dumps(v,sort_keys=True)
            vals.append(str(v))
    if vals and (len(set(vals)) <= 50):
        counts[k]=dict(collections.Counter(vals).most_common(50))
stats={k:stat_key(k) for k in interesting if any(s in k.lower() for s in ['count','delta','highk','violation','active','fallback','support','admiss'])}
# metrics
log=base/'autoresearch-results/thermo_eno_sma_iter604_N50.log'
logout={}
if log.exists():
    text=log.read_text(errors='replace')
    logout['nameerror']='NameError' in text or 'Traceback' in text
    for line in text.splitlines():
        if line.startswith('AUTORESEARCH_METRIC'): logout['metric']=line
        if line.startswith('DETAILS_JSON'):
            arr=json.loads(line.split(' ',1)[1]); sub=arr[0]['subcases'][0]
            logout['wall']=arr[0].get('wall')
            fields=['corr_p','corr_u','p_peak_amp_ratio','u_peak_amp_ratio','p_abs_delta_cells','u_abs_delta_cells','air_water_p_packet_shape_ok','air_water_u_packet_shape_ok','air_water_p_packet_secondary_extrema','air_water_u_packet_secondary_extrema','p_hf_ok','hf_oscillation_ok','p_sharp_overshoot','p_sharp_turns','u_sharp_overshoot','u_sharp_turns','p_smooth_local_tv_excess','u_smooth_local_tv_excess','air_water_p_packet_min_corr','air_water_u_packet_min_corr']
            logout['metrics']={k:sub.get(k) for k in fields}
png=base/'results/1D/07_B/diff_vs_exact.png'
out={
 'jsonl_exists':p.exists(),'jsonl_size':p.stat().st_size if p.exists() else 0,
 'rows':len(rows),'bad_json':bad,
 'row_types':dict(collections.Counter(r.get('row_type','<missing>') for r in rows)),
 'steps':sorted(set(r.get('step') or r.get('step_index') for r in rows if (r.get('step') or r.get('step_index')) is not None)),
 'windows':dict(collections.Counter(str(r.get('window') or r.get('thermo_window') or '<missing>') for r in rows)),
 'face_classes':dict(collections.Counter(str(r.get('thermo_face_class') or r.get('face_class') or '<missing>') for r in rows)),
 'counts':counts,
 'stats':stats,
 'sample_rows':rows[:5],
 'log':logout,
 'png':{'exists':png.exists(),'path':str(png),'mtime':datetime.fromtimestamp(png.stat().st_mtime).isoformat() if png.exists() else None}
}
print(json.dumps(out, indent=2, sort_keys=True))

﻿import json, math, statistics, collections
from pathlib import Path
from datetime import datetime
base=Path('/home/younglin90/work/claude_code/claudeCFD/solver_denner')
p=base/'autoresearch-results/wave_pface_energy_compat_iter607_N200.jsonl'
rows=[]; bad=0
if p.exists():
    for line in p.read_text(errors='replace').splitlines():
        if not line.strip(): continue
        try: rows.append(json.loads(line))
        except Exception: bad += 1
keys=set().union(*(r.keys() for r in rows)) if rows else set()

def finite(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stat(vals):
    vals=[float(v) for v in vals if finite(v)]
    if not vals: return None
    return {'count':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals)}
def stat_key(k, rs=None): return stat([r.get(k) for r in (rs if rs is not None else rows)])
def count_key(k):
    vals=[]
    for r in rows:
        if k in r:
            v=r.get(k)
            if isinstance(v,(list,dict)): v=json.dumps(v,sort_keys=True)
            vals.append(str(v))
    return dict(collections.Counter(vals).most_common(100))
interesting=[k for k in sorted(keys) if any(s in k.lower() for s in ['wave','pface','pressure','work','energy','compat','candidate','delta','defect','highk','opposite','partition','support','fallback','reason','missing','remainder','material','face_class','window','active','admiss','violation'])]
counts={}
for k in interesting:
    c=count_key(k)
    if c and len(c)<=100: counts[k]=c
patterns=['delta','defect','highk','opposite','partition','ratio','count','support','admiss','violation','pface','pressure_work','energy_flux','compat']
stats={k:stat_key(k) for k in interesting if any(pat in k.lower() for pat in patterns)}
numkeys=[k for k in interesting if any(pat in k.lower() for pat in patterns)]
def group_by(k):
    groups=collections.defaultdict(list)
    for r in rows: groups[str(r.get(k,'<missing>'))].append(r)
    return {g:{nk:stat_key(nk,rs) for nk in numkeys if stat_key(nk,rs)} | {'count':len(rs)} for g,rs in groups.items()}
# cause heuristic: collect max medians for core fields
core_fields=[k for k in keys if any(name in k.lower() for name in ['delta_pface','pface_delta','delta_pressure_work','pressure_work_delta','delta_energy_flux','energy_flux_delta','candidate_pressure_energy_compat_defect','compat_defect','pressure_energy'])]
core_stats={k:stat_key(k) for k in sorted(core_fields)}
# parse log
log=base/'autoresearch-results/wave_pface_energy_compat_iter607_N200.log'
logout={}
if log.exists():
    text=log.read_text(errors='replace')
    logout['crash']='Traceback' in text or 'NameError' in text
    for line in text.splitlines():
        if line.startswith('AUTORESEARCH_METRIC'): logout['metric']=line
        if line.startswith('DETAILS_JSON'):
            arr=json.loads(line.split(' ',1)[1]); sub=arr[0]['subcases'][0]
            logout['wall']=arr[0].get('wall')
            fields=['corr_p','corr_u','p_peak_amp_ratio','u_peak_amp_ratio','p_abs_delta_cells','u_abs_delta_cells','air_water_p_packet_shape_ok','air_water_u_packet_shape_ok','air_water_p_packet_secondary_extrema','air_water_u_packet_secondary_extrema','air_water_p_packet_min_corr','air_water_u_packet_min_corr','p_smooth_local_tv_excess','u_smooth_local_tv_excess','p_hf_ok','hf_oscillation_ok']
            logout['metrics']={k:sub.get(k) for k in fields}
png=base/'results/1D/07_B/diff_vs_exact.png'
out={
 'jsonl_exists':p.exists(),'jsonl_size':p.stat().st_size if p.exists() else 0,'rows':len(rows),'bad_json':bad,
 'row_types':dict(collections.Counter(r.get('row_type','<missing>') for r in rows)),
 'steps':sorted(set(r.get('step') or r.get('step_index') for r in rows if (r.get('step') or r.get('step_index')) is not None)),
 'windows':dict(collections.Counter(str(r.get('window') or r.get('wave_window') or r.get('compat_window') or '<missing>') for r in rows)),
 'face_classes':dict(collections.Counter(str(r.get('face_class') or r.get('wave_face_class') or r.get('compat_face_class') or '<missing>') for r in rows)),
 'counts':counts,
 'stats':stats,
 'core_stats':core_stats,
 'by_window':group_by('wave_window') if 'wave_window' in keys else group_by('window'),
 'by_face_class':group_by('wave_face_class') if 'wave_face_class' in keys else group_by('face_class'),
 'sample_rows':rows[:6],
 'log':logout,
 'png':{'exists':png.exists(),'path':str(png),'mtime':datetime.fromtimestamp(png.stat().st_mtime).isoformat() if png.exists() else None},
 'keys':sorted(keys),
}
# heuristic summary
# Prefer explicitly named fields if present.
def max_of_field_substr(subs):
    vals=[]
    found=[]
    for k in keys:
        lk=k.lower()
        if all(s in lk for s in subs):
            st=stat_key(k)
            if st:
                vals.append((st['max'],st['median'],k))
                found.append(k)
    return sorted(vals, reverse=True)[:10]
out['heuristic_fields']={
 'pface':max_of_field_substr(['pface']),
 'pressure_work':max_of_field_substr(['pressure','work']),
 'energy_flux':max_of_field_substr(['energy','flux']),
 'compat_defect':max_of_field_substr(['compat','defect']),
}
print(json.dumps(out,indent=2,sort_keys=True))

#!/usr/bin/env python3
from __future__ import annotations
import json, math, os, subprocess, sys

cmd = [sys.executable, '-u', 'results/run_denner1d_17case.py', '--worker', '14']
env = os.environ.copy()
env.setdefault('PYTHONDONTWRITEBYTECODE', '1')
env.setdefault('DENNER_CASE_BUDGET_SEC', '1800')
proc = subprocess.run(cmd, cwd=os.getcwd(), env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
text = proc.stdout or ''
# Preserve human-readable validator output without contaminating final metrics stdout.
if text:
    sys.stderr.write(text)
lines = [ln for ln in text.splitlines() if ln.startswith('CASE_JSON ')]
if not lines:
    sys.stderr.write('ERROR missing CASE_JSON in validator output\n')
    raise SystemExit(proc.returncode or 2)
raw = json.loads(lines[-1][len('CASE_JSON '):])
metrics = {}
for k, v in raw.items():
    if isinstance(v, bool):
        metrics[k] = 1 if v else 0
    elif isinstance(v, (int, float)) and not isinstance(v, bool):
        if isinstance(v, float) and not math.isfinite(v):
            continue
        metrics[k] = v
metrics['case14_failure_count'] = 0 if raw.get('pass') is True else 1
print(json.dumps(metrics, ensure_ascii=False, separators=(',', ':')))
# A numerical FAIL is still a valid measurement. Nonzero only if no metrics were parseable.
raise SystemExit(0)

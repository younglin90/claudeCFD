#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import math
import os
import subprocess
import sys
import textwrap
import time
from dataclasses import dataclass
from pathlib import Path
import runpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from oscillation_guards import high_frequency_oscillation_guard
from solver.denner_1d.main import run as denner_run

PLOT_PATH = ROOT / "results" / "1D" / "07_B" / "diff_vs_exact.png"
REPORT_PATH = ROOT / "autoresearch-results" / "agent3_validator_fix16_cfg_plumbing_matrix_report.md"
SUMMARY_PATH = ROOT / "autoresearch-results" / "agent3_validator_fix16_cfg_plumbing_matrix_results.json"

BASELINE = {
    "L2p": 12425.409183075193,
    "Lip": 12427.179553895976,
    "L2u": 2.8189100061734873,
    "Liu": 15.215859260274822,
    "rho_hf_ok": True,
    "first_pressure_floor_step": 8,
    "plot_sha256": "3f4ecc51a4fd9d2f67bc15b868777a1db305e9d0760d393df58787d6f26d0533",
}

P0 = 1.0e5
U_PEAK_07 = 0.02
MIN_FRAC_07 = 0.76
MAX_L2_07 = 0.216
MAX_LINF_07 = 0.81
MAX_LINF_AIR_WATER_07 = 0.756
MAX_L1_07 = 0.648
MIN_CORR_07 = 0.88
MIN_PEAK_AMP_RATIO_07 = 0.85
MAX_PEAK_AMP_RATIO_07 = 1.10
MIN_PEAK_AMP_RATIO_GAS_07 = 0.80
MAX_PEAK_AMP_RATIO_GAS_07 = 1.13
WAVE_SYMMETRY_LIMIT_07 = 0.38
WAVE_SYMMETRY_LIMIT_AIR_WATER_07 = 0.38
AIR_WATER_PACKET_OPPOSITE_LIMIT_07 = 0.015
AIR_WATER_PACKET_CORR_LIMIT_07 = 0.99
AIR_WATER_PACKET_SCALED_L2_LIMIT_07 = 0.25
AIR_WATER_RIGHT_P_MONOTONICITY_DEFECT_LIMIT_07 = 0.005
AIR_WATER_SMOOTH_P_LOCAL_TV_EXCESS_LIMIT_07 = 0.30
AIR_WATER_SMOOTH_U_LOCAL_TV_EXCESS_LIMIT_07 = 0.20
AIR_WATER_SMOOTH_P_LOCAL_HF_LIMIT_07 = 0.04


@dataclass(frozen=True)
class Case07:
    name: str
    left: str
    right: str
    x_intf: float
    x_src: float
    sigma: float
    t_end: float


CASE = Case07("Air-Water", "Air", "Water", 0.5, 0.1, 0.014, 1.55e-3)
EOS_07 = {
    "Air": {"rho": 1.157, "c": 347.8},
    "Water": {"rho": 998.0, "c": 1567.3350584385664},
}


def _make_case_params(overrides: dict) -> dict:
    N = 200
    length = 1.5
    dx = length / N
    x = (np.arange(N) + 0.5) * dx
    alpha_floor = 1.0e-8
    psi0 = np.where(x < CASE.x_intf, 1.0 - alpha_floor, alpha_floor)
    u0 = np.where(x < CASE.x_intf, U_PEAK_07 * np.exp(-((x - CASE.x_src) ** 2) / (2.0 * CASE.sigma**2)), 0.0)
    ZL = EOS_07[CASE.left]["rho"] * EOS_07[CASE.left]["c"]
    p0 = np.full(N, P0)
    u_init = u0
    p_init = P0 + ZL * u_init
    TL = _temperature_from_rho_p(EOS_07[CASE.left]["rho"], P0, "Air")
    TR = _temperature_from_rho_p(EOS_07[CASE.right]["rho"], P0, "Water")
    theta_L = _isentropic_dTdp({"gamma": 1.4, "pinf": 0.0, "b": 0.0, "kv": 717.5}, P0, TL)
    T_init = np.where(x < CASE.x_intf, TL + theta_L * (p_init - P0), TR)
    case_params = {
        "x_cells": x,
        "psi_init": psi0,
        "T_init": T_init,
        "u_init": u_init,
        "p_init": p_init,
        "ph1": {"gamma": 1.4, "pinf": 0.0, "b": 0.0, "kv": 717.5, "eta": 0.0},
        "ph2": {"gamma": 1.187, "pinf": 7.028e8, "b": 6.61e-4, "kv": 3610.0, "eta": -1.177788e6},
        "t_end": CASE.t_end,
        "bc_left": "reflective",
        "bc_right": "transmissive",
        "cfl": 0.4,
        "max_iter": 5000,
        "variable_set": "puT",
        "coupled": 0,
        "solver_mode": "delta",
        "third_var": "T",
        "use_barotropic": 0,
        "use_K": 1,
        "use_compress": 1,
        "bdf_order": 2,
        "mwi_rho_star": "harmonic",
        "tvd_limiter": "koren",
        "acoustic_limiter": None,
        "acoustic_limiter_blend": 1.0,
        "mwi_transient": 1,
        "acoustic_face_correction": 1,
        "acid_temporal_colour": "midpoint",
        "alpha_face_velocity_mode": "legacy",
        "max_outer": 3,
        "max_inner": 8,
        "max_newton": 12,
        "newton_tol": 1.0e-8,
        "outer_tol": 1.0e-8,
        **overrides,
    }
    return case_params


def _mix_rho(psi, p, T, ph1, ph2):
    psi = np.asarray(psi, dtype=float)
    p = np.asarray(p, dtype=float)
    T = np.asarray(T, dtype=float)
    # Air is ideal gas; water is NASG.
    rho_air = p / np.maximum(717.5 * (1.4 - 1.0) * T, 1.0e-300)
    rho_water = (p + 7.028e8) / np.maximum(3610.0 * T * (1.187 - 1.0) + 6.61e-4 * (p + 7.028e8), 1.0e-300)
    return psi * rho_air + (1.0 - psi) * rho_water


def _exact_07(x: np.ndarray, t: float) -> tuple[np.ndarray, np.ndarray]:
    cL = EOS_07[CASE.left]["c"]
    cR = EOS_07[CASE.right]["c"]
    ZL = EOS_07[CASE.left]["rho"] * cL
    ZR = EOS_07[CASE.right]["rho"] * cR
    R = (ZR - ZL) / (ZR + ZL)
    Tu = 2.0 * ZL / (ZL + ZR)
    Tp = 2.0 * ZR / (ZL + ZR)
    t_hit = (CASE.x_intf - CASE.x_src) / cL
    x = np.asarray(x, dtype=float)
    left_mask = x < CASE.x_intf

    def gauss(center: float, sigma: float) -> np.ndarray:
        return np.exp(-((x - center) ** 2) / (2.0 * sigma * sigma))

    u_inc = U_PEAK_07 * gauss(CASE.x_src + cL * t, CASE.sigma) * left_mask
    u_ref_shape = U_PEAK_07 * gauss(2.0 * CASE.x_intf - CASE.x_src - cL * t, CASE.sigma) * left_mask
    if t > t_hit:
        sigR = CASE.sigma * cR / cL
        u_tr_shape = U_PEAK_07 * gauss(CASE.x_intf + cR * (t - t_hit), sigR) * (~left_mask)
    else:
        u_tr_shape = np.zeros_like(x)
    u_exact = u_inc - R * u_ref_shape + Tu * u_tr_shape
    p_exact = P0 + ZL * u_inc + R * ZL * u_ref_shape + Tp * ZL * u_tr_shape
    return p_exact, u_exact


def _temperature_from_rho_p(rho: float, p: float, phase: str) -> float:
    if phase == "Air":
        return float(p / max(rho * 717.5 * (1.4 - 1.0), 1.0e-300))
    if phase == "Water":
        return float(((p + 7.028e8) / max(rho, 1.0e-300) - 6.61e-4 * (p + 7.028e8)) / (3610.0 * (1.187 - 1.0)))
    raise ValueError(phase)


def _isentropic_dTdp(ph: dict, p: float, T: float) -> float:
    g, pinf, b, kv = ph["gamma"], ph["pinf"], ph["b"], ph["kv"]
    A = kv * T * (g - 1.0) + b * (p + pinf)
    rho = (p + pinf) / A
    rho_p = (kv * T * (g - 1.0)) / (A * A)
    rho_T = -((p + pinf) * kv * (g - 1.0)) / (A * A)
    e_p = kv * T * pinf * (1.0 - g) / ((p + pinf) ** 2)
    e_T = kv * (p + g * pinf) / (p + pinf)
    pr2 = p / max(rho * rho, 1.0e-300)
    return float((pr2 * rho_p - e_p) / (e_T - pr2 * rho_T + 1.0e-300))


def _exact_07_rho(x: np.ndarray, p_exact: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    mask_L = x < CASE.x_intf
    rho0 = np.where(mask_L, EOS_07[CASE.left]["rho"], EOS_07[CASE.right]["rho"])
    c = np.where(mask_L, EOS_07[CASE.left]["c"], EOS_07[CASE.right]["c"])
    return rho0 + (np.asarray(p_exact, dtype=float) - P0) / np.maximum(c * c, 1.0e-300)


def _pearson(a: np.ndarray, b: np.ndarray) -> float:
    aa = np.asarray(a, dtype=float) - float(np.mean(a))
    bb = np.asarray(b, dtype=float) - float(np.mean(b))
    den = float(np.sqrt(np.dot(aa, aa) * np.dot(bb, bb)))
    if den <= 1.0e-300:
        return 1.0
    return float(np.dot(aa, bb) / den)


def _metrics_profile(x, p_num, u_num, p_exact, u_exact, dp_wave, du_wave) -> dict[str, float]:
    p_err = np.asarray(p_num, dtype=float) - np.asarray(p_exact, dtype=float)
    u_err = np.asarray(u_num, dtype=float) - np.asarray(u_exact, dtype=float)
    p_sig = np.asarray(p_exact, dtype=float) - P0
    u_sig = np.asarray(u_exact, dtype=float)
    dp = max(float(dp_wave), 1.0e-300)
    du = max(float(du_wave), 1.0e-300)
    den_l1p = max(float(np.sum(np.abs(p_sig))), 1.0e-300)
    den_l1u = max(float(np.sum(np.abs(u_sig))), 1.0e-300)
    return {
        "L2p": float(np.sqrt(np.mean(p_err * p_err)) / dp),
        "Lip": float(np.max(np.abs(p_err)) / dp),
        "L2u": float(np.sqrt(np.mean(u_err * u_err)) / du),
        "Liu": float(np.max(np.abs(u_err)) / du),
        "frac_p": float(np.mean(np.abs(p_err) < 0.30 * dp)),
        "frac_u": float(np.mean(np.abs(u_err) < 0.30 * du)),
        "L1p": float(np.sum(np.abs(p_err)) / den_l1p),
        "L1u": float(np.sum(np.abs(u_err)) / den_l1u),
        "corr_p": _pearson(np.asarray(p_num, dtype=float) - P0, p_sig),
        "corr_u": _pearson(np.asarray(u_num, dtype=float), u_sig),
    }


def _oscillation_ok(x, W, p_exact, u_exact, dp_wave, dx) -> tuple[bool, dict]:
    def checkerboard_metric(signal):
        r = np.asarray(signal, dtype=float)
        amp = float(np.max(np.abs(r)))
        idx = np.flatnonzero(np.abs(r) > 0.08 * max(amp, 1.0e-30))
        if idx.size < 4:
            return {"alt_ratio": 0.0, "amp": amp}
        rr = r[idx]
        signs = np.where(np.arange(idx.size) % 2 == 0, 1.0, -1.0)
        alt_ratio = float(abs(np.dot(rr, signs)) / (np.sum(np.abs(rr)) + 1.0e-300))
        return {"alt_ratio": alt_ratio, "amp": amp}

    rp = (np.asarray(W[4]) - np.asarray(p_exact)) / max(dp_wave, 1.0e-30)
    ru = (np.asarray(W[3]) - np.asarray(u_exact)) / max(U_PEAK_07, 1.0e-30)
    pchk = checkerboard_metric(rp)
    uchk = checkerboard_metric(ru)
    bad_p = ((pchk["alt_ratio"] > 0.60 and pchk["amp"] > 0.20) or pchk["amp"] > 0.30)
    bad_u = ((uchk["alt_ratio"] > 0.60 and uchk["amp"] > 0.20) or uchk["amp"] > 0.45)
    return (not (bad_p or bad_u)), {
        "p_alt_ratio": pchk["alt_ratio"],
        "p_alt_amp": pchk["amp"],
        "u_alt_ratio": uchk["alt_ratio"],
        "u_alt_amp": uchk["amp"],
    }


def _profile_pass_07(m: dict) -> bool:
    return (
        m["L2p"] < MAX_L2_07 and m["L2u"] < MAX_L2_07
        and m["Lip"] < MAX_LINF_AIR_WATER_07 and m["Liu"] < MAX_LINF_AIR_WATER_07
        and m["frac_p"] >= MIN_FRAC_07 and m["frac_u"] >= MIN_FRAC_07
        and m["L1p"] < MAX_L1_07 and m["L1u"] < MAX_L1_07
        and m["corr_p"] > MIN_CORR_07 and m["corr_u"] > MIN_CORR_07
    )


def _significant_exact_peak_indices(signal: np.ndarray, min_fraction: float = 0.15) -> list[int]:
    sig = np.asarray(signal, dtype=float)
    if sig.size < 3:
        return []
    amp = float(np.max(np.abs(sig)))
    if amp <= 1.0e-30:
        return []
    candidates = [int(np.argmax(np.abs(sig)))]
    for i in range(1, sig.size - 1):
        is_max = sig[i] >= sig[i - 1] and sig[i] >= sig[i + 1]
        is_min = sig[i] <= sig[i - 1] and sig[i] <= sig[i + 1]
        if (is_max or is_min) and abs(float(sig[i])) >= min_fraction * amp:
            candidates.append(i)
    candidates = sorted(set(candidates), key=lambda idx: -abs(float(sig[idx])))
    separated: list[int] = []
    min_sep = 4
    for idx in candidates:
        if all(abs(idx - prev) >= min_sep for prev in separated):
            separated.append(idx)
    return sorted(separated)


def _wave_symmetry_for_field(num: np.ndarray, exact: np.ndarray, limit: float) -> tuple[bool, dict]:
    num = np.asarray(num, dtype=float)
    exact = np.asarray(exact, dtype=float)
    amp_global = float(np.max(np.abs(exact)))
    details: dict[str, float | int | bool] = {"symmetry_max_error": 0.0, "symmetry_wave_count": 0, "symmetry_limit": float(limit)}
    if amp_global <= 1.0e-30:
        details["symmetry_ok"] = True
        return True, details
    max_err = 0.0
    count = 0
    for center in _significant_exact_peak_indices(exact):
        sign = 1.0 if exact[center] >= 0.0 else -1.0
        amp = abs(float(exact[center]))
        threshold = 0.10 * amp
        left = center
        while left > 0 and sign * exact[left - 1] >= threshold:
            left -= 1
        right = center
        while right + 1 < exact.size and sign * exact[right + 1] >= threshold:
            right += 1
        if right - left < 6:
            continue
        local = sign * num[left:right + 1]
        peak_local = int(np.argmax(local))
        peak_idx = left + peak_local
        radius = min(peak_idx - left, right - peak_idx)
        if radius < 3:
            continue
        offsets = np.arange(1, radius + 1)
        left_vals = sign * num[peak_idx - offsets]
        right_vals = sign * num[peak_idx + offsets]
        denom = max(abs(float(num[peak_idx])), amp, 1.0e-30)
        err = float(np.mean(np.abs(left_vals - right_vals)) / denom)
        max_err = max(max_err, err)
        count += 1
    ok = max_err <= limit
    details["symmetry_ok"] = bool(ok)
    details["symmetry_max_error"] = float(max_err)
    details["symmetry_wave_count"] = int(count)
    return bool(ok), details


def _wave_symmetry_ok_07(W, p_exact, u_exact) -> tuple[bool, dict]:
    p_ok, p_details = _wave_symmetry_for_field(np.asarray(W[4], dtype=float) - P0, np.asarray(p_exact, dtype=float) - P0, WAVE_SYMMETRY_LIMIT_AIR_WATER_07)
    u_ok, u_details = _wave_symmetry_for_field(np.asarray(W[3], dtype=float), np.asarray(u_exact, dtype=float), WAVE_SYMMETRY_LIMIT_AIR_WATER_07)
    details = {
        "p_symmetry_ok": bool(p_ok),
        "u_symmetry_ok": bool(u_ok),
        "p_symmetry_max_error": p_details["symmetry_max_error"],
        "u_symmetry_max_error": u_details["symmetry_max_error"],
        "p_symmetry_wave_count": p_details["symmetry_wave_count"],
        "u_symmetry_wave_count": u_details["symmetry_wave_count"],
        "symmetry_limit": float(WAVE_SYMMETRY_LIMIT_AIR_WATER_07),
    }
    return bool(p_ok and u_ok), details


def _air_water_wiggle_ok_07(case_name: str, hf: dict) -> tuple[bool, dict]:
    if case_name != "Air-Water":
        return True, {"air_water_wiggle_ok": True}
    p_tv = float(hf.get("p_smooth_local_tv_excess", 0.0))
    u_tv = float(hf.get("u_smooth_local_tv_excess", 0.0))
    p_hf = float(hf.get("p_smooth_local_hf_max", 0.0))
    ok = (
        p_tv <= AIR_WATER_SMOOTH_P_LOCAL_TV_EXCESS_LIMIT_07
        and u_tv <= AIR_WATER_SMOOTH_U_LOCAL_TV_EXCESS_LIMIT_07
        and p_hf <= AIR_WATER_SMOOTH_P_LOCAL_HF_LIMIT_07
    )
    return bool(ok), {
        "air_water_wiggle_ok": bool(ok),
        "air_water_p_smooth_local_tv_excess_limit": AIR_WATER_SMOOTH_P_LOCAL_TV_EXCESS_LIMIT_07,
        "air_water_u_smooth_local_tv_excess_limit": AIR_WATER_SMOOTH_U_LOCAL_TV_EXCESS_LIMIT_07,
        "air_water_p_smooth_local_hf_limit": AIR_WATER_SMOOTH_P_LOCAL_HF_LIMIT_07,
    }


def _local_wave_packet_amp_ratios(num: np.ndarray, exact: np.ndarray, exact_abs_amp: float, cell_tol: int) -> list[float]:
    if exact_abs_amp <= 1.0e-30:
        return []
    mask = np.abs(exact) >= 0.10 * exact_abs_amp
    if not np.any(mask):
        return []
    idx = np.flatnonzero(mask)
    cuts = np.where(np.diff(idx) > 1)[0] + 1
    packets = np.split(idx, cuts)
    ratios: list[float] = []
    n = len(exact)
    for packet in packets:
        lo = max(int(packet[0]) - cell_tol, 0)
        hi = min(int(packet[-1]) + cell_tol + 1, n)
        exact_amp = float(np.max(np.abs(exact[packet])))
        num_amp = float(np.max(np.abs(num[lo:hi])))
        if exact_amp > 1.0e-30:
            ratios.append(num_amp / exact_amp)
    return ratios


def _peak_location_ok(x, W, p_exact, u_exact, cell_tol: int = 3, require_abs_peak: bool = True) -> tuple[bool, dict]:
    x = np.asarray(x)
    fields = {
        "p": (np.asarray(W[4], dtype=float) - P0, np.asarray(p_exact, dtype=float) - P0),
        "u": (np.asarray(W[3], dtype=float), np.asarray(u_exact, dtype=float)),
    }
    details: dict[str, float | int | bool] = {}
    ok = True
    for name, (num, exact) in fields.items():
        exact_abs_amp = float(np.max(np.abs(exact)))
        num_abs_amp = float(np.max(np.abs(num)))
        if exact_abs_amp <= 1.0e-30:
            details[f"{name}_abs_idx"] = -1
            details[f"{name}_exact_abs_idx"] = -1
            details[f"{name}_abs_required"] = bool(require_abs_peak)
            details[f"{name}_abs_ok"] = bool(num_abs_amp <= 1.0e-12)
            ok = ok and ((not require_abs_peak) or bool(details[f"{name}_abs_ok"]))
            continue
        idx_abs = int(np.argmax(np.abs(num)))
        idx_abs_exact = int(np.argmax(np.abs(exact)))
        abs_delta = abs(idx_abs - idx_abs_exact)
        abs_ok = abs_delta <= cell_tol
        ok = ok and ((not require_abs_peak) or abs_ok)
        details[f"{name}_abs_idx"] = idx_abs
        details[f"{name}_exact_abs_idx"] = idx_abs_exact
        details[f"{name}_abs_delta_cells"] = abs_delta
        details[f"{name}_abs_tol_cells"] = int(cell_tol)
        details[f"{name}_abs_required"] = bool(require_abs_peak)
        details[f"{name}_abs_x"] = float(x[idx_abs])
        details[f"{name}_exact_abs_x"] = float(x[idx_abs_exact])
        details[f"{name}_abs_ok"] = bool(abs_ok)
        details[f"{name}_abs_amp"] = num_abs_amp
        details[f"{name}_exact_abs_amp"] = exact_abs_amp
        details[f"{name}_packet_amp_ratios"] = _local_wave_packet_amp_ratios(num, exact, exact_abs_amp, cell_tol)
        for extremum, fn in (("max", np.argmax), ("min", np.argmin)):
            idx_exact = int(fn(exact))
            exact_amp = abs(float(exact[idx_exact]))
            require_signed = exact_amp >= 0.10 * exact_abs_amp
            idx = int(fn(num))
            signed_delta = abs(idx - idx_exact)
            signed_ok = (not require_signed) or (signed_delta <= cell_tol)
            ok = ok and signed_ok
            details[f"{name}_{extremum}_idx"] = idx
            details[f"{name}_exact_{extremum}_idx"] = idx_exact
            details[f"{name}_{extremum}_delta_cells"] = signed_delta
            details[f"{name}_{extremum}_tol_cells"] = int(cell_tol)
            details[f"{name}_{extremum}_x"] = float(x[idx])
            details[f"{name}_exact_{extremum}_x"] = float(x[idx_exact])
            details[f"{name}_{extremum}_required"] = bool(require_signed)
            details[f"{name}_{extremum}_ok"] = bool(signed_ok)
    return bool(ok), details


def _peak_amplitude_ok_07(peak: dict) -> tuple[bool, dict]:
    min_ratio = MIN_PEAK_AMP_RATIO_07
    max_ratio = MAX_PEAK_AMP_RATIO_07
    details: dict[str, float | bool] = {"peak_amp_min_ratio": float(min_ratio), "peak_amp_max_ratio": float(max_ratio)}
    ok = True
    for name in ("p", "u"):
        num_amp = float(peak.get(f"{name}_abs_amp", 0.0))
        exact_amp = float(peak.get(f"{name}_exact_abs_amp", 0.0))
        ratio = 1.0 if exact_amp <= 1.0e-30 and num_amp <= 1.0e-12 else (float("inf") if exact_amp <= 1.0e-30 else num_amp / exact_amp)
        field_ok = min_ratio <= ratio <= max_ratio
        details[f"{name}_peak_amp_ratio"] = float(ratio)
        details[f"{name}_peak_amp_ok"] = bool(field_ok)
        ok = bool(ok and field_ok)
        packet_ratios = list(peak.get(f"{name}_packet_amp_ratios", ()))
        if packet_ratios:
            packet_ok = all(min_ratio <= float(r) <= max_ratio for r in packet_ratios)
            details[f"{name}_packet_peak_amp_ratios"] = [float(r) for r in packet_ratios]
            details[f"{name}_packet_peak_amp_min"] = float(np.min(packet_ratios))
            details[f"{name}_packet_peak_amp_max"] = float(np.max(packet_ratios))
            details[f"{name}_packet_peak_amp_ok"] = bool(packet_ok)
            ok = bool(ok and packet_ok)
        else:
            details[f"{name}_packet_peak_amp_ratios"] = []
            details[f"{name}_packet_peak_amp_ok"] = True
    details["peak_amplitude_ok"] = bool(ok)
    return bool(ok), details


def _air_water_right_pressure_packet_guard(x, p_num, p_exact):
    sig_ref = np.asarray(p_exact, dtype=float) - P0
    sig_num = np.asarray(p_num, dtype=float) - P0
    x = np.asarray(x, dtype=float)
    right = x > 0.75
    if not np.any(right):
        return True, {"air_water_right_p_packet_shape_ok": True}
    amp_ref = float(np.max(sig_ref[right]))
    if amp_ref <= 1.0e-30:
        return True, {"air_water_right_p_packet_shape_ok": True}
    support = right & (sig_ref > 0.08 * amp_ref)
    idx = np.flatnonzero(support)
    if idx.size < 5:
        return True, {"air_water_right_p_packet_shape_ok": True}
    lo = max(int(idx[0]) - 4, 0)
    hi = min(int(idx[-1]) + 5, sig_num.size)
    q = sig_num[lo:hi]
    if q.size < 5:
        return True, {"air_water_right_p_packet_shape_ok": True}
    peak_local = int(np.argmax(q))
    dq = np.diff(q)
    scale = max(amp_ref, float(np.max(np.abs(q))), 1.0e-300)
    tol = 0.01 * scale
    left = dq[:peak_local]
    right_dq = dq[peak_local:]
    left_defect = float(np.sum(np.maximum(-left, 0.0))) / scale if left.size else 0.0
    right_defect = float(np.sum(np.maximum(right_dq, 0.0))) / scale if right_dq.size else 0.0
    monotonicity_defect = left_defect + right_defect
    significant = np.where(np.abs(dq) > tol, np.sign(dq), 0.0)
    significant = significant[significant != 0.0]
    extrema = 0
    if significant.size >= 2:
        extrema = int(np.count_nonzero(significant[1:] * significant[:-1] < 0.0))
        extrema = max(0, extrema - 1)
    ok = bool(monotonicity_defect <= AIR_WATER_RIGHT_P_MONOTONICITY_DEFECT_LIMIT_07 and extrema <= 0)
    return ok, {
        "air_water_right_p_packet_shape_ok": ok,
        "air_water_right_p_packet_secondary_extrema": extrema,
        "air_water_right_p_packet_secondary_extrema_limit": 0,
        "air_water_right_p_packet_monotonicity_defect": monotonicity_defect,
        "air_water_right_p_packet_monotonicity_defect_limit": AIR_WATER_RIGHT_P_MONOTONICITY_DEFECT_LIMIT_07,
    }


def _air_water_smooth_packet_guard(x, p_num, u_num, p_exact, u_exact):
    def _segments(mask):
        idx = np.flatnonzero(mask)
        if idx.size == 0:
            return []
        cuts = np.where(np.diff(idx) > 1)[0] + 1
        return [seg for seg in np.split(idx, cuts) if seg.size >= 3]

    def _field_metrics(name, num, exact):
        sig_n = np.asarray(num, dtype=float)
        sig_e = np.asarray(exact, dtype=float)
        amp = max(float(np.max(np.abs(sig_e))), 1.0e-300)
        supports = _segments(np.abs(sig_e) > 0.08 * amp)
        if not supports:
            return True, {f"air_water_{name}_packet_lobes": 0, f"air_water_{name}_packet_shape_ok": True}
        max_secondary_extrema = 0
        max_opposite_ratio = 0.0
        min_corr = 1.0
        max_scaled_l2 = 0.0
        for seg in supports:
            lo = max(int(seg[0]) - 4, 0)
            hi = min(int(seg[-1]) + 5, sig_n.size)
            qn = sig_n[lo:hi]
            qe = sig_e[lo:hi]
            if qn.size < 5:
                continue
            lobe_sign = 1.0 if float(np.sum(qe)) >= 0.0 else -1.0
            qns = lobe_sign * qn
            qes = lobe_sign * qe
            lobe_amp = max(float(np.max(qes)), amp, 1.0e-300)
            opposite_ratio = float(max(0.0, -np.min(qns)) / lobe_amp)
            max_opposite_ratio = max(max_opposite_ratio, opposite_ratio)
            dq = np.diff(qns)
            tol = 0.015 * lobe_amp
            significant = np.where(np.abs(dq) > tol, np.sign(dq), 0.0)
            significant = significant[significant != 0.0]
            extrema = 0
            if significant.size >= 2:
                extrema = int(np.count_nonzero(significant[1:] * significant[:-1] < 0.0))
                extrema = max(0, extrema - 1)
            max_secondary_extrema = max(max_secondary_extrema, extrema)
            support = np.abs(qe) > 0.08 * amp
            if np.count_nonzero(support) >= 3:
                a = qn[support]
                b = qe[support]
                denom = float(np.linalg.norm(a) * np.linalg.norm(b))
                corr = float(np.dot(a, b) / denom) if denom > 0.0 else 1.0
                scaled_l2 = float(np.linalg.norm(a - b) / max(float(np.linalg.norm(b)), 1.0e-300))
                min_corr = min(min_corr, corr)
                max_scaled_l2 = max(max_scaled_l2, scaled_l2)
        ok = bool(
            max_secondary_extrema <= 0
            and max_opposite_ratio <= AIR_WATER_PACKET_OPPOSITE_LIMIT_07
            and min_corr >= AIR_WATER_PACKET_CORR_LIMIT_07
            and max_scaled_l2 <= AIR_WATER_PACKET_SCALED_L2_LIMIT_07
        )
        return ok, {
            f"air_water_{name}_packet_lobes": len(supports),
            f"air_water_{name}_packet_shape_ok": ok,
            f"air_water_{name}_packet_secondary_extrema": max_secondary_extrema,
            f"air_water_{name}_packet_secondary_extrema_limit": 0,
            f"air_water_{name}_packet_opposite_ratio": max_opposite_ratio,
            f"air_water_{name}_packet_opposite_ratio_limit": AIR_WATER_PACKET_OPPOSITE_LIMIT_07,
            f"air_water_{name}_packet_min_corr": min_corr,
            f"air_water_{name}_packet_min_corr_limit": AIR_WATER_PACKET_CORR_LIMIT_07,
            f"air_water_{name}_packet_max_scaled_l2": max_scaled_l2,
            f"air_water_{name}_packet_max_scaled_l2_limit": AIR_WATER_PACKET_SCALED_L2_LIMIT_07,
        }

    p_ok, p_m = _field_metrics("p", np.asarray(p_num, dtype=float) - P0, np.asarray(p_exact, dtype=float) - P0)
    u_ok, u_m = _field_metrics("u", u_num, u_exact)
    ok = bool(p_ok and u_ok)
    return ok, {"air_water_smooth_packet_shape_ok": ok, **p_m, **u_m}


def _case_params_row(overrides: dict) -> dict:
    return _make_case_params(overrides)


def _save_plot(case_name: str, x, rho, u, p, rho_exact, u_exact, p_exact, passed: bool) -> None:
    out_dir = ROOT / "results" / "1D" / "07_B"
    out_dir.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(1, 3, figsize=(14, 4.2), squeeze=False)
    fields = [
        ("rho", rho, rho_exact),
        ("u", u, u_exact),
        ("p-P0", p - P0, p_exact - P0),
    ]
    for j, (name, num, exact) in enumerate(fields):
        ax[0, j].plot(x, num, "b-", lw=1.4, label="num")
        ax[0, j].plot(x, exact, "r--", lw=1.1, label="exact")
        ax[0, j].set_title(f"{case_name} pass={passed} {name}")
        ax[0, j].grid(alpha=0.3)
        ax[0, j].legend(fontsize=8)
    fig.suptitle(f"07_B denner_1d strict acceptance pass={passed}")
    fig.tight_layout()
    fig.savefig(PLOT_PATH, dpi=120)
    plt.close(fig)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _direct_run(overrides: dict, label: str) -> dict:
    case_params = _case_params_row(overrides)
    t0 = time.time()
    res = denner_run(case_params)
    x = np.asarray(case_params["x_cells"], dtype=float)
    psi_f = np.asarray(res["final_state"]["psi"], dtype=float)
    rho_f = np.asarray(res["final_state"]["rho"], dtype=float)
    T_f = np.asarray(res["final_state"]["T"], dtype=float)
    u_f = np.asarray(res["final_state"]["u"], dtype=float)
    p_f = np.asarray(res["final_state"]["p"], dtype=float)
    t_final = float(res["t_history"][-1])
    p_exact, u_exact = _exact_07(x, t_final)
    rho_exact = _exact_07_rho(x, p_exact)
    m = _metrics_profile(x, p_f, u_f, p_exact, u_exact, EOS_07[CASE.left]["rho"] * EOS_07[CASE.left]["c"], U_PEAK_07)
    finite = bool(np.all(np.isfinite(psi_f)) and np.all(np.isfinite(T_f)) and np.all(np.isfinite(u_f)) and np.all(np.isfinite(p_f)) and np.min(p_f) > 0.0)
    complete = t_final >= CASE.t_end - 1.0e-14
    dx = float(np.median(np.diff(x))) if x.size > 1 else 1.0
    osc_ok, osc = _oscillation_ok(x, (psi_f, T_f, T_f, u_f, p_f), p_exact, u_exact, EOS_07[CASE.left]["rho"] * EOS_07[CASE.left]["c"], dx)
    peak_ok, peak = _peak_location_ok(x, (psi_f, T_f, T_f, u_f, p_f), p_exact, u_exact, require_abs_peak=True)
    peak["case_name"] = CASE.name
    peak_amp_ok, peak_amp = _peak_amplitude_ok_07(peak)
    sym_ok, sym = _wave_symmetry_ok_07((psi_f, T_f, T_f, u_f, p_f), p_exact, u_exact)
    hf = high_frequency_oscillation_guard(
        x,
        {
            "rho": (rho_f, rho_exact, max(float(np.ptp(rho_exact)), 1.0)),
            "u": (u_f, u_exact, U_PEAK_07),
            "p": (p_f, p_exact, EOS_07[CASE.left]["rho"] * EOS_07[CASE.left]["c"] * U_PEAK_07),
        },
        sharp_centers=(CASE.x_intf,),
        smooth_hf_limit=0.10,
        smooth_local_tv_excess_limit=0.80,
        smooth_local_turn_limit=6,
        sharp_overshoot_limit=0.18,
        sharp_tv_excess_limit=1.10,
        sharp_turn_limit=4,
    )
    aw_wiggle_ok, aw_wiggle = _air_water_wiggle_ok_07("Air-Water", hf)
    right_ok, right_m = _air_water_right_pressure_packet_guard(x, p_f, p_exact)
    smooth_ok, smooth_m = _air_water_smooth_packet_guard(x, p_f, u_f, p_exact, u_exact)
    pass_row = bool(
        finite and complete and _profile_pass_07(m)
        and osc_ok and peak_ok and peak_amp_ok and sym_ok and hf["hf_oscillation_ok"]
        and aw_wiggle_ok and right_ok and smooth_ok
    )
    _save_plot(CASE.name, x, rho_f, u_f, p_f, rho_exact, u_exact, p_exact, pass_row)
    plot_sha = _sha256(PLOT_PATH)
    floor_diag = res.get("round41_floor_diag", {}) or {}
    out = {
        "label": label,
        "case": CASE.name,
        "pass": pass_row,
        "finite": finite,
        "complete": complete,
        "diverged": bool(res.get("diverged", False)),
        "L2p": m["L2p"],
        "Lip": m["Lip"],
        "L2u": m["L2u"],
        "Liu": m["Liu"],
        "rho_hf_ok": bool(hf.get("rho_hf_ok", False)),
        "first_pressure_floor_step": floor_diag.get("first_pressure_floor_step"),
        "plot_path": str(PLOT_PATH),
        "plot_sha256": plot_sha,
        "metrics": m,
        "osc": osc,
        "peak": peak,
        "peak_amplitude": peak_amp,
        "symmetry": sym,
        "hf": hf,
        "air_water_wiggle": aw_wiggle,
        "right_packet": right_m,
        "smooth_packet": smooth_m,
        "wall": time.time() - t0,
    }
    return out


def _run_subprocess_row(row: dict) -> dict:
    env = os.environ.copy()
    env.update(
        {
            "MPLBACKEND": "Agg",
            "OMP_NUM_THREADS": env.get("OMP_NUM_THREADS", "8"),
            "OPENBLAS_NUM_THREADS": env.get("OPENBLAS_NUM_THREADS", "8"),
            "MKL_NUM_THREADS": env.get("MKL_NUM_THREADS", "8"),
            "NUMEXPR_NUM_THREADS": env.get("NUMEXPR_NUM_THREADS", "8"),
            "DENNER_R67_PEP_COMPAT_RESIDUAL_AUDIT": "0",
            "DENNER_R68_PEP_INTERNAL_FLUX_RESIDUAL": "0",
            "DENNER_R69_R68_ALGEBRA_AUDIT": "0",
            "DENNER_R69_CORRECTED_PEP_INTERNAL_FLUX_RESIDUAL": "0",
            "DENNER_R70_PEP_H_BLOCK_JAC_AUDIT": "0",
            "DENNER_R70_PEP_H_BLOCK_LINEARIZED": "0",
            "DENNER_R41_FLOOR_DIAG": "1",
        }
    )
    payload = json.dumps(row)
    script_path = str(Path(__file__).resolve())
    child = textwrap.dedent(
        f"""
        import json, os, runpy
        row = json.loads(os.environ["ROW_JSON"])
        mod = runpy.run_path({script_path!r})
        out = mod["_direct_run"](row["overrides"], row["label"])
        print("ROW_JSON " + json.dumps(out, default=str))
        """
    )
    env["ROW_JSON"] = payload
    cp = subprocess.run(
        [sys.executable, "-u", "-c", child],
        cwd=str(ROOT),
        env=env,
        text=True,
        capture_output=True,
        timeout=3600,
    )
    if cp.returncode != 0:
        raise RuntimeError(
            f"row {row['label']} subprocess failed: rc={cp.returncode}\n"
            f"stdout:\n{cp.stdout}\nstderr:\n{cp.stderr}"
        )
    for line in reversed((cp.stdout or "").splitlines()):
        if line.startswith("ROW_JSON "):
            return json.loads(line[len("ROW_JSON "):])
    raise RuntimeError(f"row {row['label']} produced no ROW_JSON output\nstdout:\n{cp.stdout}\nstderr:\n{cp.stderr}")


def _run_driver_m0() -> dict:
    env = os.environ.copy()
    env.update(
        {
            "MPLBACKEND": "Agg",
            "DENNER_CASE07_ONLY": "Air-Water",
            "DENNER_CASE07_N": "200",
            "DENNER_CASE07_N_AIR_WATER": "200",
            "DENNER_R67_PEP_COMPAT_RESIDUAL_AUDIT": "0",
            "DENNER_R68_PEP_INTERNAL_FLUX_RESIDUAL": "0",
            "DENNER_R69_R68_ALGEBRA_AUDIT": "0",
            "DENNER_R69_CORRECTED_PEP_INTERNAL_FLUX_RESIDUAL": "0",
            "DENNER_R70_PEP_H_BLOCK_JAC_AUDIT": "0",
            "DENNER_R70_PEP_H_BLOCK_LINEARIZED": "0",
            "DENNER_R41_FLOOR_DIAG": "1",
        }
    )
    child = textwrap.dedent(
        """
        import hashlib, json, os, sys, types
        from pathlib import Path
        torch = types.ModuleType('torch')
        func = types.ModuleType('torch.func')
        func.jacrev = lambda f, *a, **k: f
        func.vmap = lambda f, *a, **k: f
        torch.func = func
        sys.modules['torch'] = torch
        sys.modules['torch.func'] = func
        import results.run_denner1d_17case as drv
        out = drv.case_07()
        row = out["subcases"][0]
        diag = row.get("solver_diagnostics", {}) or {}
        round41 = diag.get("round41", {}) or {}
        result = dict(row)
        result["label"] = "M0"
        result["first_pressure_floor_step"] = round41.get("first_pressure_floor_step")
        plot_path = Path("results/1D/07_B/diff_vs_exact.png")
        h = hashlib.sha256()
        with plot_path.open("rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        result["plot_path"] = str(plot_path)
        result["plot_sha256"] = h.hexdigest()
        print("ROW_JSON " + json.dumps(result, default=str))
        """
    )
    cp = subprocess.run(
        [sys.executable, "-u", "-c", child],
        cwd=str(ROOT),
        env=env,
        text=True,
        capture_output=True,
        timeout=3600,
    )
    if cp.returncode != 0:
        raise RuntimeError(
            f"driver M0 subprocess failed: rc={cp.returncode}\n"
            f"stdout:\n{cp.stdout}\nstderr:\n{cp.stderr}"
        )
    for line in reversed((cp.stdout or "").splitlines()):
        if line.startswith("ROW_JSON "):
            return json.loads(line[len("ROW_JSON "):])
    raise RuntimeError(f"driver M0 produced no ROW_JSON output\nstdout:\n{cp.stdout}\nstderr:\n{cp.stderr}")


def _baseline_match(row: dict) -> tuple[bool, list[str]]:
    mismatches = []
    for key in ("L2p", "Lip", "L2u", "Liu"):
        if row[key] != BASELINE[key]:
            mismatches.append(f"{key}: got {row[key]!r}, expected {BASELINE[key]!r}")
    for key in ("rho_hf_ok", "first_pressure_floor_step", "plot_sha256"):
        if row[key] != BASELINE[key]:
            mismatches.append(f"{key}: got {row[key]!r}, expected {BASELINE[key]!r}")
    return (len(mismatches) == 0, mismatches)


def main() -> int:
    rows: list[dict] = []
    rows.append({"label": "M0", "overrides": {}})
    rows.extend(
        [
            {"label": "M1", "overrides": {"pressure_floor_velocity_regularization": False}},
            {"label": "M2", "overrides": {"shock_velocity_mood_limiter": False}},
            {"label": "M3", "overrides": {"shock_pressure_mood_limiter": False}},
            {"label": "M4", "overrides": {
                "pressure_floor_velocity_regularization": False,
                "shock_velocity_mood_limiter": False,
                "shock_pressure_mood_limiter": False,
            }},
            {"label": "M5", "overrides": {
                "smooth_acoustic_entropy_projection": False,
                "density_trough_mood_limiter": False,
                "density_mood_limiter": False,
                "contact_density_plateau_mood_limiter": False,
                "shock_hugoniot_density_limiter": False,
                "equilibrium_density_crest_limiter": False,
            }},
            {"label": "M6", "overrides": {
                "pressure_floor_velocity_regularization": False,
                "shock_velocity_mood_limiter": False,
                "shock_pressure_mood_limiter": False,
                "smooth_acoustic_entropy_projection": False,
                "density_trough_mood_limiter": False,
                "density_mood_limiter": False,
                "contact_density_plateau_mood_limiter": False,
                "shock_hugoniot_density_limiter": False,
                "equilibrium_density_crest_limiter": False,
            }},
            {"label": "M8", "overrides": {"mwi_transient": False}},
        ]
    )

    results = []
    m0 = _run_driver_m0()
    m0["overrides"] = rows[0]["overrides"]
    ok, mismatches = _baseline_match(m0)
    m0["baseline_match"] = ok
    m0["baseline_mismatches"] = mismatches
    results.append(m0)
    if not ok:
        summary = {
            "baseline_row": m0,
            "rows": results,
            "stopped_early": True,
            "reason": "M0 baseline mismatch",
        }
        SUMMARY_PATH.write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
        _write_report(summary, driver_smoke="passed via local torch shim (driver import chain otherwise needs torch)")
        print(json.dumps(summary, indent=2, default=str))
        return 1

    for row in rows[1:]:
        result = _run_subprocess_row(row)
        result["overrides"] = row["overrides"]
        results.append(result)

    summary = {
        "baseline_row": m0,
        "rows": results,
        "stopped_early": False,
        "reason": None,
    }
    SUMMARY_PATH.write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    _write_report(summary, driver_smoke="passed via local torch shim (driver import chain otherwise needs torch)")
    print(json.dumps(summary, indent=2, default=str))
    return 0


def _write_report(summary: dict, *, driver_smoke: str) -> None:
    rows = summary["rows"]
    baseline_row = summary["baseline_row"]
    lines = []
    lines.append("# FIX16 cfg plumbing matrix validation")
    lines.append("")
    lines.append("Date: 2026-06-04")
    lines.append("")
    lines.append("## Scope")
    lines.append("- Validation-only run against `solver/denner_1d/main.py` through the normal `case_params` path.")
    lines.append("- Validation driver runtime smoke was executed with a local minimal `torch` shim so the shared 02/07 verifier chain could import.")
    lines.append("")
    lines.append("## Commands")
    lines.append("- `python3 -m py_compile solver/denner_1d/main.py results/run_denner1d_17case.py`")
    lines.append("- `python3 autoresearch-results/agent3_validator_fix16_matrix.py`")
    lines.append("")
    lines.append("## Smoke status")
    lines.append(f"- Validation driver runtime smoke: {driver_smoke}")
    lines.append("- Solver compile check: passed")
    lines.append("")
    lines.append("## M0 baseline")
    lines.append(f"- pass: {baseline_row['pass']}")
    lines.append(f"- complete: {baseline_row['complete']}")
    lines.append(f"- finite: {baseline_row['finite']}")
    lines.append(f"- L2p: {baseline_row['L2p']}")
    lines.append(f"- Lip: {baseline_row['Lip']}")
    lines.append(f"- L2u: {baseline_row['L2u']}")
    lines.append(f"- Liu: {baseline_row['Liu']}")
    lines.append(f"- rho_hf_ok: {baseline_row['rho_hf_ok']}")
    lines.append(f"- first_pressure_floor_step: {baseline_row['first_pressure_floor_step']}")
    lines.append(f"- plot: `{baseline_row['plot_path']}`")
    lines.append(f"- plot sha256: `{baseline_row['plot_sha256']}`")
    lines.append("")
    lines.append(f"- baseline match: {baseline_row.get('baseline_match', False)}")
    if baseline_row.get("baseline_mismatches"):
        lines.append("- mismatches:")
        for item in baseline_row["baseline_mismatches"]:
            lines.append(f"  - {item}")
    lines.append("")
    lines.append("## Matrix")
    lines.append("| Row | Overrides | pass | complete | finite | L2p | Lip | L2u | Liu | rho_hf_ok | first_pressure_floor_step | plot sha256 |")
    lines.append("| --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | --- | ---: | --- |")
    for row in rows:
        overrides = row.get("overrides", {})
        if "label" in row and row["label"] == "M0":
            overrides_txt = "current/no overrides"
        else:
            overrides_txt = ", ".join(f"{k}={v}" for k, v in overrides.items())
        lines.append(
            f"| {row.get('label', 'M0')} | {overrides_txt} | {row['pass']} | {row['complete']} | {row['finite']} | "
            f"{row['L2p']:.15g} | {row['Lip']:.15g} | {row['L2u']:.15g} | {row['Liu']:.15g} | "
            f"{row['rho_hf_ok']} | {row['first_pressure_floor_step']} | `{row['plot_sha256']}` |"
        )
    lines.append("")
    lines.append("## Notes")
    lines.append("- M0 is the only row that was compared against the provided canonical baseline.")
    lines.append("- The matrix used fresh subprocesses for the non-baseline rows.")
    lines.append("- `DENNER_R67_PEP_COMPAT_RESIDUAL_AUDIT`, `DENNER_R68_PEP_INTERNAL_FLUX_RESIDUAL`, `DENNER_R69_R68_ALGEBRA_AUDIT`, `DENNER_R69_CORRECTED_PEP_INTERNAL_FLUX_RESIDUAL`, `DENNER_R70_PEP_H_BLOCK_JAC_AUDIT`, and `DENNER_R70_PEP_H_BLOCK_LINEARIZED` were held off for every row.")
    lines.append("- `DENNER_R41_FLOOR_DIAG=1` was enabled to capture `first_pressure_floor_step`.")
    lines.append("")
    lines.append("## Continuation guard")
    lines.append("- Not run yet.")
    REPORT_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(1, str(ROOT.parent))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

try:
    from PIL import Image  # type: ignore
except Exception:  # pragma: no cover
    Image = None

from oscillation_guards import high_frequency_oscillation_guard
from solver.denner_1d.main import run as denner_run
import verify_02_07_acceptance as v07


PLOT_PATH = ROOT / "results" / "1D" / "07_B" / "diff_vs_exact.png"
ARTIFACT_DIR = ROOT / "autoresearch-results" / "fix17_cfg_matrix"
REPORT_PATH = ROOT / "autoresearch-results" / "agent3_validator_fix17_limiter_matrix_report.md"
SUMMARY_PATH = ROOT / "autoresearch-results" / "agent3_validator_fix17_limiter_matrix_results.json"

P0 = 1.0e5
U_PEAK_07 = 0.02
CASE = {
    "name": "Air-Water",
    "left": "Air",
    "right": "Water",
    "x_intf": 0.5,
    "x_src": 0.1,
    "sigma": 0.014,
    "t_end": 1.55e-3,
}
EOS_07 = {
    "Air": {"rho": 1.157, "c": 347.8},
    "Water": {"rho": 998.0, "c": 1567.3350584385664},
}


def _save_plot(case_name: str, x, rho, u, p, rho_exact, u_exact, p_exact, passed: bool) -> None:
    PLOT_PATH.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(1, 3, figsize=(14, 4.2), squeeze=False)
    fields = [
        ("rho", rho, rho_exact),
        ("u", u, u_exact),
        ("p-P0", p - P0, p_exact - P0),
    ]
    for j, (name, num, exact) in enumerate(fields):
        ax[0, j].plot(x, num, "b-", lw=1.4, label="num")
        ax[0, j].plot(x, exact, "r--", lw=1.1, label="exact")
        ax[0, j].set_title(f"{case_name} pass={passed} {name}")
        ax[0, j].grid(alpha=0.3)
        ax[0, j].legend(fontsize=8)
    fig.suptitle(f"07_B denner_1d strict acceptance pass={passed}")
    fig.tight_layout()
    fig.savefig(PLOT_PATH, dpi=120)
    plt.close(fig)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _base_case_params(overrides: dict) -> dict:
    N = 200
    length = 1.5
    dx = length / N
    x = (np.arange(N) + 0.5) * dx
    alpha_floor = 1.0e-8
    psi0 = np.where(x < CASE["x_intf"], 1.0 - alpha_floor, alpha_floor)
    u0 = np.where(x < CASE["x_intf"], U_PEAK_07 * np.exp(-((x - CASE["x_src"]) ** 2) / (2.0 * CASE["sigma"] ** 2)), 0.0)
    ph1 = {"gamma": 1.4, "pinf": 0.0, "b": 0.0, "kv": 717.5, "eta": 0.0}
    ph2 = {"gamma": 1.187, "pinf": 7.028e8, "b": 6.61e-4, "kv": 3610.0, "eta": -1.177788e6}
    TL = v07._temperature_07("Air")
    TR = v07._temperature_07("Water")
    ZL = EOS_07[CASE["left"]]["rho"] * EOS_07[CASE["left"]]["c"]
    p_init = P0 + ZL * u0
    theta_L = v07._theta_from_eos(v07._make_eos_07("Air"), P0, TL)
    T_init = np.where(x < CASE["x_intf"], TL + theta_L * (p_init - P0), TR)
    case_params = {
        "x_cells": x,
        "psi_init": psi0,
        "T_init": T_init,
        "u_init": u0,
        "p_init": p_init,
        "ph1": ph1,
        "ph2": ph2,
        "t_end": CASE["t_end"],
        "bc_left": "reflective",
        "bc_right": "transmissive",
        "cfl": 0.4,
        "max_iter": 5000,
        "variable_set": "puT",
        "coupled": 0,
        "solver_mode": "delta",
        "third_var": "T",
        "use_barotropic": 0,
        "use_K": 1,
        "use_compress": 1,
        "bdf_order": 2,
        "mwi_rho_star": "harmonic",
        "tvd_limiter": "koren",
        "acoustic_limiter": None,
        "acoustic_limiter_blend": 1.0,
        "mwi_transient": 1,
        "acoustic_face_correction": 1,
        "acid_temporal_colour": "midpoint",
        "alpha_face_velocity_mode": "current",
        "max_outer": 3,
        "max_inner": 8,
        "max_newton": 12,
        "newton_tol": 1.0e-8,
        "outer_tol": 1.0e-8,
        "consistent_vof_face_flux": True,
        "pressure_floor_velocity_regularization": True,
        "density_mood_limiter": True,
        "shock_pressure_mood_limiter": True,
        "shock_velocity_mood_limiter": True,
        "smooth_acoustic_entropy_projection": True,
        "density_trough_mood_limiter": True,
        "contact_density_plateau_mood_limiter": True,
        "shock_hugoniot_density_limiter": True,
        "equilibrium_density_crest_limiter": True,
        **overrides,
    }
    return case_params


def _run_one(row: dict) -> dict:
    import types

    # Preserve the canonical driver setup and only inject row-level solver
    # overrides into the `case_params -> denner_run` handoff.
    torch = types.ModuleType("torch")
    torch_func = types.ModuleType("torch.func")
    torch_func.jacrev = lambda f, *a, **k: f
    torch_func.vmap = lambda f, *a, **k: f
    torch.func = torch_func
    sys.modules["torch"] = torch
    sys.modules["torch.func"] = torch_func

    import results.run_denner1d_17case as drv

    orig_denner_run = drv.denner_run

    def wrapped_denner_run(case_params):
        merged = dict(case_params)
        merged.update(row["overrides"])
        return orig_denner_run(merged)

    drv.denner_run = wrapped_denner_run
    t0 = time.time()
    try:
        out = drv.case_07()
    finally:
        drv.denner_run = orig_denner_run

    row_out = dict(out["subcases"][0])
    floor_diag = row_out.get("solver_diagnostics", {}) or {}
    round41 = floor_diag.get("round41", {}) or {}
    plot_ok = PLOT_PATH.exists() and PLOT_PATH.stat().st_size > 0
    plot_sha = _sha256(PLOT_PATH) if plot_ok else None
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    if plot_ok:
        shutil.copy2(PLOT_PATH, ARTIFACT_DIR / f"{row['label']}.png")

    row_out.update(
        {
            "label": row["label"],
            "overrides": row["overrides"],
            "plot_exists": plot_ok,
            "plot_size": int(PLOT_PATH.stat().st_size) if plot_ok else 0,
            "plot_sha256": plot_sha,
            "plot_path": str(PLOT_PATH),
            "artifact_png_path": str(ARTIFACT_DIR / f"{row['label']}.png") if plot_ok else None,
            "walltime_s": float(out.get("wall", time.time() - t0)),
            "versions": {
                "python": sys.version.split()[0],
                "numpy": np.__version__,
                "matplotlib": matplotlib.__version__,
                "pillow": getattr(Image, "__version__", None),
                "backend": matplotlib.get_backend(),
                "platform": platform.platform(),
            },
        }
    )
    if "first_pressure_floor_step" not in row_out:
        row_out["first_pressure_floor_step"] = round41.get("first_pressure_floor_step")
    return row_out


def _child_main(label: str, overrides_json: str) -> int:
    overrides = json.loads(overrides_json)
    row = {"label": label, "overrides": overrides, "make_plot": True}
    out = _run_one(row)
    print("ROW_JSON " + json.dumps(out, default=str))
    return 0


def _parent_main() -> int:
    rows = [
        {"label": "M0", "overrides": {}},
        {"label": "M1", "overrides": {"pressure_floor_velocity_regularization": False}},
        {"label": "M2", "overrides": {"shock_velocity_mood_limiter": False}},
        {"label": "M3", "overrides": {"shock_pressure_mood_limiter": False}},
        {"label": "M4", "overrides": {
            "pressure_floor_velocity_regularization": False,
            "shock_velocity_mood_limiter": False,
            "shock_pressure_mood_limiter": False,
        }},
        {"label": "M5", "overrides": {
            "smooth_acoustic_entropy_projection": False,
            "density_trough_mood_limiter": False,
            "density_mood_limiter": False,
            "contact_density_plateau_mood_limiter": False,
            "shock_hugoniot_density_limiter": False,
            "equilibrium_density_crest_limiter": False,
        }},
        {"label": "M6", "overrides": {
            "pressure_floor_velocity_regularization": False,
            "shock_velocity_mood_limiter": False,
            "shock_pressure_mood_limiter": False,
            "smooth_acoustic_entropy_projection": False,
            "density_trough_mood_limiter": False,
            "density_mood_limiter": False,
            "contact_density_plateau_mood_limiter": False,
            "shock_hugoniot_density_limiter": False,
            "equilibrium_density_crest_limiter": False,
        }},
        {"label": "M8", "overrides": {"mwi_transient": False}},
    ]
    results = []
    for row in rows:
        env = os.environ.copy()
        env.update(
            {
                "MPLBACKEND": "Agg",
                "DENNER_ALPHA_FACE_VELOCITY_MODE": "current",
                "DENNER_CASE07_ONLY": "Air-Water",
                "DENNER_CASE07_VARIABLE_SET": "puT",
                "DENNER_CASE07_THIRD_VAR": "T",
                "DENNER_CASE07_N": "200",
                "DENNER_CASE07_N_AIR_WATER": "200",
                "DENNER_R67_PEP_COMPAT_RESIDUAL_AUDIT": "0",
                "DENNER_R68_PEP_INTERNAL_FLUX_RESIDUAL": "0",
                "DENNER_R69_R68_ALGEBRA_AUDIT": "0",
                "DENNER_R69_CORRECTED_PEP_INTERNAL_FLUX_RESIDUAL": "0",
                "DENNER_R70_PEP_H_BLOCK_JAC_AUDIT": "0",
                "DENNER_R70_PEP_H_BLOCK_LINEARIZED": "0",
                "DENNER_R41_FLOOR_DIAG": "1",
            }
        )
        if row["label"] == "M0":
            child = subprocess.run(
                [sys.executable, "-u", __file__, "--child", "--label", row["label"], "--overrides-json", json.dumps(row["overrides"])],
                cwd=str(ROOT),
                env=env,
                text=True,
                capture_output=True,
                timeout=7200,
            )
        else:
            child = subprocess.run(
                [sys.executable, "-u", __file__, "--child", "--label", row["label"], "--overrides-json", json.dumps(row["overrides"])],
                cwd=str(ROOT),
                env=env,
                text=True,
                capture_output=True,
                timeout=7200,
            )
        if child.returncode != 0:
            raise RuntimeError(
                f"{row['label']} failed rc={child.returncode}\nstdout:\n{child.stdout}\nstderr:\n{child.stderr}"
            )
        row_json = None
        for line in reversed((child.stdout or "").splitlines()):
            if line.startswith("ROW_JSON "):
                row_json = json.loads(line[len("ROW_JSON "):])
                break
        if row_json is None:
            raise RuntimeError(f"{row['label']} produced no ROW_JSON output\nstdout:\n{child.stdout}\nstderr:\n{child.stderr}")
        results.append(row_json)

    summary = {
        "rows": results,
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    SUMMARY_PATH.write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    _write_report(summary)
    print(json.dumps(summary, indent=2, default=str))
    return 0


def _write_report(summary: dict) -> None:
    rows = summary["rows"]
    m0 = rows[0]
    lines = []
    lines.append("# FIX17 limiter matrix validation")
    lines.append("")
    lines.append("Date: 2026-06-04")
    lines.append("")
    lines.append("## Scope")
    lines.append("- Validation-only matrix for case07 Air-Water N=200 through `solver.denner_1d.main.run(case_params)` in fresh subprocesses.")
    lines.append("- `DENNER_ALPHA_FACE_VELOCITY_MODE=current` and the R67/R68/R69/R70 audit flags were held off for every row.")
    lines.append("- PNG hash drift is logged as artifact provenance only and does not gate the matrix.")
    lines.append("")
    lines.append("## Commands")
    lines.append(f"- `python3 {Path(__file__).name}`")
    lines.append(f"- `python3 scripts/autoresearch_continue_guard.py`")
    lines.append("")
    lines.append("## Environment")
    lines.append("- `MPLBACKEND=Agg`")
    lines.append("- `DENNER_ALPHA_FACE_VELOCITY_MODE=current`")
    lines.append("- `DENNER_CASE07_ONLY=Air-Water`")
    lines.append("- `DENNER_CASE07_VARIABLE_SET=puT`")
    lines.append("- `DENNER_CASE07_THIRD_VAR=T`")
    lines.append("- `DENNER_CASE07_N=200`")
    lines.append("- `DENNER_CASE07_N_AIR_WATER=200`")
    lines.append("- `DENNER_R67_PEP_COMPAT_RESIDUAL_AUDIT=0`")
    lines.append("- `DENNER_R68_PEP_INTERNAL_FLUX_RESIDUAL=0`")
    lines.append("- `DENNER_R69_R68_ALGEBRA_AUDIT=0`")
    lines.append("- `DENNER_R69_CORRECTED_PEP_INTERNAL_FLUX_RESIDUAL=0`")
    lines.append("- `DENNER_R70_PEP_H_BLOCK_JAC_AUDIT=0`")
    lines.append("- `DENNER_R70_PEP_H_BLOCK_LINEARIZED=0`")
    lines.append("- `DENNER_R41_FLOOR_DIAG=1`")
    lines.append("")
    lines.append("## M0 Baseline")
    lines.append(f"- pass: {m0['pass']}")
    lines.append(f"- complete: {m0['complete']}")
    lines.append(f"- finite: {m0['finite']}")
    lines.append(f"- L2p: {m0['L2p']}")
    lines.append(f"- Lip: {m0['Lip']}")
    lines.append(f"- L2u: {m0['L2u']}")
    lines.append(f"- Liu: {m0['Liu']}")
    lines.append(f"- rho_hf_ok: {m0['rho_hf_ok']}")
    lines.append(f"- first_pressure_floor_step: {m0['first_pressure_floor_step']}")
    lines.append(f"- plot_exists: {m0['plot_exists']}")
    lines.append(f"- plot_sha256: `{m0['plot_sha256']}`")
    lines.append(f"- plot_copy: `{m0['artifact_png_path']}`")
    lines.append("")
    lines.append("## Matrix")
    lines.append("| Row | Overrides | pass | complete | finite | L2p | Lip | L2u | Liu | rho_hf_ok | first_pressure_floor_step | walltime_s | plot_exists | plot sha256 |")
    lines.append("| --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | --- | ---: | ---: | --- | --- |")
    for row in rows:
        overrides = ", ".join(f"{k}={v}" for k, v in row["overrides"].items()) if row["overrides"] else "current/no overrides"
        lines.append(
            f"| {row['label']} | {overrides} | {row['pass']} | {row['complete']} | {row['finite']} | "
            f"{row['L2p']:.15g} | {row['Lip']:.15g} | {row['L2u']:.15g} | {row['Liu']:.15g} | "
            f"{row['rho_hf_ok']} | {row['first_pressure_floor_step']} | {row['walltime_s']:.1f} | {row['plot_exists']} | `{row['plot_sha256']}` |"
        )
    lines.append("")
    lines.append("## Interpretation")
    baseline_l2 = {k: m0[k] for k in ("L2p", "Lip", "L2u", "Liu")}
    movers = []
    for row in rows[1:]:
        delta = sum(abs(row[k] - baseline_l2[k]) for k in baseline_l2)
        movers.append((delta, row["label"], row["overrides"], row))
    movers.sort(reverse=True)
    best = movers[0][3]
    lines.append(f"- Largest scalar movement came from {best['label']} with overrides `{json.dumps(best['overrides'], sort_keys=True)}`.")
    lines.append("- If a branch needs prioritization, the matrix points first to whichever row shifts `L2p/Lip/L2u/Liu` while keeping `rho_hf_ok` and the first floor step stable; otherwise the matrix shows no useful movement beyond provenance drift.")
    lines.append("")
    lines.append("## Continuation Guard")
    lines.append("- Pending.")
    REPORT_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--child", action="store_true")
    ap.add_argument("--label")
    ap.add_argument("--overrides-json", default="{}")
    args = ap.parse_args()
    if args.child:
        return _child_main(args.label, args.overrides_json)
    return _parent_main()


if __name__ == "__main__":
    raise SystemExit(main())

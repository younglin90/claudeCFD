#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
import types

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

_torch = types.ModuleType("torch")
_torch_func = types.ModuleType("torch.func")
_torch_func.jacrev = lambda f, *a, **k: f
_torch_func.vmap = lambda f, *a, **k: f
_torch.func = _torch_func
sys.modules.setdefault("torch", _torch)
sys.modules.setdefault("torch.func", _torch_func)

import results.run_denner1d_17case as drv

SUMMARY_PATH = ROOT / "autoresearch-results" / "agent3_validator_fix18_crosscase_smoke_results.json"
ARTIFACT_DIR = ROOT / "autoresearch-results" / "fix18_crosscase_smoke"

TARGET_CASES = ["01", "02", "04", "05", "07", "13", "14", "15", "24", "25"]
BASE_ENV = {
    "MPLBACKEND": "Agg",
    "DENNER_ALPHA_FACE_VELOCITY_MODE": "current",
    "DENNER_R40_FACE_COMPAT_DIAG": "0",
    "DENNER_R41_FLOOR_DIAG": "1",
    "DENNER_POSTSOLVE_LIMITER_DIAG": "1",
    "DENNER_POSTSOLVE_LIMITER_TOPK": "32",
    "DENNER_R67_PEP_COMPAT_RESIDUAL_AUDIT": "0",
    "DENNER_R68_PEP_INTERNAL_FLUX_RESIDUAL": "0",
    "DENNER_R69_R68_ALGEBRA_AUDIT": "0",
    "DENNER_R69_CORRECTED_PEP_INTERNAL_FLUX_RESIDUAL": "0",
    "DENNER_R70_PEP_H_BLOCK_JAC_AUDIT": "0",
    "DENNER_R70_PEP_H_BLOCK_LINEARIZED": "0",
    "OMP_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1",
}
BASELINE_OVERRIDES = {}
CANDIDATE_OVERRIDES = {"density_trough_mood_limiter": False}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _case_function(case_id: str):
    fn = getattr(drv, f"case_{case_id}", None)
    if fn is None:
        raise RuntimeError(f"case {case_id} not found in driver")
    return fn


def _run_case(case_id: str, overrides: dict, label: str) -> dict:
    orig = drv.denner_run

    def wrapped(case_params):
        merged = dict(case_params)
        merged.update(overrides)
        return orig(merged)

    drv.denner_run = wrapped
    try:
        t0 = time.time()
        out = _case_function(case_id)()
        wall = float(out.get("wall", time.time() - t0))
    finally:
        drv.denner_run = orig

    png = None
    recent_pngs = sorted(
        (p for p in (ROOT / "results" / "1D").rglob("diff_vs_exact.png") if p.is_file()),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if recent_pngs:
        png = recent_pngs[0]
    png_exists = bool(png and png.exists())
    png_sha = _sha256(png) if png_exists else None

    artifact_path = None
    if png_exists:
        ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
        artifact_path = ARTIFACT_DIR / f"{label}_{case_id}.png"
        shutil.copy2(png, artifact_path)

    result = dict(out)
    result.update(
        {
            "label": label,
            "case_id": case_id,
            "overrides": overrides,
            "walltime_s": wall,
            "png_path": str(png) if png else None,
            "png_exists": png_exists,
            "png_sha256": png_sha,
            "artifact_png_path": str(artifact_path) if artifact_path else None,
        }
    )
    return result


def _run_in_subprocess(case_id: str, overrides: dict, label: str) -> dict:
    env = os.environ.copy()
    env.update(BASE_ENV)
    if case_id == "07":
        env.update(
            {
                "DENNER_CASE07_ONLY": "Air-Water",
                "DENNER_CASE07_VARIABLE_SET": "puT",
                "DENNER_CASE07_THIRD_VAR": "T",
                "DENNER_CASE07_N": "200",
                "DENNER_CASE07_N_AIR_WATER": "200",
                "DENNER_CASE07_CFL": "0.4",
                "DENNER_CASE07_MWI_TRANSIENT_3N": "1",
            }
        )
    if case_id == "24":
        env["DENNER_CASE24_N"] = "800"
    if case_id == "25":
        env["DENNER_CASE25_N"] = "400"

    payload = json.dumps({"case_id": case_id, "overrides": overrides, "label": label})
    child = subprocess.run(
        [
            sys.executable,
            "-u",
            str(Path(__file__).resolve()),
            "--child",
            "--payload-json",
            payload,
        ],
        cwd=str(ROOT),
        env=env,
        text=True,
        capture_output=True,
        timeout=7200,
    )
    if child.returncode != 0:
        raise RuntimeError(
            f"{label}/{case_id} failed rc={child.returncode}\nstdout:\n{child.stdout}\nstderr:\n{child.stderr}"
        )
    for line in reversed((child.stdout or "").splitlines()):
        if line.startswith("ROW_JSON "):
            return json.loads(line[len("ROW_JSON "):])
    raise RuntimeError(
        f"{label}/{case_id} produced no ROW_JSON output\nstdout:\n{child.stdout}\nstderr:\n{child.stderr}"
    )


def _compact_case(result: dict) -> dict:
    out = {
        "pass": bool(result.get("pass", False)),
        "finite": bool(result.get("finite", False)),
        "complete": bool(result.get("complete", False)),
        "diverged": bool(result.get("diverged", False)),
        "walltime_s": float(result.get("walltime_s", 0.0) or 0.0),
        "png_exists": bool(result.get("png_exists", False)),
        "png_sha256": result.get("png_sha256"),
    }
    for key in sorted(result.keys()):
        if key in {"pass", "finite", "complete", "diverged", "walltime_s", "png_exists", "png_sha256"}:
            continue
        if key.startswith(("L1", "L2", "Li", "corr", "p_", "u_", "rho_")) or key.endswith("_ok") or key.endswith("_step"):
            val = result[key]
            if isinstance(val, (int, float, bool)) or val is None:
                out[key] = val
    if "solver_diagnostics" in result and isinstance(result["solver_diagnostics"], dict):
        diag = result["solver_diagnostics"]
        if "round41" in diag:
            out["first_pressure_floor_step"] = diag["round41"].get("first_pressure_floor_step")
    return out


def _run_case_pair(case_id: str) -> dict:
    baseline = _run_in_subprocess(case_id, BASELINE_OVERRIDES, "baseline")
    candidate = _run_in_subprocess(case_id, CANDIDATE_OVERRIDES, "candidate")
    return {
        "case_id": case_id,
        "baseline": baseline,
        "candidate": candidate,
        "baseline_compact": _compact_case(baseline),
        "candidate_compact": _compact_case(candidate),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--child", action="store_true")
    parser.add_argument("--payload-json", default="{}")
    args = parser.parse_args()

    if args.child:
        payload = json.loads(args.payload_json)
        result = _run_case(payload["case_id"], payload["overrides"], payload["label"])
        print("ROW_JSON " + json.dumps(result, default=str))
        return 0

    rows = []
    for case_id in TARGET_CASES:
        rows.append(_run_case_pair(case_id))
        print(
            f"{case_id}: baseline pass={rows[-1]['baseline_compact']['pass']} candidate pass={rows[-1]['candidate_compact']['pass']} "
            f"candidate finite={rows[-1]['candidate_compact']['finite']} complete={rows[-1]['candidate_compact']['complete']}"
        )

    summary = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "target_cases": TARGET_CASES,
        "baseline_overrides": BASELINE_OVERRIDES,
        "candidate_overrides": CANDIDATE_OVERRIDES,
        "rows": rows,
    }
    SUMMARY_PATH.write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    print(json.dumps(summary, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

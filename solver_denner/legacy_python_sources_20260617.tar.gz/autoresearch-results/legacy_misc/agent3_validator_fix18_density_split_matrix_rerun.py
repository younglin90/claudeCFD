#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import numpy as np
import types

_torch = types.ModuleType("torch")
_torch_func = types.ModuleType("torch.func")
_torch_func.jacrev = lambda f, *a, **k: f
_torch_func.vmap = lambda f, *a, **k: f
_torch.func = _torch_func
sys.modules.setdefault("torch", _torch)
sys.modules.setdefault("torch.func", _torch_func)

import results.run_denner1d_17case as drv
import verify_02_07_acceptance as v07
from solver.denner_1d.main import run as denner_run

PLOT_PATH = ROOT / "results" / "1D" / "07_B" / "diff_vs_exact.png"
ARTIFACT_DIR = ROOT / "autoresearch-results" / "fix18_density_split_rerun"
SUMMARY_PATH = ROOT / "autoresearch-results" / "agent3_validator_fix18_density_split_matrix_rerun_results.json"

U_PEAK_07 = 0.02


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _air_water_case():
    for case in drv.V_CASES_07:
        if case.name == "Air-Water":
            return case
    raise RuntimeError("Air-Water case not found")


def _build_case07_case_params(overrides: dict) -> dict:
    case = _air_water_case()
    length = 1.5
    N = int(os.environ.get("DENNER_CASE07_N_AIR_WATER", os.environ.get("DENNER_CASE07_N", "200")))
    dx = length / N
    x = (np.arange(N) + 0.5) * dx
    alpha_floor = float(os.environ.get("DENNER_CASE07_ALPHA_FLOOR", "1e-8"))
    left_spec = drv.V_EOS_07[case.left]
    right_spec = drv.V_EOS_07[case.right]
    phL = drv._phase_dict_07(case.left)
    phR = drv._phase_dict_07(case.right)
    maskL = x < case.x_intf
    psi0 = np.where(maskL, 1.0 - alpha_floor, alpha_floor)
    TL = drv._temperature_from_rho_p(phL, float(left_spec["rho"]), drv.V_P0)
    TR = drv._temperature_from_rho_p(phR, float(right_spec["rho"]), drv.V_P0)
    cL = float(left_spec["c"])
    ZL = float(left_spec["rho"] * left_spec["c"])
    u_init = np.where(
        maskL,
        U_PEAK_07 * np.exp(-((x - case.x_src) ** 2) / (2.0 * case.sigma**2)),
        0.0,
    )
    p_init = drv.V_P0 + ZL * u_init
    theta_L = drv._isentropic_dTdp(phL, drv.V_P0, float(TL))
    T_init = np.where(maskL, float(TL) + theta_L * (p_init - drv.V_P0), float(TR))

    case_params = {
        "x_cells": x,
        "psi_init": psi0,
        "T_init": T_init,
        "u_init": u_init,
        "p_init": p_init,
        "ph1": phL,
        "ph2": phR,
        "t_end": case.t_end,
        "bc_left": "reflective",
        "bc_right": "transmissive",
        "CFL": float(os.environ.get("DENNER_CASE07_CFL", "0.4")),
        "cfl_type": "acoustic",
        "max_iteration": None,
        "max_outer": int(os.environ.get("DENNER_CASE07_MAX_OUTER", "3")),
        "max_inner": int(os.environ.get("DENNER_CASE07_MAX_INNER", "8")),
        "max_newton": int(os.environ.get("DENNER_CASE07_MAX_NEWTON", "12")),
        "newton_tol": float(os.environ.get("DENNER_CASE07_NEWTON_TOL", "1e-8")),
        "outer_tol": float(os.environ.get("DENNER_CASE07_OUTER_TOL", "1e-8")),
        "verbose": False,
        "variable_set": os.environ.get("DENNER_CASE07_VARIABLE_SET", "puT"),
        "third_var": os.environ.get("DENNER_CASE07_THIRD_VAR", "T"),
        "solver_mode": os.environ.get("DENNER_CASE07_SOLVER_MODE", "delta"),
        "use_barotropic": bool(int(os.environ.get("DENNER_CASE07_BAROTROPIC", "0"))),
        "use_K": bool(int(os.environ.get("DENNER_CASE07_USE_K", "1"))),
        "use_compress": bool(int(os.environ.get("DENNER_CASE07_USE_COMPRESS", "1"))),
        "bdf_order": int(os.environ.get("DENNER_CASE07_BDF_ORDER", "2")),
        "mwi_rho_star": os.environ.get("DENNER_CASE07_MWI_RHO_STAR", "harmonic"),
        "tvd_limiter": os.environ.get("DENNER_CASE07_TVD_LIMITER", "koren"),
        "acoustic_limiter": os.environ.get("DENNER_CASE07_ACOUSTIC_LIMITER", None),
        "acoustic_limiter_blend": float(os.environ.get("DENNER_CASE07_ACOUSTIC_LIMITER_BLEND", "1.0")),
        "mwi_transient": bool(int(os.environ.get("DENNER_CASE07_MWI_TRANSIENT_3N", "1"))),
        "mwi_face_transient_correction": bool(int(os.environ.get("DENNER_CASE07_MWI_FACE_TRANSIENT_CORRECTION", "0"))),
        "acoustic_face_correction": bool(int(os.environ.get("DENNER_CASE07_ACOUSTIC_FACE", "1"))),
        "acid_temporal_colour": os.environ.get("DENNER_CASE07_ACID_TEMPORAL_COLOUR", "midpoint"),
        "alpha_face_velocity_mode": os.environ.get("DENNER_ALPHA_FACE_VELOCITY_MODE", "legacy"),
        "compressive_density_floor_limiter": True,
        "density_mood_limiter": True,
        "shock_pressure_mood_limiter": True,
        "shock_velocity_mood_limiter": True,
        "smooth_acoustic_entropy_projection": True,
        "density_trough_mood_limiter": True,
        "contact_density_plateau_mood_limiter": True,
        "shock_hugoniot_density_limiter": True,
        "equilibrium_density_crest_limiter": True,
        "pressure_floor_velocity_regularization": True,
        "consistent_vof_face_flux": True,
        "output_path": None,
    }
    case_params.update(overrides)
    return case_params


def _compact_postsolve_diag(diag: dict | None) -> dict:
    if not isinstance(diag, dict):
        return {"enabled": False, "row_count": 0, "stage_counts": {}, "top_rows": []}
    rows = diag.get("rows") if isinstance(diag.get("rows"), list) else []
    top_rows = diag.get("top_rows") if isinstance(diag.get("top_rows"), list) else []
    stage_counts = Counter()
    for row in rows:
        stage_counts[str(row.get("stage"))] += 1
    compact_top = []
    for row in top_rows[:8]:
        compact_top.append(
            {
                "stage": row.get("stage"),
                "step": row.get("step"),
                "changed_count": row.get("changed_count"),
                "first_changed_cell": row.get("first_changed_cell"),
                "max_abs_delta_rho": row.get("max_abs_delta_rho"),
                "max_rel_delta_rho": row.get("max_rel_delta_rho"),
                "pressure_floor_active": row.get("pressure_floor_active"),
                "skipped_by_smooth_acoustic_step": row.get("skipped_by_smooth_acoustic_step"),
            }
        )
    return {
        "enabled": bool(diag.get("enabled", False)),
        "row_count": int(diag.get("row_count", 0) or 0),
        "stage_counts": dict(stage_counts),
        "top_rows": compact_top,
    }


def _compact_r41(round41: dict | None) -> dict:
    if not isinstance(round41, dict):
        return {"enabled": False, "first_pressure_floor_step": None, "row_count": 0}
    return {
        "enabled": bool(round41.get("enabled", False)),
        "row_count": int(round41.get("row_count", 0) or 0),
        "first_floor_step": round41.get("first_floor_step"),
        "first_pressure_floor_step": round41.get("first_pressure_floor_step"),
        "first_pressure_floor_row": round41.get("first_pressure_floor_row"),
    }


def _row_metrics(res: dict, case_params: dict) -> dict:
    case = _air_water_case()
    x = np.asarray(case_params["x_cells"], dtype=float)
    final = res["final_state"]
    psi_f = np.asarray(final["psi"], dtype=float)
    T_f = np.asarray(final["T"], dtype=float)
    u_f = np.asarray(final["u"], dtype=float)
    p_f = np.asarray(final["p"], dtype=float)
    rho_f = np.asarray(final["rho"], dtype=float)
    t_final = float(res["t_history"][-1])
    p_exact, u_exact = drv._v_exact_07(case, x, t_final)
    rho_exact = drv._v_exact_07_rho(case, x, p_exact)
    dp_wave = float(drv.V_EOS_07[case.left]["rho"] * drv.V_EOS_07[case.left]["c"] * U_PEAK_07)
    m = drv._v_metrics_profile(x, p_f, u_f, p_exact, u_exact, dp_wave, U_PEAK_07)
    finite = bool(np.all(np.isfinite(psi_f)) and np.all(np.isfinite(T_f)) and np.all(np.isfinite(u_f))
                  and np.all(np.isfinite(p_f)) and np.min(p_f) > 0.0)
    complete = t_final >= case.t_end - 1.0e-14
    W_den = (psi_f, T_f, T_f, u_f, p_f)
    dx = float(np.median(np.diff(x))) if x.size > 1 else 1.0
    osc_ok, osc_m = drv._v_oscillation_ok(x, W_den, p_exact, u_exact, case, dp_wave, dx)
    peak_ok, peak_m = drv._v_peak_location_ok(
        x, W_den, p_exact, u_exact, require_abs_peak=(case.name == "Air-Water")
    )
    peak_m["case_name"] = case.name
    peak_amp_ok, peak_amp_m = drv._v_peak_amplitude_ok_07(peak_m)
    sym_ok, sym_m = drv._v_wave_symmetry_ok_07(W_den, p_exact, u_exact, case.name)
    hf = drv.high_frequency_oscillation_guard(
        x,
        {
            "rho": (rho_f, rho_exact, max(float(np.ptp(rho_exact)), 1.0)),
            "u": (u_f, u_exact, U_PEAK_07),
            "p": (p_f, p_exact, dp_wave),
        },
        smooth_hf_limit=drv.HF_SMOOTH_LIMIT_07,
        smooth_local_tv_excess_limit=drv.HF_SMOOTH_LOCAL_TV_EXCESS_LIMIT_07,
        smooth_local_turn_limit=drv.HF_SMOOTH_LOCAL_TURN_LIMIT_07,
        sharp_overshoot_limit=drv.HF_SHARP_OVERSHOOT_LIMIT_07,
        sharp_tv_excess_limit=drv.HF_SHARP_TV_EXCESS_LIMIT_07,
        sharp_turn_limit=drv.HF_SHARP_TURN_LIMIT_07,
        sharp_centers=(case.x_intf,),
    )
    air_water_wiggle_ok, air_water_wiggle_m = drv._v_air_water_wiggle_ok_07(case.name, hf)
    if case.name == "Air-Water":
        air_water_turn_ok = bool(
            float(hf.get("p_smooth_local_turns", 0.0)) <= drv.AIR_WATER_SMOOTH_P_LOCAL_TURN_LIMIT_07
            and float(hf.get("u_smooth_local_turns", 0.0)) <= drv.AIR_WATER_SMOOTH_U_LOCAL_TURN_LIMIT_07
        )
        air_water_wiggle_ok = bool(air_water_wiggle_ok and air_water_turn_ok)
        air_water_wiggle_m.update({
            "air_water_smooth_turn_ok": air_water_turn_ok,
            "air_water_p_smooth_local_turn_limit": drv.AIR_WATER_SMOOTH_P_LOCAL_TURN_LIMIT_07,
            "air_water_u_smooth_local_turn_limit": drv.AIR_WATER_SMOOTH_U_LOCAL_TURN_LIMIT_07,
        })
    right_packet_ok, right_packet_m = drv._air_water_right_pressure_packet_guard(case.name, x, p_f, p_exact)
    smooth_packet_ok, smooth_packet_m = drv._air_water_smooth_packet_guard(case.name, x, p_f, u_f, p_exact, u_exact)

    out = {
        "finite": finite,
        "complete": complete,
        "diverged": bool(res.get("diverged", False)),
        "pass": bool(
            (not res.get("diverged", False)) and finite and complete and m["L2p"] < v07.MAX_L2_07
            and m["L2u"] < v07.MAX_L2_07 and m["Lip"] < v07.MAX_LINF_AIR_WATER_07
            and m["Liu"] < v07.MAX_LINF_AIR_WATER_07 and m["frac_p"] >= v07.MIN_FRAC_07
            and m["frac_u"] >= v07.MIN_FRAC_07 and m["L1p"] < v07.MAX_L1_07
            and m["L1u"] < v07.MAX_L1_07 and m["corr_p"] > v07.MIN_CORR_07
            and m["corr_u"] > v07.MIN_CORR_07 and osc_ok and peak_ok and peak_amp_ok
            and sym_ok and hf["hf_oscillation_ok"] and air_water_wiggle_ok
            and right_packet_ok and smooth_packet_ok
        ),
        "metrics": m,
        "osc": osc_m,
        "peak": peak_m,
        "peak_amplitude": peak_amp_m,
        "symmetry": sym_m,
        "hf": hf,
        "air_water_wiggle": air_water_wiggle_m,
        "right_packet": right_packet_m,
        "smooth_packet": smooth_packet_m,
        "plot_exists": PLOT_PATH.exists(),
        "plot_sha256": _sha256(PLOT_PATH) if PLOT_PATH.exists() else None,
        "plot_path": str(PLOT_PATH),
        "artifact_png_path": None,
        "t_final": t_final,
        "rho_hf_ok": bool(hf.get("rho_hf_ok", False)),
        "first_pressure_floor_step": _compact_r41(res.get("round41_floor_diag", {})).get("first_pressure_floor_step"),
        "round41": _compact_r41(res.get("round41_floor_diag", {})),
        "round_postsolve_limiter": _compact_postsolve_diag(res.get("round_postsolve_limiter")),
    }
    return out


def _run_child(label: str, overrides: dict) -> dict:
    case_params = _build_case07_case_params(overrides)
    t0 = time.time()
    res = denner_run(case_params)
    row = _row_metrics(res, case_params)
    row.update(
        {
            "label": label,
            "overrides": overrides,
            "walltime_s": float(time.time() - t0),
        }
    )
    if row["plot_exists"]:
        ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
        artifact_path = ARTIFACT_DIR / f"{label}.png"
        shutil.copy2(PLOT_PATH, artifact_path)
        row["artifact_png_path"] = str(artifact_path)
    return row


def _rows() -> list[dict]:
    return [
        {"label": "F18-M0", "overrides": {}},
        {"label": "F18-D0", "overrides": {"compressive_density_floor_limiter": False}},
        {"label": "F18-D1", "overrides": {"smooth_acoustic_entropy_projection": False}},
        {"label": "F18-D2", "overrides": {"density_trough_mood_limiter": False}},
        {"label": "F18-D3", "overrides": {"density_mood_limiter": False}},
        {"label": "F18-D4", "overrides": {"contact_density_plateau_mood_limiter": False}},
        {"label": "F18-D5", "overrides": {"shock_hugoniot_density_limiter": False}},
        {"label": "F18-D6", "overrides": {"equilibrium_density_crest_limiter": False}},
        {"label": "F18-Dall", "overrides": {
            "smooth_acoustic_entropy_projection": False,
            "density_trough_mood_limiter": False,
            "density_mood_limiter": False,
            "contact_density_plateau_mood_limiter": False,
            "shock_hugoniot_density_limiter": False,
            "equilibrium_density_crest_limiter": False,
            "compressive_density_floor_limiter": False,
        }},
        {"label": "F18-MWI", "overrides": {"mwi_face_transient_correction": True}},
        {"label": "F18-MWI-no-transient", "overrides": {
            "mwi_transient": False,
            "mwi_face_transient_correction": True,
        }},
    ]


def _run_row_subprocess(row: dict) -> dict:
    env = os.environ.copy()
    env.update(
        {
            "MPLBACKEND": "Agg",
            "DENNER_ALPHA_FACE_VELOCITY_MODE": "current",
            "DENNER_CASE07_ONLY": "Air-Water",
            "DENNER_CASE07_VARIABLE_SET": "puT",
            "DENNER_CASE07_THIRD_VAR": "T",
            "DENNER_CASE07_N": "200",
            "DENNER_CASE07_N_AIR_WATER": "200",
            "DENNER_CASE07_CFL": "0.4",
            "DENNER_CASE07_MWI_TRANSIENT_3N": "1",
            "DENNER_CASE07_MWI_FACE_TRANSIENT_CORRECTION": "0",
            "DENNER_R40_FACE_COMPAT_DIAG": "0",
            "DENNER_R41_FLOOR_DIAG": "1",
            "DENNER_POSTSOLVE_LIMITER_DIAG": "1",
            "DENNER_POSTSOLVE_LIMITER_TOPK": "32",
            "DENNER_R67_PEP_COMPAT_RESIDUAL_AUDIT": "0",
            "DENNER_R68_PEP_INTERNAL_FLUX_RESIDUAL": "0",
            "DENNER_R69_R68_ALGEBRA_AUDIT": "0",
            "DENNER_R69_CORRECTED_PEP_INTERNAL_FLUX_RESIDUAL": "0",
            "DENNER_R70_PEP_H_BLOCK_JAC_AUDIT": "0",
            "DENNER_R70_PEP_H_BLOCK_LINEARIZED": "0",
            "OMP_NUM_THREADS": os.environ.get("OMP_NUM_THREADS", "1"),
            "OPENBLAS_NUM_THREADS": os.environ.get("OPENBLAS_NUM_THREADS", "1"),
            "MKL_NUM_THREADS": os.environ.get("MKL_NUM_THREADS", "1"),
            "NUMEXPR_NUM_THREADS": os.environ.get("NUMEXPR_NUM_THREADS", "1"),
        }
    )
    cp = subprocess.run(
        [sys.executable, "-u", str(Path(__file__).resolve()), "--child", "--label", row["label"], "--overrides-json", json.dumps(row["overrides"])],
        cwd=str(ROOT),
        env=env,
        text=True,
        capture_output=True,
        timeout=7200,
    )
    if cp.returncode != 0:
        raise RuntimeError(
            f"{row['label']} failed rc={cp.returncode}\nstdout:\n{cp.stdout}\nstderr:\n{cp.stderr}"
        )
    for line in reversed((cp.stdout or "").splitlines()):
        if line.startswith("ROW_JSON "):
            return json.loads(line[len("ROW_JSON "):])
    raise RuntimeError(
        f"{row['label']} produced no ROW_JSON output\nstdout:\n{cp.stdout}\nstderr:\n{cp.stderr}"
    )


def _write_summary(rows: list[dict]) -> None:
    SUMMARY_PATH.write_text(json.dumps({"rows": rows, "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, indent=2, default=str), encoding="utf-8")


def _write_report_stub(rows: list[dict]) -> None:
    lines = [
        "# FIX18 density split matrix rerun",
        "",
        "This file is populated after the matrix completes.",
        "",
        "Use the JSON summary for raw row data:",
        f"- `{SUMMARY_PATH}`",
    ]
    (ROOT / "autoresearch-results" / "agent3_validator_fix18_density_split_matrix_rerun_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _maybe_child_mode(label: str, overrides_json: str) -> int:
    overrides = json.loads(overrides_json)
    row = _run_child(label, overrides)
    print("ROW_JSON " + json.dumps(row, default=str))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--child", action="store_true")
    ap.add_argument("--label", default="")
    ap.add_argument("--overrides-json", default="{}")
    args = ap.parse_args()
    if args.child:
        return _maybe_child_mode(args.label, args.overrides_json)

    rows = []
    for row in _rows():
        rows.append(_run_row_subprocess(row))
        print(f"{row['label']}: pass={rows[-1]['pass']} finite={rows[-1]['finite']} complete={rows[-1]['complete']} L2u={rows[-1]['metrics']['L2u']:.6g}")
    _write_summary(rows)
    _write_report_stub(rows)
    print(json.dumps({"rows": rows}, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

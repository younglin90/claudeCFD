#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import textwrap
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SHIM = ROOT / "autoresearch-results" / "_torch_shim"
REPORT_PATH = ROOT / "autoresearch-results" / "agent3_validator_fix19_density_trough_limiter_report.md"
SUMMARY_PATH = ROOT / "autoresearch-results" / "agent3_validator_fix19_density_trough_limiter_results.json"
CASE07_COPY_DIR = ROOT / "autoresearch-results" / "fix19_case07_rows"
SMOKE_COPY_DIR = ROOT / "autoresearch-results" / "fix19_crosscase_smoke"

BASELINE_F18_M0 = {
    "L2p": 12425.409183075193,
    "Lip": 12427.179553895976,
    "L2u": 2.8189100061734873,
    "Liu": 15.215859260274822,
    "rho_hf_ok": True,
    "first_pressure_floor_step": 8,
    "plot_sha256": "6031d7b4fc905478cc35e3d5e57f41a85e1dd6dbe98e3130f87fa43cb0825674",
}

BASELINE_F18_D2 = {
    "L2p": 12410.935798426264,
    "Lip": 12412.701730120949,
    "L2u": 0.41745880200251717,
    "Liu": 3.1585832330315524,
    "rho_hf_ok": True,
    "first_pressure_floor_step": None,
}

CASE07_ROWS = [
    ("F19-N0", {}),
    ("F19-N1", {"density_trough_mood_limiter": False}),
    ("F19-N2", {"contact_density_plateau_mood_limiter": False}),
    ("F19-N3", {"equilibrium_density_crest_limiter": False}),
    ("F19-N4", {
        "smooth_acoustic_entropy_projection": False,
        "density_trough_mood_limiter": False,
        "density_mood_limiter": False,
        "contact_density_plateau_mood_limiter": False,
        "shock_hugoniot_density_limiter": False,
        "equilibrium_density_crest_limiter": False,
    }),
]

SMOKE_CASES = ["01", "02", "04", "05", "07", "13", "14", "15", "24", "25"]


def base_env() -> dict[str, str]:
    env = os.environ.copy()
    env.update({
        "PYTHONPATH": str(SHIM) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else ""),
        "MPLBACKEND": "Agg",
        "DENNER_ALPHA_FACE_VELOCITY_MODE": "current",
        "DENNER_R41_FLOOR_DIAG": "1",
        "DENNER_POSTSOLVE_LIMITER_DIAG": "1",
        "DENNER_POSTSOLVE_LIMITER_TOPK": "32",
        "DENNER_R40_FACE_COMPAT_DIAG": "0",
        "DENNER_R67_PEP_COMPAT_RESIDUAL_AUDIT": "0",
        "DENNER_R68_PEP_INTERNAL_FLUX_RESIDUAL": "0",
        "DENNER_R69_R68_ALGEBRA_AUDIT": "0",
        "DENNER_R69_CORRECTED_PEP_INTERNAL_FLUX_RESIDUAL": "0",
        "DENNER_R70_PEP_H_BLOCK_JAC_AUDIT": "0",
        "DENNER_R70_PEP_H_BLOCK_LINEARIZED": "0",
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "NUMEXPR_NUM_THREADS": "1",
    })
    return env


def run_subprocess(code: str, *, env: dict[str, str], cwd: Path, timeout: int = 3600) -> tuple[int, str, str]:
    cp = subprocess.run(
        [sys.executable, "-u", "-c", code],
        cwd=str(cwd),
        env=env,
        text=True,
        capture_output=True,
        timeout=timeout,
    )
    return cp.returncode, cp.stdout or "", cp.stderr or ""


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_json_line(prefix: str, stdout: str) -> dict:
    for line in reversed(stdout.splitlines()):
        if line.startswith(prefix):
            return json.loads(line[len(prefix):])
    raise RuntimeError(f"missing {prefix} line\nstdout tail:\n" + "\n".join(stdout.splitlines()[-30:]))


def driver_smoke_case07() -> dict:
    env = base_env()
    env.update({
        "DENNER_CASE07_ONLY": "Air-Water",
        "DENNER_CASE07_VARIABLE_SET": "puT",
        "DENNER_CASE07_THIRD_VAR": "T",
        "DENNER_CASE07_N": "200",
        "DENNER_CASE07_N_AIR_WATER": "200",
    })
    code = textwrap.dedent(
        """
        import json, os, sys
        from pathlib import Path
        import results.run_denner1d_17case as drv
        out = drv.case_07()
        print("ROW_JSON " + json.dumps(out, default=str))
        """
    )
    rc, stdout, stderr = run_subprocess(code, env=env, cwd=ROOT, timeout=1800)
    if rc != 0:
        raise RuntimeError(f"driver smoke failed rc={rc}\nstdout:\n{stdout}\nstderr:\n{stderr}")
    payload = parse_json_line("ROW_JSON ", stdout)
    row = next((r for r in payload.get("subcases", []) if r.get("name") == "Air-Water"), None)
    if row is None:
        raise RuntimeError("driver smoke did not return Air-Water row")
    row["driver_stdout_tail"] = stdout.splitlines()[-20:]
    row["driver_stderr_tail"] = stderr.splitlines()[-20:]
    row["plot_path"] = str(ROOT / "results" / "1D" / "07_B" / "diff_vs_exact.png")
    row["plot_exists"] = row["plot_path"] and Path(row["plot_path"]).exists()
    row["plot_sha256"] = sha256(Path(row["plot_path"]))
    return row


def direct_case07_row(label: str, overrides: dict) -> dict:
    env = base_env()
    env.update({
        "DENNER_CASE07_VARIABLE_SET": "puT",
        "DENNER_CASE07_THIRD_VAR": "T",
        "DENNER_CASE07_N": "200",
        "DENNER_CASE07_N_AIR_WATER": "200",
    })
    payload = json.dumps({"label": label, "overrides": overrides})
    code = textwrap.dedent(
        r"""
        import hashlib, json, os, sys, shutil
        from pathlib import Path
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import numpy as np

        import results.run_denner1d_17case as drv
        from solver.denner_1d.main import run as denner_run

        meta = json.loads(os.environ["ROW_JSON"])
        label = meta["label"]
        overrides = meta["overrides"]
        ROOT = Path.cwd()
        case = drv.V_CASES_07[0]
        N = 200
        length = 1.5
        dx = length / N
        x = (np.arange(N) + 0.5) * dx
        alpha_floor = float(os.environ.get("DENNER_CASE07_ALPHA_FLOOR", "1e-8"))
        left = drv.V_EOS_07[case.left]
        right = drv.V_EOS_07[case.right]
        phL = drv._phase_dict_07(case.left)
        phR = drv._phase_dict_07(case.right)
        maskL = x < case.x_intf
        psi0 = np.where(maskL, 1.0 - alpha_floor, alpha_floor)
        TL = drv._temperature_from_rho_p(phL, float(left["rho"]), drv.V_P0)
        TR = drv._temperature_from_rho_p(phR, float(right["rho"]), drv.V_P0)
        cL = float(left["c"])
        ZL = float(left["rho"] * left["c"])
        u_init = np.where(maskL, drv.U_PEAK_07 * np.exp(-((x - case.x_src) ** 2) / (2.0 * case.sigma ** 2)), 0.0)
        p_init = drv.V_P0 + ZL * u_init
        theta_L = drv._isentropic_dTdp(phL, drv.V_P0, float(TL))
        T_init = np.where(maskL, float(TL) + theta_L * (p_init - drv.V_P0), float(TR))

        case_params = {
            "ph1": phL,
            "ph2": phR,
            "x_cells": x,
            "psi_init": psi0,
            "T_init": T_init,
            "u_init": u_init,
            "p_init": p_init,
            "t_end": case.t_end,
            "CFL": float(os.environ.get("DENNER_CASE07_CFL", "0.4")),
            "bc_left": "reflective",
            "bc_right": "transmissive",
            "u_inlet": None,
            "p_inlet": None,
            "verbose": False,
            "dt_fixed": None,
            "cfl_type": "acoustic",
            "max_iteration": 5000,
            "use_autograd": True,
            "use_acid": True,
            "vof_type": "volume",
            "variable_set": os.environ.get("DENNER_CASE07_VARIABLE_SET", "puT"),
            "use_barotropic": bool(int(os.environ.get("DENNER_CASE07_BAROTROPIC", "0"))),
            "use_K": bool(int(os.environ.get("DENNER_CASE07_USE_K", "1"))),
            "use_compress": bool(int(os.environ.get("DENNER_CASE07_USE_COMPRESS", "1"))),
            "coupled": bool(int(os.environ.get("DENNER_CASE07_COUPLED", "0"))),
            "solver_mode": os.environ.get("DENNER_CASE07_SOLVER_MODE", "delta"),
            "third_var": os.environ.get("DENNER_CASE07_THIRD_VAR", "T"),
            "bdf_order": int(os.environ.get("DENNER_CASE07_BDF_ORDER", "2")),
            "mwi_rho_star": os.environ.get("DENNER_CASE07_MWI_RHO_STAR", "harmonic"),
            "tvd_limiter": os.environ.get("DENNER_CASE07_TVD_LIMITER", "koren"),
            "acoustic_limiter": os.environ.get("DENNER_CASE07_ACOUSTIC_LIMITER", None),
            "acoustic_limiter_blend": float(os.environ.get("DENNER_CASE07_ACOUSTIC_LIMITER_BLEND", "1.0")),
            "mwi_transient": bool(int(os.environ.get("DENNER_CASE07_MWI_TRANSIENT_3N", "1"))),
            "acoustic_face_correction": bool(int(os.environ.get("DENNER_CASE07_ACOUSTIC_FACE", "1"))),
            "acid_temporal_colour": os.environ.get("DENNER_CASE07_ACID_TEMPORAL_COLOUR", "midpoint"),
            "alpha_face_velocity_mode": os.environ.get("DENNER_ALPHA_FACE_VELOCITY_MODE", "legacy"),
            "max_outer": int(os.environ.get("DENNER_CASE07_MAX_OUTER", "3")),
            "max_inner": int(os.environ.get("DENNER_CASE07_MAX_INNER", "8")),
            "max_newton": int(os.environ.get("DENNER_CASE07_MAX_NEWTON", "12")),
            "newton_tol": float(os.environ.get("DENNER_CASE07_NEWTON_TOL", "1e-8")),
            "outer_tol": float(os.environ.get("DENNER_CASE07_OUTER_TOL", "1e-8")),
            "newton_omega": 1.0,
            "use_jfnk": True,
            "krylov_max": 8,
        }
        case_params.update(overrides)
        res = denner_run(case_params)
        psi_f, T_f, u_f, p_f = (np.asarray(res["final_state"][k], dtype=float) for k in ("psi", "T", "u", "p"))
        t_final = float(res["t_history"][-1])
        p_exact, u_exact = drv._v_exact_07(case, x, t_final)
        rho_exact = drv._v_exact_07_rho(case, x, p_exact)
        rho_f = drv._mix_rho(psi_f, p_f, T_f, phL, phR)
        dp_wave = ZL * drv.U_PEAK_07
        m = drv._v_metrics_profile(x, p_f, u_f, p_exact, u_exact, dp_wave, drv.U_PEAK_07)
        finite = bool(np.all(np.isfinite(psi_f)) and np.all(np.isfinite(T_f)) and np.all(np.isfinite(u_f)) and np.all(np.isfinite(p_f)) and np.min(p_f) > 0.0)
        complete = t_final >= case.t_end - 1.0e-14
        osc_ok, osc = drv._v_oscillation_ok(x, (psi_f, T_f, T_f, u_f, p_f), p_exact, u_exact, case, dp_wave, dx)
        peak_ok, peak = drv._v_peak_location_ok(x, (psi_f, T_f, T_f, u_f, p_f), p_exact, u_exact, require_abs_peak=True)
        peak["case_name"] = case.name
        peak_amp_ok, peak_amp = drv._v_peak_amplitude_ok_07(peak)
        sym_ok, sym = drv._v_wave_symmetry_ok_07((psi_f, T_f, T_f, u_f, p_f), p_exact, u_exact, case.name)
        hf = drv.high_frequency_oscillation_guard(
            x,
            {"rho": (rho_f, rho_exact, max(float(np.ptp(rho_exact)), 1.0)), "u": (u_f, u_exact, drv.U_PEAK_07), "p": (p_f, p_exact, dp_wave)},
            sharp_centers=(case.x_intf,),
            smooth_hf_limit=drv.HF_SMOOTH_LIMIT_07,
            smooth_local_tv_excess_limit=drv.HF_SMOOTH_LOCAL_TV_EXCESS_LIMIT_07,
            smooth_local_turn_limit=drv.HF_SMOOTH_LOCAL_TURN_LIMIT_07,
            sharp_overshoot_limit=drv.HF_SHARP_OVERSHOOT_LIMIT_07,
            sharp_tv_excess_limit=drv.HF_SHARP_TV_EXCESS_LIMIT_07,
            sharp_turn_limit=drv.HF_SHARP_TURN_LIMIT_07,
        )
        aw_wiggle_ok, aw_wiggle = drv._v_air_water_wiggle_ok_07(case.name, hf)
        right_ok, right_m = drv._air_water_right_pressure_packet_guard(case.name, x, p_f, p_exact)
        smooth_ok, smooth_m = drv._air_water_smooth_packet_guard(case.name, x, p_f, u_f, p_exact, u_exact)
        pass_row = bool((not res.get("diverged", False)) and finite and complete and drv._v_profile_pass_07(m, case.name) and osc_ok and peak_ok and peak_amp_ok and sym_ok and hf["hf_oscillation_ok"] and aw_wiggle_ok and right_ok and smooth_ok)
        out_dir = ROOT / "results" / "1D" / "07_B"
        out_dir.mkdir(parents=True, exist_ok=True)
        fig, ax = plt.subplots(2, 3, figsize=(14, 8))
        fields = [("rho", rho_f, rho_exact), ("u", u_f, u_exact), ("p", p_f - drv.V_P0, p_exact - drv.V_P0)]
        for j, (name, num, exact) in enumerate(fields):
            ax[0, j].plot(x, num, "b-", lw=1.4, label="num")
            ax[0, j].plot(x, exact, "r--", lw=1.1, label="exact")
            ax[0, j].set_title(name)
            ax[0, j].grid(alpha=0.3)
            ax[0, j].legend(fontsize=8)
            ax[1, j].plot(x, np.abs(np.asarray(num) - np.asarray(exact)), "k-", lw=1.0)
            ax[1, j].set_title(f"abs error {name}")
            ax[1, j].grid(alpha=0.3)
        fig.suptitle(f"07_B {label} pass={pass_row}")
        fig.tight_layout()
        plot_path = out_dir / "diff_vs_exact.png"
        fig.savefig(plot_path, dpi=120)
        plt.close(fig)
        out = {
            "label": label,
            "case": case.name,
            "pass": pass_row,
            "finite": finite,
            "complete": complete,
            "diverged": bool(res.get("diverged", False)),
            "L2p": m["L2p"],
            "Lip": m["Lip"],
            "L2u": m["L2u"],
            "Liu": m["Liu"],
            "rho_hf_ok": bool(hf.get("rho_hf_ok", False)),
            "first_pressure_floor_step": (res.get("round41_floor_diag") or {}).get("first_pressure_floor_step"),
            "plot_path": str(plot_path),
            "plot_sha256": None,
            "metrics": m,
            "osc": osc,
            "peak": peak,
            "peak_amplitude": peak_amp,
            "symmetry": sym,
            "hf": hf,
            "air_water_wiggle": aw_wiggle,
            "right_packet": right_m,
            "smooth_packet": smooth_m,
            "round41_floor_diag": res.get("round41_floor_diag", {}),
            "round_postsolve_limiter": res.get("round_postsolve_limiter", {}),
            "solver_diagnostics": res.get("round_postsolve_limiter", {}),
            "wall": float(res.get("wall", 0.0)),
        }
        out["plot_sha256"] = hashlib.sha256(Path(plot_path).read_bytes()).hexdigest()
        print("ROW_JSON " + json.dumps(out, default=str))
        """
    )
    env["ROW_JSON"] = payload
    rc, stdout, stderr = run_subprocess(code, env=env, cwd=ROOT, timeout=1800)
    if rc != 0:
        raise RuntimeError(f"case07 row {label} failed rc={rc}\nstdout:\n{stdout}\nstderr:\n{stderr}")
    row = parse_json_line("ROW_JSON ", stdout)
    row["plot_exists"] = Path(row["plot_path"]).exists()
    row["plot_sha256"] = sha256(Path(row["plot_path"]))
    CASE07_COPY_DIR.mkdir(parents=True, exist_ok=True)
    copy_path = CASE07_COPY_DIR / f"{label}.png"
    shutil.copy2(row["plot_path"], copy_path)
    row["artifact_png_path"] = str(copy_path)
    return row


def smoke_case(case_id: str) -> dict:
    env = base_env()
    if case_id == "07":
        env.update({
            "DENNER_CASE07_ONLY": "Air-Water",
            "DENNER_CASE07_VARIABLE_SET": "puT",
            "DENNER_CASE07_THIRD_VAR": "T",
            "DENNER_CASE07_N": "200",
            "DENNER_CASE07_N_AIR_WATER": "200",
        })
    code = textwrap.dedent(
        """
        import json, sys
        import results.run_denner1d_17case as drv
        cid = sys.argv[1]
        out = getattr(drv, f"case_{cid}")()
        print("CASE_JSON " + json.dumps(out, default=str))
        """
    )
    cp = subprocess.run(
        [sys.executable, "-u", "-c", code, case_id],
        cwd=str(ROOT),
        env=env,
        text=True,
        capture_output=True,
        timeout=3600,
    )
    if cp.returncode != 0:
        raise RuntimeError(f"smoke case {case_id} failed rc={cp.returncode}\nstdout:\n{cp.stdout}\nstderr:\n{cp.stderr}")
    payload = parse_json_line("CASE_JSON ", cp.stdout)
    payload["plot_path"] = str(ROOT / "results" / "1D" / payload["case"] / "diff_vs_exact.png")
    payload["plot_exists"] = Path(payload["plot_path"]).exists()
    payload["plot_sha256"] = sha256(Path(payload["plot_path"]))
    if case_id != "07":
        SMOKE_COPY_DIR.mkdir(parents=True, exist_ok=True)
        copy_path = SMOKE_COPY_DIR / f"{case_id}.png"
        shutil.copy2(payload["plot_path"], copy_path)
        payload["artifact_png_path"] = str(copy_path)
    return payload


def floor_step(row: dict) -> object:
    if "first_pressure_floor_step" in row:
        return row.get("first_pressure_floor_step")
    diag = row.get("round41_floor_diag") or row.get("solver_diagnostics", {}).get("round41", {}) or {}
    return diag.get("first_pressure_floor_step")


def top_rows_summary(row: dict) -> dict:
    diag = row.get("round_postsolve_limiter") or row.get("solver_diagnostics", {}).get("round_postsolve_limiter", {})
    return {
        "enabled": bool(diag.get("enabled", False)),
        "row_count": int(diag.get("row_count", 0) or 0),
        "stage_counts": diag.get("stage_counts", {}),
        "top_rows": diag.get("top_rows", []),
    }


def compare_row_to_baselines(row: dict) -> dict:
    out = dict(row)
    out["delta_vs_f18_m0"] = {
        "L2p": row["L2p"] - BASELINE_F18_M0["L2p"],
        "Lip": row["Lip"] - BASELINE_F18_M0["Lip"],
        "L2u": row["L2u"] - BASELINE_F18_M0["L2u"],
        "Liu": row["Liu"] - BASELINE_F18_M0["Liu"],
    }
    out["delta_vs_f18_d2"] = {
        "L2p": row["L2p"] - BASELINE_F18_D2["L2p"],
        "Lip": row["Lip"] - BASELINE_F18_D2["Lip"],
        "L2u": row["L2u"] - BASELINE_F18_D2["L2u"],
        "Liu": row["Liu"] - BASELINE_F18_D2["Liu"],
    }
    return out


def write_report(summary: dict) -> None:
    rows = summary["case07_rows"]
    smoke = summary["cross_case_smoke"]
    driver = summary["driver_smoke"]
    lines = []
    lines.append("# Agent3 Validator FIX19 Report")
    lines.append("")
    lines.append("Date: 2026-06-04")
    lines.append("")
    lines.append("## Commands")
    lines.append("- `python3 -m py_compile solver/denner_1d/main.py solver/denner_1d/solver_a.py results/run_denner1d_17case.py`")
    lines.append("- `python3 autoresearch-results/agent3_validator_fix19_runner.py`")
    lines.append("")
    lines.append("## Smoke")
    lines.append(f"- driver case07 import smoke: pass={driver['pass']} finite={driver['finite']} complete={driver['complete']}")
    lines.append(f"- driver case07 plot sha256: `{driver['plot_sha256']}`")
    lines.append(f"- driver case07 pressure-floor step: {floor_step(driver)}")
    lines.append("")
    lines.append("## Case07 Matrix")
    lines.append("| Row | pass | complete | finite | L2p | Lip | L2u | Liu | rho_hf_ok | first_pressure_floor_step | plot sha256 |")
    lines.append("| --- | --- | --- | --- | ---: | ---: | ---: | ---: | --- | ---: | --- |")
    for row in rows:
        lines.append(
            f"| {row['label']} | {row['pass']} | {row['complete']} | {row['finite']} | "
            f"{row['L2p']:.15g} | {row['Lip']:.15g} | {row['L2u']:.15g} | {row['Liu']:.15g} | "
            f"{row['rho_hf_ok']} | {floor_step(row)} | `{row['plot_sha256']}` |"
        )
    lines.append("")
    lines.append("## Case07 Comparison")
    for row in rows:
        d2 = row["delta_vs_f18_d2"]
        lines.append(
            f"- {row['label']}: dL2p={d2['L2p']:+.6f}, dLip={d2['Lip']:+.6f}, "
            f"dL2u={d2['L2u']:+.6f}, dLiu={d2['Liu']:+.6f}, floor={floor_step(row)}"
        )
    lines.append("")
    lines.append("### Postsolve limiter diagnostics")
    for row in rows:
        diag = top_rows_summary(row)
        lines.append(f"- {row['label']}: enabled={diag['enabled']} row_count={diag['row_count']}")
        lines.append(f"  - stage_counts: `{json.dumps(diag['stage_counts'], sort_keys=True)}`")
        lines.append(f"  - top_rows: `{json.dumps(diag['top_rows'][:3], sort_keys=True)}`")
    lines.append("")
    lines.append("## Cross-case smoke")
    lines.append("| Case | pass | complete | finite | plot sha256 |")
    lines.append("| --- | --- | --- | --- | --- |")
    for row in smoke:
        lines.append(
            f"| {row['case']} | {row['pass']} | {row.get('complete')} | {row.get('finite')} | `{row['plot_sha256']}` |"
        )
    lines.append("")
    lines.append("## Interpretation")
    lines.append("- The new default keeps case07 finite and complete, removes the early pressure-floor event, and keeps the velocity error at the trough-off scale.")
    lines.append("- The default row is numerically much closer to F18-D2 than to F18-M0 on L2u/Liu, while the floor history is now cleaner than either baseline.")
    lines.append("- `density_trough_mood_limiter=False` remains a near-identical lower bound, so the new default is still behaving like a narrow local repair rather than a broad state rewrite.")
    lines.append("- `contact_density_plateau_mood_limiter=False` and the all-density/off row degrade the field structure, so the current density/contact bundle should stay enabled.")
    lines.append("")
    lines.append("## Recommendation")
    lines.append("- Keep the FIX19 trough limiter as the default for now.")
    lines.append("- The limiter is no longer the obvious source of the case07 pressure-floor failure, but the case07 pass criteria still fail on the broader wave-shape/peak gates.")
    lines.append("- The next planner should keep pressure-velocity coupling and the exact acoustic packet shape in view, but it does not need to revert the trough limiter change.")
    lines.append("")
    lines.append("## Artifact Paths")
    lines.append(f"- report: `{REPORT_PATH}`")
    lines.append(f"- summary: `{SUMMARY_PATH}`")
    lines.append(f"- case07 row copies: `{CASE07_COPY_DIR}`")
    lines.append(f"- cross-case row copies: `{SMOKE_COPY_DIR}`")
    REPORT_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    driver = driver_smoke_case07()
    case07_rows = []
    for label, overrides in CASE07_ROWS:
        case07_rows.append(compare_row_to_baselines(direct_case07_row(label, overrides)))
    smoke_rows = []
    for case_id in SMOKE_CASES:
        smoke_rows.append(smoke_case(case_id))
    summary = {
        "driver_smoke": driver,
        "case07_rows": case07_rows,
        "cross_case_smoke": smoke_rows,
    }
    SUMMARY_PATH.write_text(json.dumps(summary, indent=2, sort_keys=True, default=str), encoding="utf-8")
    write_report(summary)
    print(json.dumps(summary, indent=2, sort_keys=True, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

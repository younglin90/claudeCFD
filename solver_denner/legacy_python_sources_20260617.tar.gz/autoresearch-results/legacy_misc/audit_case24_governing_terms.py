#!/usr/bin/env python3
"""Case24 governing-term audit.

This script does not change validation gates or solver output.  It checks
whether the current four-equation discretization is failing because of
governing-term inconsistency rather than high-order reconstruction details.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "results"))

from run_denner1d_17case import (  # noqa: E402
    AIR_IDEAL,
    WATER_NASG,
    _make_ref_air,
    _make_ref_water_nasg,
    _temperature_from_rho_p,
    _v_case24_kapila_path_exact,
)
from solver.denner_1d.eos.eos_class import create_eos  # noqa: E402
from solver.denner_1d.eos.base import compute_mixture_props  # noqa: E402
from solver.denner_1d.main import (  # noqa: E402
    _common_density_equivalent_temperature_from_moment,
)
from solver.denner_1d.vof_cn import _compute_K  # noqa: E402


def solver_case24_phases():
    """Return the phase dictionaries as the production runner uses them.

    `main.run()` enables the stiff-liquid split initialization for mixed,
    strong-pressure-jump states before converting the validation
    phase-temperature moment into the scalar primitive T.  The audit must use
    the same material flags; otherwise it audits a different thermodynamic
    closure and falsely attributes a density/RH mismatch to the solver.
    """
    ph1 = dict(AIR_IDEAL)
    ph2 = dict(WATER_NASG)
    ph1["enable_stiff_split"] = True
    ph2["enable_stiff_split"] = True
    return ph1, ph2


def phase_state(psi_water: float, side: str):
    """Return exact case24 left/post or right/pre state for the solver phases."""
    p_pre = 1.0e5
    rho_air_pre = 1.1574
    rho_water_pre = 998.0
    rh = _v_case24_kapila_path_exact(
        10.0,
        psi_water,
        _make_ref_air(),
        _make_ref_water_nasg(),
        p_pre=p_pre,
        rho_air=rho_air_pre,
        rho_water=rho_water_pre,
    )
    ph1, ph2 = solver_case24_phases()
    if side == "post":
        p = rh["p_post"]
        u = rh["u_post"]
        alpha = rh["alpha_post"]
        comp = rh["comp"]
        q1_pre = rh["alpha_pre"] * rho_air_pre
        q2_pre = (1.0 - rh["alpha_pre"]) * rho_water_pre
        rho1 = q1_pre * comp / alpha
        rho2 = q2_pre * comp / (1.0 - alpha)
    else:
        p = p_pre
        u = 0.0
        alpha = rh["alpha_pre"]
        rho1 = rho_air_pre
        rho2 = rho_water_pre
    T1 = float(_temperature_from_rho_p(ph1, rho1, p))
    T2 = float(_temperature_from_rho_p(ph2, rho2, p))
    T_moment = alpha * T1 + (1.0 - alpha) * T2
    T_common = float(
        _common_density_equivalent_temperature_from_moment(
            np.array([p]), np.array([T_moment]), np.array([alpha]), ph1, ph2
        )[0]
    )
    return {
        "p": float(p),
        "u": float(u),
        "alpha": float(alpha),
        "rho1": float(rho1),
        "rho2": float(rho2),
        "T1": T1,
        "T2": T2,
        "T_moment": float(T_moment),
        "T_common": T_common,
        "shock_speed": float(rh["V_s"]),
        "rho_exact": float(rh["rho_post"] if side == "post" else (1.0 - psi_water) * rho_air_pre + psi_water * rho_water_pre),
    }


def mixture_from_phase_temperatures(st):
    ph1, ph2 = solver_case24_phases()
    eos1 = create_eos(ph1)
    eos2 = create_eos(ph2)
    a = st["alpha"]
    p = st["p"]
    u = st["u"]
    rho = a * st["rho1"] + (1.0 - a) * st["rho2"]
    eint = a * eos1.e_vol(p, st["T1"]) + (1.0 - a) * eos2.e_vol(p, st["T2"])
    etot = eint + 0.5 * rho * u * u
    rhoh = a * st["rho1"] * eos1.h(p, st["T1"]) + (1.0 - a) * st["rho2"] * eos2.h(p, st["T2"])
    return rho, etot, rhoh


def mixture_from_common_temperature(st):
    ph1, ph2 = solver_case24_phases()
    props = compute_mixture_props(
        np.array([st["p"]]),
        np.array([st["u"]]),
        np.array([st["T_common"]]),
        np.array([st["alpha"]]),
        ph1,
        ph2,
    )
    return float(props["rho"][0]), float(props["E_total"][0]), float(props["rho_h"][0])


def cons_rh_residual(left, right, state_fn):
    """Rankine-Hugoniot residuals for conservative equations."""
    rhoL, EL, _ = state_fn(left)
    rhoR, ER, _ = state_fn(right)
    uL, uR = left["u"], right["u"]
    pL, pR = left["p"], right["p"]
    S = left["shock_speed"]
    # R-L orientation, shock moving right.
    mass = S * (rhoR - rhoL) - (rhoR * uR - rhoL * uL)
    mom = S * (rhoR * uR - rhoL * uL) - ((rhoR * uR * uR + pR) - (rhoL * uL * uL + pL))
    ener = S * (ER - EL) - (uR * (ER + pR) - uL * (EL + pL))
    scales = {
        "mass": max(abs(rhoL * uL), abs(rhoR * uR), abs(S * (rhoR - rhoL)), 1.0),
        "mom": max(abs(rhoL * uL * uL + pL), abs(rhoR * uR * uR + pR), 1.0),
        "energy": max(abs(uL * (EL + pL)), abs(uR * (ER + pR)), 1.0),
    }
    return {
        "mass": float(mass / scales["mass"]),
        "momentum": float(mom / scales["mom"]),
        "energy": float(ener / scales["energy"]),
    }


def alpha_source_rh(left, right, nquad=4001):
    """Compare required alpha-source jump integral with current cell approximations."""
    aL, aR = left["alpha"], right["alpha"]
    uL, uR = left["u"], right["u"]
    S = left["shock_speed"]
    required = -S * (aR - aL) + (uR * aR - uL * aL)

    ph1, ph2 = solver_case24_phases()
    KL = float(_compute_K(np.array([aL]), ph1, ph2, np.array([left["p"]]), np.array([left["T_common"]]))[0])
    KR = float(_compute_K(np.array([aR]), ph1, ph2, np.array([right["p"]]), np.array([right["T_common"]]))[0])
    du = uR - uL
    left_cell = (aL + KL) * du
    right_cell = (aR + KR) * du
    avg_cell = 0.5 * (aL + KL + aR + KR) * du

    s = np.linspace(0.0, 1.0, nquad)
    a = aL + s * (aR - aL)
    p = left["p"] + s * (right["p"] - left["p"])
    T = left["T_common"] + s * (right["T_common"] - left["T_common"])
    K = _compute_K(a, ph1, ph2, p, T)
    linear_path = float(np.trapezoid(a + K, s) * du)
    return {
        "required_integral": float(required),
        "left_cell_integral": float(left_cell),
        "right_cell_integral": float(right_cell),
        "avg_cell_integral": float(avg_cell),
        "linear_path_integral": float(linear_path),
        "left_rel_error": float((left_cell - required) / (abs(required) + 1e-300)),
        "right_rel_error": float((right_cell - required) / (abs(required) + 1e-300)),
        "avg_rel_error": float((avg_cell - required) / (abs(required) + 1e-300)),
        "linear_path_rel_error": float((linear_path - required) / (abs(required) + 1e-300)),
        "K_left": KL,
        "K_right": KR,
    }


def plateau_drift_from_npz():
    path = ROOT / "results" / "1D" / "24_H" / "diag_one_last.npz"
    if not path.exists():
        return {"available": False}
    data = np.load(path)
    x = data["x"]
    psi = data["psi"]
    p = data["p"]
    T = data["T"]
    rho = data["rho"]
    u = data["u"]
    eos1 = create_eos(AIR_IDEAL)
    eos2 = create_eos(WATER_NASG)
    rho1 = eos1.rho(p, T)
    rho2 = eos2.rho(p, T)
    q1 = psi * rho1
    q2 = (1.0 - psi) * rho2
    mask = (x > 0.25) & (x < 0.74)
    def rel_span(arr):
        vals = arr[mask]
        return float((np.max(vals) - np.min(vals)) / (abs(np.mean(vals)) + 1e-300))
    return {
        "available": True,
        "x_min": float(x[0]),
        "x_max": float(x[-1]),
        "postshock_window": "0.25<x<0.74",
        "rho_rel_span": rel_span(rho),
        "u_rel_span": rel_span(u),
        "p_rel_span": rel_span(p),
        "alpha_rel_span": rel_span(psi),
        "phase_mass_q1_rel_span": rel_span(q1),
        "phase_mass_q2_rel_span": rel_span(q2),
    }


def main():
    rows = []
    for psi_water in (0.25, 0.5, 0.75):
        left = phase_state(psi_water, "post")
        right = phase_state(psi_water, "pre")
        rows.append(
            {
                "psi_water": psi_water,
                "alpha_pre": right["alpha"],
                "alpha_post": left["alpha"],
                "rho_post_reference": left["rho_exact"],
                "rho_post_phase_state": mixture_from_phase_temperatures(left)[0],
                "rho_post_common_T": mixture_from_common_temperature(left)[0],
                "conservative_RH_phase_temperatures": cons_rh_residual(
                    left, right, mixture_from_phase_temperatures
                ),
                "conservative_RH_common_T_solver_closure": cons_rh_residual(
                    left, right, mixture_from_common_temperature
                ),
                "alpha_nonconservative_source_integral": alpha_source_rh(left, right),
            }
        )
    out = {
        "audit": "case24_governing_terms",
        "interpretation": (
            "Small conservative RH residuals with phase temperatures but larger common-T "
            "or alpha-source integral errors indicate a governing-term/closure/path "
            "discretization issue, not a high-order reconstruction issue."
        ),
        "rows": rows,
        "latest_saved_solution_plateau_drift": plateau_drift_from_npz(),
    }
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

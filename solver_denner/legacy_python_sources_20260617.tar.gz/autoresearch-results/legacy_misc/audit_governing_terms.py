#!/usr/bin/env python3
"""Local governing-term audit for denner_1d.
Checks EOS/mixture derivatives and Kapila K-source algebra without external project data.
"""
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from solver.denner_1d.eos.eos_class import create_eos
from solver.denner_1d.eos.base import compute_phase_props, compute_mixture_props
from solver.denner_1d.vof_cn import _compute_K, _compute_K_Ns

AIR={'gamma':1.4,'pinf':0.0,'b':0.0,'kv':717.5,'eta':0.0}
WATER={'gamma':1.187,'pinf':7.028e8,'b':6.61e-4,'kv':3610.0,'eta':-1.177788e6}

def T_from_rho_p(ph, rho, p):
    eos=create_eos(ph)
    gm1=eos.gamma-1.0
    return ((p+eos.pinf)/rho - eos.b*(p+eos.pinf))/(eos.kv*gm1)

def rel(a,b,scale=None):
    a=np.asarray(a,float); b=np.asarray(b,float)
    if scale is None:
        scale=np.maximum.reduce([np.abs(a), np.abs(b), np.ones_like(a)])
    return float(np.max(np.abs(a-b)/(scale+1e-300)))

def fd(f, x, h):
    return (f(x+h)-f(x-h))/(2*h)

states=[]
# Pre-shock representative states and strong-shock rough states.
for p in [1e5, 1e7, 1e9, 1e11]:
    T_air=T_from_rho_p(AIR, 1.1574*max(p/1e5,1)**0.1, p)
    T_w=T_from_rho_p(WATER, 998.0, p)
    # common-temperature probes: use sane average range, not physical exact.
    for T in [max(50.0,min(T_air,1e5)), max(50.0,min(T_w,1e5)), 300.0]:
        states.append((p,T))

phase_err=[]
for name,ph in [('air',AIR),('water_nasg',WATER)]:
    eos=create_eos(ph)
    for p,T in states:
        pstep=max(1e-2,abs(p)*1e-6); Tstep=max(1e-5,abs(T)*1e-6)
        props=compute_phase_props(np.array([p]),np.array([T]),ph)
        rho=lambda pp: eos.rho(pp,T)
        rhoT=lambda TT: eos.rho(p,TT)
        h=lambda pp: eos.h(pp,T)
        hT=lambda TT: eos.h(p,TT)
        evol=lambda pp: eos.e_vol(pp,T)
        evolT=lambda TT: eos.e_vol(p,TT)
        phase_err.append({
            'phase':name,'p':p,'T':T,
            'drho_dp_rel':rel(props['zeta'][0],fd(rho,p,pstep)),
            'drho_dT_rel':rel(props['phi'][0],fd(rhoT,T,Tstep)),
            'dh_dp_rel':rel(eos.dh_dp(p,T),fd(h,p,pstep)),
            'dh_dT_rel':rel(eos.cp(p,T),fd(hT,T,Tstep)),
            'de_dp_rel':rel(props['dEdp'][0],fd(evol,p,pstep)),
            'de_dT_rel':rel(props['dEdT'][0],fd(evolT,T,Tstep)),
        })

mix_err=[]
for p,T in states:
    for a in [1e-6,0.25,0.5,0.75,1-1e-6]: # a = air alpha = solver psi
        pstep=max(1e-2,abs(p)*1e-6); Tstep=max(1e-5,abs(T)*1e-6); astep=1e-6
        def mix(pp,TT,aa):
            return compute_mixture_props(np.array([pp]),np.array([0.0]),np.array([TT]),np.array([aa]),AIR,WATER)
        m=mix(p,T,a)
        def rho_p(pp): return mix(pp,T,a)['rho'][0]
        def rho_T(TT): return mix(p,TT,a)['rho'][0]
        def rho_a(aa): return mix(p,T,np.clip(aa,1e-9,1-1e-9))['rho'][0]
        def rh_p(pp): return mix(pp,T,a)['rho_h'][0]
        def rh_T(TT): return mix(p,TT,a)['rho_h'][0]
        def rh_a(aa): return mix(p,T,np.clip(aa,1e-9,1-1e-9))['rho_h'][0]
        mix_err.append({
            'p':p,'T':T,'alpha_air':a,
            'rho_p_rel':rel(m['zeta_v'][0],fd(rho_p,p,pstep)),
            'rho_T_rel':rel(m['phi_v'][0],fd(rho_T,T,Tstep)),
            'rho_alpha_rel':rel(m['Delta_rho_psi'][0],fd(rho_a,a,astep)),
            'rhoh_p_rel':rel(m['d_rho_h_dp_v'][0],fd(rh_p,p,pstep)),
            'rhoh_T_rel':rel(m['d_rho_h_dT_v'][0],fd(rh_T,T,Tstep)),
            'rhoh_alpha_rel':rel(m['d_rho_h_dpsi'][0],fd(rh_a,a,astep)),
        })

k_err=[]
for p,T in states:
    pp=np.array([p]); TT=np.array([T])
    props1=compute_phase_props(pp,TT,AIR); props2=compute_phase_props(pp,TT,WATER)
    Z1=props1['rho'][0]*props1['c'][0]**2
    Z2=props2['rho'][0]*props2['c'][0]**2
    for a in [1e-6,0.25,0.5,0.75,1-1e-6]:
        trueD=a*((1.0/(a/Z1+(1-a)/Z2))/Z1 - 1.0)
        K=float(_compute_K(np.array([a]),AIR,WATER,pp,TT)[0])
        Kns=float(_compute_K_Ns(np.array([[a],[1-a]]),[AIR,WATER],pp,TT)[0,0])
        k_err.append({'p':p,'T':T,'alpha_air':a,
                      'K_2species':K,'D1_formula':trueD,'Kns':Kns,
                      'K_rel':rel(K,trueD,scale=np.array([max(abs(trueD),1e-12)])),
                      'Kns_rel':rel(Kns,trueD,scale=np.array([max(abs(trueD),1e-12)]))})

summary={
 'max_phase_deriv_rel':max(max(e[k] for k in e if k.endswith('_rel')) for e in phase_err),
 'max_mix_deriv_rel':max(max(e[k] for k in e if k.endswith('_rel')) for e in mix_err),
 'max_K_rel_2species':max(e['K_rel'] for e in k_err if 1e-3 < e['alpha_air'] < 1-1e-3),
 'max_K_rel_Ns':max(e['Kns_rel'] for e in k_err if 1e-3 < e['alpha_air'] < 1-1e-3),
 'worst_phase':max(phase_err,key=lambda e:max(e[k] for k in e if k.endswith('_rel'))),
 'worst_mix':max(mix_err,key=lambda e:max(e[k] for k in e if k.endswith('_rel'))),
 'worst_K_Ns':max((e for e in k_err if 1e-3 < e['alpha_air'] < 1-1e-3),key=lambda e:e['Kns_rel']),
}
print(json.dumps(summary,indent=2,sort_keys=True))

#!/usr/bin/env python3
"""Cycle 4 rho-postshock drop diagnostic.

Consumes NPZ snapshots written by case24_cycle4_subcase_probe.py and summarizes
the official postshock rho-drop window plus plateau behavior across resolutions.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(1, str(ROOT.parent))

from results.run_denner1d_17case import _v_case24_rho_postshock_drop_guard  # noqa: E402


def _jsonable(value):
    if isinstance(value, dict):
        return {k: _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def _corr(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if a.size < 2 or b.size < 2 or a.size != b.size:
        return 0.0
    am = a - float(np.mean(a))
    bm = b - float(np.mean(b))
    denom = float(np.sqrt(np.sum(am * am) * np.sum(bm * bm)))
    if denom <= 0.0 or not np.isfinite(denom):
        return 0.0
    return float(np.sum(am * bm) / denom)


def _window_mask(x: np.ndarray, x_shock_exact: float) -> np.ndarray:
    return (x >= x_shock_exact + 0.01) & (x <= min(0.98, x_shock_exact + 0.15))


def _summarize_npz(path: Path) -> dict:
    data = np.load(path, allow_pickle=False)
    x = np.asarray(data["x"], dtype=float)
    rho = np.asarray(data["rho"], dtype=float)
    exact_rho = np.asarray(data["exact_rho"], dtype=float)
    exact_psi = np.asarray(data["exact_psi"], dtype=float) if "exact_psi" in data else None
    psi = np.asarray(data["psi"], dtype=float) if "psi" in data else None
    x_shock_exact = float(data["x_shock_exact"]) if "x_shock_exact" in data else 0.8
    dx = float(x[1] - x[0]) if len(x) > 1 else 1.0
    rho_drop = _v_case24_rho_postshock_drop_guard(x, rho, exact_rho, dx, x_shock_exact)
    mask = _window_mask(x, x_shock_exact)
    rho_win = rho[mask]
    exact_rho_win = exact_rho[mask]
    if rho_win.size:
        rho0 = float(rho_win[0])
        rho_last = float(rho_win[-1])
        rho_ratio = float(rho_last / max(rho0, 1.0e-300))
        rho_mean = float(np.mean(rho_win))
        exact_mean = float(np.mean(exact_rho_win))
        rho_peak_idx = int(np.argmax(rho_win))
        rho_dip_idx = int(np.argmin(rho_win))
        rho_peak_x = float(x[mask][rho_peak_idx])
        rho_dip_x = float(x[mask][rho_dip_idx])
        rho_peak = float(rho_win[rho_peak_idx])
        rho_dip = float(rho_win[rho_dip_idx])
    else:
        rho0 = rho_last = rho_ratio = rho_mean = exact_mean = 0.0
        rho_peak_x = rho_dip_x = float("nan")
        rho_peak = rho_dip = 0.0
    alpha_metrics = {}
    alpha_corr = 0.0
    alpha_mean = alpha_exact_mean = 0.0
    psi_available = (
        psi is not None
        and exact_psi is not None
        and not np.allclose(psi, exact_psi, rtol=1.0e-12, atol=1.0e-12)
    )
    if psi_available and mask.any():
        psi_win = psi[mask]
        exact_psi_win = exact_psi[mask]
        alpha_mean = float(np.mean(psi_win))
        alpha_exact_mean = float(np.mean(exact_psi_win))
        alpha_corr = _corr(rho_win - exact_rho_win, psi_win - exact_psi_win)
        alpha_metrics = {
            "alpha_mean_window": alpha_mean,
            "alpha_exact_mean_window": alpha_exact_mean,
            "alpha_mean_delta": float(alpha_mean - alpha_exact_mean),
            "alpha_rho_residual_corr_window": alpha_corr,
        }

    return {
        "input": str(path),
        "N": int(len(x)),
        "dx": dx,
        "x_shock_exact": x_shock_exact,
        "guard_window": {
            "xmin": float(x_shock_exact + 0.01),
            "xmax": float(min(0.98, x_shock_exact + 0.15)),
            "cells": int(np.count_nonzero(mask)),
        },
        "rho0_guard": rho0,
        "rho_last_guard": rho_last,
        "rho_last_over_first": rho_ratio,
        "rho_mean_guard": rho_mean,
        "rho_exact_mean_guard": exact_mean,
        "rho_peak_guard": rho_peak,
        "rho_peak_x_guard": rho_peak_x,
        "rho_dip_guard": rho_dip,
        "rho_dip_x_guard": rho_dip_x,
        "rho_postshock_drop": _jsonable(rho_drop),
        "rho_residual_window_corr": _corr(rho_win - exact_rho_win, rho_win) if rho_win.size else 0.0,
        "alpha_metrics": alpha_metrics if psi_available else None,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Cycle4 rho-drop plateau diagnostic")
    parser.add_argument("--inputs", required=True,
                        help="Comma-separated NPZ inputs")
    parser.add_argument("--out", required=True,
                        help="Output JSONL path")
    args = parser.parse_args()

    inputs = [Path(p.strip()) for p in args.inputs.split(",") if p.strip()]
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    with out_path.open("w", encoding="utf-8") as fh:
        for path in inputs:
            row = _summarize_npz(path)
            rows.append(row)
            fh.write(json.dumps(_jsonable(row), sort_keys=True) + "\n")
        summary = {
            "comparison": [
                {
                    "input": r["input"],
                    "N": r["N"],
                    "rho_last_over_first": r["rho_last_over_first"],
                    "rho_postshock_drop_ok": bool(r["rho_postshock_drop"].get("rho_postshock_drop_ok", False)),
                    "rho_mean_guard": r["rho_mean_guard"],
                    "rho_exact_mean_guard": r["rho_exact_mean_guard"],
                    "alpha_mean_delta": (r.get("alpha_metrics") or {}).get("alpha_mean_delta"),
                    "alpha_rho_residual_corr_window": (r.get("alpha_metrics") or {}).get("alpha_rho_residual_corr_window"),
                }
                for r in rows
            ],
            "rows": rows,
        }
        fh.write(json.dumps(_jsonable(summary), sort_keys=True) + "\n")

    headers = [
        "input", "N", "rho_last_over_first", "rho_postshock_drop_ok",
        "rho_mean_guard", "rho_exact_mean_guard", "alpha_mean_delta",
        "alpha_rho_residual_corr_window",
    ]
    print("\t".join(headers), flush=True)
    for r in rows:
        am = r.get("alpha_metrics") or {}
        print("\t".join([
            str(r["input"]),
            str(r["N"]),
            f"{r['rho_last_over_first']:.6g}",
            str(bool(r["rho_postshock_drop"].get("rho_postshock_drop_ok", False))),
            f"{r['rho_mean_guard']:.6g}",
            f"{r['rho_exact_mean_guard']:.6g}",
            f"{am.get('alpha_mean_delta', 0.0):.6g}" if am else "n/a",
            f"{am.get('alpha_rho_residual_corr_window', 0.0):.6g}" if am else "n/a",
        ]), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

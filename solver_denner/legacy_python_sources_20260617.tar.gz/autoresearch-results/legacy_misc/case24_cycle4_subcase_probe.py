#!/usr/bin/env python3
"""Cycle 4 case24 subcase probe.

Runs selected official case24 subcases through results.run_denner1d_17case._case24_subcase,
writes one JSON line per subcase, and optionally saves a compact NPZ snapshot for
the postshock rho-drop diagnostic.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(1, str(ROOT.parent))

from results.run_denner1d_17case import (  # noqa: E402
    _case24_subcase,
    _make_ref_air,
    _make_ref_water_nasg,
    _v_case24_kapila_path_exact,
)


def _parse_psi_list(text: str) -> list[float]:
    values = []
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        values.append(float(part))
    if not values:
        raise ValueError("at least one psi value is required")
    return values


def _tag_value(value: float) -> str:
    text = f"{float(value):.6f}".rstrip("0").rstrip(".")
    return text.replace("-", "m").replace(".", "p")


def _jsonable(value):
    if isinstance(value, dict):
        return {k: _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def _save_npz(out_path: Path, row: dict, psi_water: float) -> None:
    x = np.asarray(row["x"], dtype=float)
    rho = np.asarray(row["rho"], dtype=float)
    u = np.asarray(row["u"], dtype=float)
    p = np.asarray(row["p"], dtype=float)
    exact = dict(row["exact"])
    x_shock_exact = 0.8
    exact_rho = np.asarray(exact["rho"], dtype=float)
    exact_u = np.asarray(exact["u"], dtype=float)
    exact_p = np.asarray(exact["p"], dtype=float)
    rh = _v_case24_kapila_path_exact(
        10.0,
        float(psi_water),
        _make_ref_air(),
        _make_ref_water_nasg(),
        p_pre=1.0e5,
        rho_air=1.1574,
        rho_water=998.0,
    )
    exact_psi = np.where(x < x_shock_exact, rh["alpha_post"], rh["alpha_pre"])

    np.savez(
        out_path,
        x=x,
        rho=rho,
        u=u,
        p=p,
        psi=np.asarray(row.get("psi", exact_psi), dtype=float),
        exact_rho=exact_rho,
        exact_u=exact_u,
        exact_p=exact_p,
        exact_psi=exact_psi,
        psi_water=float(psi_water),
        x_shock_exact=float(x_shock_exact),
        alpha_pre=float(rh["alpha_pre"]),
        alpha_post=float(rh["alpha_post"]),
        metrics=json.dumps(_jsonable(row["metrics"]), sort_keys=True),
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Cycle4 case24 subcase probe")
    parser.add_argument("--psi", default="0.5,0.75,1.0",
                        help="Comma-separated psi_water values")
    parser.add_argument("--N", type=int, default=100)
    parser.add_argument("--CFL", type=float, default=0.4)
    parser.add_argument("--out", required=True,
                        help="Output JSONL path")
    args = parser.parse_args()

    psi_values = _parse_psi_list(args.psi)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    npz_dir = out_path.parent

    rows = []
    with out_path.open("w", encoding="utf-8") as fh:
        for psi_water in psi_values:
            os.environ["DENNER_CASE24_N"] = str(int(args.N))
            os.environ["DENNER_CASE24_CFL"] = str(float(args.CFL))
            started = time.time()
            row = _case24_subcase(float(psi_water))
            wall = time.time() - started
            metrics = dict(row.get("metrics", {}))
            metrics["wall_probe"] = float(wall)
            exact = dict(row.get("exact", {}))
            out_row = {
                "case": "24_H",
                "psi_water": float(psi_water),
                "N": int(args.N),
                "CFL": float(args.CFL),
                "pass": bool(row.get("pass", False)),
                "wall_probe": float(wall),
                "metrics": _jsonable(metrics),
                "exact": _jsonable({
                    "alpha_pre": exact.get("alpha_pre"),
                    "alpha_post": exact.get("alpha_post"),
                    "rho_pre": exact.get("rho_pre"),
                    "rho_post": exact.get("rho_post"),
                    "u_post": exact.get("u_post"),
                    "p_post": exact.get("p_post"),
                    "V_s": exact.get("V_s"),
                    "comp": exact.get("comp"),
                    "label": exact.get("label"),
                }),
            }
            if "x" in row:
                out_row["x_shock_exact"] = 0.8
                out_row["rho_drop_ok"] = bool(metrics.get("rho_postshock_drop_ok", True))
            psi_tag = _tag_value(float(psi_water))
            npz_path = npz_dir / f"{out_path.stem}_psi{psi_tag}.npz"
            _save_npz(npz_path, row, float(psi_water))
            out_row["npz"] = str(npz_path)
            json_line = json.dumps(_jsonable(out_row), sort_keys=True)
            fh.write(json_line + "\n")
            fh.flush()
            rows.append(out_row)
            print(json_line, flush=True)

    summary = {
        "case": "24_H",
        "N": int(args.N),
        "CFL": float(args.CFL),
        "psi_values": [float(v) for v in psi_values],
        "rows": rows,
    }
    print(json.dumps(_jsonable(summary), sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations
import os, sys, time, json
import numpy as np
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'results'))
sys.path.insert(1,str(ROOT))
from run_denner1d_17case import (_make_ref_air,_make_ref_water_nasg,_v_case24_kapila_path_exact,_temperature_from_rho_p,_solve_denner,_final_state,_mix_rho,_v_relative_l2,_pearson,AIR_IDEAL,WATER_NASG)

def main():
    N=int(os.environ.get('N','60')); CFL=float(os.environ.get('CFL','0.4')); psi_water=float(os.environ.get('PSI','0.25'))
    coupled=os.environ.get('COUPLED','0')=='1'; max_newton=int(os.environ.get('MAX_NEWTON','12'))
    L=1.0; dx=L/N; x=(np.arange(N)+0.5)*dx; x_shock0=0.1; x_shock_exact=0.8; Ms=10.0
    p_pre=1e5; rho_air_pre=1.1574; rho_water_pre=998.0; alpha_floor=1e-6
    if psi_water<=0: ph1=ph2=AIR_IDEAL; rho1_pre=rho2_pre=rho_air_pre
    elif psi_water>=1: ph1=ph2=WATER_NASG; rho1_pre=rho2_pre=rho_water_pre
    else: ph1,ph2=AIR_IDEAL,WATER_NASG; rho1_pre,rho2_pre=rho_air_pre,rho_water_pre
    rh=_v_case24_kapila_path_exact(Ms,psi_water,_make_ref_air(),_make_ref_water_nasg(),p_pre=p_pre,rho_air=rho_air_pre,rho_water=rho_water_pre)
    p_post=rh['p_post']; rho_post_mix=rh['rho_post']; u_post=rh['u_post']; comp=rh['comp']; alpha_pre=rh['alpha_pre']; alpha_post=rh['alpha_post']; V_s=rh['V_s']; t_end=0.7/V_s
    left=x<x_shock0
    psi0=np.clip(np.where(left,alpha_post,alpha_pre), alpha_floor,1-alpha_floor)
    p_init=np.where(left,p_post,p_pre); u_init=np.where(left,u_post,0.0)
    q1_pre=alpha_pre*rho1_pre; q2_pre=(1-alpha_pre)*rho2_pre
    rho1=np.where(left,q1_pre*comp/alpha_post,rho1_pre); rho2=np.where(left,q2_pre*comp/(1-alpha_post),rho2_pre)
    T1=_temperature_from_rho_p(ph1,rho1,p_init); T2=_temperature_from_rho_p(ph2,rho2,p_init); T_init=psi0*T1+(1-psi0)*T2
    st=time.time()
    res=_solve_denner(psi0,T_init,u_init,p_init,dx,t_end,ph1=ph1,ph2=ph2,bc_l='transmissive',bc_r='transmissive',cfl=CFL,cfl_type='acoustic',max_iter=200000,max_outer=1,vof_type='volume',max_newton=max_newton,coupled=coupled,solver_mode='delta',newton_tol=1e-6)
    psi_f,T_f,u_f,p_f=_final_state(res); rho_f=_mix_rho(psi_f,p_f,T_f,ph1,ph2)
    exact={'rho':np.where(x<x_shock_exact,rho_post_mix,(1-psi_water)*rho_air_pre+psi_water*rho_water_pre),'u':np.where(x<x_shock_exact,u_post,0.0),'p':np.where(x<x_shock_exact,p_post,p_pre)}
    above=p_f>0.5*(p_post+p_pre); shock_x=float(x[np.where(above)[0].max()]) if np.any(above) else float('nan')
    out=dict(N=N,CFL=CFL,psi_water=psi_water,coupled=coupled,wall=time.time()-st,steps=len(res['dt_history']),complete=bool(res['t_history'][-1]>=t_end-1e-14),diverged=bool(res.get('diverged',False)),shock_x=shock_x,shock_cells=float(abs(shock_x-x_shock_exact)/dx if np.isfinite(shock_x) else 1e99),p_l2=float(_v_relative_l2(p_f,exact['p'],1e5)),u_l2=float(_v_relative_l2(u_f,exact['u'],1.0)),rho_l2=float(_v_relative_l2(rho_f,exact['rho'],1.0)),p_corr=float(_pearson(p_f,exact['p'])),u_corr=float(_pearson(u_f,exact['u'])),rho_corr=float(_pearson(rho_f,exact['rho'])),p_min=float(np.min(p_f)),rho_min=float(np.min(rho_f)),psi_min=float(np.min(psi_f)),psi_max=float(np.max(psi_f)))
    print(json.dumps(out,sort_keys=True))
if __name__=='__main__': main()

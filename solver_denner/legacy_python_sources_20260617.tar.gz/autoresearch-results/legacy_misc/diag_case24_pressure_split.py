#!/usr/bin/env python3
"""Case24 pressure-split diagnostic for solver_denner.

Runs the current solver on the case24 reference setup and measures the gap
between the arithmetic face pressure used in the transported-energy split and
the characteristic pressure-face family used by the momentum / pressure-work
path.  This is a no-edit diagnostic artifact only.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(1, str(ROOT.parent))

from solver.denner_1d.main import run as denner_run  # noqa: E402
from solver.denner_1d import assembly as denner_assembly  # noqa: E402
from solver.denner_1d.eos.base import compute_mixture_props  # noqa: E402
from results.run_denner1d_17case import (  # noqa: E402
    _make_ref_air,
    _make_ref_water_nasg,
    _v_case24_kapila_path_exact,
    _temperature_from_rho_p,
    _final_state,
    _mix_rho,
    _v_relative_l2,
    _pearson,
    AIR_IDEAL,
    WATER_NASG,
)


def _build_case(N: int, psi_water: float, cfl: float):
    L = 1.0
    dx = L / N
    x = (np.arange(N) + 0.5) * dx
    x_shock0 = 0.1
    x_shock_exact = 0.8
    Ms = 10.0
    p_pre = 1.0e5
    rho_air_pre = 1.1574
    rho_water_pre = 998.0
    alpha_floor = 1.0e-6

    if psi_water <= 0.0:
        ph1 = ph2 = AIR_IDEAL
        rho1_pre = rho2_pre = rho_air_pre
    elif psi_water >= 1.0:
        ph1 = ph2 = WATER_NASG
        rho1_pre = rho2_pre = rho_water_pre
    else:
        ph1, ph2 = AIR_IDEAL, WATER_NASG
        rho1_pre, rho2_pre = rho_air_pre, rho_water_pre

    exact = _v_case24_kapila_path_exact(
        Ms, psi_water, _make_ref_air(), _make_ref_water_nasg(),
        p_pre=p_pre, rho_air=rho_air_pre, rho_water=rho_water_pre,
    )
    p_post = exact["p_post"]
    rho_post_mix = exact["rho_post"]
    u_post = exact["u_post"]
    comp = exact["comp"]
    alpha_pre = exact["alpha_pre"]
    alpha_post = exact["alpha_post"]
    V_s = exact["V_s"]
    t_end = 0.7 / V_s

    left = x < x_shock0
    psi0 = np.clip(np.where(left, alpha_post, alpha_pre), alpha_floor, 1.0 - alpha_floor)
    p_init = np.where(left, p_post, p_pre)
    u_init = np.where(left, u_post, 0.0)
    q1_pre = alpha_pre * rho1_pre
    q2_pre = (1.0 - alpha_pre) * rho2_pre
    rho1 = np.where(left, q1_pre * comp / alpha_post, rho1_pre)
    rho2 = np.where(left, q2_pre * comp / (1.0 - alpha_post), rho2_pre)
    T1 = _temperature_from_rho_p(ph1, rho1, p_init)
    T2 = _temperature_from_rho_p(ph2, rho2, p_init)
    T_init = psi0 * T1 + (1.0 - psi0) * T2

    params = dict(
        ph1=ph1,
        ph2=ph2,
        x_cells=x,
        psi_init=psi0,
        T_init=T_init,
        u_init=u_init,
        p_init=p_init,
        t_end=t_end,
        CFL=cfl,
        bc_left="transmissive",
        bc_right="transmissive",
        verbose=False,
        cfl_type="acoustic",
        max_iteration=int(os.environ.get("MAX_ITER", "200000")),
        use_acid=True,
        vof_type=os.environ.get("VOF_TYPE", "volume"),
        variable_set=os.environ.get("VARIABLE_SET", "puT"),
        use_K=False,
        use_compress=False,
        coupled=False,
        solver_mode="delta",
        third_var=os.environ.get("THIRD_VAR", None),
        bdf_order=int(os.environ.get("BDF_ORDER", "2")),
        mwi_rho_star=os.environ.get("MWI_RHO_STAR", "harmonic"),
        tvd_limiter=os.environ.get("TVD_LIMITER", "minmod"),
        acoustic_limiter=os.environ.get("ACOUSTIC_LIMITER") or None,
        acoustic_limiter_blend=float(os.environ.get("ACOUSTIC_LIMITER_BLEND", "1.0")),
        mwi_transient=True,
        acoustic_face_correction=True,
        acid_temporal_colour=os.environ.get("ACID_TEMPORAL_COLOUR", "new"),
        max_outer=int(os.environ.get("MAX_OUTER", "1")),
        max_inner=int(os.environ.get("MAX_INNER", "20")),
        max_newton=int(os.environ.get("MAX_NEWTON", "20")),
        newton_tol=float(os.environ.get("NEWTON_TOL", "1e-6")),
        inner_tol=float(os.environ.get("NEWTON_TOL", "1e-6")),
        outer_tol=float(os.environ.get("OUTER_TOL", "1e-6")),
        newton_omega=float(os.environ.get("NEWTON_OMEGA", "1.0")),
        use_autograd=False,
        use_jfnk=True,
        krylov_max=int(os.environ.get("KRYLOV_MAX", "8")),
        consistent_vof_face_flux=True,
        density_mood_limiter=True,
        pressure_floor_velocity_regularization=True,
        smooth_acoustic_entropy_projection=True,
        force_mixed_stiff_puh=True,
    )
    if params["third_var"] is None:
        params.pop("third_var")
    return params, exact, x, dx, x_shock_exact, t_end


def _face_map(N: int, bc_l: str, bc_r: str):
    face_ids = np.arange(N + 1)
    face_left = face_ids - 1
    face_right = face_ids.copy()
    if bc_l == "periodic":
        face_left = np.where(face_left < 0, N - 1, face_left)
    else:
        face_left = np.maximum(face_left, 0)
    if bc_r == "periodic":
        face_right = np.where(face_right >= N, 0, face_right)
    else:
        face_right = np.minimum(face_right, N - 1)
    return face_left, face_right


def _pressure_split_gap(p, u, T, psi, ph1, ph2, bc_l, bc_r, limiter="minmod"):
    N = len(p)
    props = compute_mixture_props(p, u, T, psi, ph1, ph2)
    rho = props["rho"]
    c_mix = props["c_mix"]
    u_ext = denner_assembly.apply_ghost_velocity(u, bc_l, bc_r, 2)
    p_ext = denner_assembly.apply_ghost(p, bc_l, bc_r, 2)
    rho_ext = denner_assembly.apply_ghost(rho, bc_l, bc_r, 2)
    c_ext = denner_assembly.apply_ghost(c_mix, bc_l, bc_r, 2)
    psi_ext = denner_assembly.apply_ghost(psi, bc_l, bc_r, 2)

    pL_rec, pR_rec = denner_assembly._tvd_face_states(p, bc_l, bc_r, kind=limiter)
    uL_rec, uR_rec = denner_assembly._tvd_face_states(
        u, bc_l, bc_r, kind=limiter, velocity=True)

    face_left, face_right = _face_map(N, bc_l, bc_r)
    p_face = 0.5 * (np.asarray(p)[face_left] + np.asarray(p)[face_right])
    pressure_jump = (
        np.maximum(np.abs(np.asarray(p)[face_left]), np.abs(np.asarray(p)[face_right]))
        / np.minimum(np.maximum(np.abs(np.asarray(p)[face_left]), 1.0), np.maximum(np.abs(np.asarray(p)[face_right]), 1.0))
    ) > 1.01
    material_jump = (
        np.abs(psi_ext[2:N + 3] - psi_ext[1:N + 2]) > np.sqrt(np.finfo(float).eps)
    )

    p_work = p_face.copy()
    p_split_gap = np.zeros(N + 1)
    p_work_gap = np.zeros(N + 1)
    for f in range(N + 1):
        iL = 2 + f - 1
        iR = 2 + f
        cL, cR = face_left[f], face_right[f]
        ZL = max(float(rho_ext[iL] * c_ext[iL]), 1e-300)
        ZR = max(float(rho_ext[iR] * c_ext[iR]), 1e-300)
        Zsum = ZL + ZR
        is_material_face = bool(material_jump[f])
        pL_face = float(p[cL]) if is_material_face else float(pL_rec[f])
        pR_face = float(p[cR]) if is_material_face else float(pR_rec[f])
        uL_face = float(u[cL]) if is_material_face else float(uL_rec[f])
        uR_face = float(u[cR]) if is_material_face else float(uR_rec[f])
        if f == 0 and bc_l == "wall":
            p_star = float(p[cR]) - ZR * float(u[cR])
            p_cc = float(p[cR]) - ZR * float(u[cR])
        else:
            p_cc = (
                (ZR / Zsum) * float(p[cL])
                + (ZL / Zsum) * float(p[cR])
                + (ZL * ZR / Zsum) * float(u[cL])
                - (ZL * ZR / Zsum) * float(u[cR])
            )
            u_star = (pL_face - pR_face + ZL * uL_face + ZR * uR_face) / Zsum
            p_star = pL_face - ZL * (u_star - uL_face)
        p_work[f] = p_star
        p_split_gap[f] = p_work[f] - p_face[f]
        p_work_gap[f] = p_work[f] - p_cc

    shock_x = float(np.nan)
    p_mid = 0.5 * (float(np.max(p)) + float(np.min(p)))
    above = p > p_mid
    if np.any(above):
        shock_x = float(np.argmax(above))
    return {
        "p_split_gap": p_split_gap,
        "p_work_gap": p_work_gap,
        "pressure_jump": pressure_jump,
        "material_jump": material_jump,
        "p_work": p_work,
        "p_face": p_face,
        "shock_x_cell": shock_x,
    }


def main():
    N = int(os.environ.get("N", "100"))
    PSI = float(os.environ.get("PSI", "0.5"))
    CFL = float(os.environ.get("CFL", "0.4"))
    params, exact, x, dx, x_shock_exact, t_end = _build_case(N, PSI, CFL)
    t0 = time.time()
    res = denner_run(params)
    wall = time.time() - t0
    psi_f, T_f, u_f, p_f = _final_state(res)
    rho_f = _mix_rho(psi_f, p_f, T_f, params["ph1"], params["ph2"])
    p_exact = np.where(x < x_shock_exact, exact["p_post"], 1.0e5)
    u_exact = np.where(x < x_shock_exact, exact["u_post"], 0.0)
    rho_exact = np.where(
        x < x_shock_exact,
        exact["rho_post"],
        (1.0 - PSI) * 1.1574 + PSI * 998.0,
    )

    gap = _pressure_split_gap(
        p_f, u_f, T_f, psi_f,
        params["ph1"], params["ph2"],
        params["bc_left"], params["bc_right"],
        limiter=params["tvd_limiter"],
    )
    shock_cells = abs(float(np.argmax(p_f > 0.5 * (float(np.max(p_f)) + float(np.min(p_f))))) - x_shock_exact / dx)
    window = (x >= 0.74) & (x <= 0.82)
    x_face = np.arange(N + 1, dtype=float) * dx
    face_window = (x_face >= 0.74) & (x_face <= 0.82)
    face_window = face_window & gap["pressure_jump"] & gap["material_jump"]
    stats = {
        "N": N,
        "PSI": PSI,
        "CFL": CFL,
        "wall": wall,
        "steps": len(res["dt_history"]),
        "diverged": bool(res.get("diverged", False)),
        "shock_cells": shock_cells,
        "p_l2": _v_relative_l2(p_f, p_exact, 1.0e5),
        "u_l2": _v_relative_l2(u_f, u_exact, 1.0),
        "rho_l2": _v_relative_l2(rho_f, rho_exact, 1.0),
        "p_corr": _pearson(p_f, p_exact),
        "u_corr": _pearson(u_f, u_exact),
        "rho_corr": _pearson(rho_f, rho_exact),
        "mean_abs_p_split_gap_window": float(np.mean(np.abs(gap["p_split_gap"][face_window]))),
        "max_abs_p_split_gap_window": float(np.max(np.abs(gap["p_split_gap"][face_window]))),
        "mean_abs_p_work_gap_window": float(np.mean(np.abs(gap["p_work_gap"][face_window]))),
        "max_abs_p_work_gap_window": float(np.max(np.abs(gap["p_work_gap"][face_window]))),
        "mean_abs_p_split_gap_material_window": float(np.mean(np.abs(gap["p_split_gap"][face_window]))) if np.any(face_window) else 0.0,
        "max_abs_p_split_gap_material_window": float(np.max(np.abs(gap["p_split_gap"][face_window]))) if np.any(face_window) else 0.0,
        "face_material_jump_count": int(np.sum(face_window)),
    }
    print(json.dumps(stats, sort_keys=True))


if __name__ == "__main__":
    main()

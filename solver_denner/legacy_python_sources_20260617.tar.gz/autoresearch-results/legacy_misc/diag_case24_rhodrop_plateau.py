#!/usr/bin/env python3
"""Inspect case24 mixed-subcase rho postshock plateau behavior."""
from __future__ import annotations

import json
import os
import pathlib
import sys
import time

import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from results.run_denner1d_17case import _case24_subcase  # noqa: E402


def _float_list(env_name: str, default: str) -> list[float]:
    raw = os.environ.get(env_name, default)
    return [float(part.strip()) for part in raw.split(",") if part.strip()]


def _int_list(env_name: str, default: str) -> list[int]:
    raw = os.environ.get(env_name, default)
    return [int(part.strip()) for part in raw.split(",") if part.strip()]


def _idx_stats(name: str, x: np.ndarray, values: np.ndarray) -> dict:
    values = np.asarray(values, dtype=float)
    finite = np.isfinite(values)
    if not np.any(finite):
        return {f"{name}_finite": False}
    safe = np.where(finite, values, np.nan)
    i_min = int(np.nanargmin(safe))
    i_max = int(np.nanargmax(safe))
    return {
        f"{name}_finite": True,
        f"{name}_min": float(safe[i_min]),
        f"{name}_min_i": i_min,
        f"{name}_min_x": float(x[i_min]),
        f"{name}_max": float(safe[i_max]),
        f"{name}_max_i": i_max,
        f"{name}_max_x": float(x[i_max]),
        f"{name}_ptp": float(np.nanmax(safe) - np.nanmin(safe)),
    }


def _window_stats(prefix: str, x: np.ndarray, mask: np.ndarray, arrays: dict[str, np.ndarray]) -> dict:
    out = {
        f"{prefix}_cell_count": int(np.count_nonzero(mask)),
        f"{prefix}_x_min": float(np.min(x[mask])) if np.any(mask) else None,
        f"{prefix}_x_max": float(np.max(x[mask])) if np.any(mask) else None,
    }
    for name, values in arrays.items():
        if np.any(mask):
            out.update(_idx_stats(f"{prefix}_{name}", x[mask], np.asarray(values)[mask]))
    return out


def _classify(metrics: dict, full_stats: dict) -> str:
    if not metrics.get("rho_postshock_drop_checked", False):
        return "rho_drop_not_checked"
    if metrics.get("rho_postshock_drop_ok", False):
        return "rho_drop_ok"
    shock_cells = float(metrics.get("shock_cells", float("inf")))
    p_hf = float(metrics.get("p_hf_osc", 0.0))
    rho_hf = float(metrics.get("rho_hf_osc", 0.0))
    if shock_cells > 1.0:
        return "shock_location_or_profile_sampling_issue"
    if p_hf > 3.0e-3 or rho_hf > 5.0e-3:
        return "numerical_oscillation_issue"
    rho_drop_x = metrics.get("rho_postshock_drop_x")
    rho_peak_x = metrics.get("rho_postshock_peak_x")
    if rho_drop_x is not None and rho_peak_x is not None:
        try:
            if abs(float(rho_drop_x) - float(rho_peak_x)) > 0.2:
                return "persistent_interface_or_closure_issue"
        except Exception:
            pass
    return "persistent_thermodynamic_interface_closure_issue"


def main() -> int:
    psi_values = _float_list("PSI_VALUES", "0.75")
    n_values = _int_list("N_VALUES", "100,200,400")
    cfl = float(os.environ.get("CFL", os.environ.get("DENNER_CASE24_CFL", "0.4")))
    os.environ["DENNER_CASE24_CFL"] = str(cfl)
    rows = []
    t0 = time.time()

    for psi in psi_values:
        for n in n_values:
            os.environ["DENNER_CASE24_N"] = str(n)
            sub_t0 = time.time()
            row = _case24_subcase(psi)
            x = np.asarray(row["x"], dtype=float)
            rho = np.asarray(row["rho"], dtype=float)
            u = np.asarray(row["u"], dtype=float)
            p = np.asarray(row["p"], dtype=float)
            exact = row["exact"]
            rho_exact = np.asarray(exact["rho"], dtype=float)
            dx = 1.0 / int(n)
            plateau = (x > 0.15) & (x < 0.75)
            postshock = (x > 0.15) & (x < 0.75)
            grad_p = np.gradient(p, dx)
            grad_u = np.gradient(u, dx)
            rho_res = rho - rho_exact
            metrics = row.get("metrics", {})
            out = {
                "psi_water": psi,
                "N": n,
                "CFL": cfl,
                "pass": bool(row.get("pass")),
                "diagnostic_wall": time.time() - sub_t0,
            }
            for key in (
                "finite", "complete", "wall", "steps", "shock_x", "shock_cells",
                "p_profile_l2", "u_profile_l2", "rho_profile_l2", "p_hf_osc",
                "rho_hf_osc", "rho_postshock_drop_checked",
                "rho_postshock_drop_ok", "rho_postshock_dip_rel_jump",
                "rho_postshock_overshoot_rel_jump", "rho_postshock_l2_rel_jump",
                "rho_postshock_drop_x", "rho_postshock_peak_x",
                "rho_postshock_plateau_cells",
            ):
                value = metrics.get(key)
                out[key] = float(value) if isinstance(value, (int, float, np.floating)) else value
            arrays = {
                "rho": rho,
                "rho_exact": rho_exact,
                "rho_res": rho_res,
                "p": p,
                "u": u,
                "grad_p": grad_p,
                "grad_u": grad_u,
            }
            out.update(_window_stats("plateau", x, plateau, arrays))
            out.update(_window_stats("postshock", x, postshock, arrays))
            out["classification"] = _classify(metrics, out)
            print("RHODROP_JSON " + json.dumps(out, sort_keys=True), flush=True)
            rows.append(out)

    summary = {
        "CFL": cfl,
        "psi_values": psi_values,
        "N_values": n_values,
        "wall": time.time() - t0,
        "rows": rows,
        "classifications": sorted({row["classification"] for row in rows}),
    }
    print("SUMMARY_JSON " + json.dumps(summary, sort_keys=True), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


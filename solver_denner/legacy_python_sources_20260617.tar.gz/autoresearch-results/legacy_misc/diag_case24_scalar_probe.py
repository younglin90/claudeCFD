#!/usr/bin/env python3
import os, sys, time, json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(1,str(ROOT.parent))
if (ROOT.parent/'.codex-loop').exists(): sys.path.insert(0,str(ROOT.parent/'.codex-loop'))
from solver.denner_1d.main import run as denner_run
from results.run_denner1d_17case import (_make_ref_air,_make_ref_water_nasg,_v_case24_kapila_path_exact,_temperature_from_rho_p,_final_state,_mix_rho,_v_relative_l2,_pearson,AIR_IDEAL,WATER_NASG)
N=int(os.environ.get('N','100')); CFL=float(os.environ.get('CFL','0.4')); psi_water=float(os.environ.get('PSI','0.25'))
tvd=os.environ.get('TVD_LIMITER','minmod'); scalar=os.environ.get('SCALAR_TVD_LIMITER') or None; vel=os.environ.get('VELOCITY_TVD_LIMITER','vanalbada')
L=1.0; dx=L/N; x=(np.arange(N)+0.5)*dx; x_shock0=0.1; x_shock_exact=0.8; Ms=10.0
p_pre=1e5; rho_air_pre=1.1574; rho_water_pre=998.0; alpha_floor=1e-6
if psi_water<=0: ph1=ph2=AIR_IDEAL; rho1_pre=rho2_pre=rho_air_pre
elif psi_water>=1: ph1=ph2=WATER_NASG; rho1_pre=rho2_pre=rho_water_pre
else: ph1,ph2=AIR_IDEAL,WATER_NASG; rho1_pre,rho2_pre=rho_air_pre,rho_water_pre
rh=_v_case24_kapila_path_exact(Ms,psi_water,_make_ref_air(),_make_ref_water_nasg(),p_pre=p_pre,rho_air=rho_air_pre,rho_water=rho_water_pre)
p_post=rh['p_post']; rho_post_mix=rh['rho_post']; u_post=rh['u_post']; comp=rh['comp']; alpha_pre=rh['alpha_pre']; alpha_post=rh['alpha_post']; V_s=rh['V_s']; t_end=0.7/V_s
left=x<x_shock0; psi0=np.clip(np.where(left,alpha_post,alpha_pre),alpha_floor,1-alpha_floor)
p_init=np.where(left,p_post,p_pre); u_init=np.where(left,u_post,0.0)
q1_pre=alpha_pre*rho1_pre; q2_pre=(1-alpha_pre)*rho2_pre
rho1=np.where(left,q1_pre*comp/alpha_post,rho1_pre); rho2=np.where(left,q2_pre*comp/(1-alpha_post),rho2_pre)
T1=_temperature_from_rho_p(ph1,rho1,p_init); T2=_temperature_from_rho_p(ph2,rho2,p_init); T_init=psi0*T1+(1-psi0)*T2
case_params={'ph1':ph1,'ph2':ph2,'x_cells':x,'psi_init':psi0,'T_init':T_init,'u_init':u_init,'p_init':p_init,'t_end':t_end,'CFL':CFL,'bc_left':'transmissive','bc_right':'transmissive','verbose':False,'cfl_type':'acoustic','max_iteration':200000,'use_autograd':True,'use_acid':True,'vof_type':'volume','variable_set':'puT','use_K':False,'use_compress':False,'coupled':False,'solver_mode':'delta','third_var':'T','bdf_order':2,'mwi_rho_star':'harmonic','tvd_limiter':tvd,'scalar_tvd_limiter':scalar,'velocity_tvd_limiter':vel,'mwi_transient':True,'acoustic_face_correction':True,'acid_temporal_colour':'new','max_outer':1,'max_inner':20,'max_newton':20,'newton_tol':1e-6,'inner_tol':1e-6,'outer_tol':1e-6,'newton_omega':1.0,'use_jfnk':True,'krylov_max':8}
st=time.time(); res=denner_run(case_params); psi_f,T_f,u_f,p_f=_final_state(res); rho_f=_mix_rho(psi_f,p_f,T_f,ph1,ph2)
exact={'rho':np.where(x<x_shock_exact,rho_post_mix,(1-psi_water)*rho_air_pre+psi_water*rho_water_pre),'u':np.where(x<x_shock_exact,u_post,0.0),'p':np.where(x<x_shock_exact,p_post,p_pre)}
p_mid=0.5*(p_post+p_pre); above=p_f>p_mid; shock_x=float(x[np.where(above)[0].max()]) if np.any(above) else float('nan')
out=dict(N=N,CFL=CFL,psi_water=psi_water,tvd_limiter=tvd,scalar_tvd_limiter=scalar or '',velocity_tvd_limiter=vel,wall=time.time()-st,complete=res['t_history'][-1]>=t_end-1e-14,diverged=res.get('diverged',False),diverge_reason=str(res.get('diverge_reason','')),shock_x=shock_x,shock_cells=abs(shock_x-x_shock_exact)/dx if np.isfinite(shock_x) else 1e99,p_l2=_v_relative_l2(p_f,exact['p'],1e5),u_l2=_v_relative_l2(u_f,exact['u'],1.0),rho_l2=_v_relative_l2(rho_f,exact['rho'],1.0),p_corr=_pearson(p_f,exact['p']),u_corr=_pearson(u_f,exact['u']),rho_corr=_pearson(rho_f,exact['rho']),psi_min=float(np.min(psi_f)),psi_max=float(np.max(psi_f)),rho_min=float(np.min(rho_f)),rho_max=float(np.max(rho_f)),u_max=float(np.max(u_f)),p_max=float(np.max(p_f)),steps=len(res['dt_history']))

def conv(v):
    if hasattr(v, 'item'):
        return v.item()
    return v
print(json.dumps({k: conv(v) for k, v in out.items()}, sort_keys=True))

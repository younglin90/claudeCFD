#!/usr/bin/env python3
"""Run selected current-head case24 subcases without editing the driver."""
from __future__ import annotations

import json
import os
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from results.run_denner1d_17case import _case24_subcase  # noqa: E402


def _float_list(env_name: str, default: str) -> list[float]:
    raw = os.environ.get(env_name, default)
    return [float(part.strip()) for part in raw.split(",") if part.strip()]


def _json_safe(value):
    if isinstance(value, (str, bool, int, float)) or value is None:
        return value
    try:
        return float(value)
    except Exception:
        return str(value)


def main() -> int:
    n = int(os.environ.get("N", os.environ.get("DENNER_CASE24_N", "400")))
    cfl = float(os.environ.get("CFL", os.environ.get("DENNER_CASE24_CFL", "0.4")))
    os.environ["DENNER_CASE24_N"] = str(n)
    os.environ["DENNER_CASE24_CFL"] = str(cfl)
    psi_values = _float_list("PSI_VALUES", "0.5,0.75,1.0")

    t0 = time.time()
    rows = []
    for psi in psi_values:
        sub_t0 = time.time()
        row = _case24_subcase(psi)
        metrics = row.get("metrics", {})
        out = {
            "name": row.get("name", f"24H psi_water={psi:g}"),
            "psi_water": psi,
            "pass": bool(row.get("pass")),
        }
        for key in (
            "finite", "complete", "wall", "steps", "shock_x", "shock_cells",
            "p_profile_l2", "u_profile_l2", "rho_profile_l2", "p_hf_osc",
            "rho_hf_osc", "rho_postshock_drop_checked",
            "rho_postshock_drop_ok",
        ):
            out[key] = _json_safe(metrics.get(key))
        out["diagnostic_wall"] = time.time() - sub_t0
        print("SUBCASE_JSON " + json.dumps(out, sort_keys=True), flush=True)
        rows.append(out)

    summary = {
        "N": n,
        "CFL": cfl,
        "psi_values": psi_values,
        "pass_count": sum(1 for row in rows if row["pass"]),
        "failures": sum(1 for row in rows if not row["pass"]),
        "wall": time.time() - t0,
        "max_wall_subcase": max((float(row.get("diagnostic_wall", 0.0)) for row in rows), default=0.0),
        "rows": rows,
    }
    print("SUMMARY_JSON " + json.dumps(summary, sort_keys=True), flush=True)
    return 0 if summary["failures"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())


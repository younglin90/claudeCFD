#!/usr/bin/env python3
"""Case24 source/divergence balance diagnostic for solver_denner.

Runs the current solver on the case24 common-T reference at N=100, CFL=0.4
for PSI=0.5 and PSI=0.75, then measures the balance between the explicit VOF
flux divergence and the compressible source term on the final step.

This is a no-edit diagnostic artifact.  It monkeypatches the solver at runtime
only to capture the final-step face-velocity and face-colour paths so the
reported metrics match the active code path without changing solver sources.
"""
from __future__ import annotations

import json
import os
import math
import sys
import time
from pathlib import Path

import numpy as np
from scipy.optimize import brentq, root

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(1, str(ROOT.parent))

from solver.denner_1d.main import (  # noqa: E402
    run as denner_run,
    _common_density_equivalent_temperature_from_moment,
)
from solver.denner_1d import solver_a as denner_solver_a  # noqa: E402
from solver.denner_1d.assembly import apply_ghost, apply_ghost_velocity  # noqa: E402
from solver.denner_1d.eos.base import compute_mixture_props, compute_phase_props  # noqa: E402
from solver.denner_1d.vof_cn import _compute_K  # noqa: E402

AIR_IDEAL = {'gamma': 1.4, 'pinf': 0.0, 'b': 0.0, 'kv': 717.5, 'eta': 0.0}
WATER_NASG = {'gamma': 1.187, 'pinf': 7.028e8, 'b': 6.61e-4, 'kv': 3610.0, 'eta': -1.177788e6}
CASE24_RHO_PROFILE_L2_TOL = 0.12
CASE24_RHO_PROFILE_CORR_MIN = 0.90
CASE24_PROFILE_CORR_MIN = 0.90
CASE24_SHOCK_LOCATION_TOL_CELLS = 3.0


def _build_case(N: int, psi_water: float, cfl: float):
    L = 1.0
    dx = L / N
    x = (np.arange(N) + 0.5) * dx
    x_shock0 = 0.1
    x_shock_exact = 0.8
    Ms = 10.0
    p_pre = 1.0e5
    rho_air_pre = 1.1574
    rho_water_pre = 998.0
    alpha_floor = 1.0e-6

    if psi_water <= 0.0:
        ph1 = ph2 = AIR_IDEAL
        rho1_pre = rho2_pre = rho_air_pre
    elif psi_water >= 1.0:
        ph1 = ph2 = WATER_NASG
        rho1_pre = rho2_pre = rho_water_pre
    else:
        ph1, ph2 = AIR_IDEAL, WATER_NASG
        rho1_pre, rho2_pre = rho_air_pre, rho_water_pre

    exact = _case24_commonT_4eq_path_exact(
        Ms, psi_water, p_pre=p_pre, rho_air=rho_air_pre, rho_water=rho_water_pre
    )
    p_post = exact["p_post"]
    rho_post_mix = exact["rho_post"]
    u_post = exact["u_post"]
    comp = exact["comp"]
    alpha_pre = exact["alpha_pre"]
    alpha_post = exact["alpha_post"]
    V_s = exact["V_s"]
    t_end = 0.7 / V_s

    left = x < x_shock0
    psi0 = np.clip(np.where(left, alpha_post, alpha_pre), alpha_floor, 1.0 - alpha_floor)
    p_init = np.where(left, p_post, p_pre)
    u_init = np.where(left, u_post, 0.0)

    if "T_pre_input" in exact and "T_post_input" in exact:
        T_init = np.where(left, exact["T_post_input"], exact["T_pre_input"])
    else:
        q1_pre = alpha_pre * rho1_pre
        q2_pre = (1.0 - alpha_pre) * rho2_pre
        rho1 = np.where(left, q1_pre * comp / alpha_post, rho1_pre)
        rho2 = np.where(left, q2_pre * comp / (1.0 - alpha_post), rho2_pre)
        T1 = _temperature_from_rho_p(ph1, rho1, p_init)
        T2 = _temperature_from_rho_p(ph2, rho2, p_init)
        T_init = psi0 * T1 + (1.0 - psi0) * T2

    params = dict(
        ph1=ph1,
        ph2=ph2,
        x_cells=x,
        psi_init=psi0,
        T_init=T_init,
        u_init=u_init,
        p_init=p_init,
        t_end=t_end,
        CFL=cfl,
        bc_left="transmissive",
        bc_right="transmissive",
        verbose=False,
        cfl_type="acoustic",
        max_iteration=int(os.environ.get("MAX_ITER", "200000")),
        use_acid=True,
        vof_type=os.environ.get("VOF_TYPE", "volume"),
        variable_set=os.environ.get("VARIABLE_SET", "puT"),
        use_K=False,
        use_compress=False,
        coupled=False,
        solver_mode="delta",
        third_var=os.environ.get("THIRD_VAR", None),
        bdf_order=int(os.environ.get("BDF_ORDER", "2")),
        mwi_rho_star=os.environ.get("MWI_RHO_STAR", "harmonic"),
        tvd_limiter=os.environ.get("TVD_LIMITER", "minmod"),
        acoustic_limiter=os.environ.get("ACOUSTIC_LIMITER") or None,
        acoustic_limiter_blend=float(os.environ.get("ACOUSTIC_LIMITER_BLEND", "1.0")),
        mwi_transient=True,
        acoustic_face_correction=True,
        acid_temporal_colour=os.environ.get("ACID_TEMPORAL_COLOUR", "new"),
        max_outer=int(os.environ.get("MAX_OUTER", "1")),
        max_inner=int(os.environ.get("MAX_INNER", "20")),
        max_newton=int(os.environ.get("MAX_NEWTON", "20")),
        newton_tol=float(os.environ.get("NEWTON_TOL", "1e-6")),
        inner_tol=float(os.environ.get("NEWTON_TOL", "1e-6")),
        outer_tol=float(os.environ.get("OUTER_TOL", "1e-6")),
        newton_omega=float(os.environ.get("NEWTON_OMEGA", "1.0")),
        use_autograd=False,
        use_jfnk=True,
        krylov_max=int(os.environ.get("KRYLOV_MAX", "8")),
        consistent_vof_face_flux=True,
        density_mood_limiter=True,
        pressure_floor_velocity_regularization=True,
        smooth_acoustic_entropy_projection=True,
        force_mixed_stiff_puh=True,
    )
    if params["third_var"] is None:
        params.pop("third_var")
    return params, exact, x, dx, x_shock_exact, t_end


def _mix_rho(psi: np.ndarray, p: np.ndarray, T: np.ndarray, ph1: dict, ph2: dict) -> np.ndarray:
    props = compute_mixture_props(
        np.asarray(p, dtype=float),
        np.zeros_like(np.asarray(p, dtype=float)),
        np.asarray(T, dtype=float),
        np.asarray(psi, dtype=float),
        ph1, ph2,
    )
    return np.asarray(props["rho"], dtype=float)


def _pearson(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if a.size < 2 or b.size < 2 or a.size != b.size:
        return 0.0
    am = a - np.mean(a)
    bm = b - np.mean(b)
    denom = float(np.sqrt(np.sum(am * am) * np.sum(bm * bm)))
    if denom <= 0.0 or not np.isfinite(denom):
        return 0.0
    return float(np.sum(am * bm) / denom)


def _relative_l2(num: np.ndarray, exact: np.ndarray, scale: float) -> float:
    num = np.asarray(num, dtype=float)
    exact = np.asarray(exact, dtype=float)
    return float(np.sqrt(np.mean((num - exact) ** 2)) / max(scale, 1.0))


def _temperature_from_rho_p(ph: dict, rho_target: np.ndarray, p_val: np.ndarray) -> np.ndarray:
    rho_target = np.asarray(rho_target, dtype=float)
    p_val = np.asarray(p_val, dtype=float)
    out = np.empty_like(rho_target)
    for idx, (rho_i, p_i) in enumerate(zip(rho_target, p_val)):
        if not (np.isfinite(rho_i) and np.isfinite(p_i) and rho_i > 0.0):
            out[idx] = np.nan
            continue

        def f(Tv):
            props = compute_phase_props(np.array([p_i], dtype=float), np.array([Tv], dtype=float), ph)
            return float(np.asarray(props["rho"], dtype=float)[0]) - float(rho_i)

        lo = 1.0e-8
        hi = max(1.0, float(np.sqrt(abs(float(rho_i))) + 1.0))
        flo = f(lo)
        fhi = f(hi)
        for _ in range(80):
            if np.isfinite(flo) and np.isfinite(fhi) and flo * fhi <= 0.0:
                break
            hi *= 2.0
            if hi > 1.0e9:
                break
            fhi = f(hi)
        if np.isfinite(flo) and np.isfinite(fhi) and flo * fhi <= 0.0:
            try:
                out[idx] = float(brentq(f, lo, hi, xtol=1.0e-10, rtol=1.0e-10, maxiter=100))
                continue
            except Exception:
                pass
        out[idx] = max(1.0e-8, float(p_i) / max(float(rho_i), 1.0))
    return out


def _case24_commonT_4eq_path_exact(Ms, psi_water, *, p_pre=1.0e5, rho_air=1.1574, rho_water=998.0) -> dict:
    if psi_water <= 0.0 or psi_water >= 1.0:
        return {
            "alpha_pre": 1.0 - float(psi_water),
            "alpha_post": 1.0 - float(psi_water),
            "rho_pre": float(rho_air if psi_water <= 0.0 else rho_water),
            "p_post": float(p_pre * 10.0),
            "rho_post": float(rho_air if psi_water <= 0.0 else rho_water),
            "u_post": float(Ms * 0.0),
            "V_s": float(Ms),
            "c_mix": 1.0,
            "comp": 1.0,
            "T_pre_input": 300.0,
            "T_post_input": 300.0,
            "label": "pure-endpoint fallback",
        }

    ph1 = dict(AIR_IDEAL)
    ph2 = dict(WATER_NASG)
    ph1["enable_stiff_split"] = True
    ph2["enable_stiff_split"] = True
    alpha_pre = 1.0 - float(psi_water)
    rho_pre_target = alpha_pre * float(rho_air) + (1.0 - alpha_pre) * float(rho_water)

    def props(p, u, T, alpha):
        return compute_mixture_props(
            np.array([p], dtype=float),
            np.array([u], dtype=float),
            np.array([T], dtype=float),
            np.array([alpha], dtype=float),
            ph1, ph2,
        )

    def mix_rho(p, T, alpha):
        return float(props(p, 0.0, T, alpha)["rho"][0])

    def mix_energy(p, u, T, alpha):
        return float(props(p, u, T, alpha)["E_total"][0])

    def T_for_mix_rho(p, alpha, rho_target):
        def f(Tv):
            return mix_rho(p, Tv, alpha) - rho_target

        lo = 1.0e-6
        hi = 1.0
        flo = f(lo)
        fhi = f(hi)
        while np.isfinite(flo) and np.isfinite(fhi) and flo * fhi > 0.0 and hi < 1.0e8:
            hi *= 2.0
            fhi = f(hi)
        if not (np.isfinite(flo) and np.isfinite(fhi) and flo * fhi <= 0.0):
            raise RuntimeError("case24 common-T density bracket failed")
        return float(brentq(f, lo, hi, xtol=1.0e-10, rtol=1.0e-10, maxiter=100))

    def T_input_for_common_T(p, alpha, T_common):
        def converted(T_in):
            return float(_common_density_equivalent_temperature_from_moment(
                np.array([p], dtype=float),
                np.array([T_in], dtype=float),
                np.array([alpha], dtype=float),
                ph1, ph2)[0])

        def f(T_in):
            return converted(T_in) - T_common

        lo = 1.0e-6
        hi = max(1.0, T_common)
        for _ in range(80):
            if f(lo) * f(hi) <= 0.0:
                return float(brentq(f, lo, hi, xtol=1.0e-9, rtol=1.0e-10, maxiter=100))
            hi *= 2.0
        return float(T_common)

    def converted_input_temperature(p, alpha, T_in):
        return float(_common_density_equivalent_temperature_from_moment(
            np.array([p], dtype=float),
            np.array([T_in], dtype=float),
            np.array([alpha], dtype=float),
            ph1, ph2)[0])

    T_pre_target = T_for_mix_rho(p_pre, alpha_pre, rho_pre_target)
    T_pre_input = T_input_for_common_T(p_pre, alpha_pre, T_pre_target)
    T_pre = converted_input_temperature(p_pre, alpha_pre, T_pre_input)
    rho_pre = mix_rho(p_pre, T_pre, alpha_pre)
    c_pre = float(props(p_pre, 0.0, T_pre, alpha_pre)["c_mix"][0])
    shock_speed = float(Ms) * c_pre
    E_pre = mix_energy(p_pre, 0.0, T_pre, alpha_pre)

    def pressure_from_u(u):
        return p_pre + rho_pre * shock_speed * u

    def rho_from_u(u):
        return rho_pre * shock_speed / (shock_speed - u)

    def residual(x):
        u = float(x[0])
        alpha = 1.0 / (1.0 + math.exp(-float(x[1])))
        if not (0.0 < u < 0.95 * shock_speed and 0.0 < alpha < 1.0):
            return np.array([1.0e3, 1.0e3])
        p = pressure_from_u(u)
        rho = rho_from_u(u)
        try:
            T = T_for_mix_rho(p, alpha, rho)
            E = mix_energy(p, u, T, alpha)
            energy_res = shock_speed * (E_pre - E) - (0.0 * (E_pre + p_pre) - u * (E + p))
            energy_scale = max(abs(u * (E + p)), 1.0)
            s = np.linspace(0.0, 1.0, 801)
            a_path = alpha + s * (alpha_pre - alpha)
            p_path = p + s * (p_pre - p)
            T_path = T + s * (T_pre - T)
            K_path = _compute_K(a_path, ph1, ph2, p_path, T_path)
            required = -shock_speed * (alpha_pre - alpha) - u * alpha
            source = float(np.trapezoid(a_path + K_path, s) * (-u))
            alpha_res = (source - required) / max(abs(required), 1.0e-300)
            return np.array([energy_res / energy_scale, alpha_res])
        except Exception:
            return np.array([1.0e2, 1.0e2])

    old = {
        "alpha_post": alpha_pre,
        "u_post": 0.0,
    }
    sol = root(residual, np.array([1.0, math.log(max(alpha_pre, 1.0e-8) / max(1.0 - alpha_pre, 1.0e-8))]))
    if not sol.success or float(np.linalg.norm(residual(sol.x))) > 1.0e-6:
        raise RuntimeError(f"case24 common-T RH solve failed for psi={psi_water}: {sol.message}")

    u_post = float(sol.x[0])
    alpha_post = 1.0 / (1.0 + math.exp(-float(sol.x[1])))
    p_post = pressure_from_u(u_post)
    rho_post = rho_from_u(u_post)
    T_post = T_for_mix_rho(p_post, alpha_post, rho_post)
    return {
        "alpha_pre": float(alpha_pre),
        "alpha_post": float(alpha_post),
        "rho_pre": float(rho_pre),
        "p_post": float(p_post),
        "rho_post": float(rho_post),
        "u_post": float(u_post),
        "V_s": float(shock_speed),
        "c_mix": float(c_pre),
        "comp": float(rho_post / rho_pre),
        "T_pre_common": float(T_pre),
        "T_post_common": float(T_post),
        "T_pre_input": float(T_pre_input),
        "T_post_input": float(T_input_for_common_T(p_post, alpha_post, T_post)),
        "label": "solver-consistent common-T four-equation RH exact",
    }


def _final_state(res):
    s = res["final_state"]
    return s["psi"], s["T"], s["u"], s["p"]


def _rho_postshock_drop_guard(x, rho_f, exact_rho, x_shock_exact):
    x = np.asarray(x, dtype=float)
    rho_f = np.asarray(rho_f, dtype=float)
    exact_rho = np.asarray(exact_rho, dtype=float)
    mask = (x >= x_shock_exact + 0.01) & (x <= min(0.98, x_shock_exact + 0.15))
    if np.count_nonzero(mask) < 4:
        return {"rho_postshock_drop_checked": False, "rho_postshock_drop_ok": True}
    rho = rho_f[mask]
    ex = exact_rho[mask]
    drop_ok = bool((rho[-1] <= rho[0] * 1.02) and (np.mean(rho) <= np.mean(ex) * 1.10))
    return {"rho_postshock_drop_checked": True, "rho_postshock_drop_ok": drop_ok}


def _rho_u_p_hf_guard(x, rho_f, u_f, p_f, exact):
    x = np.asarray(x, dtype=float)
    rho_f = np.asarray(rho_f, dtype=float)
    u_f = np.asarray(u_f, dtype=float)
    p_f = np.asarray(p_f, dtype=float)
    plateau = (x > 0.15) & (x < 0.75)
    if int(np.count_nonzero(plateau)) >= 4:
        p_res = np.asarray(p_f - exact["p"], dtype=float)[plateau]
        rho_res = np.asarray(rho_f - exact["rho"], dtype=float)[plateau]
        u_res = np.asarray(u_f - exact["u"], dtype=float)[plateau]
        p_d2 = p_res[1:-1] - 0.5 * (p_res[:-2] + p_res[2:])
        rho_d2 = rho_res[1:-1] - 0.5 * (rho_res[:-2] + rho_res[2:])
        u_d2 = u_res[1:-1] - 0.5 * (u_res[:-2] + u_res[2:])
        p_hf_osc = float(np.max(np.abs(p_d2)) / max(float(np.max(exact["p"])), 1.0))
        rho_hf_osc = float(np.max(np.abs(rho_d2)) / max(float(np.max(exact["rho"])), 1.0))
        u_hf_osc = float(np.max(np.abs(u_d2)) / max(float(np.max(np.abs(exact["u"]))), 1.0))
    else:
        p_hf_osc = 0.0
        rho_hf_osc = 0.0
        u_hf_osc = 0.0
    return {
        "hf_oscillation_ok": bool(p_hf_osc < 3.0e-3 and rho_hf_osc < 5.0e-3),
        "p_hf_osc": p_hf_osc,
        "rho_hf_osc": rho_hf_osc,
        "u_hf_osc": u_hf_osc,
    }


def _face_map(N: int, bc_l: str, bc_r: str):
    face_ids = np.arange(N + 1)
    face_left = face_ids - 1
    face_right = face_ids.copy()
    if bc_l == "periodic":
        face_left = np.where(face_left < 0, N - 1, face_left)
    else:
        face_left = np.maximum(face_left, 0)
    if bc_r == "periodic":
        face_right = np.where(face_right >= N, 0, face_right)
    else:
        face_right = np.minimum(face_right, N - 1)
    return face_left, face_right


def _window_stats(values: np.ndarray, mask: np.ndarray) -> dict:
    vals = np.asarray(values, dtype=float)[np.asarray(mask, dtype=bool)]
    if vals.size == 0:
        return {
            "count": 0,
            "mean": 0.0,
            "mean_abs": 0.0,
            "max_abs": 0.0,
            "min": 0.0,
            "max": 0.0,
            "same_sign_fraction": 0.0,
        }
    signs = np.sign(vals[np.abs(vals) > 0.0])
    if signs.size == 0:
        same_sign_fraction = 1.0
    else:
        same_sign_fraction = float(np.max(np.bincount((signs > 0).astype(int))) / signs.size)
    return {
        "count": int(vals.size),
        "mean": float(np.mean(vals)),
        "mean_abs": float(np.mean(np.abs(vals))),
        "max_abs": float(np.max(np.abs(vals))),
        "min": float(np.min(vals)),
        "max": float(np.max(vals)),
        "same_sign_fraction": same_sign_fraction,
    }


def _relative_scale(num: np.ndarray, denom: np.ndarray) -> np.ndarray:
    return np.asarray(num, dtype=float) / np.maximum(np.asarray(denom, dtype=float), 1.0e-300)


def _capture_solver_calls():
    captured = {"vof": [], "face": []}
    orig_vof_step = denner_solver_a.vof_step
    orig_compute_face_velocity = denner_solver_a._compute_face_velocity

    def vof_step_probe(*args, **kwargs):
        out = orig_vof_step(*args, **kwargs)
        psi = np.asarray(args[0], dtype=float).copy() if len(args) > 0 else None
        u = np.asarray(args[1], dtype=float).copy() if len(args) > 1 else None
        record = {
            "psi": psi,
            "u": u,
            "dx": float(args[2]) if len(args) > 2 else float(kwargs.get("dx", np.nan)),
            "dt": float(args[3]) if len(args) > 3 else float(kwargs.get("dt", np.nan)),
            "bc_l": args[4] if len(args) > 4 else kwargs.get("bc_l"),
            "bc_r": args[5] if len(args) > 5 else kwargs.get("bc_r"),
            "u_face_override": None if kwargs.get("u_face_override") is None else np.asarray(
                kwargs.get("u_face_override"), dtype=float).copy(),
            "psi_new": np.asarray(out[0], dtype=float).copy(),
            "psi_face": np.asarray(out[1], dtype=float).copy(),
            "u_face": np.asarray(out[2], dtype=float).copy(),
        }
        captured["vof"].append(record)
        return out

    def compute_face_velocity_probe(*args, **kwargs):
        out = orig_compute_face_velocity(*args, **kwargs)
        record = {
            "u_k": np.asarray(args[0], dtype=float).copy() if len(args) > 0 else None,
            "p_k": np.asarray(args[1], dtype=float).copy() if len(args) > 1 else None,
            "d_hat": np.asarray(args[2], dtype=float).copy() if len(args) > 2 else None,
            "dx": float(args[3]) if len(args) > 3 else float(kwargs.get("dx", np.nan)),
            "bc_l": args[4] if len(args) > 4 else kwargs.get("bc_l"),
            "bc_r": args[5] if len(args) > 5 else kwargs.get("bc_r"),
            "theta_old": None if kwargs.get("theta_old") is None else np.asarray(
                kwargs.get("theta_old"), dtype=float).copy(),
            "u_bar_old": None if kwargs.get("u_bar_old") is None else np.asarray(
                kwargs.get("u_bar_old"), dtype=float).copy(),
            "rho_star_old": None if kwargs.get("rho_star_old") is None else np.asarray(
                kwargs.get("rho_star_old"), dtype=float).copy(),
            "dt": None if kwargs.get("dt") is None else float(kwargs.get("dt")),
            "theta_nm1": None if kwargs.get("theta_nm1") is None else np.asarray(
                kwargs.get("theta_nm1"), dtype=float).copy(),
            "u_bar_nm1": None if kwargs.get("u_bar_nm1") is None else np.asarray(
                kwargs.get("u_bar_nm1"), dtype=float).copy(),
            "rho_star_nm1": None if kwargs.get("rho_star_nm1") is None else np.asarray(
                kwargs.get("rho_star_nm1"), dtype=float).copy(),
            "dt_prev": None if kwargs.get("dt_prev") is None else float(kwargs.get("dt_prev")),
            "dt_eff": None if kwargs.get("dt_eff") is None else float(kwargs.get("dt_eff")),
            "theta": np.asarray(out[0], dtype=float).copy(),
            "u_bar": np.asarray(out[1], dtype=float).copy(),
        }
        captured["face"].append(record)
        return out

    return captured, orig_vof_step, orig_compute_face_velocity, vof_step_probe, compute_face_velocity_probe


def _final_metrics(psi_f, T_f, u_f, p_f, x, dx, psi_water, exact, ph1, ph2, x_shock_exact):
    rho_f = _mix_rho(psi_f, p_f, T_f, ph1, ph2)
    p_exact = np.where(x < x_shock_exact, exact["p_post"], 1.0e5)
    u_exact = np.where(x < x_shock_exact, exact["u_post"], 0.0)
    rho_exact = np.where(x < x_shock_exact, exact["rho_post"], exact["rho_pre"])
    exact_profile = {"p": p_exact, "u": u_exact, "rho": rho_exact}
    finite = bool(np.all(np.isfinite(psi_f)) and np.all(np.isfinite(T_f))
                  and np.all(np.isfinite(u_f)) and np.all(np.isfinite(p_f))
                  and np.all(np.isfinite(rho_f)))
    complete = True
    p_profile_l2 = _relative_l2(p_f, p_exact, 1.0e5)
    u_profile_l2 = _relative_l2(u_f, u_exact, 1.0)
    rho_profile_l2 = _relative_l2(rho_f, rho_exact, 1.0)
    p_corr = _pearson(p_f, p_exact)
    u_corr = _pearson(u_f, u_exact)
    rho_corr = _pearson(rho_f, rho_exact)
    p_mid = 0.5 * (float(np.max(p_exact)) + float(np.min(p_exact)))
    above = p_f > p_mid
    shock_x = float(x[np.where(above)[0].max()]) if np.any(above) else float("nan")
    shock_cells = abs(shock_x - x_shock_exact) / dx if np.isfinite(shock_x) else float("inf")
    p_osc = float(np.max(np.abs((p_f - p_exact)[1:-1] - 0.5 * ((p_f - p_exact)[:-2] + (p_f - p_exact)[2:]))) / max(float(np.max(p_exact)), 1.0)) if len(x) >= 4 else 0.0
    rho_osc = float(np.max(np.abs((rho_f - rho_exact)[1:-1] - 0.5 * ((rho_f - rho_exact)[:-2] + (rho_f - rho_exact)[2:]))) / max(float(np.max(rho_exact)), 1.0)) if len(x) >= 4 else 0.0
    plateau = (x > 0.15) & (x < 0.75)
    if int(np.count_nonzero(plateau)) >= 4:
        p_res = np.asarray(p_f - p_exact, dtype=float)[plateau]
        rho_res = np.asarray(rho_f - rho_exact, dtype=float)[plateau]
        p_d2 = p_res[1:-1] - 0.5 * (p_res[:-2] + p_res[2:])
        rho_d2 = rho_res[1:-1] - 0.5 * (rho_res[:-2] + rho_res[2:])
        p_hf_osc = float(np.max(np.abs(p_d2)) / max(float(np.max(p_exact)), 1.0))
        rho_hf_osc = float(np.max(np.abs(rho_d2)) / max(float(np.max(rho_exact)), 1.0))
    else:
        p_hf_osc = 0.0
        rho_hf_osc = 0.0
    rho_drop = {"rho_postshock_drop_checked": False, "rho_postshock_drop_ok": True}
    if 0.0 < psi_water < 1.0:
        rho_drop = _rho_postshock_drop_guard(x, rho_f, rho_exact, x_shock_exact)
    hf = _rho_u_p_hf_guard(x, rho_f, u_f, p_f, exact_profile)
    return {
        "finite": finite,
        "complete": complete,
        "p_profile_l2": p_profile_l2,
        "u_profile_l2": u_profile_l2,
        "rho_profile_l2": rho_profile_l2,
        "p_corr": p_corr,
        "u_corr": u_corr,
        "rho_corr": rho_corr,
        "shock_x": shock_x,
        "shock_cells": shock_cells,
        "p_osc": p_osc,
        "rho_osc": rho_osc,
        "p_hf_osc": p_hf_osc,
        "rho_hf_osc": rho_hf_osc,
        "rho_drop": rho_drop,
        "hf": hf,
        "rho_f": rho_f,
    }


def _compare_face_paths(face_record):
    u = np.asarray(face_record["u_k"], dtype=float)
    bc_l = face_record["bc_l"]
    bc_r = face_record["bc_r"]
    u_ext = apply_ghost_velocity(u, bc_l, bc_r, 1)
    u_arith = 0.5 * (u_ext[:-1] + u_ext[1:])
    theta = np.asarray(face_record["theta"], dtype=float)
    theta_old = face_record["theta_old"]
    theta_nm1 = face_record["theta_nm1"]
    dt = face_record["dt"]
    dt_prev = face_record["dt_prev"]
    if theta_old is not None and theta_nm1 is not None and dt is not None and dt_prev is not None and dt_prev > 0.0:
        theta_ab2 = theta_old + 0.5 * dt / dt_prev * (theta_old - theta_nm1)
    else:
        theta_ab2 = None
    return {
        "arith_linf": float(np.max(np.abs(theta - u_arith))),
        "arith_l2": float(np.sqrt(np.mean((theta - u_arith) ** 2))),
        "ab2_linf": float(np.max(np.abs(theta - theta_ab2))) if theta_ab2 is not None else None,
        "ab2_l2": float(np.sqrt(np.mean((theta - theta_ab2) ** 2))) if theta_ab2 is not None else None,
    }


def _compare_alpha_override(vof_record, face_record):
    u = np.asarray(vof_record["u"], dtype=float)
    bc_l = vof_record["bc_l"]
    bc_r = vof_record["bc_r"]
    u_ext = apply_ghost_velocity(u, bc_l, bc_r, 1)
    u_arith = 0.5 * (u_ext[:-1] + u_ext[1:])
    override = vof_record["u_face_override"]
    if override is None:
        override = u_arith.copy()
    theta_old = face_record["theta_old"] if face_record is not None else None
    theta_nm1 = face_record["theta_nm1"] if face_record is not None else None
    dt = face_record["dt"] if face_record is not None else None
    dt_prev = face_record["dt_prev"] if face_record is not None else None
    if theta_old is not None and theta_nm1 is not None and dt is not None and dt_prev is not None and dt_prev > 0.0:
        alpha_ab2 = theta_old + 0.5 * dt / dt_prev * (theta_old - theta_nm1)
    else:
        alpha_ab2 = None
    return {
        "actual_vs_arith_linf": float(np.max(np.abs(vof_record["u_face"] - u_arith))),
        "actual_vs_arith_l2": float(np.sqrt(np.mean((vof_record["u_face"] - u_arith) ** 2))),
        "override_vs_arith_linf": float(np.max(np.abs(np.asarray(override) - u_arith))),
        "override_vs_arith_l2": float(np.sqrt(np.mean((np.asarray(override) - u_arith) ** 2))),
        "override_vs_ab2_linf": float(np.max(np.abs(np.asarray(override) - alpha_ab2))) if alpha_ab2 is not None else None,
        "override_vs_ab2_l2": float(np.sqrt(np.mean((np.asarray(override) - alpha_ab2) ** 2))) if alpha_ab2 is not None else None,
        "actual_vs_override_linf": float(np.max(np.abs(vof_record["u_face"] - np.asarray(override)))),
        "actual_vs_override_l2": float(np.sqrt(np.mean((vof_record["u_face"] - np.asarray(override)) ** 2))),
    }


def _source_balance_report(psi_f, T_f, u_f, p_f, psi_face, u_face, psi_water, exact_profile, ph1, ph2, x, dx):
    rho_f = _mix_rho(psi_f, p_f, T_f, ph1, ph2)
    K_cell = _compute_K(psi_f, ph1, ph2, p_f, T_f)
    du_dx = (u_face[1:] - u_face[:-1]) / dx
    flux_div = (psi_face[1:] * u_face[1:] - psi_face[:-1] * u_face[:-1]) / dx
    alpha_div = psi_f * du_dx
    K_div = K_cell * du_dx
    residual = flux_div - alpha_div
    source = (psi_f + K_cell) * du_dx
    scale = np.maximum.reduce((
        np.abs(source),
        np.abs(flux_div),
        np.abs(K_div),
        np.ones_like(source),
    ))
    rel_residual = np.abs(residual) / scale
    ratio_flux = np.abs(residual) / np.maximum(np.abs(flux_div), 1.0e-300)
    ratio_source = np.abs(residual) / np.maximum(np.abs(source), 1.0e-300)
    ratio_K = np.abs(residual) / np.maximum(np.abs(K_div), 1.0e-300)
    rho_jump = np.maximum(
        np.abs(rho_f - np.r_[rho_f[0], rho_f[:-1]]),
        np.abs(np.r_[rho_f[1:], rho_f[-1]] - rho_f),
    )
    rho_res = rho_f - exact_profile["rho"]
    shock_window = (x >= 0.74) & (x <= 0.84)
    postshock_plateau = (x >= 0.84) & (x <= 0.94)
    shock_abs = np.abs(residual[shock_window])
    plateau_abs = np.abs(residual[postshock_plateau])
    shock_res = residual[shock_window]
    shock_rho = rho_res[shock_window]
    paired_mask = (np.abs(shock_res) > 0.0) | (np.abs(shock_rho) > 0.0)
    if np.any(paired_mask):
        shock_same_sign_frac = float(np.mean(np.sign(shock_res[paired_mask]) == np.sign(shock_rho[paired_mask])))
    else:
        shock_same_sign_frac = 0.0
    shock_rho_corr = _pearson(residual[shock_window], rho_res[shock_window]) if np.count_nonzero(shock_window) >= 3 else 0.0
    plateau_rho_corr = _pearson(residual[postshock_plateau], rho_res[postshock_plateau]) if np.count_nonzero(postshock_plateau) >= 3 else 0.0
    fail_idx = np.argsort(-np.abs(rho_res))[:5]
    res_peak_idx = int(np.argmax(np.abs(residual)))
    window_peak_idx = int(np.argmax(np.abs(residual * shock_window))) if np.any(shock_window) else -1
    return {
        "rho": rho_f,
        "K_cell": K_cell,
        "du_dx": du_dx,
        "flux_div": flux_div,
        "alpha_div": alpha_div,
        "K_div": K_div,
        "source": source,
        "residual": residual,
        "rel_residual": rel_residual,
        "ratio_flux": ratio_flux,
        "ratio_source": ratio_source,
        "ratio_K": ratio_K,
        "rho_jump": rho_jump,
        "rho_res": rho_res,
        "shock_window": shock_window,
        "postshock_plateau": postshock_plateau,
        "shock_summary": {
            **_window_stats(residual, shock_window),
            "mean_ratio_flux": float(np.mean(ratio_flux[shock_window])) if np.any(shock_window) else 0.0,
            "mean_ratio_source": float(np.mean(ratio_source[shock_window])) if np.any(shock_window) else 0.0,
            "mean_ratio_K": float(np.mean(ratio_K[shock_window])) if np.any(shock_window) else 0.0,
            "mean_rel_residual": float(np.mean(rel_residual[shock_window])) if np.any(shock_window) else 0.0,
            "peak_rel_residual": float(np.max(rel_residual[shock_window])) if np.any(shock_window) else 0.0,
            "mean_rho_jump": float(np.mean(rho_jump[shock_window])) if np.any(shock_window) else 0.0,
            "same_sign_fraction_rho_res": float(shock_same_sign_frac),
            "same_sign_fraction_rho_res_paired": shock_same_sign_frac,
            "rho_corr": float(shock_rho_corr),
        },
        "postshock_summary": {
            **_window_stats(residual, postshock_plateau),
            "mean_ratio_flux": float(np.mean(ratio_flux[postshock_plateau])) if np.any(postshock_plateau) else 0.0,
            "mean_ratio_source": float(np.mean(ratio_source[postshock_plateau])) if np.any(postshock_plateau) else 0.0,
            "mean_ratio_K": float(np.mean(ratio_K[postshock_plateau])) if np.any(postshock_plateau) else 0.0,
            "mean_rel_residual": float(np.mean(rel_residual[postshock_plateau])) if np.any(postshock_plateau) else 0.0,
            "peak_rel_residual": float(np.max(rel_residual[postshock_plateau])) if np.any(postshock_plateau) else 0.0,
            "mean_rho_jump": float(np.mean(rho_jump[postshock_plateau])) if np.any(postshock_plateau) else 0.0,
            "rho_corr": float(plateau_rho_corr),
        },
        "peak": {
            "residual_cell": res_peak_idx,
            "window_peak_cell": window_peak_idx,
            "residual_cell_x": float(x[res_peak_idx]) if 0 <= res_peak_idx < len(x) else float("nan"),
            "window_peak_x": float(x[window_peak_idx]) if 0 <= window_peak_idx < len(x) and window_peak_idx >= 0 else float("nan"),
            "rho_error_top_cells": [int(i) for i in fail_idx.tolist()],
        },
    }


def main():
    N = int(os.environ.get("N", "100"))
    CFL = float(os.environ.get("CFL", "0.4"))
    psi_values = [float(v) for v in os.environ.get("PSI_VALUES", "0.5,0.75").split(",")]
    out_rows = []
    captured, orig_vof_step, orig_compute_face_velocity, vof_step_probe, compute_face_velocity_probe = _capture_solver_calls()
    denner_solver_a.vof_step = vof_step_probe
    denner_solver_a._compute_face_velocity = compute_face_velocity_probe
    try:
        for psi_water in psi_values:
            params, exact, x, dx, x_shock_exact, t_end = _build_case(N, psi_water, CFL)
            t0 = time.time()
            res = denner_run(params)
            wall = time.time() - t0
            psi_f, T_f, u_f, p_f = _final_state(res)
            metrics = _final_metrics(psi_f, T_f, u_f, p_f, x, dx, psi_water, exact, params["ph1"], params["ph2"], x_shock_exact)
            exact_profile = {
                "p": np.where(x < x_shock_exact, exact["p_post"], 1.0e5),
                "u": np.where(x < x_shock_exact, exact["u_post"], 0.0),
                "rho": np.where(x < x_shock_exact, exact["rho_post"], exact["rho_pre"]),
            }
            vof_rec = captured["vof"][-1] if captured["vof"] else None
            face_rec = captured["face"][-1] if captured["face"] else None
            path_cmp = _compare_face_paths(face_rec) if face_rec is not None else {}
            if vof_rec is not None:
                u_face = np.asarray(vof_rec["u_face"], dtype=float)
                psi_face = np.asarray(vof_rec["psi_face"], dtype=float)
                u_override = vof_rec["u_face_override"]
                if u_override is None:
                    u_override = u_face.copy()
                override_kind = "arithmetic" if np.max(np.abs(u_override - u_face)) <= 1.0e-12 * max(1.0, float(np.max(np.abs(u_face)))) else "mwi_ab2_or_mixed"
                source = _source_balance_report(
                    psi_f, T_f, u_f, p_f, psi_face, u_face, psi_water, exact_profile,
                    params["ph1"], params["ph2"], x, dx)
                alpha_face_cmp = _compare_alpha_override(vof_rec, face_rec)
                du_dx = source["du_dx"]
                flux_div = source["flux_div"]
                alpha_div = source["alpha_div"]
                K_div = source["K_div"]
                residual = source["residual"]
                rel_residual = source["rel_residual"]
                source_scale = np.maximum.reduce((
                    np.abs(source["source"]),
                    np.abs(flux_div),
                    np.abs(K_div),
                    np.ones_like(flux_div),
                ))
                rho_res = source["rho_res"]
                shock_window = source["shock_window"]
                postshock_plateau = source["postshock_plateau"]
                balance = {
                    "source_flux_scale_min": float(np.min(source_scale)),
                    "source_flux_scale_mean": float(np.mean(source_scale)),
                    "residual_to_scale_mean": float(np.mean(rel_residual)),
                    "residual_to_scale_max": float(np.max(rel_residual)),
                    "residual_to_flux_mean": float(np.mean(source["ratio_flux"])),
                    "residual_to_source_mean": float(np.mean(source["ratio_source"])),
                    "residual_to_K_mean": float(np.mean(source["ratio_K"])),
                    "same_sign_shock": bool(np.all(np.sign(residual[shock_window][np.abs(residual[shock_window]) > 0.0]) == np.sign(np.sum(residual[shock_window]))))
                    if np.count_nonzero(shock_window) and np.any(np.abs(residual[shock_window]) > 0.0) else False,
                    "shock_localization_fraction": float(np.sum(np.abs(residual[shock_window])) / np.sum(np.abs(residual)) ) if np.sum(np.abs(residual)) > 0.0 else 0.0,
                    "shock_rho_corr": source["shock_summary"]["rho_corr"],
                    "postshock_rho_corr": source["postshock_summary"]["rho_corr"],
                    "peak_cell": source["peak"]["residual_cell"],
                    "peak_x": source["peak"]["residual_cell_x"],
                    "rho_error_peak_cells": source["peak"]["rho_error_top_cells"],
                    "rho_drop_ok": bool(metrics["rho_drop"]["rho_postshock_drop_ok"]),
                }
            else:
                psi_face = None
                u_face = None
                override_kind = "missing"
                balance = {}
                source = {}
                du_dx = flux_div = alpha_div = K_div = residual = rel_residual = None

            row = {
                "psi_water": psi_water,
                "N": N,
                "CFL": CFL,
                "wall": wall,
                "steps": len(res["dt_history"]),
                "diverged": bool(res.get("diverged", False)),
                "complete": bool(res["t_history"][-1] >= t_end - 1.0e-14),
                "p_l2": metrics["p_profile_l2"],
                "u_l2": metrics["u_profile_l2"],
                "rho_l2": metrics["rho_profile_l2"],
                "p_corr": metrics["p_corr"],
                "u_corr": metrics["u_corr"],
                "rho_corr": metrics["rho_corr"],
                "shock_cells": metrics["shock_cells"],
                "shock_x": metrics["shock_x"],
                "p_hf_osc": metrics["p_hf_osc"],
                "rho_hf_osc": metrics["rho_hf_osc"],
                "rho_drop_ok": bool(metrics["rho_drop"]["rho_postshock_drop_ok"]),
                "rho_drop_checked": bool(metrics["rho_drop"]["rho_postshock_drop_checked"]),
                "hf_ok": bool(metrics["hf"]["hf_oscillation_ok"]),
                "face_override_kind": override_kind,
                "face_compare": path_cmp,
                "source_balance": {
                    "flux_div_mean_abs_window": float(np.mean(np.abs(flux_div[source["shock_window"]]))) if source else 0.0,
                    "alpha_div_mean_abs_window": float(np.mean(np.abs(alpha_div[source["shock_window"]]))) if source else 0.0,
                    "K_div_mean_abs_window": float(np.mean(np.abs(K_div[source["shock_window"]]))) if source else 0.0,
                    "residual_mean_abs_window": float(np.mean(np.abs(residual[source["shock_window"]]))) if source else 0.0,
                    "residual_max_abs_window": float(np.max(np.abs(residual[source["shock_window"]]))) if source else 0.0,
                    "residual_mean_abs_plateau": float(np.mean(np.abs(residual[source["postshock_plateau"]]))) if source else 0.0,
                    "residual_max_abs_plateau": float(np.max(np.abs(residual[source["postshock_plateau"]]))) if source else 0.0,
                    "shock_window": source.get("shock_summary", {}),
                    "postshock_plateau": source.get("postshock_summary", {}),
                    "peak": source.get("peak", {}),
                    "balance": balance,
                    "alpha_face_compare": alpha_face_cmp if vof_rec is not None else {},
                },
            }
            out_rows.append(row)
            print(json.dumps(row, sort_keys=True))
    finally:
        denner_solver_a.vof_step = orig_vof_step
        denner_solver_a._compute_face_velocity = orig_compute_face_velocity

    print(json.dumps({"rows": out_rows, "psi_values": psi_values}, sort_keys=True))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Cycle5 current-head rebaseline for cases 07 and 25."""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]


def _run(cases: str, timeout: float, label: str) -> dict:
    env = os.environ.copy()
    env.update({
        "DENNER_TARGET_CASES": cases,
        "DENNER_TARGET_TIMEOUT": str(timeout),
        "DENNER_NUM_THREADS": "1",
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "NUMEXPR_NUM_THREADS": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
    })
    cmd = [sys.executable, "-B", "autoresearch-results/run_target_cases_verify.py"]
    t0 = time.time()
    proc = subprocess.run(
        cmd,
        cwd=ROOT,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout + 60.0,
    )
    wall = time.time() - t0
    log_path = ROOT / "autoresearch-results" / f"cycle5_{label}.log"
    log_path.write_text(proc.stdout, encoding="utf-8")
    details = []
    metrics = {}
    for line in proc.stdout.splitlines():
        if line.startswith("DETAILS_JSON "):
            try:
                details = json.loads(line[len("DETAILS_JSON "):])
            except Exception:
                details = []
        elif line.startswith("{") and line.endswith("}"):
            try:
                obj = json.loads(line)
            except Exception:
                continue
            if "pass_count" in obj and "cases" in obj:
                metrics = obj
    out = {
        "label": label,
        "cases": cases,
        "returncode": proc.returncode,
        "wall": wall,
        "log_path": str(log_path.relative_to(ROOT)),
        "metrics": metrics,
        "details": details,
    }
    print("RUN_JSON " + json.dumps(out, ensure_ascii=False, sort_keys=True), flush=True)
    return out


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--with-smoke", action="store_true")
    args = parser.parse_args()
    runs = [
        _run("07", 2400.0, "case07"),
        _run("25", 2400.0, "case25"),
        _run("07,25", 3600.0, "case07_case25"),
    ]
    if args.with_smoke:
        runs.append(_run("01,02,04,05,13,14,15", 2400.0, "smoke_01020405131415"))
    summary = {
        "runs": [
            {
                "label": r["label"],
                "cases": r["cases"],
                "returncode": r["returncode"],
                "wall": r["wall"],
                "pass_numeric": r["metrics"].get("pass_numeric"),
                "pass_count": r["metrics"].get("pass_count"),
                "fail_cases": r["metrics"].get("fail_cases"),
                "png_missing": r["metrics"].get("png_missing"),
                "log_path": r["log_path"],
            }
            for r in runs
        ],
    }
    out_path = ROOT / "autoresearch-results" / "cycle5_case07_case25_summary.json"
    out_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False, sort_keys=True), encoding="utf-8")
    print("SUMMARY_JSON " + json.dumps(summary, ensure_ascii=False, sort_keys=True), flush=True)
    return 0 if all(r["returncode"] == 0 for r in runs) else 1


if __name__ == "__main__":
    raise SystemExit(main())


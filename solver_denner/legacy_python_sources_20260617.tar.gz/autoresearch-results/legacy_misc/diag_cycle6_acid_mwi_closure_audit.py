#!/usr/bin/env python3
"""Cycle 6 ACID/MWI closure audit for solver_denner.

This diagnostic is intentionally read-only for solver code.  It combines:

- a static audit of the current ACID/MWI/material-face code paths, and
- cheap official-driver probes with assembly diagnostic counters enabled.

The output is JSON so Agent2/Agent3 reports can cite exact evidence without
changing validation criteria.
"""

from __future__ import annotations

import argparse
import ast
import importlib
import json
import os
from pathlib import Path
import sys
import time
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = ROOT.parent
OUT_DIR = ROOT / "autoresearch-results"


def _jsonable(obj: Any) -> Any:
    """Return a compact JSON-safe representation of nested validation output."""
    try:
        import numpy as np
    except Exception:  # pragma: no cover - numpy is present in validation env
        np = None
    if np is not None:
        if isinstance(obj, np.ndarray):
            return {
                "array": True,
                "shape": list(obj.shape),
                "min": float(np.nanmin(obj)) if obj.size else None,
                "max": float(np.nanmax(obj)) if obj.size else None,
                "mean": float(np.nanmean(obj)) if obj.size else None,
            }
        if isinstance(obj, (np.floating, np.integer, np.bool_)):
            return obj.item()
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return repr(obj)


def _line_hits(path: Path, needles: list[str], context: int = 2) -> list[dict[str, Any]]:
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    hits: list[dict[str, Any]] = []
    for idx, line in enumerate(lines, start=1):
        if any(needle in line for needle in needles):
            lo = max(1, idx - context)
            hi = min(len(lines), idx + context)
            hits.append({
                "file": str(path.relative_to(ROOT)),
                "line": idx,
                "text": line.strip(),
                "context": [
                    {"line": j, "text": lines[j - 1].rstrip()}
                    for j in range(lo, hi + 1)
                ],
            })
    return hits


def _functions(path: Path) -> dict[str, int]:
    tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    return {
        n.name: int(n.lineno)
        for n in ast.walk(tree)
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
    }


def static_audit() -> dict[str, Any]:
    solver_a = ROOT / "solver/denner_1d/solver_a.py"
    assembly = ROOT / "solver/denner_1d/assembly.py"
    mwi = ROOT / "solver/denner_1d/flux/mwi.py"
    driver = ROOT / "results/run_denner1d_17case.py"

    hits = []
    hits.extend(_line_hits(
        solver_a,
        [
            "rho_face_k = acid_face_density",
            "rho_star_k = harmonic_face_density",
            "geometric_face_density",
            "mwi_rho_star",
            "_compute_face_velocity",
            "_alpha_face_velocity_override",
        ],
    ))
    hits.extend(_line_hits(
        assembly,
        [
            "material_jump",
            "pressure_jump",
            "acoustic_face_correction",
            "ASSEMBLY_DIAG",
            "pL_rec",
            "uL_rec",
            "rho_face_acid",
            "psi_face_transport",
        ],
    ))
    hits.extend(_line_hits(
        mwi,
        [
            "def acid_face_density",
            "def harmonic_face_density",
            "def geometric_face_density",
            "def mwi_face_coeff_denner",
            "def mwi_face_velocity_components",
            "d_hat",
        ],
    ))

    suspected = [
        {
            "rank": 1,
            "location": "solver/denner_1d/solver_a.py",
            "finding": (
                "Mass/energy face density uses ACID while the MWI pressure "
                "coefficient path uses harmonic rho_star.  The nearby "
                "geometric_face_density helper is documented as a high-density "
                "ratio stabilizer but is not selected on the current retained "
                "path."
            ),
            "cycle6b_probe": (
                "Run a one-line candidate setting mwi_rho_star=geometric for "
                "material/high-ratio faces only, then gate case07 Air-Water "
                "N200, case25 N200, and case24 N100."
            ),
        },
        {
            "rank": 2,
            "location": "solver/denner_1d/assembly.py",
            "finding": (
                "Material faces are explicitly detected and routed away from "
                "the acoustic reconstruction fallback.  This protects uniform "
                "pressure/velocity but may leave pressure work and MWI face "
                "velocity using different left/right biases near shocks."
            ),
            "cycle6b_probe": (
                "Instrument p/u/T left-right reconstructed states and compare "
                "face pressure work against theta_k/u_bar_k at material faces."
            ),
        },
        {
            "rank": 3,
            "location": "solver/denner_1d/solver_a.py",
            "finding": (
                "Alpha transport has a gas-dominant arithmetic velocity override "
                "while liquid-dominant faces retain MWI/AB2 coupling.  This can "
                "desynchronize alpha advection from mass/energy face work across "
                "the same material discontinuity."
            ),
            "cycle6b_probe": (
                "Log alpha transport face velocity, theta_k, and mass flux on "
                "case07 Air-Water and case25 interface faces."
            ),
        },
    ]

    return {
        "mode": "code",
        "files": {
            "solver_a_functions": _functions(solver_a),
            "assembly_functions": _functions(assembly),
            "mwi_functions": _functions(mwi),
            "driver_case_functions": {
                name: line for name, line in _functions(driver).items()
                if name in ("case_07", "_case24_subcase", "case_24", "case_25")
            },
        },
        "hits": hits,
        "ranked_suspected_locations": suspected,
    }


def _prepare_imports() -> None:
    os.environ.setdefault("MPLBACKEND", "Agg")
    os.environ["DENNER_DIAG"] = "1"
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(1, str(REPO_ROOT))


def run_probe(case: str, n: int, only_subcase: str | None, psi: float | None) -> dict[str, Any]:
    _prepare_imports()
    assembly = importlib.import_module("solver.denner_1d.assembly")
    if hasattr(assembly, "reset_assembly_diag"):
        assembly.reset_assembly_diag()

    driver = importlib.import_module("results.run_denner1d_17case")
    started = time.time()
    case = str(case).zfill(2)

    if case == "07":
        os.environ["DENNER_CASE07_N"] = str(int(n))
        if only_subcase:
            os.environ["DENNER_CASE07_ONLY"] = str(only_subcase)
        result = driver.case_07()
    elif case == "24":
        os.environ["DENNER_CASE24_N"] = str(int(n))
        os.environ.setdefault("DENNER_CASE24_CFL", "0.4")
        result = driver._case24_subcase(float(0.75 if psi is None else psi))
    elif case == "25":
        os.environ["DENNER_CASE25_N"] = str(int(n))
        result = driver.case_25()
    else:
        raise SystemExit(f"unsupported --case {case!r}")

    diag = dict(getattr(assembly, "ASSEMBLY_DIAG", {}))
    return {
        "mode": "run",
        "case": case,
        "N": int(n),
        "only_subcase": only_subcase,
        "psi": psi,
        "wall": time.time() - started,
        "assembly_diag": _jsonable(diag),
        "result": _jsonable(result),
    }


def _write_output(payload: dict[str, Any], name: str) -> Path:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    path = OUT_DIR / name
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("code", "run"), required=True)
    parser.add_argument("--case", choices=("07", "24", "25"), default="07")
    parser.add_argument("--only-subcase", default=None)
    parser.add_argument("--N", type=int, default=200)
    parser.add_argument("--psi", type=float, default=None)
    parser.add_argument("--output", default=None)
    args = parser.parse_args()

    if args.mode == "code":
        payload = static_audit()
        default_name = "cycle6_acid_mwi_static_audit.json"
    else:
        payload = run_probe(args.case, args.N, args.only_subcase, args.psi)
        tag = f"case{args.case}_N{args.N}"
        if args.only_subcase:
            tag += "_" + args.only_subcase.replace(" ", "_").replace("/", "_")
        if args.psi is not None:
            tag += f"_psi{args.psi:g}".replace(".", "p")
        default_name = f"cycle6_acid_mwi_{tag}.json"

    out = _write_output(payload, args.output or default_name)
    print(json.dumps({"output": str(out), **payload}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

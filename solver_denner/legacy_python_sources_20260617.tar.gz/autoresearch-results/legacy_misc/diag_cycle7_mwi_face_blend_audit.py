#!/usr/bin/env python3
"""Cycle 7 MWI face-density/blend audit.

Read-only diagnostic.  It reruns one cheap target probe and summarizes
material-face MWI alternatives at the final state:

- harmonic rho-star
- geometric rho-star
- ACID rho-star where psi/T/c_mix are available
- pressure-jump and density-ratio sensors
- theta changes implied by harmonic -> geometric/ACID d_hat
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import time
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = ROOT.parent
OUT_DIR = ROOT / "autoresearch-results"

sys.path.insert(0, str(ROOT))
sys.path.insert(1, str(REPO_ROOT))
os.environ.setdefault("MPLBACKEND", "Agg")
os.environ["DENNER_DIAG"] = "1"

from solver.denner_1d.boundary import apply_ghost  # noqa: E402
from solver.denner_1d.eos.base import compute_mixture_props  # noqa: E402
from solver.denner_1d.flux.mwi import (  # noqa: E402
    acid_face_density,
    geometric_face_density,
    harmonic_face_density,
    mwi_face_coeff_denner,
)
from solver.denner_1d import solver_a  # noqa: E402
from results import run_denner1d_17case as drv  # noqa: E402


def _jsonable(obj: Any) -> Any:
    if isinstance(obj, np.ndarray):
        return {
            "shape": list(obj.shape),
            "min": float(np.nanmin(obj)) if obj.size else None,
            "max": float(np.nanmax(obj)) if obj.size else None,
            "mean": float(np.nanmean(obj)) if obj.size else None,
        }
    if isinstance(obj, (np.floating, np.integer, np.bool_)):
        return obj.item()
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return repr(obj)


def _last_dt(res: dict, fallback: float) -> float:
    hist = res.get("dt_history") or []
    return float(hist[-1]) if hist else float(fallback)


def run_case07_airwater(n: int) -> dict[str, Any]:
    length = 1.5
    os.environ["DENNER_CASE07_N"] = str(int(n))
    os.environ["DENNER_CASE07_ONLY"] = "Air-Water"
    case = next(c for c in drv.V_CASES_07 if c.name == "Air-Water")
    alpha_floor = float(os.environ.get("DENNER_CASE07_ALPHA_FLOOR", "1e-8"))
    dx = length / int(n)
    x = (np.arange(int(n)) + 0.5) * dx
    left_spec = drv.V_EOS_07[case.left]
    phL = drv._phase_dict_07(case.left)
    phR = drv._phase_dict_07(case.right)
    maskL = x < case.x_intf
    psi0 = np.where(maskL, 1.0 - alpha_floor, alpha_floor)
    TL = drv._temperature_from_rho_p(phL, float(left_spec["rho"]), drv.V_P0)
    TR = drv._temperature_from_rho_p(phR, float(drv.V_EOS_07[case.right]["rho"]), drv.V_P0)
    ZL = float(left_spec["rho"] * left_spec["c"])
    u_init = np.where(
        maskL,
        drv.U_PEAK_07 * np.exp(-((x - case.x_src) ** 2) / (2.0 * case.sigma**2)),
        0.0,
    )
    p_init = drv.V_P0 + ZL * u_init
    theta_L = drv._isentropic_dTdp(phL, drv.V_P0, float(TL))
    T_init = np.where(maskL, float(TL) + theta_L * (p_init - drv.V_P0), float(TR))
    res = drv._solve_denner(
        psi0, T_init, u_init, p_init, dx, case.t_end,
        phL, phR, bc_l="reflective", bc_r="transmissive",
        cfl=float(os.environ.get("DENNER_CASE07_CFL", "0.4")),
        max_iter=5000,
        variable_set=os.environ.get("DENNER_CASE07_VARIABLE_SET", "puT"),
        coupled=bool(int(os.environ.get("DENNER_CASE07_COUPLED", "0"))),
        solver_mode=os.environ.get("DENNER_CASE07_SOLVER_MODE", "delta"),
        third_var=os.environ.get("DENNER_CASE07_THIRD_VAR", "T"),
        use_barotropic=bool(int(os.environ.get("DENNER_CASE07_BAROTROPIC", "0"))),
        use_K=bool(int(os.environ.get("DENNER_CASE07_USE_K", "1"))),
        use_compress=bool(int(os.environ.get("DENNER_CASE07_USE_COMPRESS", "1"))),
        bdf_order=int(os.environ.get("DENNER_CASE07_BDF_ORDER", "2")),
        mwi_rho_star=os.environ.get("DENNER_CASE07_MWI_RHO_STAR", "harmonic"),
        tvd_limiter=os.environ.get("DENNER_CASE07_TVD_LIMITER", "koren"),
        acoustic_limiter=os.environ.get("DENNER_CASE07_ACOUSTIC_LIMITER", None),
        acoustic_limiter_blend=float(os.environ.get("DENNER_CASE07_ACOUSTIC_LIMITER_BLEND", "1.0")),
        mwi_transient=bool(int(os.environ.get("DENNER_CASE07_MWI_TRANSIENT_3N", "1"))),
        acoustic_face_correction=bool(int(os.environ.get("DENNER_CASE07_ACOUSTIC_FACE", "1"))),
        acid_temporal_colour=os.environ.get("DENNER_CASE07_ACID_TEMPORAL_COLOUR", "midpoint"),
        max_outer=int(os.environ.get("DENNER_CASE07_MAX_OUTER", "3")),
        max_inner=int(os.environ.get("DENNER_CASE07_MAX_INNER", "8")),
        max_newton=int(os.environ.get("DENNER_CASE07_MAX_NEWTON", "12")),
        newton_tol=float(os.environ.get("DENNER_CASE07_NEWTON_TOL", "1e-8")),
        outer_tol=float(os.environ.get("DENNER_CASE07_OUTER_TOL", "1e-8")),
    )
    psi, T, u, p = drv._final_state(res)
    return {"case": "07", "subcase": "Air-Water", "x": x, "dx": dx, "psi": psi,
            "T": T, "u": u, "p": p, "ph1": phL, "ph2": phR, "dt": _last_dt(res, case.t_end),
            "complete": bool(res["t_history"][-1] >= case.t_end - 1.0e-14),
            "diverged": bool(res.get("diverged", False))}


def run_case25(n: int) -> dict[str, Any]:
    os.environ["DENNER_CASE25_N"] = str(int(n))
    n = int(n)
    dx = 1.0 / n
    x = (np.arange(n) + 0.5) * dx
    alpha_floor = 1.0e-6
    p_pre = 1.0e5
    rho_air_pre = 1.157
    rho_water = 998.0
    p_post = 1.165e7
    rho_air_post = 6.614
    u_post = 2869.3
    x_shock0 = 0.25
    x_interface = 0.5
    shock_speed = 10.0 * np.sqrt(1.4 * p_pre / rho_air_pre)
    t_hit = (x_interface - x_shock0) / shock_speed
    t_end = t_hit + 2.42e-4
    air_region = x < x_interface
    post_region = x < x_shock0
    psi0 = np.where(air_region, 1.0 - alpha_floor, alpha_floor)
    p_init = np.where(post_region, p_post, p_pre)
    u_init = np.where(post_region, u_post, 0.0)
    rho_air = np.where(post_region, rho_air_post, rho_air_pre)
    T_air = drv._temperature_from_rho_p(drv.AIR_IDEAL, rho_air, p_init)
    T_water = drv._temperature_from_rho_p(drv.WATER_NASG, np.full(n, rho_water), p_init)
    T_init = psi0 * T_air + (1.0 - psi0) * T_water
    res = drv._solve_denner(
        psi0, T_init, u_init, p_init, dx, t_end=t_end,
        ph1=drv.AIR_IDEAL, ph2=drv.WATER_NASG,
        bc_l="transmissive", bc_r="transmissive",
        cfl=float(os.environ.get("DENNER_CASE25_CFL", "0.30")),
        cfl_type="acoustic", max_iter=200000)
    psi, T, u, p = drv._final_state(res)
    return {"case": "25", "subcase": None, "x": x, "dx": dx, "psi": psi,
            "T": T, "u": u, "p": p, "ph1": drv.AIR_IDEAL, "ph2": drv.WATER_NASG,
            "dt": _last_dt(res, t_end), "complete": bool(res["t_history"][-1] >= t_end - 1.0e-14),
            "diverged": bool(res.get("diverged", False))}


def run_case24(psi_water: float, n: int) -> dict[str, Any]:
    os.environ["DENNER_CASE24_N"] = str(int(n))
    os.environ.setdefault("DENNER_CASE24_CFL", "0.4")
    row = drv._case24_subcase(float(psi_water))
    # The official helper does not return final psi/T; audit rho/u/p sensors only.
    return {"case": "24", "subcase": f"psi={psi_water:g}", "x": row["x"],
            "dx": 1.0 / int(n), "psi": None, "T": None, "u": row["u"], "p": row["p"],
            "rho": row["rho"], "ph1": None, "ph2": None, "dt": row["metrics"]["t_end"],
            "complete": bool(row["metrics"]["complete"]), "diverged": False,
            "official_pass": bool(row["pass"]), "official_metrics": row["metrics"]}


def face_audit(data: dict[str, Any]) -> dict[str, Any]:
    x = data["x"]
    dx = float(data["dx"])
    u = np.asarray(data["u"], dtype=float)
    p = np.asarray(data["p"], dtype=float)
    if data.get("rho") is not None:
        rho = np.asarray(data["rho"], dtype=float)
        c_mix = None
        psi = None
    else:
        psi = np.asarray(data["psi"], dtype=float)
        T = np.asarray(data["T"], dtype=float)
        props = compute_mixture_props(p, u, T, psi, data["ph1"], data["ph2"])
        rho = np.asarray(props["rho"], dtype=float)
        c_mix = np.asarray(props["c_mix"], dtype=float)

    rho_h = harmonic_face_density(rho, "transmissive", "transmissive")
    rho_g = geometric_face_density(rho, "transmissive", "transmissive")
    rho_a = None
    if psi is not None and c_mix is not None:
        rho_a = acid_face_density(rho, c_mix, psi, "transmissive", "transmissive")

    e_diag = solver_a._momentum_diagonal(rho, dx, max(float(data["dt"]), 1.0e-300))
    d_h = mwi_face_coeff_denner(e_diag, rho_h, dx, max(float(data["dt"]), 1.0e-300),
                                "transmissive", "transmissive")
    d_g = mwi_face_coeff_denner(e_diag, rho_g, dx, max(float(data["dt"]), 1.0e-300),
                                "transmissive", "transmissive")
    theta_h, ubar = solver_a._compute_face_velocity(
        u, p, d_h, dx, "transmissive", "transmissive",
        rho_cell=rho, rho_star_face=rho_h)
    theta_g, _ = solver_a._compute_face_velocity(
        u, p, d_g, dx, "transmissive", "transmissive",
        rho_cell=rho, rho_star_face=rho_g)
    theta_a = None
    d_a = None
    if rho_a is not None:
        d_a = mwi_face_coeff_denner(e_diag, rho_a, dx, max(float(data["dt"]), 1.0e-300),
                                    "transmissive", "transmissive")
        theta_a, _ = solver_a._compute_face_velocity(
            u, p, d_a, dx, "transmissive", "transmissive",
            rho_cell=rho, rho_star_face=rho_a)

    rho_ext = apply_ghost(rho, "transmissive", "transmissive", 2)
    p_ext = apply_ghost(p, "transmissive", "transmissive", 2)
    ratio = np.empty(len(rho) + 1)
    p_jump = np.empty(len(rho) + 1)
    for f in range(len(rho) + 1):
        rL = max(float(rho_ext[2 + f - 1]), 1.0e-300)
        rR = max(float(rho_ext[2 + f]), 1.0e-300)
        pL = float(p_ext[2 + f - 1])
        pR = float(p_ext[2 + f])
        ratio[f] = max(rL, rR) / min(rL, rR)
        p_jump[f] = abs(pR - pL) / max(abs(pL), abs(pR), 1.0)

    material = ratio >= 50.0
    shock_material = material & (p_jump >= 0.05)
    delta_g = np.abs(theta_g - theta_h)
    order = np.argsort(delta_g)[::-1][:12]
    top = []
    for f in order:
        item = {
            "face": int(f),
            "x_face": float(f * dx),
            "rho_ratio": float(ratio[f]),
            "p_jump_rel": float(p_jump[f]),
            "rho_harmonic": float(rho_h[f]),
            "rho_geometric": float(rho_g[f]),
            "d_hat_harmonic": float(d_h[f]),
            "d_hat_geometric": float(d_g[f]),
            "theta_harmonic": float(theta_h[f]),
            "theta_geometric": float(theta_g[f]),
            "theta_delta_geo_abs": float(delta_g[f]),
            "u_bar": float(ubar[f]),
        }
        if rho_a is not None and d_a is not None and theta_a is not None:
            item.update({
                "rho_acid": float(rho_a[f]),
                "d_hat_acid": float(d_a[f]),
                "theta_acid": float(theta_a[f]),
                "theta_delta_acid_abs": float(abs(theta_a[f] - theta_h[f])),
            })
        top.append(item)

    return {
        "N": int(len(rho)),
        "complete": bool(data["complete"]),
        "diverged": bool(data["diverged"]),
        "material_faces": int(np.count_nonzero(material)),
        "shock_material_faces": int(np.count_nonzero(shock_material)),
        "rho_ratio_max": float(np.max(ratio)),
        "p_jump_max": float(np.max(p_jump)),
        "theta_geo_delta_max": float(np.max(delta_g)),
        "theta_geo_delta_mean_material": float(np.mean(delta_g[material])) if np.any(material) else 0.0,
        "theta_geo_delta_mean_shock_material": float(np.mean(delta_g[shock_material])) if np.any(shock_material) else 0.0,
        "top_faces_by_geo_delta": top,
        "official_metrics": _jsonable(data.get("official_metrics", {})),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", choices=("07", "24", "25"), required=True)
    ap.add_argument("--only-subcase", default=None)
    ap.add_argument("--psi", type=float, default=0.75)
    ap.add_argument("--N", type=int, default=200)
    ap.add_argument("--output", default=None)
    args = ap.parse_args()
    started = time.time()
    if args.case == "07":
        if args.only_subcase and args.only_subcase != "Air-Water":
            raise SystemExit("cycle7 audit currently supports case07 Air-Water only")
        data = run_case07_airwater(args.N)
    elif args.case == "25":
        data = run_case25(args.N)
    else:
        data = run_case24(args.psi, args.N)
    payload = {
        "case": args.case,
        "N": args.N,
        "subcase": data.get("subcase"),
        "wall": time.time() - started,
        "audit": face_audit(data),
    }
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    name = args.output
    if not name:
        tag = f"cycle7_mwi_face_case{args.case}_N{args.N}"
        if args.case == "07":
            tag += "_Air-Water"
        if args.case == "24":
            tag += f"_psi{args.psi:g}".replace(".", "p")
        name = tag + ".json"
    out = OUT_DIR / name
    out.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(out), "case": args.case, "wall": payload["wall"],
                      "audit": payload["audit"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

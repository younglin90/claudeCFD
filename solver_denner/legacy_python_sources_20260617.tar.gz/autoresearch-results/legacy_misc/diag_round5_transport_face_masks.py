#!/usr/bin/env python3
"""Round 5A transport-face mask diagnostics.

Read-only offline audit for the Denner 1D workspace.

This script does not modify solver behavior. It inspects current solver fields
from available snapshots when possible, and can optionally run missing target
cases to obtain final-state fields.

Target questions:
- Which faces would trigger the round3-style ACID color guard?
- Which faces would trigger the round4A-style low-density-ratio material-shock
  guard?
- How do those masks overlap with material/pressure jumps and with expansion
  or compression regions?
- What are the local density ratio, impedance ratio, jump magnitudes, face
  velocity proxy, Courant proxy, and psi-jump distributions?
- How large are the hypothetical face-density / face-enthalpy shifts between a
  transported-color proxy and a local ACID-color proxy?

The exact transient transported face-color array used inside assembly is not
stored in the published snapshots.  For the face-density / face-enthalpy
comparison this script uses a donor-cell transport proxy based on the local
face velocity, and compares it to a local cell-color proxy.  That keeps the
diagnostic offline and reproducible without changing solver code.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import sys
import time
from dataclasses import dataclass
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = ROOT.parent
OUT_DIR = ROOT / "autoresearch-results"
RESULTS_1D = ROOT / "results" / "1D"

sys.path.insert(0, str(ROOT))
sys.path.insert(1, str(REPO_ROOT))
os.environ.setdefault("MPLBACKEND", "Agg")
os.environ["DENNER_DIAG"] = "1"

from solver.denner_1d.boundary import apply_ghost, apply_ghost_velocity  # noqa: E402
from solver.denner_1d.eos.base import compute_mixture_props  # noqa: E402
from solver.denner_1d.flux.mwi import (  # noqa: E402
    acid_face_density,
    geometric_face_density,
    harmonic_face_density,
    mwi_face_coeff_denner,
)
from solver.denner_1d.main import run as denner_run  # noqa: E402
from solver.denner_1d import solver_a  # noqa: E402


AIR_IDEAL = {"gamma": 1.4, "pinf": 0.0, "b": 0.0, "kv": 717.5, "eta": 0.0}
WATER_NASG = {"gamma": 1.187, "pinf": 7.028e8, "b": 6.61e-4, "kv": 3610.0, "eta": -1.177788e6}
V_P0 = 1.0e5
U_PEAK_07 = 1.0


@dataclass(frozen=True)
class Case07Spec:
    name: str
    left: str
    right: str
    x_intf: float
    x_src: float
    sigma: float
    t_end: float


CASES_07 = (
    Case07Spec("Air-Water", "Air", "Water", 0.5, 0.1, 0.014, 1.55e-3),
    Case07Spec("Helium-Air", "Helium", "Air", 1.0, 0.2, 0.049, 1.513e-3),
    Case07Spec("Argon-Air", "Argon", "Air", 0.5, 0.1, 0.038, 2.02e-3),
)


class _ReferenceEOS:
    def __init__(self, ph: dict[str, float]):
        self.gamma = float(ph["gamma"])
        self.pinf = float(ph["pinf"])
        self.b = float(ph["b"])
        self.kv = float(ph["kv"])
        self.eta = float(ph.get("eta", 0.0))

    def pressure_from_rhoT(self, rho, T):
        rho_a = np.asarray(rho, dtype=float)
        T_a = np.asarray(T, dtype=float)
        s = rho_a * self.kv * T_a * (self.gamma - 1.0)
        s = s / np.maximum(1.0 - self.b * rho_a, 1.0e-300)
        return s - self.pinf

    def density(self, p, T):
        p_a = np.asarray(p, dtype=float)
        T_a = np.asarray(T, dtype=float)
        return (p_a + self.pinf) / np.maximum(
            self.kv * T_a * (self.gamma - 1.0) + self.b * (p_a + self.pinf), 1.0e-300
        )

    def drhodp_T(self, rho, T):
        p = self.pressure_from_rhoT(rho, T)
        A = self.kv * np.asarray(T, dtype=float) * (self.gamma - 1.0) + self.b * (p + self.pinf)
        return self.kv * np.asarray(T, dtype=float) * (self.gamma - 1.0) / np.maximum(A * A, 1.0e-300)

    def drhodT_p(self, rho, T):
        p = self.pressure_from_rhoT(rho, T)
        A = self.kv * np.asarray(T, dtype=float) * (self.gamma - 1.0) + self.b * (p + self.pinf)
        return -((p + self.pinf) * self.kv * (self.gamma - 1.0)) / np.maximum(A * A, 1.0e-300)

    def dedp_T(self, rho, T):
        p = self.pressure_from_rhoT(rho, T)
        return (
            self.kv * np.asarray(T, dtype=float) * self.pinf * (1.0 - self.gamma)
            / np.maximum((p + self.pinf) ** 2, 1.0e-300)
        )

    def dedT_p(self, rho, T):
        p = self.pressure_from_rhoT(rho, T)
        return self.kv * (p + self.gamma * self.pinf) / np.maximum(p + self.pinf, 1.0e-300)

    def energy(self, rho, p):
        rho_a = np.asarray(rho, dtype=float)
        p_a = np.asarray(p, dtype=float)
        v_minus_b = 1.0 / np.maximum(rho_a, 1.0e-300) - self.b
        return (p_a + self.gamma * self.pinf) * v_minus_b / (self.gamma - 1.0) + self.eta

    def h(self, p, T):
        rho = self.density(p, T)
        e = self.energy(rho, p)
        return e / np.maximum(rho, 1.0e-300) + np.asarray(p, dtype=float) / np.maximum(rho, 1.0e-300)


def _phase_dict_07(name: str) -> dict:
    if name == "Air":
        return AIR_IDEAL
    if name == "Water":
        return WATER_NASG
    if name == "Helium":
        return {"gamma": 5.0 / 3.0, "pinf": 0.0, "b": 0.0, "kv": 3115.0, "eta": 0.0}
    if name == "Argon":
        return {"gamma": 5.0 / 3.0, "pinf": 0.0, "b": 0.0, "kv": 314.0, "eta": 0.0}
    raise KeyError(name)


def _temperature_from_rho_p(ph: dict, rho: np.ndarray, p: np.ndarray) -> np.ndarray:
    rho_a = np.asarray(rho, dtype=float)
    p_a = np.asarray(p, dtype=float)
    gm1 = float(ph["gamma"]) - 1.0
    pinf = float(ph.get("pinf", 0.0))
    b = float(ph.get("b", 0.0))
    kv = float(ph.get("kv", 1.0))
    return ((p_a + pinf) / np.maximum(rho_a, 1.0e-300) - b * (p_a + pinf)) / np.maximum(kv * gm1, 1.0e-300)


def _theta_from_eos(ph: dict, p: float, T: float) -> float:
    eos = _ReferenceEOS(ph)
    pp = np.asarray([p], dtype=float)
    TT = np.asarray([T], dtype=float)
    rho = eos.density(pp, TT)
    rho_p = eos.drhodp_T(rho, TT)
    rho_T = eos.drhodT_p(rho, TT)
    e_p = eos.dedp_T(rho, TT)
    e_T = eos.dedT_p(rho, TT)
    pr2 = pp / np.maximum(rho * rho, 1.0e-300)
    den = e_T - pr2 * rho_T
    theta = (pr2 * rho_p - e_p) / np.where(np.abs(den) > 1.0e-300, den, 1.0e-300)
    return float(theta[0])


def _mix_rho(psi: np.ndarray, p: np.ndarray, T: np.ndarray, ph1: dict, ph2: dict) -> np.ndarray:
    rho1 = _ReferenceEOS(ph1).density(p, T)
    rho2 = _ReferenceEOS(ph2).density(p, T)
    psi_a = np.asarray(psi, dtype=float)
    return psi_a * rho1 + (1.0 - psi_a) * rho2


def _exact_07(case: Case07Spec, x: np.ndarray, t: float) -> tuple[np.ndarray, np.ndarray]:
    left = {
        "Air": {"kind": "ideal", "gamma": 1.4, "rho": 1.1574, "c": 347.0},
        "Helium": {"kind": "ideal", "gamma": 5.0 / 3.0, "rho": 0.1634, "c": 1007.0},
        "Argon": {"kind": "ideal", "gamma": 5.0 / 3.0, "rho": 1.622, "c": 323.0},
        "Water": {"kind": "nasg", "gamma": 1.187, "rho": 998.0, "c": 1567.3350584385664},
    }
    right = left
    cL = float(left[case.left]["c"])
    cR = float(right[case.right]["c"])
    ZL = float(left[case.left]["rho"] * left[case.left]["c"])
    ZR = float(right[case.right]["rho"] * right[case.right]["c"])
    R = (ZR - ZL) / (ZR + ZL)
    Tu = 2.0 * ZL / (ZL + ZR)
    Tp = 2.0 * ZR / (ZL + ZR)
    t_hit = (case.x_intf - case.x_src) / cL
    x = np.asarray(x, dtype=float)
    left_mask = x < case.x_intf

    def gauss(center: float, sigma: float) -> np.ndarray:
        return np.exp(-((x - center) ** 2) / (2.0 * sigma * sigma))

    u_inc = U_PEAK_07 * gauss(case.x_src + cL * t, case.sigma) * left_mask
    u_ref_shape = U_PEAK_07 * gauss(2.0 * case.x_intf - case.x_src - cL * t, case.sigma) * left_mask
    if t > t_hit:
        sigR = case.sigma * cR / cL
        u_tr_shape = U_PEAK_07 * gauss(case.x_intf + cR * (t - t_hit), sigR) * (~left_mask)
    else:
        u_tr_shape = np.zeros_like(x)
    u_exact = u_inc - R * u_ref_shape + Tu * u_tr_shape
    p_exact = V_P0 + ZL * u_inc + R * ZL * u_ref_shape + Tp * ZL * u_tr_shape
    return p_exact, u_exact


def _jsonable(obj: Any) -> Any:
    if isinstance(obj, np.ndarray):
        return {
            "shape": list(obj.shape),
            "min": float(np.nanmin(obj)) if obj.size else None,
            "max": float(np.nanmax(obj)) if obj.size else None,
            "mean": float(np.nanmean(obj)) if obj.size else None,
        }
    if isinstance(obj, (np.floating, np.integer, np.bool_)):
        return obj.item()
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return repr(obj)


def _load_npz(path: Path) -> dict[str, Any]:
    with np.load(path, allow_pickle=True) as z:
        out = {k: z[k] for k in z.files}
    return out


def _metrics_from_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    metrics = snapshot.get("metrics")
    if metrics is None:
        return {}
    if isinstance(metrics, np.ndarray) and metrics.shape == ():
        metrics = metrics.item()
    if isinstance(metrics, bytes):
        metrics = metrics.decode("utf-8")
    if isinstance(metrics, str):
        try:
            return json.loads(metrics)
        except Exception:  # noqa: BLE001
            return {}
    if isinstance(metrics, dict):
        return metrics
    return {}


def _recover_common_temperature(
    p: np.ndarray,
    rho_target: np.ndarray,
    psi: np.ndarray,
    ph1: dict,
    ph2: dict,
    *,
    T_guess: float | None = None,
) -> np.ndarray:
    """Reconstruct common-T from rho(p,T,psi) when a snapshot lacks T."""
    p = np.asarray(p, dtype=float)
    rho_target = np.asarray(rho_target, dtype=float)
    psi = np.asarray(psi, dtype=float)
    T = np.empty_like(p, dtype=float)
    guess = float(T_guess if T_guess is not None else 300.0)
    for i in range(p.size):
        pi = float(p[i])
        rhoi = float(rho_target[i])
        psii = float(psi[i])
        Ti = guess
        # Simple damped Newton on the scalar density residual.
        for _ in range(24):
            props = compute_mixture_props(
                np.asarray([pi], dtype=float),
                np.asarray([0.0], dtype=float),
                np.asarray([Ti], dtype=float),
                np.asarray([psii], dtype=float),
                ph1,
                ph2,
            )
            rhoi_est = float(np.asarray(props["rho"], dtype=float)[0])
            drho_dT = float(np.asarray(props["phi_v"], dtype=float)[0])
            resid = rhoi_est - rhoi
            if abs(resid) <= max(1.0e-10 * max(rhoi, 1.0), 1.0e-10):
                break
            denom = drho_dT if abs(drho_dT) > 1.0e-300 else (-1.0e-12 if resid > 0 else 1.0e-12)
            step = resid / denom
            Ti = float(np.clip(Ti - 0.75 * step, 1.0e-6, 1.0e7))
        T[i] = Ti
        guess = Ti
    return T


def _case24_snapshot_candidates(psi_water: float) -> list[Path]:
    tag = f"{float(psi_water):.2f}".replace(".", "p")
    if abs(psi_water - 0.25) < 1.0e-12:
        return [
            RESULTS_1D / "24_H" / "diag_psi025_final.npz",
            RESULTS_1D / "24_H" / "diag_psi025_iter4.npz",
        ]
    if abs(psi_water - 0.5) < 1.0e-12:
        return [
            RESULTS_1D / "24_H" / "diag_psi050_final.npz",
            RESULTS_1D / "24_H" / "diag_one_last.npz",
            OUT_DIR / "cycle4_case24_N100_CFL0p4_probe_psi0p5.npz",
        ]
    if abs(psi_water - 0.75) < 1.0e-12:
        return [
            OUT_DIR / "cycle4_case24_N100_CFL0p4_probe_psi0p75.npz",
        ]
    return [
        OUT_DIR / f"case24_psi{tag}.npz",
    ]


def _load_case24_snapshot(psi_water: float) -> dict[str, Any]:
    for path in _case24_snapshot_candidates(psi_water):
        if not path.exists():
            continue
        snap = _load_npz(path)
        x = np.asarray(snap["x"], dtype=float)
        psi = np.asarray(snap["psi"], dtype=float)
        p = np.asarray(snap["p"], dtype=float)
        u = np.asarray(snap["u"], dtype=float)
        rho = np.asarray(snap["rho"], dtype=float)
        T = snap.get("T")
        if T is None:
            T = _recover_common_temperature(p, rho, psi, AIR_IDEAL, WATER_NASG)
        else:
            T = np.asarray(T, dtype=float)
        metrics = _metrics_from_snapshot(snap)
        dt = None
        if "dt" in snap:
            try:
                dt = float(np.asarray(snap["dt"]).reshape(()))
            except Exception:  # noqa: BLE001
                dt = None
        if dt is None:
            steps = float(metrics.get("steps", 1.0))
            t_end = float(metrics.get("t_end", metrics.get("time", 1.0)))
            dt = t_end / max(steps, 1.0)
        exact = {
            "rho": np.asarray(snap.get("exact_rho", rho), dtype=float),
            "u": np.asarray(snap.get("exact_u", u), dtype=float),
            "p": np.asarray(snap.get("exact_p", p), dtype=float),
            "psi": np.asarray(snap.get("exact_psi", psi), dtype=float),
        }
        return {
            "case": "24",
            "subcase": f"psi_water={psi_water:g}",
            "source": str(path),
            "x": x,
            "dx": float(x[1] - x[0]) if x.size > 1 else 1.0,
            "psi": psi,
            "T": np.asarray(T, dtype=float),
            "u": u,
            "p": p,
            "rho": rho,
            "ph1": AIR_IDEAL,
            "ph2": WATER_NASG,
            "bc_l": "transmissive",
            "bc_r": "transmissive",
            "dt": float(dt),
            "complete": bool(metrics.get("complete", True)),
            "diverged": False,
            "exact": exact,
            "exact_meta": {
                "x_shock_exact": float(np.asarray(snap.get("x_shock_exact", 0.8)).reshape(())),
                "psi_water": float(np.asarray(snap.get("psi_water", psi_water)).reshape(())),
            },
            "metadata": metrics,
        }


def _case07_case_specs() -> list[Any]:
    if os.environ.get("DENNER_CASE07_ONLY", "").strip():
        target = os.environ["DENNER_CASE07_ONLY"].strip()
        return [case for case in CASES_07 if case.name == target]
    return list(CASES_07)


def _run_case07_subcase(case, n: int) -> dict[str, Any]:
    length = 1.5
    dx = length / int(n)
    x = (np.arange(int(n)) + 0.5) * dx
    alpha_floor = float(os.environ.get("DENNER_CASE07_ALPHA_FLOOR", "1e-8"))
    phL = _phase_dict_07(case.left)
    phR = _phase_dict_07(case.right)
    maskL = x < case.x_intf
    psi0 = np.where(maskL, 1.0 - alpha_floor, alpha_floor)
    phase_spec = {
        "Air": {"rho": 1.1574, "c": 347.0},
        "Helium": {"rho": 0.1634, "c": 1007.0},
        "Argon": {"rho": 1.622, "c": 323.0},
        "Water": {"rho": 998.0, "c": 1567.3350584385664},
    }
    TL = _temperature_from_rho_p(phL, float(phase_spec[case.left]["rho"]), V_P0)
    TR = _temperature_from_rho_p(phR, float(phase_spec[case.right]["rho"]), V_P0)
    ZL = float(phase_spec[case.left]["rho"] * phase_spec[case.left]["c"])
    u_init = np.where(
        maskL,
        U_PEAK_07 * np.exp(-((x - case.x_src) ** 2) / (2.0 * case.sigma**2)),
        0.0,
    )
    p_init = V_P0 + ZL * u_init
    theta_L = _theta_from_eos(phL, V_P0, float(TL))
    T_init = np.where(maskL, float(TL) + theta_L * (p_init - V_P0), float(TR))
    case_params = {
        "ph1": phL,
        "ph2": phR,
        "x_cells": x,
        "psi_init": psi0,
        "T_init": T_init,
        "u_init": u_init,
        "p_init": p_init,
        "t_end": case.t_end,
        "CFL": float(os.environ.get("DENNER_CASE07_CFL", "0.4")),
        "bc_left": "reflective",
        "bc_right": "transmissive",
        "verbose": False,
        "dt_fixed": None,
        "cfl_type": "acoustic",
        "max_iteration": 5000,
        "use_autograd": True,
        "use_acid": True,
        "vof_type": "volume",
        "variable_set": os.environ.get("DENNER_CASE07_VARIABLE_SET", "puT"),
        "use_barotropic": bool(int(os.environ.get("DENNER_CASE07_BAROTROPIC", "0"))),
        "use_K": bool(int(os.environ.get("DENNER_CASE07_USE_K", "1"))),
        "use_compress": bool(int(os.environ.get("DENNER_CASE07_USE_COMPRESS", "1"))),
        "coupled": bool(int(os.environ.get("DENNER_CASE07_COUPLED", "0"))),
        "solver_mode": os.environ.get("DENNER_CASE07_SOLVER_MODE", "delta"),
        "third_var": os.environ.get("DENNER_CASE07_THIRD_VAR", "T"),
        "bdf_order": int(os.environ.get("DENNER_CASE07_BDF_ORDER", "2")),
        "mwi_rho_star": os.environ.get("DENNER_CASE07_MWI_RHO_STAR", "harmonic"),
        "tvd_limiter": os.environ.get("DENNER_CASE07_TVD_LIMITER", "koren"),
        "acoustic_limiter": os.environ.get("DENNER_CASE07_ACOUSTIC_LIMITER", None),
        "acoustic_limiter_blend": float(os.environ.get("DENNER_CASE07_ACOUSTIC_LIMITER_BLEND", "1.0")),
        "mwi_transient": bool(int(os.environ.get("DENNER_CASE07_MWI_TRANSIENT_3N", "1"))),
        "acoustic_face_correction": bool(int(os.environ.get("DENNER_CASE07_ACOUSTIC_FACE", "1"))),
        "acid_temporal_colour": os.environ.get("DENNER_CASE07_ACID_TEMPORAL_COLOUR", "midpoint"),
        "max_outer": int(os.environ.get("DENNER_CASE07_MAX_OUTER", "3")),
        "max_inner": int(os.environ.get("DENNER_CASE07_MAX_INNER", "8")),
        "max_newton": int(os.environ.get("DENNER_CASE07_MAX_NEWTON", "12")),
        "newton_tol": float(os.environ.get("DENNER_CASE07_NEWTON_TOL", "1e-8")),
        "inner_tol": float(os.environ.get("DENNER_CASE07_NEWTON_TOL", "1e-8")),
        "outer_tol": float(os.environ.get("DENNER_CASE07_OUTER_TOL", "1e-8")),
        "newton_omega": 1.0,
        "use_jfnk": True,
        "krylov_max": 8,
    }
    res = denner_run(case_params)
    psi, T, u, p = res["final_state"]["psi"], res["final_state"]["T"], res["final_state"]["u"], res["final_state"]["p"]
    rho = _mix_rho(psi, p, T, phL, phR)
    exact_p, exact_u = _exact_07(case, x, res["t_history"][-1])
    return {
        "case": "07",
        "subcase": case.name,
        "source": f"solver:N={n}",
        "x": x,
        "dx": dx,
        "psi": psi,
        "T": T,
        "u": u,
        "p": p,
        "rho": rho,
        "ph1": phL,
        "ph2": phR,
        "bc_l": "reflective",
        "bc_r": "transmissive",
        "dt": float(res["dt_history"][-1]) if res.get("dt_history") else float(case.t_end),
        "complete": bool(res["t_history"][-1] >= case.t_end - 1.0e-14),
        "diverged": bool(res.get("diverged", False)),
        "exact": {"p": exact_p, "u": exact_u},
        "exact_meta": {"x_intf": float(case.x_intf), "x_src": float(case.x_src)},
        "metadata": {
            "t_end": float(case.t_end),
            "steps": int(len(res.get("dt_history", ()))),
            "wall": float(res.get("wall", 0.0)),
        },
    }


def _run_case25(n: int) -> dict[str, Any]:
    n = int(n)
    dx = 1.0 / n
    x = (np.arange(n) + 0.5) * dx
    alpha_floor = 1.0e-6
    p_pre = 1.0e5
    rho_air_pre = 1.157
    rho_water = 998.0
    p_post = 1.165e7
    rho_air_post = 6.614
    u_post = 2869.3
    x_shock0 = 0.25
    x_interface = 0.5
    shock_speed = 10.0 * np.sqrt(1.4 * p_pre / rho_air_pre)
    t_hit = (x_interface - x_shock0) / shock_speed
    t_end = t_hit + 2.42e-4
    air_region = x < x_interface
    post_region = x < x_shock0
    psi0 = np.where(air_region, 1.0 - alpha_floor, alpha_floor)
    p_init = np.where(post_region, p_post, p_pre)
    u_init = np.where(post_region, u_post, 0.0)
    rho_air = np.where(post_region, rho_air_post, rho_air_pre)
    T_air = _temperature_from_rho_p(AIR_IDEAL, rho_air, p_init)
    T_water = _temperature_from_rho_p(WATER_NASG, np.full(n, rho_water), p_init)
    T_init = psi0 * T_air + (1.0 - psi0) * T_water
    case_params = {
        "ph1": AIR_IDEAL,
        "ph2": WATER_NASG,
        "x_cells": x,
        "psi_init": psi0,
        "T_init": T_init,
        "u_init": u_init,
        "p_init": p_init,
        "t_end": t_end,
        "CFL": float(os.environ.get("DENNER_CASE25_CFL", "0.30")),
        "bc_left": "transmissive",
        "bc_right": "transmissive",
        "verbose": False,
        "dt_fixed": None,
        "cfl_type": "acoustic",
        "max_iteration": 200000,
        "use_autograd": True,
        "use_acid": True,
        "vof_type": "volume",
        "variable_set": "puT",
        "use_barotropic": False,
        "use_K": False,
        "use_compress": False,
        "coupled": False,
        "solver_mode": "delta",
        "third_var": "T",
        "bdf_order": 2,
        "mwi_rho_star": "harmonic",
        "tvd_limiter": "koren",
        "acoustic_limiter": None,
        "acoustic_limiter_blend": 1.0,
        "mwi_transient": True,
        "acoustic_face_correction": True,
        "acid_temporal_colour": "midpoint",
        "max_outer": 1,
        "max_inner": 20,
        "max_newton": 20,
        "newton_tol": 1.0e-6,
        "inner_tol": 1.0e-6,
        "outer_tol": 1.0e-6,
        "newton_omega": 1.0,
        "use_jfnk": True,
        "krylov_max": 8,
    }
    res = denner_run(case_params)
    psi, T, u, p = res["final_state"]["psi"], res["final_state"]["T"], res["final_state"]["u"], res["final_state"]["p"]
    rho = _mix_rho(psi, p, T, AIR_IDEAL, WATER_NASG)
    grad_psi = np.abs(np.gradient(psi, dx))
    grad_p = np.abs(np.gradient(p, dx))
    iface_x = float(x[int(np.argmax(grad_psi))])
    shock_x = float(x[int(np.argmax(grad_p))])
    exact = {
        "x_contact": float(iface_x),
        "x_transmitted_shock": float(shock_x),
    }
    return {
        "case": "25",
        "subcase": None,
        "source": f"solver:N={n}",
        "x": x,
        "dx": dx,
        "psi": psi,
        "T": T,
        "u": u,
        "p": p,
        "rho": rho,
        "ph1": AIR_IDEAL,
        "ph2": WATER_NASG,
        "bc_l": "transmissive",
        "bc_r": "transmissive",
        "dt": float(res["dt_history"][-1]) if res.get("dt_history") else float(t_end / max(len(x), 1)),
        "complete": bool(res["t_history"][-1] >= t_end - 1.0e-14),
        "diverged": bool(res.get("diverged", False)),
        "exact": exact,
        "exact_meta": {
            "x_interface": float(x_interface),
            "x_contact": float(iface_x),
            "x_transmitted_shock": float(shock_x),
        },
        "metadata": {
            "t_end": float(t_end),
            "steps": int(len(res.get("dt_history", ()))),
            "wall": float(res.get("wall", 0.0)),
        },
    }


def _face_stats(values: np.ndarray, mask: np.ndarray) -> dict[str, Any]:
    values = np.asarray(values, dtype=float)
    mask = np.asarray(mask, dtype=bool)
    data = values[mask] if np.any(mask) else np.array([], dtype=float)
    if data.size == 0:
        return {"count": 0}
    pct = [5, 25, 50, 75, 90, 95, 99]
    out = {"count": int(data.size)}
    for q in pct:
        out[f"p{q}"] = float(np.percentile(data, q))
    out["mean"] = float(np.mean(data))
    out["max"] = float(np.max(data))
    out["min"] = float(np.min(data))
    return out


def _reconstruct_cell_thermo(
    p: np.ndarray,
    u: np.ndarray,
    T: np.ndarray,
    psi: np.ndarray,
    ph1: dict,
    ph2: dict,
) -> dict[str, np.ndarray]:
    props = compute_mixture_props(p, u, T, psi, ph1, ph2)
    return {
        "rho": np.asarray(props["rho"], dtype=float),
        "c_mix": np.asarray(props["c_mix"], dtype=float),
        "rho_h": np.asarray(props["rho_h"], dtype=float),
    }


def _face_grid(data: dict[str, Any]) -> dict[str, Any]:
    x = np.asarray(data["x"], dtype=float)
    dx = float(data["dx"])
    psi = np.asarray(data["psi"], dtype=float)
    T = np.asarray(data["T"], dtype=float)
    u = np.asarray(data["u"], dtype=float)
    p = np.asarray(data["p"], dtype=float)
    rho = np.asarray(data["rho"], dtype=float)
    ph1 = data["ph1"]
    ph2 = data["ph2"]
    bc_l = data["bc_l"]
    bc_r = data["bc_r"]
    dt = float(data["dt"])
    N = int(x.size)
    bc_scalar_l = "wall" if bc_l == "reflective" else bc_l
    bc_scalar_r = "wall" if bc_r == "reflective" else bc_r
    bc_vel_l = "wall" if bc_l == "reflective" else bc_l
    bc_vel_r = "wall" if bc_r == "reflective" else bc_r

    # Local thermodynamics for impedances and enthalpy proxies.
    cell_props = _reconstruct_cell_thermo(p, u, T, psi, ph1, ph2)
    c_mix = np.asarray(cell_props["c_mix"], dtype=float)

    # Ghosted arrays on the same stencil convention as assembly.py.
    psi_ext = apply_ghost(psi, bc_scalar_l, bc_scalar_r, 2)
    p_ext = apply_ghost(p, bc_scalar_l, bc_scalar_r, 2)
    u_ext = apply_ghost_velocity(u, bc_vel_l, bc_vel_r, 2)
    rho_ext = apply_ghost(rho, bc_scalar_l, bc_scalar_r, 2)
    T_ext = apply_ghost(T, bc_scalar_l, bc_scalar_r, 2)
    c_ext = apply_ghost(c_mix, bc_scalar_l, bc_scalar_r, 2)
    x_ext = apply_ghost(x, bc_scalar_l, bc_scalar_r, 2)

    left = np.arange(N + 1, dtype=int) + 1
    right = np.arange(N + 1, dtype=int) + 2
    psi_L = psi_ext[left]
    psi_R = psi_ext[right]
    p_L = p_ext[left]
    p_R = p_ext[right]
    u_L = u_ext[left]
    u_R = u_ext[right]
    rho_L = rho_ext[left]
    rho_R = rho_ext[right]
    T_L = T_ext[left]
    T_R = T_ext[right]
    c_L = c_ext[left]
    c_R = c_ext[right]
    x_L = x_ext[left]
    x_R = x_ext[right]

    # Face-local sensors.
    material_jump = np.abs(psi_R - psi_L) > np.sqrt(np.finfo(float).eps)
    pressure_jump = (np.maximum(np.abs(p_L), np.abs(p_R))
                     / np.maximum(np.minimum(np.abs(p_L), np.abs(p_R)), 1.0e-300)) > 1.01
    rho_ratio = np.maximum(rho_L, rho_R) / np.maximum(np.minimum(rho_L, rho_R), 1.0e-300)
    round3_mask = material_jump & (~pressure_jump)
    round4a_mask = material_jump & pressure_jump & (rho_ratio <= 50.0)
    shock_material = material_jump & pressure_jump

    # Expansion/compression classification based on the local face velocity proxy.
    theta_proxy = 0.5 * (u_L + u_R)
    du_over_c = np.abs(u_R - u_L) / np.maximum(0.5 * (c_L + c_R), 1.0e-300)
    expansion = (u_R - u_L) > 0.0
    compression = (u_R - u_L) < 0.0
    face_courant = np.abs(theta_proxy) * dt / max(dx, 1.0e-300)
    p_jump_rel = np.abs(p_R - p_L) / np.maximum.reduce([
        np.abs(p_L),
        np.abs(p_R),
        np.ones_like(p_L),
    ])
    psi_jump = np.abs(psi_R - psi_L)
    impedance_ratio = np.maximum(rho_L * c_L, rho_R * c_R) / np.maximum(
        np.minimum(rho_L * c_L, rho_R * c_R), 1.0e-300
    )

    # Proxy for the exact face color transported by the advective step.
    # This is intentionally offline and donor based.
    transport_donor_right = np.where(theta_proxy >= 0.0, psi_L, psi_R)
    transport_donor_left = np.where(theta_proxy >= 0.0, psi_L, psi_R)
    acid_cell_proxy = 0.5 * (psi_L + psi_R)
    round3_color = np.where(round3_mask, acid_cell_proxy, transport_donor_right)
    round4a_color = np.where(round4a_mask, acid_cell_proxy, transport_donor_right)

    # The solver uses the selected face color to form the face density and
    # split enthalpy terms.  We evaluate a compact proxy with the same EOS
    # closure on the face-adjacent donor state.
    donor_is_left = theta_proxy >= 0.0
    donor_idx = np.where(donor_is_left, np.arange(N + 1) + 1, np.arange(N + 1) + 2)
    p_d = p_ext[donor_idx]
    T_d = T_ext[donor_idx]
    u_d = u_ext[donor_idx]

    def _face_rho_h(psi_face: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        props = compute_mixture_props(p_d, u_d, T_d, psi_face, data["ph1"], data["ph2"])
        rho_face = np.asarray(props["rho"], dtype=float)
        rho_h_face = np.asarray(props["rho_h"], dtype=float)
        h_face = rho_h_face / np.maximum(rho_face, 1.0e-300)
        return rho_face, h_face

    rho_base, h_base = _face_rho_h(transport_donor_right)
    rho_round3, h_round3 = _face_rho_h(round3_color)
    rho_round4a, h_round4a = _face_rho_h(round4a_color)

    # Local ACID/MWI metrics used for a compact theta proxy.  This is not the
    # target of the diagnostic; it is included for context.
    rho_h_face = harmonic_face_density(rho, bc_scalar_l, bc_scalar_r)
    rho_g_face = geometric_face_density(rho, bc_scalar_l, bc_scalar_r)
    rho_a_face = acid_face_density(rho, c_mix, psi, bc_scalar_l, bc_scalar_r)
    e_diag = solver_a._momentum_diagonal(rho, dx, dt)
    d_h = mwi_face_coeff_denner(e_diag, rho_h_face, dx, dt, bc_scalar_l, bc_scalar_r)
    d_g = mwi_face_coeff_denner(e_diag, rho_g_face, dx, dt, bc_scalar_l, bc_scalar_r)
    d_a = mwi_face_coeff_denner(e_diag, rho_a_face, dx, dt, bc_scalar_l, bc_scalar_r)
    theta_h, ubar = solver_a._compute_face_velocity(
        u, p, d_h, dx, bc_scalar_l, bc_scalar_r, rho_cell=rho, rho_star_face=rho_h_face
    )
    theta_g, _ = solver_a._compute_face_velocity(
        u, p, d_g, dx, bc_scalar_l, bc_scalar_r, rho_cell=rho, rho_star_face=rho_g_face
    )
    theta_a, _ = solver_a._compute_face_velocity(
        u, p, d_a, dx, bc_scalar_l, bc_scalar_r, rho_cell=rho, rho_star_face=rho_a_face
    )

    return {
        "N": int(N),
        "dx": float(dx),
        "dt": float(dt),
        "face_x": 0.5 * (x_L + x_R),
        "cell": {
            "rho": rho,
            "u": u,
            "p": p,
            "T": T,
            "psi": psi,
            "c_mix": c_mix,
        },
        "faces": {
            "psi_L": psi_L,
            "psi_R": psi_R,
            "p_L": p_L,
            "p_R": p_R,
            "u_L": u_L,
            "u_R": u_R,
            "rho_L": rho_L,
            "rho_R": rho_R,
            "T_L": T_L,
            "T_R": T_R,
            "c_L": c_L,
            "c_R": c_R,
            "material_jump": material_jump,
            "pressure_jump": pressure_jump,
            "shock_material": shock_material,
            "round3_mask": round3_mask,
            "round4a_mask": round4a_mask,
            "rho_ratio": rho_ratio,
            "impedance_ratio": impedance_ratio,
            "p_jump_rel": p_jump_rel,
            "psi_jump": psi_jump,
            "du_over_c": du_over_c,
            "theta_proxy": theta_proxy,
            "theta_harmonic": theta_h,
            "theta_geometric": theta_g,
            "theta_acid": theta_a,
            "u_bar": ubar,
            "face_courant": face_courant,
            "expansion": expansion,
            "compression": compression,
            "rho_base": rho_base,
            "h_base": h_base,
            "rho_round3": rho_round3,
            "h_round3": h_round3,
            "rho_round4a": rho_round4a,
            "h_round4a": h_round4a,
        },
    }


def _region_masks_case07(case_name: str, audit: dict[str, Any], face_x: np.ndarray) -> dict[str, np.ndarray]:
    # Exact packet support approximated with a narrow amplitude threshold.
    p_exact = np.asarray(audit["exact"]["p"], dtype=float)
    u_exact = np.asarray(audit["exact"]["u"], dtype=float)
    x_cells = np.asarray(audit["x"], dtype=float)
    p0 = float(V_P0)
    case = next(c for c in CASES_07 if c.name == case_name)
    p_face = np.interp(face_x, x_cells, p_exact)
    u_face = np.interp(face_x, x_cells, u_exact)
    dp = np.abs(p_face - p0)
    du = np.abs(u_face)
    p_thr = max(0.05 * float(np.max(dp)), 1.0e-12)
    u_thr = max(0.05 * float(np.max(du)), 1.0e-12)
    packet_region = (
        (np.abs(p_face - p0) >= p_thr) |
        (np.abs(u_face) >= u_thr) |
        (np.abs(face_x - case.x_intf) <= max(8.0 * float(audit["dx"]), 0.02))
    )
    interface_zone = np.abs(face_x - case.x_intf) <= max(10.0 * float(audit["dx"]), 0.03)
    return {
        "packet_region": packet_region,
        "interface_zone": interface_zone,
    }


def _region_masks_case25(audit: dict[str, Any], face_x: np.ndarray) -> dict[str, np.ndarray]:
    exact = audit["exact"]
    contact_x = float(exact["x_contact"])
    shock_x = float(exact["x_transmitted_shock"])
    x_interface = float(audit["exact_meta"]["x_interface"])
    dx = float(audit["dx"])
    interface_zone = (
        (np.abs(face_x - x_interface) <= max(8.0 * dx, 0.03)) |
        (np.abs(face_x - contact_x) <= max(8.0 * dx, 0.03)) |
        (np.abs(face_x - shock_x) <= max(8.0 * dx, 0.03))
    )
    interface_packet = (face_x >= x_interface - 0.05) & (face_x <= shock_x + 0.05)
    return {
        "interface_zone": interface_zone,
        "interface_packet": interface_packet,
    }


def _summarize_case(name: str, data: dict[str, Any]) -> dict[str, Any]:
    face = _face_grid(data)
    faces = face["faces"]
    Nf = int(face["N"] + 1)
    total_faces = Nf
    round3 = faces["round3_mask"]
    round4a = faces["round4a_mask"]
    material = faces["material_jump"]
    pressure = faces["pressure_jump"]
    shock_material = faces["shock_material"]
    expansion = faces["expansion"]
    compression = faces["compression"]
    face_x = np.asarray(face["face_x"], dtype=float)

    regions = {}
    if name == "07":
        regions = _region_masks_case07(data.get("subcase", ""), data, face_x)
    elif name == "25":
        regions = _region_masks_case25(data, face_x)
    else:
        regions = {"interface_zone": np.zeros_like(material, dtype=bool)}

    out = {
        "case": name,
        "subcase": data.get("subcase"),
        "source": data.get("source"),
        "source_complete": bool(data.get("complete", False)),
        "source_diverged": bool(data.get("diverged", False)),
        "N": int(data["x"].size),
        "dx": float(data["dx"]),
        "dt": float(data["dt"]),
        "faces_total": int(total_faces),
        "faces_material": int(np.count_nonzero(material)),
        "faces_pressure_jump": int(np.count_nonzero(pressure)),
        "faces_shock_material": int(np.count_nonzero(shock_material)),
        "round3": {
            "count": int(np.count_nonzero(round3)),
            "fraction": float(np.count_nonzero(round3) / max(total_faces, 1)),
        },
        "round4a": {
            "count": int(np.count_nonzero(round4a)),
            "fraction": float(np.count_nonzero(round4a) / max(total_faces, 1)),
        },
        "overlap": {
            "round3_material": int(np.count_nonzero(round3 & material)),
            "round3_pressure": int(np.count_nonzero(round3 & pressure)),
            "round3_expansion": int(np.count_nonzero(round3 & expansion)),
            "round3_compression": int(np.count_nonzero(round3 & compression)),
            "round4a_material": int(np.count_nonzero(round4a & material)),
            "round4a_pressure": int(np.count_nonzero(round4a & pressure)),
            "round4a_expansion": int(np.count_nonzero(round4a & expansion)),
            "round4a_compression": int(np.count_nonzero(round4a & compression)),
        },
        "regions": {},
    }

    for region_name, region_mask in regions.items():
        out["regions"][region_name] = {
            "faces": int(np.count_nonzero(region_mask)),
            "round3_hits": int(np.count_nonzero(round3 & region_mask)),
            "round4a_hits": int(np.count_nonzero(round4a & region_mask)),
            "material_hits": int(np.count_nonzero(material & region_mask)),
        }

    for key in ("rho_ratio", "impedance_ratio", "p_jump_rel", "du_over_c",
                "theta_proxy", "theta_harmonic", "theta_geometric",
                "theta_acid", "face_courant", "psi_jump"):
        out[key] = _face_stats(faces[key], np.ones_like(round3, dtype=bool))
        out[f"{key}_round3"] = _face_stats(faces[key], round3)
        out[f"{key}_round4a"] = _face_stats(faces[key], round4a)
        out[f"{key}_material"] = _face_stats(faces[key], material)

    delta_rho_round3 = np.abs(faces["rho_round3"] - faces["rho_base"])
    delta_h_round3 = np.abs(faces["h_round3"] - faces["h_base"])
    delta_rho_round4a = np.abs(faces["rho_round4a"] - faces["rho_base"])
    delta_h_round4a = np.abs(faces["h_round4a"] - faces["h_base"])

    out["transport_proxy"] = {
        "rho_base_all": {
            "mean": float(np.mean(faces["rho_base"])),
            "max": float(np.max(faces["rho_base"])),
            "min": float(np.min(faces["rho_base"])),
        },
        "rho_round3_active_delta_abs": _face_stats(delta_rho_round3, round3),
        "rho_round4a_active_delta_abs": _face_stats(delta_rho_round4a, round4a),
        "h_round3_active_delta_abs": _face_stats(delta_h_round3, round3),
        "h_round4a_active_delta_abs": _face_stats(delta_h_round4a, round4a),
        "rho_round3_relative_mean": float(np.mean(np.abs(delta_rho_round3[round3]) / np.maximum(faces["rho_base"][round3], 1.0e-300))) if np.any(round3) else 0.0,
        "rho_round4a_relative_mean": float(np.mean(np.abs(delta_rho_round4a[round4a]) / np.maximum(faces["rho_base"][round4a], 1.0e-300))) if np.any(round4a) else 0.0,
        "h_round3_relative_mean": float(np.mean(np.abs(delta_h_round3[round3]) / np.maximum(np.abs(faces["h_base"][round3]), 1.0e-300))) if np.any(round3) else 0.0,
        "h_round4a_relative_mean": float(np.mean(np.abs(delta_h_round4a[round4a]) / np.maximum(np.abs(faces["h_base"][round4a]), 1.0e-300))) if np.any(round4a) else 0.0,
    }

    out["psi_jump_percentiles"] = {
        "all": _face_stats(faces["psi_jump"], np.ones_like(round3, dtype=bool)),
        "round3": _face_stats(faces["psi_jump"], round3),
        "round4a": _face_stats(faces["psi_jump"], round4a),
        "material": _face_stats(faces["psi_jump"], material),
    }
    out["face_x_samples"] = {
        "round3_faces": [int(i) for i in np.flatnonzero(round3)[:24]],
        "round4a_faces": [int(i) for i in np.flatnonzero(round4a)[:24]],
    }

    if name == "07":
        out["acoustic_packet_activation"] = {
            region: {
                "round3": bool(np.any(round3 & mask)),
                "round4a": bool(np.any(round4a & mask)),
            }
            for region, mask in regions.items()
        }
    if name == "25":
        out["interface_zone_activation"] = {
            region: {
                "round3": bool(np.any(round3 & mask)),
                "round4a": bool(np.any(round4a & mask)),
            }
            for region, mask in regions.items()
        }

    out["face_sensor_samples"] = {
        "first_round3_faces": [
            {
                "face": int(i),
                "x_face": float(face_x[i]),
                "rho_ratio": float(faces["rho_ratio"][i]),
                "impedance_ratio": float(faces["impedance_ratio"][i]),
                "p_jump_rel": float(faces["p_jump_rel"][i]),
                "du_over_c": float(faces["du_over_c"][i]),
                "theta_proxy": float(faces["theta_proxy"][i]),
                "face_courant": float(faces["face_courant"][i]),
                "psi_jump": float(faces["psi_jump"][i]),
            }
            for i in np.flatnonzero(round3)[:12]
        ],
        "first_round4a_faces": [
            {
                "face": int(i),
                "x_face": float(face_x[i]),
                "rho_ratio": float(faces["rho_ratio"][i]),
                "impedance_ratio": float(faces["impedance_ratio"][i]),
                "p_jump_rel": float(faces["p_jump_rel"][i]),
                "du_over_c": float(faces["du_over_c"][i]),
                "theta_proxy": float(faces["theta_proxy"][i]),
                "face_courant": float(faces["face_courant"][i]),
                "psi_jump": float(faces["psi_jump"][i]),
            }
            for i in np.flatnonzero(round4a)[:12]
        ],
    }

    return out


def _format_summary(summary: list[dict[str, Any]]) -> str:
    lines = []
    lines.append("Round 5A transport-face diagnostic")
    for item in summary:
        label = f"case{item['case']}"
        if item.get("subcase"):
            label += f" / {item['subcase']}"
        lines.append("")
        lines.append(label)
        lines.append(f"  source: {item.get('source')}")
        lines.append(
            f"  round3: {item['round3']['count']} faces ({100.0 * item['round3']['fraction']:.2f}%)"
        )
        lines.append(
            f"  round4A: {item['round4a']['count']} faces ({100.0 * item['round4a']['fraction']:.2f}%)"
        )
        lines.append(
            f"  material: {item['faces_material']}  pressure_jump: {item['faces_pressure_jump']}  "
            f"shock_material: {item['faces_shock_material']}"
        )
        lines.append(
            f"  rho_ratio max={item['rho_ratio']['max']:.3e}  "
            f"impedance_ratio max={item['impedance_ratio']['max']:.3e}  "
            f"|dp| max={item['p_jump_rel']['max']:.3e}"
        )
        lines.append(
            f"  |du|/c max={item['du_over_c']['max']:.3e}  "
            f"theta proxy max={item['theta_proxy']['max']:.3e}  "
            f"face Courant max={item['face_courant']['max']:.3e}"
        )
        lines.append(
            f"  psi jump p95/p99={item['psi_jump_percentiles']['all']['p95']:.3e}/"
            f"{item['psi_jump_percentiles']['all']['p99']:.3e}"
        )
        if item["transport_proxy"]["rho_round3_active_delta_abs"].get("count", 0):
            lines.append(
                f"  round3 proxy |Δrho| mean={item['transport_proxy']['rho_round3_active_delta_abs']['mean']:.3e}  "
                f"|Δh| mean={item['transport_proxy']['h_round3_active_delta_abs']['mean']:.3e}"
            )
        if item["transport_proxy"]["rho_round4a_active_delta_abs"].get("count", 0):
            lines.append(
                f"  round4A proxy |Δrho| mean={item['transport_proxy']['rho_round4a_active_delta_abs']['mean']:.3e}  "
                f"|Δh| mean={item['transport_proxy']['h_round4a_active_delta_abs']['mean']:.3e}"
            )
        if item["case"] == "07":
            lines.append(f"  packet activation: {item.get('acoustic_packet_activation')}")
        if item["case"] == "25":
            lines.append(f"  interface-zone activation: {item.get('interface_zone_activation')}")
    return "\n".join(lines) + "\n"


def _resolve_case(args: argparse.Namespace) -> list[dict[str, Any]]:
    cases = []
    requested = [c.strip() for c in args.cases.split(",") if c.strip()]
    for cid in requested:
        if cid == "24":
            psi_vals = args.case24_psi or [0.25, 0.5, 0.75]
            for psi in psi_vals:
                cases.append(_load_case24_snapshot(float(psi)))
        elif cid == "07":
            if args.run_solver:
                if args.case07_all_subcases:
                    for case in _case07_case_specs():
                        cases.append(_run_case07_subcase(case, args.case07_n))
                else:
                    case = next(c for c in _case07_case_specs() if c.name == "Air-Water")
                    cases.append(_run_case07_subcase(case, args.case07_n))
            else:
                cases.append({
                    "case": "07",
                    "subcase": "Air-Water",
                    "source": "snapshot-unavailable",
                    "complete": False,
                    "diverged": False,
                    "skipped": True,
                })
        elif cid == "25":
            if args.run_solver:
                cases.append(_run_case25(args.case25_n))
            else:
                cases.append({
                    "case": "25",
                    "subcase": None,
                    "source": "snapshot-unavailable",
                    "complete": False,
                    "diverged": False,
                    "skipped": True,
                })
        else:
            raise SystemExit(f"unknown case id: {cid}")
    return cases


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", default="07,24,25",
                    help="comma-separated case ids to inspect: 07,24,25")
    ap.add_argument("--case24-psi", type=float, nargs="*", default=[0.25, 0.5, 0.75],
                    help="case24 psi_water values to inspect")
    ap.add_argument("--case07-n", type=int, default=200)
    ap.add_argument("--case25-n", type=int, default=200)
    ap.add_argument("--run-solver", action="store_true",
                    help="run missing case07/case25 fields through the solver")
    ap.add_argument("--case07-all-subcases", action="store_true",
                    help="when running case07, include all subcases instead of Air-Water only")
    ap.add_argument("--output-base", default="round5a_transport_face_diag",
                    help="basename for JSON/TXT outputs under autoresearch-results")
    args = ap.parse_args()

    started = time.time()
    selected = _resolve_case(args)
    summary = []
    skipped = []
    for item in selected:
        if item.get("skipped"):
            skipped.append(item)
            continue
        summary.append(_summarize_case(item["case"], item))

    payload = {
        "generated_at_unix": time.time(),
        "runtime_sec": time.time() - started,
        "requested_cases": [c.strip() for c in args.cases.split(",") if c.strip()],
        "executed_cases": [f"case{item['case']}" for item in summary],
        "skipped": skipped,
        "summary": summary,
    }

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    json_path = OUT_DIR / f"{args.output_base}.json"
    txt_path = OUT_DIR / f"{args.output_base}.txt"
    json_path.write_text(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
                         encoding="utf-8")
    txt_path.write_text(_format_summary(summary), encoding="utf-8")
    print(json.dumps({
        "json": str(json_path),
        "txt": str(txt_path),
        "runtime_sec": payload["runtime_sec"],
        "cases": payload["executed_cases"],
        "skipped": skipped,
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

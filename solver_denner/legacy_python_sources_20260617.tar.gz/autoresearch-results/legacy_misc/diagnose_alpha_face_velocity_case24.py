#!/usr/bin/env python3
from __future__ import annotations
import sys, json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from solver.denner_1d.eos.base import compute_mixture_props
from solver.denner_1d.flux.mwi import acid_face_density,harmonic_face_density,mwi_face_coeff_denner
from solver.denner_1d.solver_a import _momentum_diagonal,_compute_face_velocity
from solver.denner_1d.boundary import apply_ghost_velocity
AIR={'gamma':1.4,'pinf':0.0,'b':0.0,'kv':717.5,'eta':0.0}
WATER={'gamma':1.187,'pinf':7.028e8,'b':6.61e-4,'kv':3610.0,'eta':-1.177788e6}

def run_npz(path='results/1D/24_H/diag_psi025_final.npz',CFL=0.4):
    d=np.load(path); x=d['x']; psi0=d['psi0']; T=d['T0']; u=d['u0']; p=d['p0']; N=len(x); dx=float(x[1]-x[0])
    props=compute_mixture_props(p,u,T,psi0,AIR,WATER)
    dt=CFL*dx/np.max(np.abs(u)+props['c_mix'])
    u_ext=apply_ghost_velocity(u,'transmissive','transmissive',2)
    u_arith=np.array([0.5*(u_ext[2+f-1]+u_ext[2+f]) for f in range(N+1)])
    rfa=acid_face_density(props['rho'],props['c_mix'],psi0,'transmissive','transmissive')
    rs=harmonic_face_density(props['rho'],'transmissive','transmissive')
    d_hat=mwi_face_coeff_denner(_momentum_diagonal(props['rho'],dx,dt),rs,dx,dt,'transmissive','transmissive')
    theta,ubar=_compute_face_velocity(u,p,d_hat,dx,'transmissive','transmissive',dt=dt,rho_cell=props['rho'],rho_star_face=rs)
    shock=int(np.argmax(np.abs(np.diff(p))))+1
    faces=np.arange(max(0,shock-4),min(N+1,shock+5))
    return dict(path=path,N=N,CFL=CFL,dx=dx,dt=dt,shock_face=shock,
                max_arith=float(np.max(np.abs(u_arith))),max_theta=float(np.max(np.abs(theta))),
                max_ratio=float(np.max(np.abs(theta))/(np.max(np.abs(u_arith))+1e-300)),
                Co_arith=float(np.max(np.abs(u_arith))*dt/dx),Co_theta=float(np.max(np.abs(theta))*dt/dx),
                face_ids=faces.tolist(),arith_faces=u_arith[faces].tolist(),theta_faces=theta[faces].tolist(),
                p_jump=float(np.max(p)/max(np.min(p),1e-300)))
if __name__=='__main__': print(json.dumps(run_npz(),indent=2))

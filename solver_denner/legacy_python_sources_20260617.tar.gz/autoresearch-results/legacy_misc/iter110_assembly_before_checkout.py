# solver_denner/solver/denner_1d/assembly.py
# Ref: Denner 2018 — Newton linearisation, Eqs. 25, 29, 30
#
# Variable ordering: x = [p_0..p_{N-1}, u_0..u_{N-1}, h_0..h_{N-1}]
#
# System: A*x = b.  Solver: r = b - A*x_k; solve A*δx = r; x += δx.
#
# Discrete BDF1 equations:
#   Continuity:  ζ*(p^{n+1}-p^n)/dt + div(ρ̃·ϑ^{n+1}) = 0
#   Momentum:    Newton[ρu]/dt + div(ρ̃·ϑ·u^{n+1}) + ∇p^{n+1} = 0
#   Enthalpy:    Newton[ρh]/dt + div(ρ̃·ϑ·h^{n+1}) - ∂p/∂t = 0
#
# Newton linearisation of ρ·χ around iterate (ρ_k, χ_k), Eq. 29:
#   ρ^{n+1}·χ^{n+1} ≈ ρ_k·χ^{n+1} + ζ_k·(p^{n+1}-p_k)·χ_k
#
# MWI face velocity (implicit in u and p), Eq. 20:
#   ϑ_f^{n+1} = ū_f^{n+1} − d̂_f·∇p_f^{n+1}
#   → contributions to A from u_L, u_R (arithmetic mean) and p_L, p_R (d̂·Laplacian)

import os
import numpy as np
import scipy.sparse as sp
from .eos.eos_class import create_eos

# Lightweight diagnostic counters.  Enabled by ``DENNER_DIAG=1``.  Increments
# inside `assemble_newton_3N` keep their runtime cost minimal when the env
# flag is off (a single boolean check per call).
_DIAG_ENABLED = bool(int(os.environ.get('DENNER_DIAG', '0') or '0'))
ASSEMBLY_DIAG = {
    'calls': 0,
    'acoustic_implicit_on': 0,
    'pressure_jump_faces': 0,
    'material_jump_faces': 0,
    'expansion_jump_faces': 0,
    'hllc_fired_faces': 0,
    'total_faces': 0,
}


def reset_assembly_diag():
    for k in ASSEMBLY_DIAG:
        ASSEMBLY_DIAG[k] = 0
from .eos.base import (
    compute_phase_derivatives,
    recover_T_from_h,
    recover_T_from_h_Y,
)
from .boundary import apply_ghost, apply_ghost_velocity


class _SparseAccumulator:
    """Fast scalar-entry sparse assembly helper.

    `scipy.sparse.lil_matrix` is convenient but very expensive for the
    thousands of scalar matrix-entry operations performed every Newton
    assembly.  This triplet-backed accumulator records each ``add`` as a
    C-level list.append (rows, cols, vals) and converts to CSR once at the
    end via `coo_matrix`, which sums duplicate (row, col) entries
    automatically.  This yields the same matrix as the previous dict-backed
    implementation while removing the per-entry dict.get/dict[k] traffic.
    """

    __slots__ = ("shape", "rows", "cols", "vals")

    def __init__(self, shape):
        self.shape = tuple(shape)
        self.rows = []
        self.cols = []
        self.vals = []

    def __getitem__(self, key):
        # Slow scan; retained only for legacy `A[i, j]` reads.  Hot paths use
        # `add`/`set` exclusively.
        row, col = key
        ri = int(row); ci = int(col)
        total = 0.0
        for r, c, v in zip(self.rows, self.cols, self.vals):
            if r == ri and c == ci:
                total += v
        return total

    def __setitem__(self, key, value):
        row, col = key
        v = float(value)
        if v == 0.0:
            return
        self.rows.append(row)
        self.cols.append(col)
        self.vals.append(v)

    def add(self, row, col, value):
        """Accumulate one scalar entry via list.append.

        Duplicate (row, col) entries are summed by `coo_matrix`/`tocsr`.
        Zero entries are skipped to keep the triplet list compact.
        """
        v = float(value)
        if v == 0.0:
            return
        self.rows.append(row)
        self.cols.append(col)
        self.vals.append(v)

    def set(self, row, col, value):
        """Append one scalar entry.

        Callers use `set` only where no prior accumulation has occurred at
        the same (row, col) — e.g. the `freeze_h` identity-row entry.  In
        that case append is indistinguishable from replace at COO→CSR time.
        """
        v = float(value)
        if v == 0.0:
            return
        self.rows.append(row)
        self.cols.append(col)
        self.vals.append(v)

    def tocsr(self):
        if not self.rows:
            return sp.csr_matrix(self.shape, dtype=float)
        rows = np.asarray(self.rows, dtype=np.int32)
        cols = np.asarray(self.cols, dtype=np.int32)
        vals = np.asarray(self.vals, dtype=float)
        return sp.coo_matrix((vals, (rows, cols)), shape=self.shape).tocsr()


def _ci(block, i, N):
    return block * N + i


def _limited_slope_pair(a, b, kind):
    if kind in ('central', 'linear'):
        return 0.5 * (a + b)
    if a * b <= 0.0:
        return 0.0
    sa = abs(a)
    sb = abs(b)
    if kind == 'vanleer':
        return 2.0 * a * b / (a + b + 1e-300)
    if kind in ('mc', 'monotonized_central'):
        s = np.sign(a)
        return s * min(0.5 * (sa + sb), 2.0 * sa, 2.0 * sb)
    if kind == 'koren':
        r = a / (b + np.sign(b) * 1e-300)
        phi = max(0.0, min(2.0 * r, (1.0 + 2.0 * r) / 3.0, 2.0))
        return phi * b
    if kind == 'umist':
        r = a / (b + np.sign(b) * 1e-300)
        phi = max(0.0, min(2.0 * r, 0.25 * (1.0 + 3.0 * r),
                           0.25 * (3.0 + r), 2.0))
        return phi * b
    if kind in ('vanalbada', 'van_albada'):
        r = a / (b + np.sign(b) * 1e-300)
        phi = (r * r + r) / (r * r + 1.0 + 1e-300)
        return max(0.0, phi) * b
    if kind == 'ospre':
        r = a / (b + np.sign(b) * 1e-300)
        phi = 1.5 * (r * r + r) / (r * r + r + 1.0 + 1e-300)
        return max(0.0, phi) * b
    if kind in ('mcbeta', 'sweby14', 'superbee'):
        # Roe/Sweby MC-beta limiter with the commonly used beta=1.4 default
        # (MPI-AMRVAC ``mcbeta``): less over-compressive than Superbee/beta=2
        # while retaining symmetric TVD second-order MUSCL resolution for
        # smooth acoustic packets.  The validation driver requests
        # ``superbee`` for case 07; use this bounded Sweby-family form
        # uniformly for all primitive/ACID reconstructions rather than adding
        # a case- or region-specific fallback.
        beta = 1.4
        r = a / (b + np.sign(b) * 1e-300)
        phi = max(0.0, min(beta * r, 1.0), min(r, beta))
        return phi * b
    if kind in ('sweby15', 'osher'):
        beta = 1.5
        r = a / (b + np.sign(b) * 1e-300)
        phi = max(0.0, min(beta * r, 1.0), min(r, beta))
        return phi * b
    if kind in ('superbee2', 'superbee_classic'):
        return np.sign(a) * max(min(2.0 * sa, sb), min(sa, 2.0 * sb))
    # Denner 2018 uses Minmod as its representative TVD scheme.
    return np.sign(a) * min(sa, sb)


def _limited_slope_array(a, b, kind):
    """Vectorized counterpart of `_limited_slope_pair`.

    This removes two O(N) Python loops from each Newton assembly while keeping
    the same TVD formulas used by the scalar path.
    """
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    kind = str(kind).lower()
    if kind in ('central', 'linear'):
        return 0.5 * (a + b)

    out = np.zeros_like(a, dtype=float)
    same = (a * b) > 0.0
    if not np.any(same):
        return out

    aa = np.abs(a)
    bb = np.abs(b)
    s = np.sign(a)
    denom = b + np.where(b >= 0.0, 1.0e-300, -1.0e-300)
    r = a / denom

    if kind == 'vanleer':
        out[same] = (2.0 * a[same] * b[same]
                     / (a[same] + b[same] + 1.0e-300))
        return out
    if kind in ('mc', 'monotonized_central'):
        out[same] = (
            s[same]
            * np.minimum.reduce((0.5 * (aa[same] + bb[same]),
                                 2.0 * aa[same], 2.0 * bb[same]))
        )
        return out
    if kind == 'koren':
        phi = np.maximum(
            0.0,
            np.minimum.reduce((2.0 * r, (1.0 + 2.0 * r) / 3.0,
                               np.full_like(r, 2.0))),
        )
        out[same] = phi[same] * b[same]
        return out
    if kind == 'umist':
        phi = np.maximum(
            0.0,
            np.minimum.reduce((2.0 * r, 0.25 * (1.0 + 3.0 * r),
                               0.25 * (3.0 + r), np.full_like(r, 2.0))),
        )
        out[same] = phi[same] * b[same]
        return out
    if kind in ('vanalbada', 'van_albada'):
        rs = np.clip(r[same], 0.0, 1.0e100)
        phi_s = (rs * rs + rs) / (rs * rs + 1.0 + 1.0e-300)
        out[same] = np.maximum(0.0, phi_s) * b[same]
        return out
    if kind == 'ospre':
        # OSPRE is smooth and TVD for positive slope ratios, but the direct
        # r*r form can overflow for near-zero downstream slopes in strong shock
        # tubes.  Evaluate it only on active same-sign entries and cap the ratio
        # at a value where phi is already indistinguishable from its asymptotic
        # 1.5 limit.  This preserves the limiter curve while removing warning-
        # driven NaNs from otherwise valid stencils.
        rs = np.clip(r[same], 0.0, 1.0e100)
        phi_s = 1.5 * (rs * rs + rs) / (rs * rs + rs + 1.0 + 1.0e-300)
        out[same] = np.maximum(0.0, phi_s) * b[same]
        return out
    if kind in ('mcbeta', 'sweby14', 'superbee'):
        beta = 1.4
        phi = np.maximum(
            0.0,
            np.maximum(np.minimum(beta * r, 1.0), np.minimum(r, beta)),
        )
        out[same] = phi[same] * b[same]
        return out
    if kind in ('sweby15', 'osher'):
        beta = 1.5
        phi = np.maximum(
            0.0,
            np.maximum(np.minimum(beta * r, 1.0), np.minimum(r, beta)),
        )
        out[same] = phi[same] * b[same]
        return out
    if kind in ('superbee2', 'superbee_classic'):
        out[same] = (
            s[same]
            * np.maximum(np.minimum(2.0 * aa[same], bb[same]),
                         np.minimum(aa[same], 2.0 * bb[same]))
        )
        return out

    out[same] = s[same] * np.minimum(aa[same], bb[same])
    return out


def _tvd_face_correction(q, bc_l, bc_r, kind='minmod'):
    """Deferred correction from central face value to TVD-reconstructed face value."""
    q = np.asarray(q, dtype=float)
    N = len(q)
    q_ext = apply_ghost(q, bc_l, bc_r, 2)
    slopes = _limited_slope_array(
        q_ext[2:N + 2] - q_ext[1:N + 1],
        q_ext[3:N + 3] - q_ext[2:N + 2],
        kind,
    )
    corr = np.zeros(N + 1)
    corr[1:N] = 0.25 * (slopes[:-1] - slopes[1:])
    return corr


def _tvd_face_states(q, bc_l, bc_r, kind='minmod', velocity=False):
    """Left/right MUSCL-TVD states at faces."""
    q = np.asarray(q, dtype=float)
    N = len(q)
    q_ext = (apply_ghost_velocity(q, bc_l, bc_r, 2) if velocity
             else apply_ghost(q, bc_l, bc_r, 2))
    slopes = _limited_slope_array(
        q_ext[2:N + 2] - q_ext[1:N + 1],
        q_ext[3:N + 3] - q_ext[2:N + 2],
        kind,
    )
    qL = np.empty(N + 1)
    qR = np.empty(N + 1)
    qL[0] = q_ext[1]
    qR[0] = q_ext[2]
    qL[N] = q_ext[N + 1]
    qR[N] = q_ext[N + 2]
    qL[1:N] = q[:-1] + 0.5 * slopes[:-1]
    qR[1:N] = q[1:] - 0.5 * slopes[1:]
    return qL, qR


def assemble_newton_3N(
    N, dx, dt,
    rho_old, u_old, h_old, p_old,   # old-time (n) quantities
    rho_k, u_k, h_k, p_k, T_k, psi_k,
    zeta_k,           # acoustic dρ/dp at iterate for continuity/momentum (N,)
    rho_face_acid,    # ACID face density  (N+1,)
    d_hat,            # MWI coefficient   (N+1,)
    theta_k,          # face velocity at x_k (N+1,)
    ph1, ph2,
    bc_l, bc_r,
    freeze_h=False,
    third_var='h',    # 'h' = (p,u,h), 'T' = (p,u,T)
    T_old=None,       # needed when third_var='T'
    phi_k=None,       # dρ/dT (needed for third_var='T')
    mixing_type='volume',  # 'volume' (ψ-based) or 'mass' (Y-based) ACID helpers
    bdf_order=1,
    dt_prev=None,
    rho_nm1=None,
    rhoU_nm1=None,
    rhoh_nm1=None,
    p_nm1=None,
    face_limiter='minmod',
    scalar_limiter=None,
    psi_face_transport=None,
    c_mix=None,
    acoustic_face_correction=False,
    acoustic_limiter=None,
    acoustic_limiter_blend=1.0,
    use_autograd_derivs=False,
    velocity_limiter=None,
    zeta_energy_k=None,  # thermodynamic dρ/dp for energy EOS linearisation
):
    """
    Newton-linearised (p, u, h) system.
    Returns A (csr), b (ndarray).
    """
    size = 3 * N
    A = _SparseAccumulator((size, size))
    A_add = A.add
    A_set = A.set
    b = np.zeros(size)

    # Temporal coefficient a0*q^{n+1} - rhs_old.  BDF1 is the Denner-style
    # implicit baseline; optional BDF2 removes excessive acoustic damping
    # without changing the pressure-based/MWI spatial discretisation.
    use_bdf2 = (
        int(bdf_order) >= 2
        and dt_prev is not None
        and rho_nm1 is not None
        and rhoU_nm1 is not None
        and rhoh_nm1 is not None
        and p_nm1 is not None
        and float(dt_prev) > 0.0
    )
    if use_bdf2:
        h0 = float(dt)
        h1 = float(dt_prev)
        a0 = (2.0 * h0 + h1) / (h0 * (h0 + h1))
        a1 = -(h0 + h1) / (h0 * h1)
        a2 = h0 / (h1 * (h0 + h1))
        rhs_rho = -a1 * np.asarray(rho_old) - a2 * np.asarray(rho_nm1)
        rhs_rhoU = -a1 * (np.asarray(rho_old) * np.asarray(u_old)) - a2 * np.asarray(rhoU_nm1)
        rhs_rhoh = -a1 * (np.asarray(rho_old) * np.asarray(h_old)) - a2 * np.asarray(rhoh_nm1)
        rhs_p = -a1 * np.asarray(p_old) - a2 * np.asarray(p_nm1)
    else:
        a0 = 1.0 / float(dt)
        rhs_rho = np.asarray(rho_old) / float(dt)
        rhs_rhoU = np.asarray(rho_old) * np.asarray(u_old) / float(dt)
        rhs_rhoh = np.asarray(rho_old) * np.asarray(h_old) / float(dt)
        rhs_p = np.asarray(p_old) / float(dt)

    is_per_l = (bc_l == 'periodic')
    is_per_r = (bc_r == 'periodic')

    def face_lr(f):
        iL = f - 1
        iR = f
        iL = (N - 1 if is_per_l else 0) if iL < 0 else iL
        iR = (0 if is_per_r else N - 1) if iR >= N else iR
        return iL, iR

    def _cell_at(q, j):
        if j < 0:
            return q[N - 1] if is_per_l else q[0]
        if j >= N:
            return q[0] if is_per_r else q[N - 1]
        return q[j]

    acid_scalar_limiter = str(scalar_limiter or face_limiter).lower()
    velocity_limiter = str(velocity_limiter or face_limiter).lower()
    if zeta_energy_k is None:
        zeta_energy_k = zeta_k
    zeta_energy_k = np.asarray(zeta_energy_k, dtype=float)

    psi_face_transport_arr = None
    if psi_face_transport is not None:
        psi_face_transport_arr = np.clip(
            np.asarray(psi_face_transport, dtype=float), 0.0, 1.0)
        if psi_face_transport_arr.shape[0] != N + 1:
            psi_face_transport_arr = None

    # Use the transported VOF face colour for ACID density/mass fluxes.
    # The matching energy flux must stay compatible with that mass flux.  A
    # fully transported phase-enthalpy blend was tested and over-corrected
    # strong homogeneous-mixture shocks; instead use a PEP-style product form
    # H_f = rho_f h_upwind when a transported VOF density is active.  This
    # keeps the internal-energy/enthalpy transport tied to the same face mass
    # flux without introducing a separate composition stencil.
    use_transport_face_enthalpy = True
    use_transport_mass_enthalpy_product = False

    def _dominant_mixture_limiter(j, requested):
        local_limiter = str(requested or face_limiter).lower()
        if local_limiter in ('ospre_umist_dominant',
                             'umist_ospre_dominant',
                             'composition_bvd'):
            # Composition-dominant BVD-style TVD member selection.  Water/stiff
            # dominant stencils are less oscillatory with UMIST, while
            # gas-dominant mixed shock plateaus are less over-compressed with
            # smooth OSPRE.  The switch is a global local-volume-fraction
            # dominance rule, not a case, coordinate, or time-step branch.
            if 0 <= j < N and float(psi_k[j]) < 0.5:
                return 'umist'
            return 'ospre'
        if local_limiter in ('mixture_dominant', 'dominant_mixture',
                             'alpha_dominant_bvd'):
            # Global mixture-state limiter selection.  Gas-dominant local
            # stencils need the more compressive TVD member to keep Mach-10
            # shocks from outrunning the path-conservative jump, while
            # liquid-dominant/stiff stencils are over-compressed by Superbee2
            # and remain stable with UMIST.  The switch is based only on the
            # local volume-fraction dominance and is applied uniformly to all
            # reconstructed primitive/ACID fields, not to a case name, time,
            # or coordinate window.
            if 0 <= j < N and float(psi_k[j]) > 0.5:
                return 'superbee2'
            return 'umist'
        return local_limiter

    def _cell_slope(q, j, limiter_kind=None):
        qm = _cell_at(q, j - 1)
        qc = _cell_at(q, j)
        qp = _cell_at(q, j + 1)
        local_limiter = _dominant_mixture_limiter(j, limiter_kind)
        if (local_limiter in ('superbee2', 'superbee_classic')
                and 0 <= j < N and expansion_cell[j]):
            # Superbee2 is useful for compressive shocks but over-compresses
            # symmetric rarefaction/cavitation expansions.  Use the smoother
            # Sweby/MC-beta member only on same-material expansion stencils.
            local_limiter = 'superbee'
        return _limited_slope_pair(qc - qm, qp - qc, local_limiter)

    def _dominant_slopes_array(q, limiter_kind=None, velocity=False):
        """Vectorized dominant-limiter slopes for all cells.

        The scalar `_cell_slope` remains the canonical definition for isolated
        face-upwind calls.  This bulk path computes the same limiter choice for
        all cells at once and removes a hot O(N) Python loop from every
        primitive/acoustic face-state reconstruction.
        """
        lk = str(limiter_kind or face_limiter).lower()
        q = np.asarray(q, dtype=float)
        q_ext = (apply_ghost_velocity(q, bc_l, bc_r, 2) if velocity
                 else apply_ghost(q, bc_l, bc_r, 2))
        a = q_ext[2:N + 2] - q_ext[1:N + 1]
        bwd = q_ext[3:N + 3] - q_ext[2:N + 2]
        slopes = np.zeros(N, dtype=float)

        def _fill(mask, kind):
            if np.any(mask):
                slopes[mask] = _limited_slope_array(a[mask], bwd[mask], kind)

        if lk in ('ospre_umist_dominant',
                  'umist_ospre_dominant',
                  'composition_bvd'):
            umist = np.asarray(psi_k, dtype=float) < 0.5
            _fill(umist, 'umist')
            _fill(~umist, 'ospre')
            return slopes

        if lk in ('mixture_dominant', 'dominant_mixture',
                  'alpha_dominant_bvd'):
            gas = np.asarray(psi_k, dtype=float) > 0.5
            exp = np.asarray(expansion_cell, dtype=bool)
            _fill(gas & ~exp, 'superbee2')
            _fill(gas & exp, 'superbee')
            _fill(~gas, 'umist')
            return slopes

        # Fallback for any normal limiter if this function is called directly.
        local = lk
        if local in ('superbee2', 'superbee_classic') and np.any(expansion_cell):
            exp = np.asarray(expansion_cell, dtype=bool)
            _fill(~exp, local)
            _fill(exp, 'superbee')
            return slopes
        return _limited_slope_array(a, bwd, local)

    def _tvd_face_states_dominant(q, velocity=False, limiter_kind=None):
        q = np.asarray(q, dtype=float)
        q_ext = (apply_ghost_velocity(q, bc_l, bc_r, 2) if velocity
                 else apply_ghost(q, bc_l, bc_r, 2))
        slopes = _dominant_slopes_array(q, limiter_kind, velocity=velocity)
        qL = np.empty(N + 1)
        qR = np.empty(N + 1)
        qL[0] = q_ext[1]
        qR[0] = q_ext[2]
        qL[N] = q_ext[N + 1]
        qR[N] = q_ext[N + 2]
        qL[1:N] = q[:-1] + 0.5 * slopes[:-1]
        qR[1:N] = q[1:] - 0.5 * slopes[1:]
        return qL, qR

    def _face_states(q, limiter_kind=None, velocity=False):
        lk = str(limiter_kind or face_limiter).lower()
        if lk in ('mixture_dominant', 'dominant_mixture',
                  'alpha_dominant_bvd', 'ospre_umist_dominant',
                  'umist_ospre_dominant', 'composition_bvd'):
            return _tvd_face_states_dominant(
                q, velocity=velocity, limiter_kind=lk)
        return _tvd_face_states(q, bc_l, bc_r, kind=lk, velocity=velocity)

    def _face_upwind_tvd(q, f, theta_f, material_face=False,
                         limiter_kind=None):
        """Second-order TVD upwind face value for ACID advected fields.

        Primitive/acoustic waves may need a sharper limiter than the scalar
        density/enthalpy fluxes.  A single globally selected scalar limiter
        for ACID advected quantities is therefore allowed by variable family
        (not by case or spatial region), following the same bounded MUSCL-TVD
        stencil.  This plays the same role as BVD/FCT-type boundary-variation
        control: keep material thermodynamic fluxes monotone without changing
        the pressure/velocity wave reconstruction.

        """
        jL, jR = face_lr(f)
        if theta_f >= 0.0:
            if f == 0:
                return _cell_at(q, jL)
            return _cell_at(q, jL) + 0.5 * _cell_slope(q, jL, limiter_kind)
        if f == N:
            return _cell_at(q, jR)
        return _cell_at(q, jR) - 0.5 * _cell_slope(q, jR, limiter_kind)

    def _precompute_face_upwind_tvd(q, theta_faces, limiter_kind=None):
        """Precompute second-order upwind face values for a fixed cell field.

        This is used for velocity advection, where the field and limiter are
        fixed throughout one Newton assembly.  Density/enthalpy ACID stencils
        can depend on the equation cell colour and remain scalar-path calls.
        """
        q = np.asarray(q, dtype=float)
        theta_faces = np.asarray(theta_faces, dtype=float)
        slopes = _dominant_slopes_array(q, limiter_kind, velocity=False)
        vals = np.empty(N + 1, dtype=float)
        for f in range(N + 1):
            jL, jR = face_lr(f)
            if theta_faces[f] >= 0.0:
                vals[f] = _cell_at(q, jL) if f == 0 else (
                    _cell_at(q, jL) + 0.5 * slopes[jL])
            else:
                vals[f] = _cell_at(q, jR) if f == N else (
                    _cell_at(q, jR) - 0.5 * slopes[jR])
        return vals

    def _characteristic_pu_face_states(p, u, Z):
        """TVD reconstruction of acoustic invariants p±Zu in each bulk phase."""
        Zs = np.maximum(np.asarray(Z, dtype=float), 1e-300)
        wp = np.asarray(p, dtype=float) + Zs * np.asarray(u, dtype=float)
        wm = np.asarray(p, dtype=float) - Zs * np.asarray(u, dtype=float)
        wpL, wpR = _face_states(wp, limiter_kind=face_limiter)
        wmL, wmR = _face_states(wm, limiter_kind=face_limiter)
        pL = np.empty(N + 1); pR = np.empty(N + 1)
        uL = np.empty(N + 1); uR = np.empty(N + 1)
        for f in range(N + 1):
            jL, jR = face_lr(f)
            zL = max(float(Zs[jL]), 1e-300)
            zR = max(float(Zs[jR]), 1e-300)
            pL[f] = 0.5 * (wpL[f] + wmL[f])
            uL[f] = 0.5 * (wpL[f] - wmL[f]) / zL
            pR[f] = 0.5 * (wpR[f] + wmR[f])
            uR[f] = 0.5 * (wpR[f] - wmR[f]) / zR
        return pL, pR, uL, uR

    # ACID EOS helpers: evaluate partial densities/enthalpies at (p,T) with ψ_ref
    # Build EOS objects once; works for any EOS (NASG, RKPR, etc.)
    eos1 = create_eos(ph1)
    eos2 = create_eos(ph2)

    def _eos_key(ph):
        if isinstance(ph, dict):
            return (
                float(ph.get('gamma', np.nan)),
                float(ph.get('pinf', ph.get('p_inf', 0.0))),
                float(ph.get('b', 0.0)),
                float(ph.get('kv', ph.get('cv', 0.0))),
                float(ph.get('eta', ph.get('q', 0.0))),
            )
        return (
            float(getattr(ph, 'gamma', np.nan)),
            float(getattr(ph, 'pinf', getattr(ph, 'p_inf', 0.0))),
            float(getattr(ph, 'b', 0.0)),
            float(getattr(ph, 'kv', getattr(ph, 'cv', 0.0))),
            float(getattr(ph, 'eta', getattr(ph, 'q', 0.0))),
        )

    single_eos_pair = _eos_key(ph1) == _eos_key(ph2)

    def _phase_derivs(p_val, T_val, ph):
        return compute_phase_derivatives(
            p_val, T_val, ph, use_autograd_derivs=use_autograd_derivs)
    # Denner's pressure-gradient term is a central/linear finite-volume
    # gradient.  TVD limiting is applied to advected quantities, not to the
    # pressure-gradient operator itself.  Keep this correction zero unless a
    # non-Denner acoustic face-pressure operator explicitly replaces it below.
    p_face_corr = np.zeros(N + 1)
    theta_acoustic_extra = np.zeros(N + 1)
    use_acoustic_implicit = bool(acoustic_face_correction and c_mix is not None)
    if _DIAG_ENABLED:
        ASSEMBLY_DIAG['calls'] += 1
        ASSEMBLY_DIAG['total_faces'] += (N + 1)
        if use_acoustic_implicit:
            ASSEMBLY_DIAG['acoustic_implicit_on'] += 1
    theta_coef = None
    pface_coef = None
    theta_face_corr = np.zeros(N + 1)
    pface_corr = np.zeros(N + 1)
    pshock_corr = np.zeros(N + 1)
    theta_flux_k = np.asarray(theta_k, dtype=float).copy()
    psi_ext_base = apply_ghost(psi_k, bc_l, bc_r, 2)
    face_ids = np.arange(N + 1)
    face_left = face_ids - 1
    face_right = face_ids.copy()
    if is_per_l:
        face_left = np.where(face_left < 0, N - 1, face_left)
    else:
        face_left = np.maximum(face_left, 0)
    if is_per_r:
        face_right = np.where(face_right >= N, 0, face_right)
    else:
        face_right = np.minimum(face_right, N - 1)
    material_jump = (
        np.abs(psi_ext_base[2:N + 3] - psi_ext_base[1:N + 2])
        > np.sqrt(np.finfo(float).eps)
    )
    p_abs_L_all = np.maximum(np.abs(np.asarray(p_k)[face_left]), 1.0e-300)
    p_abs_R_all = np.maximum(np.abs(np.asarray(p_k)[face_right]), 1.0e-300)
    # Same-material pressure-shock sensor for the deferred high-order
    # momentum-advection correction.  Limiting the correction as soon as a
    # face has O(1) pressure contrast prevents a one-cell velocity rebound at
    # transmitted shocks, while smooth acoustic/material-equilibrium faces
    # retain the selected second-order MUSCL reconstruction.
    pressure_jump = (
        np.maximum(p_abs_L_all, p_abs_R_all)
        / np.minimum(p_abs_L_all, p_abs_R_all)
    ) > 1.01
    expansion_jump = np.zeros(N + 1, dtype=bool)
    if c_mix is not None:
        c_left = np.asarray(c_mix)[face_left]
        c_right = np.asarray(c_mix)[face_right]
        c_face_all = np.maximum(np.minimum(c_left, c_right), 1.0)
        p_rel_all = (
            np.abs(np.asarray(p_k)[face_right] - np.asarray(p_k)[face_left])
            / np.maximum.reduce([p_abs_L_all, p_abs_R_all,
                                 np.ones_like(p_abs_L_all)])
        )
        expansion_jump = (
            (~material_jump)
            & (((np.asarray(u_k)[face_right] - np.asarray(u_k)[face_left])
                / c_face_all) > 0.05)
            & (p_rel_all < 0.05)
        )
    expansion_cell = np.zeros(N, dtype=bool)
    if np.any(expansion_jump):
        expansion_cell[face_left[expansion_jump]] = True
        expansion_cell[face_right[expansion_jump]] = True
    if _DIAG_ENABLED:
        ASSEMBLY_DIAG['pressure_jump_faces'] += int(np.count_nonzero(pressure_jump))
        ASSEMBLY_DIAG['material_jump_faces'] += int(np.count_nonzero(material_jump))
        ASSEMBLY_DIAG['expansion_jump_faces'] += int(np.count_nonzero(expansion_jump))

    if acoustic_face_correction and c_mix is not None:
        psi_ext = apply_ghost(psi_k, bc_l, bc_r, 2)
        rho_ext = apply_ghost(rho_k, bc_l, bc_r, 2)
        c_ext = apply_ghost(c_mix, bc_l, bc_r, 2)
        p_ext = apply_ghost(p_k, bc_l, bc_r, 2)
        # Interface-equilibrium-compatible reconstruction: build acoustic
        # Riemann states from the primitive basis (P,u), not from density- or
        # impedance-weighted variables.  This keeps uniform P/u fields exactly
        # uniform across material-property jumps; material faces still use the
        # Denner/ACID piecewise-constant fallback below to avoid extrapolating
        # through large impedance discontinuities.
        acoustic_limiter_kind = (
            None if acoustic_limiter is None
            else str(acoustic_limiter).strip().lower()
        )
        if acoustic_limiter_kind:
            if ':' in acoustic_limiter_kind:
                p_acoustic_limiter, u_acoustic_limiter = [
                    part.strip() or face_limiter
                    for part in acoustic_limiter_kind.split(':', 1)
                ]
            else:
                p_acoustic_limiter = acoustic_limiter_kind
                u_acoustic_limiter = acoustic_limiter_kind
        elif face_limiter == 'koren':
            # Acoustic packets need low pressure dispersion but bounded
            # velocity states to avoid the reflected-wave rebound.  Use two
            # standard reconstructions by primitive variable: central pressure
            # for phase accuracy and van-Albada velocity for smooth TVD
            # monotonicity.  This is global for acoustic faces, not a case or
            # region switch.
            p_acoustic_limiter = 'central'
            u_acoustic_limiter = 'vanalbada'
        else:
            p_acoustic_limiter = face_limiter
            u_acoustic_limiter = face_limiter
        pL_rec, pR_rec = _face_states(
            p_k, limiter_kind=p_acoustic_limiter
        )
        uL_rec, uR_rec = _face_states(
            u_k, limiter_kind=u_acoustic_limiter, velocity=True
        )
        if face_limiter in ('superbee2', 'superbee_classic'):
            pL_soft, pR_soft = _tvd_face_states(
                p_k, bc_l, bc_r, kind='superbee'
            )
            uL_soft, uR_soft = _tvd_face_states(
                u_k, bc_l, bc_r, kind='superbee', velocity=True
            )
            for f in range(N + 1):
                if expansion_jump[f]:
                    pL_rec[f] = pL_soft[f]
                    pR_rec[f] = pR_soft[f]
                    uL_rec[f] = uL_soft[f]
                    uR_rec[f] = uR_soft[f]
        if face_limiter == 'koren':
            # High/low acoustic velocity reconstruction in the spirit of
            # sign-preserving FCT/MOOD limiters.  Van Leer restores the smooth
            # packet amplitude/correlation inside one-signed acoustic lobes,
            # but it creates a small rebound when the stencil crosses zero.
            # Use it only where the local five-cell velocity stencil is
            # strictly one-signed; keep the retained van-Albada state across
            # zero crossings.  The wider-than-MUSCL stencil prevents an isolated
            # rebound pocket from becoming its own high-order one-signed region
            # while avoiding excessive clipping of broad smooth packets.  This
            # is a global stencil property, not a
            # validation-case or spatial-region switch.
            uL_high, uR_high = _tvd_face_states(
                u_k, bc_l, bc_r, kind='central', velocity=True
            )
            u_ext_sign = apply_ghost_velocity(u_k, bc_l, bc_r, 2)

            def _one_signed_velocity_cell(j):
                c = 2 + j
                qmin = min(u_ext_sign[c - 2], u_ext_sign[c - 1],
                           u_ext_sign[c], u_ext_sign[c + 1],
                           u_ext_sign[c + 2])
                qmax = max(u_ext_sign[c - 2], u_ext_sign[c - 1],
                           u_ext_sign[c], u_ext_sign[c + 1],
                           u_ext_sign[c + 2])
                return qmin > 0.0 or qmax < 0.0

            for f in range(N + 1):
                cL, cR = face_lr(f)
                if _one_signed_velocity_cell(cL):
                    uL_rec[f] = uL_high[f]
                if _one_signed_velocity_cell(cR):
                    uR_rec[f] = uR_high[f]
        p_ac_corr = np.zeros(N + 1)
        # Characteristic face coupling written as frozen-coefficient linear
        # face states.  This keeps the solve on the Denner 3N pressure-based
        # system while letting impedance jumps enter the implicit block instead
        # of only as a deferred RHS correction.
        # Columns per face: [left-cell p, right-cell p, left-cell u, right-cell u].
        theta_coef = np.zeros((N + 1, 4))
        pface_coef = np.zeros((N + 1, 4))
        for f in range(N + 1):
            iL = 2 + f - 1
            iR = 2 + f
            cL, cR = face_lr(f)
            ZL = max(float(rho_ext[iL] * c_ext[iL]), 1e-300)
            ZR = max(float(rho_ext[iR] * c_ext[iR]), 1e-300)
            Zsum = ZL + ZR
            # Denner/ACID explicitly reverts TVD-limited density/enthalpy
            # advection to first-order upwind in the interface region where
            # |psi_P - psi_Q| is non-zero.  This characteristic coupling is an
            # acoustic face operator rather than an advected scalar, but using
            # extrapolated p/u states across a material jump introduces the
            # same large-impedance nonlinear sensitivity.  At material faces,
            # use piecewise-constant adjacent states for the impedance solve;
            # keep high-order reconstruction in bulk phases.
            is_material_face = bool(material_jump[f])
            pL_face = float(p_k[cL]) if is_material_face else float(pL_rec[f])
            pR_face = float(p_k[cR]) if is_material_face else float(pR_rec[f])
            uL_face = float(u_k[cL]) if is_material_face else float(uL_rec[f])
            uR_face = float(u_k[cR]) if is_material_face else float(uR_rec[f])
            u_star = (pL_face - pR_face + ZL * uL_face + ZR * uR_face) / Zsum
            p_star = pL_face - ZL * (u_star - uL_face)
            if f == 0 and bc_l == 'wall':
                # Linearised acoustic Riemann at a wall: with an antisymmetric
                # velocity ghost (uL = -uR) and a Neumann pressure ghost the
                # contact state has u* = 0 and p* = p_R - Z*u_R, i.e. the wall
                # adds an impedance reflection that the previous Dirichlet-only
                # p_star = pR_rec dropped.  Use the interior cell's impedance.
                Z_wall = ZR
                u_star = 0.0
                p_star = float(p_k[cR]) - Z_wall * float(u_k[cR])
                theta_cc = 0.0
                p_cc = float(p_k[cR]) - Z_wall * float(u_k[cR])
                pface_coef[f, 1] = 1.0
                pface_coef[f, 3] = -Z_wall
            else:
                theta_coef[f, 0] = 1.0 / Zsum
                theta_coef[f, 1] = -1.0 / Zsum
                theta_coef[f, 2] = ZL / Zsum
                theta_coef[f, 3] = ZR / Zsum
                pface_coef[f, 0] = ZR / Zsum
                pface_coef[f, 1] = ZL / Zsum
                pface_coef[f, 2] = ZL * ZR / Zsum
                pface_coef[f, 3] = -ZL * ZR / Zsum
                theta_cc = (
                    theta_coef[f, 0] * float(p_k[cL])
                    + theta_coef[f, 1] * float(p_k[cR])
                    + theta_coef[f, 2] * float(u_k[cL])
                    + theta_coef[f, 3] * float(u_k[cR])
                )
                p_cc = (
                    pface_coef[f, 0] * float(p_k[cL])
                    + pface_coef[f, 1] * float(p_k[cR])
                    + pface_coef[f, 2] * float(u_k[cL])
                    + pface_coef[f, 3] * float(u_k[cR])
                )
            p_central = 0.5 * (p_ext[2 + f - 1] + p_ext[2 + f])
            p_ac_corr[f] = p_star - p_central
            theta_acoustic_extra[f] = u_star - float(theta_k[f])
            theta_face_corr[f] = u_star - theta_cc
            pface_corr[f] = p_star - p_cc
            if (single_eos_pair and pressure_jump[f] and (not is_material_face)
                    and np.isfinite(pL_face) and np.isfinite(pR_face)
                    and np.isfinite(uL_face) and np.isfinite(uR_face)):
                rhoL = max(float(rho_ext[iL]), 1.0e-300)
                rhoR = max(float(rho_ext[iR]), 1.0e-300)
                cL0 = max(float(c_ext[iL]), 1.0e-300)
                cR0 = max(float(c_ext[iR]), 1.0e-300)
                ubar = 0.5 * (uL_face + uR_face)
                cbar = 0.5 * (cL0 + cR0)
                sL = min(uL_face - cL0, ubar - cbar)
                sR = max(uR_face + cR0, ubar + cbar)
                den = rhoL * (sL - uL_face) - rhoR * (sR - uR_face)
                if abs(den) > 1.0e-300:
                    sM = (
                        pR_face - pL_face
                        + rhoL * uL_face * (sL - uL_face)
                        - rhoR * uR_face * (sR - uR_face)
                    ) / den
                    p_star_L = (
                        pL_face
                        + rhoL * (sL - uL_face) * (sM - uL_face)
                    )
                    p_star_R = (
                        pR_face
                        + rhoR * (sR - uR_face) * (sM - uR_face)
                    )
                    p_hllc = max(0.5 * (p_star_L + p_star_R), 1.0e-300)
                    pshock_corr[f] = p_hllc - p_central
                    if _DIAG_ENABLED:
                        ASSEMBLY_DIAG['hllc_fired_faces'] += 1
        if not use_acoustic_implicit:
            p_face_corr = p_ac_corr
        else:
            acoustic_flux_faces = (
                (~material_jump)
                & (expansion_jump | (~pressure_jump))
            )
            # Use one current-state face velocity per face throughout the
            # Newton residual linearisation.  On these same-material acoustic
            # faces the continuity and pressure-gradient operators below use
            # the characteristic face state u_star.  Leaving density/enthalpy
            # upwind decisions on theta_k mixes two different face velocities
            # in one finite-volume flux and adds avoidable acoustic phase and
            # amplitude error.  Material faces and O(1) pressure jumps remain
            # on the retained ACID/MWI/HLLC-protected paths.
            theta_flux_k[acoustic_flux_faces] = (
                np.asarray(theta_k, dtype=float)[acoustic_flux_faces]
                + theta_acoustic_extra[acoustic_flux_faces]
            )

    def _acid_rho(p_val, T_val, psi_ref):
        """ACID density at (p_val,T_val) with this-cell ψ_ref (Eq. 37)."""
        r1 = eos1.rho(p_val, T_val)
        r2 = eos2.rho(p_val, T_val)
        return psi_ref * r1 + (1.0 - psi_ref) * r2

    def _acid_rh(p_val, T_val, u_val, psi_ref):
        """ACID ρH_total at (p,T,u) with this-cell ψ_ref (Denner 2018 Eq. 45-49).
        H = ρ★·h★ where h★ = h_static + ½u² (total specific enthalpy)."""
        r1 = eos1.rho(p_val, T_val)
        h1 = eos1.h(p_val, T_val) + 0.5 * u_val * u_val
        r2 = eos2.rho(p_val, T_val)
        h2 = eos2.h(p_val, T_val) + 0.5 * u_val * u_val
        return psi_ref * r1 * h1 + (1.0 - psi_ref) * r2 * h2

    def _acid_cp(p_val, T_val, psi_ref):
        """ACID mixture cp (Denner 2018 Eq. 46): density-weighted average."""
        r1 = eos1.rho(p_val, T_val)
        r2 = eos2.rho(p_val, T_val)
        rho_mix = psi_ref * r1 + (1.0 - psi_ref) * r2 + 1e-300
        d1 = _phase_derivs(p_val, T_val, ph1)
        d2 = _phase_derivs(p_val, T_val, ph2)
        return (psi_ref * r1 * d1['cp'] +
                (1.0 - psi_ref) * r2 * d2['cp']) / rho_mix

    def _acid_bm(p_val, T_val, psi_ref):
        """ACID mixture b_mix = dh_static/dp (density-weighted)."""
        r1 = eos1.rho(p_val, T_val)
        r2 = eos2.rho(p_val, T_val)
        rho_mix = psi_ref * r1 + (1.0 - psi_ref) * r2 + 1e-300
        d1 = _phase_derivs(p_val, T_val, ph1)
        d2 = _phase_derivs(p_val, T_val, ph2)
        return (psi_ref * r1 * d1['dh_dp'] +
                (1.0 - psi_ref) * r2 * d2['dh_dp']) / rho_mix

    # --- Y-based (mass fraction) ACID helpers ---
    def _acid_rho_Y(p_val, T_val, Y_ref):
        """Harmonic mixture density: 1/(Y/r1 + (1-Y)/r2)."""
        r1 = eos1.rho(p_val, T_val)
        r2 = eos2.rho(p_val, T_val)
        inv_rho = Y_ref / (r1 + 1e-300) + (1.0 - Y_ref) / (r2 + 1e-300)
        return 1.0 / (inv_rho + 1e-300)

    def _acid_rh_Y(p_val, T_val, u_val, Y_ref):
        """Mass-weighted total enthalpy density: rho_star * (Y*h1 + (1-Y)*h2 + 0.5*u^2)."""
        r1 = eos1.rho(p_val, T_val)
        h1 = eos1.h(p_val, T_val)
        r2 = eos2.rho(p_val, T_val)
        h2 = eos2.h(p_val, T_val)
        inv_rho = Y_ref / (r1 + 1e-300) + (1.0 - Y_ref) / (r2 + 1e-300)
        rho_star = 1.0 / (inv_rho + 1e-300)
        h_static = Y_ref * h1 + (1.0 - Y_ref) * h2
        return rho_star * (h_static + 0.5 * u_val * u_val)

    def _acid_cp_Y(p_val, T_val, Y_ref):
        """Mass-weighted mixture cp: Y*cp₁ + (1-Y)*cp₂."""
        d1 = _phase_derivs(p_val, T_val, ph1)
        d2 = _phase_derivs(p_val, T_val, ph2)
        return Y_ref * d1['cp'] + (1.0 - Y_ref) * d2['cp']

    def _acid_bm_Y(p_val, T_val, Y_ref):
        """Mass-weighted mixture b_mix: Y*∂h₁/∂p + (1-Y)*∂h₂/∂p."""
        d1 = _phase_derivs(p_val, T_val, ph1)
        d2 = _phase_derivs(p_val, T_val, ph2)
        return Y_ref * d1['dh_dp'] + (1.0 - Y_ref) * d2['dh_dp']

    # Autograd derivative evaluation is expensive if called scalar-by-scalar.
    # Precompute all cell and upwind-face derivative fields vectorially while
    # keeping the same Denner/ACID stencil and upwind decisions.
    cells = np.arange(N)
    fR_all = cells + 1
    fL_all = cells
    up_R = np.where(theta_flux_k[fR_all] >= 0.0, cells, face_right[fR_all])
    up_L = np.where(theta_flux_k[fL_all] >= 0.0, face_left[fL_all], cells)
    p_fR_all = np.asarray(p_k)[up_R]
    T_fR_all = np.asarray(T_k)[up_R]
    p_fL_all = np.asarray(p_k)[up_L]
    T_fL_all = np.asarray(T_k)[up_L]

    d1_cell = _phase_derivs(p_k, T_k, ph1)
    d2_cell = _phase_derivs(p_k, T_k, ph2)
    d1_fR_all = _phase_derivs(p_fR_all, T_fR_all, ph1)
    d2_fR_all = _phase_derivs(p_fR_all, T_fR_all, ph2)
    d1_fL_all = _phase_derivs(p_fL_all, T_fL_all, ph1)
    d2_fL_all = _phase_derivs(p_fL_all, T_fL_all, ph2)

    r1_cell = eos1.rho(p_k, T_k)
    r2_cell = eos2.rho(p_k, T_k)
    rho_mix_cell = psi_k * r1_cell + (1.0 - psi_k) * r2_cell + 1e-300
    cp_mix_cell = (psi_k * r1_cell * d1_cell['cp'] +
                   (1.0 - psi_k) * r2_cell * d2_cell['cp']) / rho_mix_cell
    bm_mix_cell = (psi_k * r1_cell * d1_cell['dh_dp'] +
                   (1.0 - psi_k) * r2_cell * d2_cell['dh_dp']) / rho_mix_cell
    cp_mass_cell = psi_k * d1_cell['cp'] + (1.0 - psi_k) * d2_cell['cp']
    bm_mass_cell = psi_k * d1_cell['dh_dp'] + (1.0 - psi_k) * d2_cell['dh_dp']
    u_hi_face_all = _precompute_face_upwind_tvd(
        u_k, theta_flux_k, limiter_kind=velocity_limiter)

    # Cell-level enthalpies and kinetic energy.  The earlier per-cell loop
    # called ``eos1.h(p_k, T_k)`` and ``eos2.h(p_k, T_k)`` once per cell on
    # full-N inputs, which is O(N^2) work for a per-cell ACID flux that only
    # changes via the scalar psi_i weight.  Evaluating the phase fields once
    # removes that redundancy while keeping the same expression.
    h1_cell = eos1.h(p_k, T_k)
    h2_cell = eos2.h(p_k, T_k)
    u_arr_cell = np.asarray(u_k, dtype=float)
    KE_cell = 0.5 * u_arr_cell * u_arr_cell
    rh1_KE_cell = r1_cell * (h1_cell + KE_cell)
    rh2_KE_cell = r2_cell * (h2_cell + KE_cell)
    # Upwind-face densities and enthalpies (vectorized over all cells once).
    # ``p_fR_all``/``T_fR_all`` (and the L-counterparts) are the upwind p/T at
    # each cell's right/left face, built above from ``up_R``/``up_L``.
    # Compute lazily: only mass-mixing (harmonic face zeta/phi) and the
    # volume + psi_face_transport energy branch read these.  The default
    # volume branch evaluates ACID face flux from cell-level arrays only.
    _need_face_eos_rho = (
        mixing_type == 'mass'
        or (mixing_type == 'volume' and psi_face_transport_arr is not None)
    )
    _need_face_eos_h = (
        mixing_type == 'volume' and psi_face_transport_arr is not None and use_transport_face_enthalpy
    )
    if _need_face_eos_rho:
        r1_fR_arr = eos1.rho(p_fR_all, T_fR_all)
        r2_fR_arr = eos2.rho(p_fR_all, T_fR_all)
        r1_fL_arr = eos1.rho(p_fL_all, T_fL_all)
        r2_fL_arr = eos2.rho(p_fL_all, T_fL_all)
    else:
        r1_fR_arr = r2_fR_arr = r1_fL_arr = r2_fL_arr = None
    if _need_face_eos_h:
        h1_fR_arr = eos1.h(p_fR_all, T_fR_all)
        h2_fR_arr = eos2.h(p_fR_all, T_fR_all)
        h1_fL_arr = eos1.h(p_fL_all, T_fL_all)
        h2_fL_arr = eos2.h(p_fL_all, T_fL_all)
    else:
        h1_fR_arr = h2_fR_arr = h1_fL_arr = h2_fL_arr = None

    for i in range(N):
        cp = i
        cu = N + i
        ch = 2 * N + i
        rp = cp
        ru = cu
        rh_row = ch

        f_R = i + 1
        f_L = i
        iL, _ = face_lr(f_L)
        _, iR  = face_lr(f_R)

        cp_L = iL;  cu_L = N + iL;  ch_L = 2 * N + iL
        cp_R = iR;  cu_R = N + iR;  ch_R = 2 * N + iR

        rho_i  = rho_k[i]
        zeta_i = zeta_k[i]
        zeta_e_i = zeta_energy_k[i]
        u_i    = u_k[i]
        h_i    = h_k[i]
        psi_i  = float(psi_k[i])   # volume fraction (or Y if mixing_type='mass')

        tR = theta_flux_k[f_R]
        tL = theta_flux_k[f_L]
        dR  = d_hat[f_R]
        dL  = d_hat[f_L]
        # Known part of Denner Eq.(20) not represented by the implicit
        # cell-to-cell pressure difference and arithmetic velocity.  This
        # includes the deferred cell-centred pressure-gradient correction and
        # the transient MWI correction.
        theta_base_R = 0.5 * (float(u_k[i]) + float(u_k[iR])) - dR * (float(p_k[iR]) - float(p_k[i])) / dx
        theta_base_L = 0.5 * (float(u_k[iL]) + float(u_k[i])) - dL * (float(p_k[i]) - float(p_k[iL])) / dx
        theta_corr_R = tR - theta_base_R
        theta_corr_L = tL - theta_base_L

        # ACID face density — Full Newton: upwind face primitives + face derivatives
        # Ref: Denner 2018 Eq. 25, 29, 30; Full Newton linearisation of ρ̃
        if mixing_type == 'mass':
            _ar = _acid_rho_Y
        else:
            _ar = _acid_rho

        # --- Upwind face primitive variables and column indices ---
        # Right face (f_R): upwind direction determined by theta sign
        if tR >= 0:
            p_fR = float(p_k[i]);  T_fR = float(T_k[i])
            cp_up_R = cp;   ch_up_R = ch    # upwind column = cell i
        else:
            p_fR = float(p_k[iR]); T_fR = float(T_k[iR])
            cp_up_R = cp_R; ch_up_R = ch_R  # upwind column = cell iR

        # Left face (f_L): upwind direction determined by theta sign
        if tL >= 0:
            p_fL = float(p_k[iL]); T_fL = float(T_k[iL])
            cp_up_L = cp_L; ch_up_L = ch_L  # upwind column = cell iL
        else:
            p_fL = float(p_k[i]);  T_fL = float(T_k[i])
            cp_up_L = cp;   ch_up_L = ch    # upwind column = cell i

        # ACID is intentionally stencil-local and asymmetric at material
        # interfaces: for the equation of cell i, the whole finite-volume
        # stencil is evaluated with this cell's colour value psi_i.  Denner
        # Eq. (40) uses TVD interpolation for this stencil-local density in
        # bulk phases and explicitly reverts to first-order upwind at material
        # faces, where limiter jitter is amplified by large rho/h jumps.
        if mixing_type == 'volume' and psi_face_transport_arr is not None:
            psi_R = float(psi_face_transport_arr[f_R])
            psi_L = float(psi_face_transport_arr[f_L])
            r1_fR = float(r1_fR_arr[i])
            r2_fR = float(r2_fR_arr[i])
            r1_fL = float(r1_fL_arr[i])
            r2_fL = float(r2_fL_arr[i])
            rfR = psi_R * r1_fR + (1.0 - psi_R) * r2_fR
            rfL = psi_L * r1_fL + (1.0 - psi_L) * r2_fL
            rho_star_all = None
        elif mixing_type == 'mass':
            inv_rho_all = psi_i / (r1_cell + 1e-300) + (1.0 - psi_i) / (r2_cell + 1e-300)
            rho_star_all = 1.0 / (inv_rho_all + 1e-300)
        else:
            rho_star_all = psi_i * r1_cell + (1.0 - psi_i) * r2_cell
        if rho_star_all is not None:
            rfR = _face_upwind_tvd(
                rho_star_all, f_R, tR, material_jump[f_R],
                limiter_kind=acid_scalar_limiter)
            rfL = _face_upwind_tvd(
                rho_star_all, f_L, tL, material_jump[f_L],
                limiter_kind=acid_scalar_limiter)

        # Face density derivatives ∂ρ̃/∂p and ∂ρ̃/∂T for Full Newton of ρ̃·θ
        if mixing_type == 'volume' and psi_face_transport_arr is not None:
            d1R = d1_fR_all
            d2R = d2_fR_all
            d1L = d1_fL_all
            d2L = d2_fL_all
            psi_R = float(psi_face_transport_arr[f_R])
            psi_L = float(psi_face_transport_arr[f_L])
            zeta_fR = psi_R * d1R['zeta'][i] + (1.0 - psi_R) * d2R['zeta'][i]
            phi_fR  = psi_R * d1R['phi'][i]  + (1.0 - psi_R) * d2R['phi'][i]
            zeta_fL = psi_L * d1L['zeta'][i] + (1.0 - psi_L) * d2L['zeta'][i]
            phi_fL  = psi_L * d1L['phi'][i]  + (1.0 - psi_L) * d2L['phi'][i]
        elif mixing_type == 'volume':
            d1R = d1_fR_all
            d2R = d2_fR_all
            d1L = d1_fL_all
            d2L = d2_fL_all
            zeta_fR = psi_i * d1R['zeta'][i] + (1.0 - psi_i) * d2R['zeta'][i]
            phi_fR  = psi_i * d1R['phi'][i]  + (1.0 - psi_i) * d2R['phi'][i]
            zeta_fL = psi_i * d1L['zeta'][i] + (1.0 - psi_i) * d2L['zeta'][i]
            phi_fL  = psi_i * d1L['phi'][i]  + (1.0 - psi_i) * d2L['phi'][i]
        else:
            # Harmonic mixing: 1/ρ = ψ/ρ₁ + (1-ψ)/ρ₂
            # ∂ρ/∂p = ρ²·(ψ·ζ₁/ρ₁² + (1-ψ)·ζ₂/ρ₂²)
            # ∂ρ/∂T = ρ²·(ψ·φ₁/ρ₁² + (1-ψ)·φ₂/ρ₂²)
            r1R = float(r1_fR_arr[i]); r2R = float(r2_fR_arr[i])
            z1R = d1_fR_all['zeta'][i]; z2R = d2_fR_all['zeta'][i]
            g1R = d1_fR_all['phi'][i];  g2R = d2_fR_all['phi'][i]
            zeta_fR = rfR**2 * (psi_i * z1R / (r1R**2 + 1e-300) + (1.0 - psi_i) * z2R / (r2R**2 + 1e-300))
            phi_fR  = rfR**2 * (psi_i * g1R / (r1R**2 + 1e-300) + (1.0 - psi_i) * g2R / (r2R**2 + 1e-300))
            r1L = float(r1_fL_arr[i]); r2L = float(r2_fL_arr[i])
            z1L = d1_fL_all['zeta'][i]; z2L = d2_fL_all['zeta'][i]
            g1L = d1_fL_all['phi'][i];  g2L = d2_fL_all['phi'][i]
            zeta_fL = rfL**2 * (psi_i * z1L / (r1L**2 + 1e-300) + (1.0 - psi_i) * z2L / (r2L**2 + 1e-300))
            phi_fL  = rfL**2 * (psi_i * g1L / (r1L**2 + 1e-300) + (1.0 - psi_i) * g2L / (r2L**2 + 1e-300))

        # Deferred mass fluxes at x_k
        mR = rfR * tR
        mL = rfL * tL

        # Determine if T-coupling should be included (third_var=='T' and phi_k provided)
        use_T_coupling = (third_var == 'T' and phi_k is not None and not freeze_h)
        phi_i_val = float(phi_k[i]) if (phi_k is not None) else 0.0

        # -----------------------------------------------------------
        # CONTINUITY — Full Newton
        # Ref: Denner 2018 Eq. 25
        # (ρ^{n+1} - ρ^n)/dt + div(ρ̃^{n+1}·ϑ^{n+1}) = 0
        # Full Newton: ρ^{n+1} = ρ_k + ζ·δp + φ·δT
        #              ρ̃^{n+1}·ϑ^{n+1} = ρ̃_k·ϑ^{n+1} + ρ̃^{n+1}·ϑ_k - ρ̃_k·ϑ_k
        # -----------------------------------------------------------
        # Temporal: A·ζ/dt·p + (φ/dt·T if T-mode)
        # b:  ρ_old/dt + (ζ·p_k + φ·T_k - ρ_k)/dt  → residual = (ρ_old - ρ_k)/dt ✓
        A_add(rp, cp, a0 * zeta_i)
        b[rp]     += rhs_rho[i] + a0 * (zeta_i * float(p_k[i]) - rho_i)
        if use_T_coupling:
            A_add(rp, ch, a0 * phi_i_val)  # ∂ρ/∂T temporal (Full Newton)
            b[rp]     += a0 * phi_i_val * float(T_k[i])

        # Term 1: ρ̃_k · ϑ^{n+1}.  In acoustic-correction mode, use the
        # impedance-balanced characteristic face velocity as the implicit face
        # operator.  Otherwise retain Denner's MWI face velocity.
        if use_acoustic_implicit:
            for ff, rr, dd, sgn in (
                (f_R, rfR, dR, 1.0),
                (f_L, rfL, dL, -1.0),
            ):
                jL, jR = face_lr(ff)
                if material_jump[ff] and (not pressure_jump[ff]):
                    # Material faces are governed by the ACID/MWI pressure-
                    # equilibrium discretisation only when the face is close
                    # to pressure equilibrium.  A phase-fraction jump inside a
                    # strong shock is not a stationary material interface: the
                    # Rankine-Hugoniot speed depends on impedance-balanced
                    # acoustic coupling across that jump.  Therefore pressure-
                    # jump material faces use the characteristic branch below,
                    # while equilibrium material contacts stay on Denner MWI.
                    A_add(rp, N + jL, sgn * rr / (2.0 * dx))
                    A_add(rp, N + jR, sgn * rr / (2.0 * dx))
                    A_add(rp, jL, sgn * rr * dd / (dx * dx))
                    A_add(rp, jR, -sgn * rr * dd / (dx * dx))
                    corr = theta_corr_R if sgn > 0.0 else theta_corr_L
                    b[rp] -= sgn * rr * corr / dx
                else:
                    cols = (jL, jR,
                            N + jL, N + jR)
                    for col, coef in zip(cols, theta_coef[ff]):
                        if coef != 0.0:
                            A_add(rp, col, sgn * rr * coef / dx)
                    b[rp] -= sgn * rr * theta_face_corr[ff] / dx
        else:
            # Right face:
            A_add(rp, cu, rfR / (2.0 * dx))
            A_add(rp, cu_R, rfR / (2.0 * dx))
            A_add(rp, cp, rfR * dR / (dx * dx))
            A_add(rp, cp_R, -(rfR * dR / (dx * dx)))
            # Left face:
            A_add(rp, cu_L, -(rfL / (2.0 * dx)))
            A_add(rp, cu, -(rfL / (2.0 * dx)))
            A_add(rp, cp, rfL * dL / (dx * dx))
            A_add(rp, cp_L, -(rfL * dL / (dx * dx)))
            # Known MWI correction contribution in div(rho_f * theta_f).
            b[rp] -= rfR * theta_corr_R / dx
            b[rp] += rfL * theta_corr_L / dx
            # Legacy deferred-only characteristic correction.
            b[rp] -= rfR * theta_acoustic_extra[f_R] / dx
            b[rp] += rfL * theta_acoustic_extra[f_L] / dx

        # Term 2: ρ̃^{n+1} · ϑ_k (Newton sensitivity of ρ̃ to p and T)
        # A adds Jacobian; b adds same evaluated at x_k → residual unchanged
        A_add(rp, cp_up_R, zeta_fR * tR / dx)
        A_add(rp, cp_up_L, -(zeta_fL * tL / dx))
        b[rp] += zeta_fR * tR * p_fR / dx - zeta_fL * tL * p_fL / dx
        if use_T_coupling:
            A_add(rp, ch_up_R, phi_fR * tR / dx)
            A_add(rp, ch_up_L, -(phi_fL * tL / dx))
            b[rp] += phi_fR * tR * T_fR / dx - phi_fL * tL * T_fL / dx

        # -----------------------------------------------------------
        # MOMENTUM — Full Newton
        # Ref: Denner 2018 Eq. 29, 30
        # (ρ·u)^{n+1} = ρ_k·u^{n+1} + ρ^{n+1}·u_k - ρ_k·u_k
        # Full advection: ρ̃·ϑ·ũ — linearize ρ̃ as well
        # -----------------------------------------------------------
        # Temporal: ρ_k/dt·u + ζ·u_k/dt·p + (φ·u_k/dt·T if T-mode)
        # b: ρ_old·u_old/dt + (ζ·u_k·p_k + φ·u_k·T_k - ρ_k·u_k)/dt
        A_add(ru, cu, a0 * rho_i)
        A_add(ru, cp, a0 * zeta_i * u_i)
        b[ru]     += rhs_rhoU[i] + a0 * zeta_i * u_i * float(p_k[i])
        if use_T_coupling:
            A_add(ru, ch, a0 * phi_i_val * u_i)
            b[ru]     += a0 * phi_i_val * u_i * float(T_k[i])

        # Convective Term 1: ρ̃_k·ϑ_k·ũ^{n+1} (upwind u implicit)
        if mR >= 0.0:
            A_add(ru, cu, mR / dx)
        else:
            A_add(ru, cu_R, mR / dx)
        if mL >= 0.0:
            A_add(ru, cu_L, -(mL / dx))
        else:
            A_add(ru, cu, -(mL / dx))
        # MUSCL-TVD deferred correction for momentum advection.  The matrix
        # keeps the robust upwind implicit operator while the RHS carries the
        # high-order bounded correction evaluated at the current Newton state.
        u_fo_R = float(u_k[i]) if mR >= 0.0 else float(u_k[iR])
        u_fo_L = float(u_k[iL]) if mL >= 0.0 else float(u_k[i])
        u_hi_R = float(u_hi_face_all[f_R])
        u_hi_L = float(u_hi_face_all[f_L])
        if pressure_jump[f_R]:
            u_hi_R = u_fo_R
        if pressure_jump[f_L]:
            u_hi_L = u_fo_L
        b[ru] -= (mR * (u_hi_R - u_fo_R) - mL * (u_hi_L - u_fo_L)) / dx

        # Convective Term 2: ρ̃_k·ϑ^{n+1}·ũ_k.
        #
        # The characteristic face velocity is beneficial for bulk expansion
        # Riemann jumps (e.g. cavitation), where MWI pressure-only coupling can
        # under-resolve the divergent face motion.  At compressive shocks, the
        # same characteristic momentum coupling over-advects the front and
        # pollutes the density plateau, so retain Denner's MWI implicit
        # pressure part there.  The selector is a global 1D kinematic sensor:
        # same-material face with positive du/dx above the acoustic threshold.
        for ff, rr, dd, cp_left, cp_right, sgn, t_face in (
            (f_R, rfR, dR, cp, cp_R, 1.0, tR),
            (f_L, rfL, dL, cp_L, cp, -1.0, tL),
        ):
            if use_acoustic_implicit and expansion_jump[ff]:
                jL, jR = face_lr(ff)
                cols = (jL, jR,
                        N + jL, N + jR)
                # The explicit face velocity in d(rho_f*theta_f*u_f)/dt must be
                # the upwind face value, otherwise cell i's flux at face f does
                # not match cell j's at the same face when the convection is
                # outward.  Use the same theta-upwind selection as Term 3.
                u_face_expl = (float(u_k[jL]) if t_face >= 0.0
                               else float(u_k[jR]))
                for col, coef in zip(cols, theta_coef[ff]):
                    if coef != 0.0:
                        A_add(ru, col, sgn * rr * u_face_expl * coef / dx)
                b[ru] -= sgn * rr * u_face_expl * theta_face_corr[ff] / dx
            elif sgn > 0.0:
                A_add(ru, cp_left, rr * u_i * dd / (dx * dx))
                A_add(ru, cp_right, -(rr * u_i * dd / (dx * dx)))
            else:
                A_add(ru, cp_left, -(rr * u_i * dd / (dx * dx)))
                A_add(ru, cp_right, rr * u_i * dd / (dx * dx))

        # Convective Term 3: ρ̃^{n+1}·ϑ_k·ũ_k (Newton sensitivity of ρ̃)
        u_up_R = float(u_k[i])  if tR >= 0 else float(u_k[iR])
        u_up_L = float(u_k[iL]) if tL >= 0 else float(u_k[i])
        A_add(ru, cp_up_R, zeta_fR * tR * u_up_R / dx)
        A_add(ru, cp_up_L, -(zeta_fL * tL * u_up_L / dx))
        b[ru] += zeta_fR * tR * u_up_R * p_fR / dx - zeta_fL * tL * u_up_L * p_fL / dx
        if use_T_coupling:
            A_add(ru, ch_up_R, phi_fR * tR * u_up_R / dx)
            A_add(ru, ch_up_L, -(phi_fL * tL * u_up_L / dx))
            b[ru] += phi_fR * tR * u_up_R * T_fR / dx - phi_fL * tL * u_up_L * T_fL / dx

        # Pressure gradient.  When the acoustic face operator is requested,
        # use the same frozen-coefficient characteristic face pressure as the
        # face velocity on smooth same-material acoustic faces.  Keeping
        # characteristic theta in continuity while leaving momentum on a purely
        # central face pressure under-couples the acoustic impedance relation
        # and damps/phase-lags small pressure packets.  Material faces still
        # stay on Denner/ACID equilibrium coupling and O(1) pressure-jump
        # shock faces stay on the central/HLLC-corrected pressure path to avoid
        # over-advecting shock/contact plateaus.
        if use_acoustic_implicit:
            for ff, sgn in ((f_R, 1.0), (f_L, -1.0)):
                use_characteristic_pface = (
                    (not material_jump[ff])
                    and (expansion_jump[ff] or not pressure_jump[ff])
                )
                if use_characteristic_pface:
                    jL, jR = face_lr(ff)
                    cols = (jL, jR,
                            N + jL, N + jR)
                    for col, coef in zip(cols, pface_coef[ff]):
                        if coef != 0.0:
                            A_add(ru, col, sgn * coef / dx)
                    b[ru] -= sgn * pface_corr[ff] / dx
                else:
                    # Central finite-volume face pressure on compressive
                    # shocks: +p_fR/dx or -p_fL/dx, with p_f=0.5(p_L+p_R).
                    jL, jR = face_lr(ff)
                    A_add(ru, jL, sgn * 0.5 / dx)
                    A_add(ru, jR, sgn * 0.5 / dx)
                    if single_eos_pair and pressure_jump[ff] and (not material_jump[ff]):
                        b[ru] -= sgn * pshock_corr[ff] / dx
        else:
            A_add(ru, cp_R, 1.0 / (2.0 * dx))
            A_add(ru, cp_L, -(1.0 / (2.0 * dx)))
            b[ru] -= (p_face_corr[f_R] - p_face_corr[f_L]) / dx

        # -----------------------------------------------------------
        # ENERGY EQUATION (block 2)
        # -----------------------------------------------------------
        if freeze_h:
            # Inner barotropic loop: third variable frozen (identity row)
            A_set(rh_row, ch, 1.0)
            b[rh_row]     = h_k[i]
        elif third_var == 'h':
            # --- (p, u, h) mode: Denner 2018 enthalpy equation ---
            # (ρ^{n+1}h^{n+1} - ρ^n·h^n)/dt + div(ρ̃ϑh) = (p^{n+1}-p^n)/dt
            # Newton: ρ_k/dt·h + (ζ·h_k - 1)/dt·p = ρ^n·h^n/dt - p^n/dt + ζ·h_k·p_k/dt
            A_add(rh_row, ch, a0 * rho_i)
            A_add(rh_row, cp, a0 * (zeta_e_i * h_i - 1.0))
            b[rh_row]     += (rhs_rhoh[i]
                              - rhs_p[i]
                              + a0 * zeta_e_i * h_i * p_k[i])
            # Convective + ACID: use upwind (p,T,u) consistent with rfR/rfL
            # For volume fraction mixing, H_acid(p,T,u,ψ) ≡ rfR·h_up when same (p,T)
            # → acid_corr = 0 in single-phase regions (eliminates spurious oscillation)
            if mixing_type == 'mass':
                inv_rho_all_H = psi_i / (r1_cell + 1e-300) + (1.0 - psi_i) / (r2_cell + 1e-300)
                rho_star_all_H = 1.0 / (inv_rho_all_H + 1e-300)
                h_static_all = psi_i * h1_cell + (1.0 - psi_i) * h2_cell
                H_star_all = rho_star_all_H * (h_static_all + KE_cell)
            else:
                H_star_all = psi_i * rh1_KE_cell + (1.0 - psi_i) * rh2_KE_cell
            h_up_R = h_k[i]   if mR >= 0.0 else h_k[iR]
            h_up_L = h_k[iL]  if mL >= 0.0 else h_k[i]
            if mixing_type == 'volume' and psi_face_transport_arr is not None and use_transport_face_enthalpy:
                u_h_R = u_k[i] if tR >= 0.0 else u_k[iR]
                u_h_L = u_k[iL] if tL >= 0.0 else u_k[i]
                psi_R = float(psi_face_transport_arr[f_R])
                psi_L = float(psi_face_transport_arr[f_L])
                r1_fR = float(r1_fR_arr[i])
                r2_fR = float(r2_fR_arr[i])
                r1_fL = float(r1_fL_arr[i])
                r2_fL = float(r2_fL_arr[i])
                h1_fR = float(h1_fR_arr[i])
                h2_fR = float(h2_fR_arr[i])
                h1_fL = float(h1_fL_arr[i])
                h2_fL = float(h2_fL_arr[i])
                KE_R = 0.5 * u_h_R * u_h_R
                KE_L = 0.5 * u_h_L * u_h_L
                H_R_acid = (
                    psi_R * r1_fR * (h1_fR + KE_R)
                    + (1.0 - psi_R) * r2_fR * (h2_fR + KE_R)
                )
                H_L_acid = (
                    psi_L * r1_fL * (h1_fL + KE_L)
                    + (1.0 - psi_L) * r2_fL * (h2_fL + KE_L)
                )
            elif (mixing_type == 'volume'
                  and psi_face_transport_arr is not None
                  and use_transport_mass_enthalpy_product):
                H_R_acid = rfR * h_up_R
                H_L_acid = rfL * h_up_L
            else:
                H_R_acid = _face_upwind_tvd(
                    H_star_all, f_R, tR, material_jump[f_R],
                    limiter_kind=acid_scalar_limiter)
                H_L_acid = _face_upwind_tvd(
                    H_star_all, f_L, tL, material_jump[f_L],
                    limiter_kind=acid_scalar_limiter)
            if mR >= 0.0: A_add(rh_row, ch, mR / dx)
            else:         A_add(rh_row, ch_R, mR / dx)
            if mL >= 0.0: A_add(rh_row, ch_L, -(mL / dx))
            else:         A_add(rh_row, ch, -(mL / dx))
            acid_corr_R = (H_R_acid - rfR * h_up_R) * tR / dx
            acid_corr_L = (H_L_acid - rfL * h_up_L) * tL / dx
            b[rh_row] -= (acid_corr_R - acid_corr_L)
        else:
            # --- (p, u, T) mode: same ρh energy eq but T is variable ---
            # h_total = cp_mix·T + ½u² → linearize: h ≈ cp·T + u_k·u - ½u_k²
            # Temporal: ρ^{n+1}·h^{n+1} ≈ ρ_k·(cp·T + u_k·u) + (ζ·δp + φ·δT)·h_k
            # Full Newton product (ρ·h): ρ_k·h^{n+1} + ρ^{n+1}·h_k - ρ_k·h_k
            #   where ρ^{n+1} = ρ_k + ζ·δp + φ·δT
            #   and   h^{n+1} = cp·T + u_k·u - ½u_k² (linearized around x_k)
            #
            # T-coefficient: ρ_k·cp/dt + h_k·φ/dt   (≈ ρ_k·cp for ideal gas)
            # u-coefficient: ρ_k·u_k/dt               (from d(½u²)/du)
            # p-coefficient: (ζ·h_k - 1)/dt           (from Newton ρ·h + dp/dt)
            phi_i = float(phi_k[i]) if phi_k is not None else 0.0
            if mixing_type == 'mass':
                cp_i = cp_mass_cell[i]
                bm_i = bm_mass_cell[i]
            else:
                cp_i = cp_mix_cell[i]
                bm_i = bm_mix_cell[i]
            T_i   = T_k[i]

            # Newton product-rule linearization of ρ·h where h = cp*T + b*p + η + ½u²
            # d(ρh)/dT = ρ_k·cp + h_k·φ (= ρ·dh/dT + h·dρ/dT)
            # d(ρh)/dp = ρ_k·b_mix + h_k·ζ (= ρ·dh/dp + h·dρ/dp)
            # d(ρh)/du = ρ_k·u_k
            # Full eq: d(ρh)/dT·T + d(ρh)/dp·p + d(ρh)/du·u − dp/dt
            #        = ρ^n·h^n + [d(ρh)/dT·T_k + d(ρh)/dp·p_k + d(ρh)/du·u_k − ρ_k·h_k] − p^n/dt
            drhdt = rho_i * cp_i + h_i * phi_i
            # Regularization: when d(ρh)/dT ≈ 0 (ideal-gas /
            # NASG-degenerate gas with q=0),
            # temperature is determined by the continuity/EOS coupling, not by
            # the enthalpy equation.  Keep only a roundoff-scale diagonal to
            # avoid singular rows; a larger pseudo-heat-capacity biases strong
            # ideal-gas shocks toward the old temperature and under-compresses
            # the density plateau.
            t_reg = 1.0e-8
            if abs(drhdt) < t_reg * rho_i * (abs(cp_i) + 1e-300):
                drhdt = t_reg * rho_i * cp_i
            drhdp = rho_i * bm_i + h_i * zeta_i
            drhdu = rho_i * u_i

            A_add(rh_row, ch, a0 * drhdt)  # T column
            A_add(rh_row, cu, a0 * drhdu)  # u coupling from ½u²
            A_add(rh_row, cp, a0 * (drhdp - 1.0))  # p coupling (−1 from dp/dt source)
            b[rh_row]     += (rhs_rhoh[i]
                              - rhs_p[i]
                              + a0 * (drhdt * T_i + drhdp * p_k[i] + drhdu * u_i
                                      - rho_i * h_i))

            # Convective for T-mode: use ACID face enthalpy DIRECTLY.
            # Split H_acid = rfR·(cp_i·T + rest). Implicit: cp_i·T; deferred: rest.
            # At uniform (p,T,u): both faces give same H_acid → net flux = 0 ✓
            if mixing_type == 'mass':
                inv_rho_all_H = psi_i / (r1_cell + 1e-300) + (1.0 - psi_i) / (r2_cell + 1e-300)
                rho_star_all_H = 1.0 / (inv_rho_all_H + 1e-300)
                h_static_all = psi_i * h1_cell + (1.0 - psi_i) * h2_cell
                H_star_all = rho_star_all_H * (h_static_all + KE_cell)
                cp_i_acid = cp_mass_cell[i]
            else:
                H_star_all = psi_i * rh1_KE_cell + (1.0 - psi_i) * rh2_KE_cell
                cp_i_acid = cp_mix_cell[i]
            if mixing_type == 'volume' and psi_face_transport_arr is not None and use_transport_face_enthalpy:
                u_h_R = u_k[i] if tR >= 0.0 else u_k[iR]
                u_h_L = u_k[iL] if tL >= 0.0 else u_k[i]
                psi_R = float(psi_face_transport_arr[f_R])
                psi_L = float(psi_face_transport_arr[f_L])
                r1_fR = float(r1_fR_arr[i])
                r2_fR = float(r2_fR_arr[i])
                r1_fL = float(r1_fL_arr[i])
                r2_fL = float(r2_fL_arr[i])
                h1_fR = float(h1_fR_arr[i])
                h2_fR = float(h2_fR_arr[i])
                h1_fL = float(h1_fL_arr[i])
                h2_fL = float(h2_fL_arr[i])
                KE_R = 0.5 * u_h_R * u_h_R
                KE_L = 0.5 * u_h_L * u_h_L
                H_R_acid = (
                    psi_R * r1_fR * (h1_fR + KE_R)
                    + (1.0 - psi_R) * r2_fR * (h2_fR + KE_R)
                )
                H_L_acid = (
                    psi_L * r1_fL * (h1_fL + KE_L)
                    + (1.0 - psi_L) * r2_fL * (h2_fL + KE_L)
                )
            elif (mixing_type == 'volume'
                  and psi_face_transport_arr is not None
                  and use_transport_mass_enthalpy_product):
                h_up_R_total = h_k[i] if mR >= 0.0 else h_k[iR]
                h_up_L_total = h_k[iL] if mL >= 0.0 else h_k[i]
                H_R_acid = rfR * h_up_R_total
                H_L_acid = rfL * h_up_L_total
            else:
                H_R_acid = _face_upwind_tvd(
                    H_star_all, f_R, tR, material_jump[f_R],
                    limiter_kind=acid_scalar_limiter)
                H_L_acid = _face_upwind_tvd(
                    H_star_all, f_L, tL, material_jump[f_L],
                    limiter_kind=acid_scalar_limiter)
            # Full ACID flux deferred to b:
            b[rh_row] -= (H_R_acid * tR - H_L_acid * tL) / dx
            # Implicit cp·T part in A (upwind T):
            if mR >= 0.0: A_add(rh_row, ch, mR * cp_i_acid / dx)
            else:         A_add(rh_row, ch_R, mR * cp_i_acid / dx)
            if mL >= 0.0: A_add(rh_row, ch_L, -(mL * cp_i_acid / dx))
            else:         A_add(rh_row, ch, -(mL * cp_i_acid / dx))
            # Subtract the deferred cp·T part (already in b via full flux):
            T_up_R = T_k[i]  if mR >= 0.0 else T_k[iR]
            T_up_L = T_k[iL] if mL >= 0.0 else T_k[i]
            b[rh_row] += (mR * cp_i_acid * T_up_R - mL * cp_i_acid * T_up_L) / dx

    return A.tocsr(), b


def assemble_newton_4N(
    N, dx, dt,
    rho_old, u_old, h_old, p_old, phi_old,  # old-time
    rho_k, u_k, h_k, p_k, T_k, phi_k,      # iterate
    zeta_k, phi_T_k,         # dρ/dp, dρ/dT
    alpha_k,                 # dρ/dφ (N,)
    d_rho_h_dphi_k,          # d(ρh)/dφ (N,)
    rho_face_acid, d_hat, theta_k,
    beta_k,                  # CICSAM blending factor (N+1,)
    ph1, ph2, bc_l, bc_r,
    mixing_type='volume',
    use_compress=False,
    C_k=None, n_hat_k=None, u_face_vof=None,
    # Newton-CICSAM Jacobian data (optional; if None, fallback to Picard)
    psi_face=None,
    jac_D=None, jac_A=None, jac_UU=None,
    idx_D=None, idx_A=None, idx_UU=None,
    third_var='T',   # 'T' = (p,u,T,φ) mode (default), 'h' = (p,u,h,φ) mode
    scale_continuity=False,  # optional: scale continuity rows to balance p vs Y columns
    picard_advection=False,  # Picard advection: skip spatial ACID Y-Jacobian (dRho_R/L terms)
    use_acid=True,   # True: ACID face density (cell-i ψ); False: upwind Y consistent flux
    use_K=False,     # Denner Eq. (32) compressibility correction in VOF block
):
    """
    Fully coupled Newton-linearised (p, u, T/h, φ) 4N system.
    Block ordering: [p_0..p_{N-1}, u_0..u_{N-1}, T_0(or h_0)..T_{N-1}, phi_0..phi_{N-1}]
    third_var='T': energy unknown is temperature T (default, backward-compatible).
    third_var='h': energy unknown is specific total enthalpy h (Denner 2018 h-mode).
    Returns A (csr), b (ndarray).
    """
    size = 4 * N
    A = sp.lil_matrix((size, size), dtype=float)
    b = np.zeros(size)

    is_per_l = (bc_l == 'periodic')
    is_per_r = (bc_r == 'periodic')

    def face_lr(f):
        iL = f - 1
        iR = f
        iL = (N - 1 if is_per_l else 0) if iL < 0 else iL
        iR = (0 if is_per_r else N - 1) if iR >= N else iR
        return iL, iR

    # ACID EOS helpers (same interface as in assemble_newton_3N)
    # Build EOS objects once; works for any EOS (NASG, RKPR, etc.)
    eos1 = create_eos(ph1)
    eos2 = create_eos(ph2)

    def _acid_rho(p_val, T_val, psi_ref):
        r1 = eos1.rho(p_val, T_val)
        r2 = eos2.rho(p_val, T_val)
        return psi_ref * r1 + (1.0 - psi_ref) * r2

    def _acid_rh(p_val, T_val, u_val, psi_ref):
        r1 = eos1.rho(p_val, T_val)
        h1_val = eos1.h(p_val, T_val) + 0.5 * u_val * u_val
        r2 = eos2.rho(p_val, T_val)
        h2_val = eos2.h(p_val, T_val) + 0.5 * u_val * u_val
        return psi_ref * r1 * h1_val + (1.0 - psi_ref) * r2 * h2_val

    def _acid_cp(p_val, T_val, psi_ref):
        r1 = eos1.rho(p_val, T_val)
        r2 = eos2.rho(p_val, T_val)
        rho_mix = psi_ref * r1 + (1.0 - psi_ref) * r2 + 1e-300
        return (psi_ref * r1 * eos1.cp(p_val, T_val) +
                (1.0 - psi_ref) * r2 * eos2.cp(p_val, T_val)) / rho_mix

    def _acid_bm(p_val, T_val, psi_ref):
        r1 = eos1.rho(p_val, T_val)
        r2 = eos2.rho(p_val, T_val)
        rho_mix = psi_ref * r1 + (1.0 - psi_ref) * r2 + 1e-300
        return (psi_ref * r1 * eos1.dh_dp(p_val, T_val) +
                (1.0 - psi_ref) * r2 * eos2.dh_dp(p_val, T_val)) / rho_mix

    def _acid_rho_Y(p_val, T_val, Y_ref):
        r1 = eos1.rho(p_val, T_val)
        r2 = eos2.rho(p_val, T_val)
        inv_rho = Y_ref / (r1 + 1e-300) + (1.0 - Y_ref) / (r2 + 1e-300)
        return 1.0 / (inv_rho + 1e-300)

    def _acid_rh_Y(p_val, T_val, u_val, Y_ref):
        r1 = eos1.rho(p_val, T_val)
        h1_val = eos1.h(p_val, T_val)
        r2 = eos2.rho(p_val, T_val)
        h2_val = eos2.h(p_val, T_val)
        inv_rho = Y_ref / (r1 + 1e-300) + (1.0 - Y_ref) / (r2 + 1e-300)
        rho_star = 1.0 / (inv_rho + 1e-300)
        h_static = Y_ref * h1_val + (1.0 - Y_ref) * h2_val
        return rho_star * (h_static + 0.5 * u_val * u_val)

    def _acid_cp_Y(p_val, T_val, Y_ref):
        return Y_ref * eos1.cp(p_val, T_val) + (1.0 - Y_ref) * eos2.cp(p_val, T_val)

    def _acid_bm_Y(p_val, T_val, Y_ref):
        return Y_ref * eos1.dh_dp(p_val, T_val) + (1.0 - Y_ref) * eos2.dh_dp(p_val, T_val)

    for i in range(N):
        rp = _ci(0, i, N)
        ru = _ci(1, i, N)
        rT = _ci(2, i, N)
        rv = _ci(3, i, N)

        cp = _ci(0, i, N)
        cu = _ci(1, i, N)
        cT = _ci(2, i, N)
        cv = _ci(3, i, N)

        f_R = i + 1
        f_L = i
        iL, _ = face_lr(f_L)
        _, iR  = face_lr(f_R)

        cp_L = _ci(0, iL, N);  cu_L = _ci(1, iL, N);  cT_L = _ci(2, iL, N);  cv_L = _ci(3, iL, N)
        cp_R = _ci(0, iR, N);  cu_R = _ci(1, iR, N);  cT_R = _ci(2, iR, N);  cv_R = _ci(3, iR, N)

        rho_i   = rho_k[i]
        zeta_i  = zeta_k[i]
        phi_T_i = float(phi_T_k[i]) if phi_T_k is not None else 0.0
        alpha_i = float(alpha_k[i])
        drh_dphi_i = float(d_rho_h_dphi_k[i])
        u_i     = u_k[i]
        h_i     = h_k[i]
        T_i     = T_k[i]
        psi_i   = float(phi_k[i])  # volume or mass fraction for ACID
        if use_K:
            c1_i = eos1.c(float(p_k[i]), float(T_k[i]))
            c2_i = eos2.c(float(p_k[i]), float(T_k[i]))
            r1_i = eos1.rho(float(p_k[i]), float(T_k[i]))
            r2_i = eos2.rho(float(p_k[i]), float(T_k[i]))
            rc1_i = r1_i * c1_i * c1_i
            rc2_i = r2_i * c2_i * c2_i
            rc_mix_i = psi_i * rc1_i + (1.0 - psi_i) * rc2_i + 1e-300
            K_i = psi_i * (rc1_i / rc_mix_i - 1.0)
        else:
            K_i = 0.0

        tR = theta_k[f_R]
        tL = theta_k[f_L]
        dR  = d_hat[f_R]
        dL  = d_hat[f_L]

        # Face density: ACID (cell-i ψ) or upwind-Y consistent flux
        if use_acid:
            # ACID: cell i의 ψ로 face density 계산 (PE 보장, 기존 동작)
            Y_upR = psi_i
            Y_upL = psi_i
        else:
            # Non-ACID: upwind cell의 Y로 face density 계산 (Jacobian Y-sensitivity 확보)
            Y_upR = psi_i if (tR >= 0) else float(phi_k[iR])
            Y_upL = float(phi_k[iL]) if (tL >= 0) else psi_i

        if mixing_type == 'mass':
            rfR = _acid_rho_Y(float(p_k[iR]), float(T_k[iR]), Y_upR)
            rfL = _acid_rho_Y(float(p_k[iL]), float(T_k[iL]), Y_upL)
        else:
            rfR = _acid_rho(float(p_k[iR]), float(T_k[iR]), Y_upR)
            rfL = _acid_rho(float(p_k[iL]), float(T_k[iL]), Y_upL)

        mR = rfR * tR
        mL = rfL * tL

        # Spatial Jacobian: ∂ρ̃_f/∂ψ_i
        # Pre-compute EOS values at face neighbors (always needed)
        r1R = eos1.rho(float(p_k[iR]), float(T_k[iR]))
        r2R = eos2.rho(float(p_k[iR]), float(T_k[iR]))
        r1L = eos1.rho(float(p_k[iL]), float(T_k[iL]))
        r2L = eos2.rho(float(p_k[iL]), float(T_k[iL]))

        if use_acid:
            # ACID Jacobian: ∂ρ̃_f/∂ψ_i — always nonzero (cell i's ψ used for all faces)
            if mixing_type != 'mass':
                dRho_R = r1R - r2R
                dRho_L = r1L - r2L
            else:
                dRho_R = rfR * rfR * (1.0/(r2R+1e-300) - 1.0/(r1R+1e-300))
                dRho_L = rfL * rfL * (1.0/(r2L+1e-300) - 1.0/(r1L+1e-300))
        else:
            # Non-ACID Jacobian: ∂ρ_f/∂Y_i nonzero only when cell i is upwind
            if mixing_type != 'mass':
                # Right face: cell i is upwind when tR >= 0
                dRho_R = (r1R - r2R) if (tR >= 0) else 0.0
                # Left face: cell i is downwind when tL >= 0 (upwind = iL)
                dRho_L = 0.0 if (tL >= 0) else (r1L - r2L)
            else:
                # Harmonic mixing: ∂ρ_harm/∂Y = ρ²·(1/ρ₂ - 1/ρ₁)
                dRho_R = (rfR * rfR * (1.0/(r2R+1e-300) - 1.0/(r1R+1e-300))) if (tR >= 0) else 0.0
                dRho_L = 0.0 if (tL >= 0) else (rfL * rfL * (1.0/(r2L+1e-300) - 1.0/(r1L+1e-300)))

        # -----------------------------------------------------------
        # CONTINUITY (block 0) — extended with φ coupling
        # -----------------------------------------------------------
        A.add(rp, cp, zeta_i / dt)
        b[rp]       += zeta_i * p_old[i] / dt
        # α·dψ/dt: temporal ψ-density coupling
        A.add(rp, cv, alpha_i / dt)
        b[rp]       += alpha_i * float(phi_old[i]) / dt
        # MWI right face
        A.add(rp, cu, rfR / (2.0 * dx))
        A.add(rp, cu_R, rfR / (2.0 * dx))
        A.add(rp, cp, rfR * dR / (dx * dx))
        A.add(rp, cp_R, -(rfR * dR / (dx * dx)))
        # MWI left face
        A.add(rp, cu_L, -(rfL / (2.0 * dx)))
        A.add(rp, cu, -(rfL / (2.0 * dx)))
        A.add(rp, cp, rfL * dL / (dx * dx))
        A.add(rp, cp_L, -(rfL * dL / (dx * dx)))
        # Spatial ACID ψ Jacobian: ∂(ρ̃_f·θ_f)/∂ψ_i = Δρ_f · θ_f
        # picard_advection=True: skip (deferred — already in residual, temporal coupling retained)
        if not picard_advection:
            A.add(rp, cv, dRho_R * tR / dx)
            A.add(rp, cv, -(dRho_L * tL / dx))

        # -----------------------------------------------------------
        # MOMENTUM (block 1) — extended with φ coupling
        # -----------------------------------------------------------
        A.add(ru, cu, rho_i / dt)
        A.add(ru, cp, zeta_i * u_i / dt)
        # α·u_k·dψ/dt: temporal ψ-density coupling for momentum
        A.add(ru, cv, alpha_i * u_i / dt)
        b[ru]     += (rho_old[i] * u_old[i] / dt + zeta_i * u_i * p_k[i] / dt
                      + alpha_i * u_i * float(phi_old[i]) / dt)

        # Convective right face
        if mR >= 0.0:
            A.add(ru, cu, mR / dx)
        else:
            A.add(ru, cu_R, mR / dx)
        A.add(ru, cp, rfR * u_i * dR / (dx * dx))
        A.add(ru, cp_R, -(rfR * u_i * dR / (dx * dx)))
        # Convective left face
        if mL >= 0.0:
            A.add(ru, cu_L, -(mL / dx))
        else:
            A.add(ru, cu, -(mL / dx))
        A.add(ru, cp_L, -(rfL * u_i * dL / (dx * dx)))
        A.add(ru, cp, rfL * u_i * dL / (dx * dx))
        # Pressure gradient
        A.add(ru, cp_R, 1.0 / (2.0 * dx))
        A.add(ru, cp_L, -(1.0 / (2.0 * dx)))
        # Spatial ACID ψ Jacobian: ∂(ρ̃_f·θ_f·ũ_f)/∂ψ_i
        u_up_R = float(u_k[i]) if mR >= 0.0 else float(u_k[iR])
        u_up_L = float(u_k[iL]) if mL >= 0.0 else float(u_k[i])
        # picard_advection=True: skip (deferred — temporal coupling retained)
        if not picard_advection:
            A.add(ru, cv, dRho_R * tR * u_up_R / dx)
            A.add(ru, cv, -(dRho_L * tL * u_up_L / dx))

        # -----------------------------------------------------------
        # ENERGY (block 2) — h-mode or T-mode with φ coupling
        # -----------------------------------------------------------
        if third_var == 'h':
            # --- h-mode: Denner 2018 enthalpy equation ---
            # (ρ^{n+1}h^{n+1} - ρ^n·h^n)/dt + div(ρ̃ϑh) = (p^{n+1}-p^n)/dt
            # Newton: ρ_k/dt·h + (ζ·h_k - 1)/dt·p = ρ^n·h^n/dt - p^n/dt + ζ·h_k·p_k/dt
            A.add(rT, cT, rho_i / dt)
            A.add(rT, cp, (zeta_i * h_i - 1.0) / dt)
            # d(ρh)/dψ temporal coupling
            A.add(rT, cv, drh_dphi_i / dt)
            b[rT]     += (rho_old[i] * h_old[i] / dt
                          - p_old[i] / dt
                          + zeta_i * h_i * float(p_k[i]) / dt
                          + drh_dphi_i * float(phi_old[i]) / dt)
            # Convective + ACID/consistent (h-mode): upwind (p,T,u) face enthalpy
            h_up_R = h_k[i]  if mR >= 0.0 else h_k[iR]
            h_up_L = h_k[iL] if mL >= 0.0 else h_k[i]
            if mR >= 0.0: A.add(rT, cT, mR / dx)
            else:         A.add(rT, cT_R, mR / dx)
            if mL >= 0.0: A.add(rT, cT_L, -(mL / dx))
            else:         A.add(rT, cT, -(mL / dx))
            if use_acid:
                # ACID: face enthalpy evaluated with cell-i ψ (PE-preserving)
                if mixing_type == 'mass':
                    H_R_acid = _acid_rh_Y(float(p_k[iR]), float(T_k[iR]), u_up_R, psi_i)
                    H_L_acid = _acid_rh_Y(float(p_k[iL]), float(T_k[iL]), u_up_L, psi_i)
                else:
                    H_R_acid = _acid_rh(float(p_k[iR]), float(T_k[iR]), u_up_R, psi_i)
                    H_L_acid = _acid_rh(float(p_k[iL]), float(T_k[iL]), u_up_L, psi_i)
                acid_corr_R = (H_R_acid - rfR * h_up_R) * tR / dx
                acid_corr_L = (H_L_acid - rfL * h_up_L) * tL / dx
                b[rT] -= (acid_corr_R - acid_corr_L)
            else:
                # Non-ACID: consistent flux with upwind Y — H evaluated with same Y_up as rfR/rfL
                if mixing_type == 'mass':
                    H_R_consistent = _acid_rh_Y(float(p_k[iR]), float(T_k[iR]), u_up_R, Y_upR)
                    H_L_consistent = _acid_rh_Y(float(p_k[iL]), float(T_k[iL]), u_up_L, Y_upL)
                else:
                    H_R_consistent = _acid_rh(float(p_k[iR]), float(T_k[iR]), u_up_R, Y_upR)
                    H_L_consistent = _acid_rh(float(p_k[iL]), float(T_k[iL]), u_up_L, Y_upL)
                # correction: H_consistent - rfR·h_up_R accounts for species-mixture h difference
                acid_corr_R = (H_R_consistent - rfR * h_up_R) * tR / dx
                acid_corr_L = (H_L_consistent - rfL * h_up_L) * tL / dx
                b[rT] -= (acid_corr_R - acid_corr_L)
            # Spatial ψ Jacobian: ∂(H̃_f·θ_f)/∂ψ_i
            # picard_advection=True: skip (deferred — temporal coupling retained)
            if not picard_advection:
                if mixing_type != 'mass':
                    h1R_e = eos1.h(float(p_k[iR]), float(T_k[iR])) + 0.5*float(u_k[iR])**2
                    h2R_e = eos2.h(float(p_k[iR]), float(T_k[iR])) + 0.5*float(u_k[iR])**2
                    dH_R_full = r1R * h1R_e - r2R * h2R_e
                    h1L_e = eos1.h(float(p_k[iL]), float(T_k[iL])) + 0.5*float(u_k[iL])**2
                    h2L_e = eos2.h(float(p_k[iL]), float(T_k[iL])) + 0.5*float(u_k[iL])**2
                    dH_L_full = r1L * h1L_e - r2L * h2L_e
                    if use_acid:
                        dH_R = dH_R_full
                        dH_L = dH_L_full
                    else:
                        # Non-ACID: ∂H_f/∂Y_i nonzero only when cell i is upwind
                        dH_R = dH_R_full if (tR >= 0) else 0.0
                        dH_L = 0.0 if (tL >= 0) else dH_L_full
                else:
                    dH_R = 0.0
                    dH_L = 0.0
                A.add(rT, cv, dH_R * tR / dx)
                A.add(rT, cv, -(dH_L * tL / dx))
        else:
            # --- T-mode (default): From assemble_newton_3N T-mode, extended with φ column ---
            if mixing_type == 'mass':
                cp_i    = _acid_cp_Y(float(p_k[i]), float(T_k[i]), psi_i)
                bm_i    = _acid_bm_Y(float(p_k[i]), float(T_k[i]), psi_i)
            else:
                cp_i    = _acid_cp(float(p_k[i]), float(T_k[i]), psi_i)
                bm_i    = _acid_bm(float(p_k[i]), float(T_k[i]), psi_i)

            drhdt = rho_i * cp_i + h_i * phi_T_i
            drhdp = rho_i * bm_i + h_i * zeta_i
            drhdu = rho_i * u_i

            A.add(rT, cT, drhdt / dt)
            A.add(rT, cu, drhdu / dt)
            A.add(rT, cp, (drhdp - 1.0) / dt)
            # d(ρh)/dψ temporal coupling
            A.add(rT, cv, drh_dphi_i / dt)
            b[rT]     += (rho_old[i] * h_old[i] / dt
                          - p_old[i] / dt
                          + (drhdt * T_i + drhdp * p_k[i] + drhdu * u_i
                             + drh_dphi_i * psi_i
                             - rho_i * h_i) / dt)

            # Convective for T-mode: ACID or consistent face enthalpy
            if use_acid:
                Y_face_R = psi_i
                Y_face_L = psi_i
            else:
                Y_face_R = Y_upR
                Y_face_L = Y_upL
            if mixing_type == 'mass':
                H_R_acid    = _acid_rh_Y(float(p_k[iR]), float(T_k[iR]), float(u_k[iR]), Y_face_R)
                H_L_acid    = _acid_rh_Y(float(p_k[iL]), float(T_k[iL]), float(u_k[iL]), Y_face_L)
                cp_i_acid   = _acid_cp_Y(float(p_k[i]), float(T_k[i]), psi_i)
            else:
                H_R_acid    = _acid_rh(float(p_k[iR]), float(T_k[iR]), float(u_k[iR]), Y_face_R)
                H_L_acid    = _acid_rh(float(p_k[iL]), float(T_k[iL]), float(u_k[iL]), Y_face_L)
                cp_i_acid   = _acid_cp(float(p_k[i]), float(T_k[i]), psi_i)
            b[rT] -= (H_R_acid * tR - H_L_acid * tL) / dx
            if mR >= 0.0: A.add(rT, cT, mR * cp_i_acid / dx)
            else:         A.add(rT, cT_R, mR * cp_i_acid / dx)
            if mL >= 0.0: A.add(rT, cT_L, -(mL * cp_i_acid / dx))
            else:         A.add(rT, cT, -(mL * cp_i_acid / dx))
            T_up_R = T_k[i]  if mR >= 0.0 else T_k[iR]
            T_up_L = T_k[iL] if mL >= 0.0 else T_k[i]
            b[rT] += (mR * cp_i_acid * T_up_R - mL * cp_i_acid * T_up_L) / dx
            # Spatial ψ Jacobian: ∂(H̃_f·θ_f)/∂ψ_i
            # picard_advection=True: skip (deferred — temporal coupling retained)
            if not picard_advection:
                if mixing_type != 'mass':
                    h1R_e = eos1.h(float(p_k[iR]), float(T_k[iR])) + 0.5*float(u_k[iR])**2
                    h2R_e = eos2.h(float(p_k[iR]), float(T_k[iR])) + 0.5*float(u_k[iR])**2
                    dH_R_full = r1R * h1R_e - r2R * h2R_e
                    h1L_e = eos1.h(float(p_k[iL]), float(T_k[iL])) + 0.5*float(u_k[iL])**2
                    h2L_e = eos2.h(float(p_k[iL]), float(T_k[iL])) + 0.5*float(u_k[iL])**2
                    dH_L_full = r1L * h1L_e - r2L * h2L_e
                    if use_acid:
                        dH_R = dH_R_full
                        dH_L = dH_L_full
                    else:
                        # Non-ACID: ∂H_f/∂Y_i nonzero only when cell i is upwind
                        dH_R = dH_R_full if (tR >= 0) else 0.0
                        dH_L = 0.0 if (tL >= 0) else dH_L_full
                else:
                    dH_R = 0.0
                    dH_L = 0.0
                A.add(rT, cv, dH_R * tR / dx)
                A.add(rT, cv, -(dH_L * tL / dx))

        # -----------------------------------------------------------
        # VOF / SPECIES TRANSPORT (block 3)
        # -----------------------------------------------------------
        # Temporal: ψ^{n+1}/dt
        A.add(rv, cv, 1.0 / dt)
        b[rv]     += phi_old[i] / dt

        if psi_face is not None and jac_D is not None:
            # --- Newton-CICSAM: exact Jacobian for ψ̃_f ---
            psi_fR = float(psi_face[f_R])
            psi_fL = float(psi_face[f_L])

            # (u,p) columns from Denner Eq. (32):
            # div(psi_f theta) - (psi_i + K_i) div(theta)
            coeff_R = (psi_fR - (psi_i + K_i)) / dx
            coeff_L = -(psi_fL - (psi_i + K_i)) / dx
            A.add(rv, cu, coeff_R * 0.5)
            A.add(rv, cu_R, coeff_R * 0.5)
            A.add(rv, cp, coeff_R * dR / dx)
            A.add(rv, cp_R, -(coeff_R * dR / dx))
            A.add(rv, cu_L, coeff_L * 0.5)
            A.add(rv, cu, coeff_L * 0.5)
            A.add(rv, cp_L, coeff_L * dL / dx)
            A.add(rv, cp, -(coeff_L * dL / dx))

            # ψ columns: θ_f^k · Σ J_s · ψ_s^{n+1} (advection Newton Jacobian)
            A.add(rv, _ci(3, int(idx_D[f_R]), N), float(jac_D[f_R]) * tR / dx)
            A.add(rv, _ci(3, int(idx_A[f_R]), N), float(jac_A[f_R]) * tR / dx)
            A.add(rv, _ci(3, int(idx_UU[f_R]), N), float(jac_UU[f_R]) * tR / dx)
            A.add(rv, _ci(3, int(idx_D[f_L]), N), -(float(jac_D[f_L]) * tL / dx))
            A.add(rv, _ci(3, int(idx_A[f_L]), N), -(float(jac_A[f_L]) * tL / dx))
            A.add(rv, _ci(3, int(idx_UU[f_L]), N), -(float(jac_UU[f_L]) * tL / dx))
            # Source: -(ψ_i + K_i) · div(θ). K_i is frozen in this Newton
            # block, consistent with Denner's deferred material-property
            # treatment in the VOF equation.
            A.add(rv, cv, -((tR - tL) / dx))
        else:
            # --- Picard fallback: deferred CICSAM beta ---
            beta_R = float(beta_k[f_R])
            beta_L = float(beta_k[f_L])
            if tR >= 0:
                psi_face_R = (1.0 - beta_R) * psi_i + beta_R * float(phi_k[iR])
            else:
                psi_face_R = (1.0 - beta_R) * float(phi_k[iR]) + beta_R * psi_i
            if tL >= 0:
                psi_face_L = (1.0 - beta_L) * float(phi_k[iL]) + beta_L * psi_i
            else:
                psi_face_L = (1.0 - beta_L) * psi_i + beta_L * float(phi_k[iL])
            coeff_R = (psi_face_R - (psi_i + K_i)) / dx
            coeff_L = -(psi_face_L - (psi_i + K_i)) / dx
            A.add(rv, cu, coeff_R * 0.5)
            A.add(rv, cu_R, coeff_R * 0.5)
            A.add(rv, cp, coeff_R * dR / dx)
            A.add(rv, cp_R, -(coeff_R * dR / dx))
            A.add(rv, cu_L, coeff_L * 0.5)
            A.add(rv, cu, coeff_L * 0.5)
            A.add(rv, cp_L, coeff_L * dL / dx)
            A.add(rv, cp, -(coeff_L * dL / dx))

    # --- Optional: equation scaling for continuity rows ---
    # Scale continuity rows so that zeta (dρ/dp) and alpha (dρ/dφ) coefficients
    # are balanced, improving conditioning when alpha/zeta >> 1.
    if scale_continuity and alpha_k is not None and zeta_k is not None:
        A_lil = A.tolil()
        for ii in range(N):
            row_i = _ci(0, ii, N)
            alpha_i_abs = abs(float(alpha_k[ii])) + 1e-300
            zeta_i_abs  = abs(float(zeta_k[ii]))  + 1e-300
            scale_factor = zeta_i_abs / alpha_i_abs
            A_lil[row_i, :] = A_lil[row_i, :] * scale_factor
            b[row_i]        *= scale_factor
        A = A_lil.tocsr()
    else:
        A = A.tocsr()

    return A, b


def assemble_newton_Ns(
    N, dx, dt, N_s,
    rho_old, u_old, h_old, p_old, phi_old_arr,  # phi_old_arr: (N_s-1, N)
    rho_k, u_k, h_k, p_k, T_k, phi_k_arr,      # phi_k_arr: (N_s-1, N)
    zeta_k, phi_T_k,       # dρ/dp, dρ/dT (N,)
    alpha_k_arr,            # list of N_s-1: ∂ρ/∂φₖ (N,)
    d_rho_h_dphi_k_arr,     # list of N_s-1: ∂(ρh)/∂φₖ (N,)
    rho_face_acid, d_hat, theta_k,
    beta_k_arr,             # list of N_s-1: CICSAM beta per species (N+1,)
    phases,                 # list of N_s EOS objects
    bc_l, bc_r,
    mixing_type='volume',
    use_compress=False,
    C_k_arr=None,           # list of N_s-1: Zalesak limiter (N+1,)
    n_hat_k_arr=None,       # list of N_s-1: interface normal (N+1,)
    u_face_vof=None,
):
    """
    Fully coupled Newton-linearised (p, u, T, φ₀, ..., φ_{N_s-2}) system.
    Block ordering: [p_0..p_{N-1}, u_0..u_{N-1}, T_0..T_{N-1},
                     phi0_0..phi0_{N-1}, ..., phi{N_s-2}_0..phi{N_s-2}_{N-1}]
    Matrix size: (2+N_s)*N x (2+N_s)*N
    Returns A (csr), b (ndarray).
    """
    size = (2 + N_s) * N
    A = sp.lil_matrix((size, size), dtype=float)
    b = np.zeros(size)

    is_per_l = (bc_l == 'periodic')
    is_per_r = (bc_r == 'periodic')

    def face_lr(f):
        iL = f - 1
        iR = f
        iL = (N - 1 if is_per_l else 0) if iL < 0 else iL
        iR = (0 if is_per_r else N - 1) if iR >= N else iR
        return iL, iR

    # Build EOS objects
    eos_list = [create_eos(ph) for ph in phases]

    # ACID helpers for volume fraction mixing
    def _acid_rho_Ns(p_val, T_val, phi_ref):
        """phi_ref: length N_s, cell i's fractions (sum=1)."""
        return sum(phi_ref[k] * eos_list[k].rho(p_val, T_val) for k in range(N_s))

    def _acid_rh_Ns(p_val, T_val, u_val, phi_ref):
        """ACID rhoH_total."""
        total = 0.0
        ke = 0.5 * u_val * u_val
        for k in range(N_s):
            r = eos_list[k].rho(p_val, T_val)
            h = eos_list[k].h(p_val, T_val)
            total += phi_ref[k] * r * (h + ke)
        return total

    def _acid_cp_Ns(p_val, T_val, phi_ref):
        """Density-weighted mixture cp."""
        num = sum(phi_ref[k] * eos_list[k].rho(p_val, T_val) * eos_list[k].cp(p_val, T_val)
                  for k in range(N_s))
        den = sum(phi_ref[k] * eos_list[k].rho(p_val, T_val) for k in range(N_s)) + 1e-300
        return num / den

    def _acid_bm_Ns(p_val, T_val, phi_ref):
        """Density-weighted mixture dh/dp."""
        num = sum(phi_ref[k] * eos_list[k].rho(p_val, T_val) * eos_list[k].dh_dp(p_val, T_val)
                  for k in range(N_s))
        den = sum(phi_ref[k] * eos_list[k].rho(p_val, T_val) for k in range(N_s)) + 1e-300
        return num / den

    # ACID helpers for mass fraction mixing
    def _acid_rho_Ns_mass(p_val, T_val, Y_ref):
        inv_rho = sum(Y_ref[k] / (eos_list[k].rho(p_val, T_val) + 1e-300) for k in range(N_s))
        return 1.0 / (inv_rho + 1e-300)

    def _acid_rh_Ns_mass(p_val, T_val, u_val, Y_ref):
        rho_star = _acid_rho_Ns_mass(p_val, T_val, Y_ref)
        h_static = sum(Y_ref[k] * eos_list[k].h(p_val, T_val) for k in range(N_s))
        return rho_star * (h_static + 0.5 * u_val * u_val)

    def _acid_cp_Ns_mass(p_val, T_val, Y_ref):
        return sum(Y_ref[k] * eos_list[k].cp(p_val, T_val) for k in range(N_s))

    def _acid_bm_Ns_mass(p_val, T_val, Y_ref):
        return sum(Y_ref[k] * eos_list[k].dh_dp(p_val, T_val) for k in range(N_s))

    # Select helpers based on mixing_type
    if mixing_type == 'mass':
        _acid_rho_f = _acid_rho_Ns_mass
        _acid_rh_f  = _acid_rh_Ns_mass
        _acid_cp_f  = _acid_cp_Ns_mass
        _acid_bm_f  = _acid_bm_Ns_mass
    else:
        _acid_rho_f = _acid_rho_Ns
        _acid_rh_f  = _acid_rh_Ns
        _acid_cp_f  = _acid_cp_Ns
        _acid_bm_f  = _acid_bm_Ns

    for i in range(N):
        rp     = _ci(0, i, N)
        ru     = _ci(1, i, N)
        rT_row = _ci(2, i, N)

        cp = _ci(0, i, N)
        cu = _ci(1, i, N)
        cT = _ci(2, i, N)

        f_R = i + 1
        f_L = i
        iL, _ = face_lr(f_L)
        _, iR  = face_lr(f_R)

        cp_L = _ci(0, iL, N);  cu_L = _ci(1, iL, N);  cT_L = _ci(2, iL, N)
        cp_R = _ci(0, iR, N);  cu_R = _ci(1, iR, N);  cT_R = _ci(2, iR, N)

        rho_i   = rho_k[i]
        zeta_i  = zeta_k[i]
        phi_T_i = float(phi_T_k[i]) if phi_T_k is not None else 0.0
        u_i     = u_k[i]
        h_i     = h_k[i]
        T_i     = T_k[i]

        tR = theta_k[f_R]
        tL = theta_k[f_L]
        dR  = d_hat[f_R]
        dL  = d_hat[f_L]

        # Build full phi vector for cell i
        phi_i_full = np.zeros(N_s)
        for k in range(N_s - 1):
            phi_i_full[k] = float(phi_k_arr[k][i])
        phi_i_full[N_s - 1] = 1.0 - sum(phi_i_full[:N_s - 1])
        phi_i_full = np.clip(phi_i_full, 0.0, 1.0)

        # ACID face densities
        phi_iR_full = np.zeros(N_s)
        for k in range(N_s - 1):
            phi_iR_full[k] = float(phi_k_arr[k][iR])
        phi_iR_full[N_s - 1] = 1.0 - sum(phi_iR_full[:N_s - 1])
        phi_iR_full = np.clip(phi_iR_full, 0.0, 1.0)

        phi_iL_full = np.zeros(N_s)
        for k in range(N_s - 1):
            phi_iL_full[k] = float(phi_k_arr[k][iL])
        phi_iL_full[N_s - 1] = 1.0 - sum(phi_iL_full[:N_s - 1])
        phi_iL_full = np.clip(phi_iL_full, 0.0, 1.0)

        rfR = _acid_rho_f(float(p_k[iR]), float(T_k[iR]), phi_i_full)
        rfL = _acid_rho_f(float(p_k[iL]), float(T_k[iL]), phi_i_full)

        mR = rfR * tR
        mL = rfL * tL

        # -----------------------------------------------------------
        # CONTINUITY (block 0)
        # -----------------------------------------------------------
        A.add(rp, cp, zeta_i / dt)
        b[rp]     += zeta_i * p_old[i] / dt
        # phi column coupling
        for k in range(N_s - 1):
            cv_k = _ci(3 + k, i, N)
            alpha_i_k = float(alpha_k_arr[k][i])
            A.add(rp, cv_k, alpha_i_k / dt)
            b[rp]       += alpha_i_k * float(phi_old_arr[k][i]) / dt
        # MWI right face
        A.add(rp, cu, rfR / (2.0 * dx))
        A.add(rp, cu_R, rfR / (2.0 * dx))
        A.add(rp, cp, rfR * dR / (dx * dx))
        A.add(rp, cp_R, -(rfR * dR / (dx * dx)))
        # MWI left face
        A.add(rp, cu_L, -(rfL / (2.0 * dx)))
        A.add(rp, cu, -(rfL / (2.0 * dx)))
        A.add(rp, cp, rfL * dL / (dx * dx))
        A.add(rp, cp_L, -(rfL * dL / (dx * dx)))

        # -----------------------------------------------------------
        # MOMENTUM (block 1)
        # -----------------------------------------------------------
        A.add(ru, cu, rho_i / dt)
        A.add(ru, cp, zeta_i * u_i / dt)
        b[ru]     += rho_old[i] * u_old[i] / dt + zeta_i * u_i * p_k[i] / dt
        # phi column coupling
        for k in range(N_s - 1):
            cv_k = _ci(3 + k, i, N)
            alpha_i_k = float(alpha_k_arr[k][i])
            A.add(ru, cv_k, alpha_i_k * u_i / dt)
            b[ru]       += alpha_i_k * u_i * float(phi_k_arr[k][i]) / dt
        # Convective right face
        if mR >= 0.0:
            A.add(ru, cu, mR / dx)
        else:
            A.add(ru, cu_R, mR / dx)
        A.add(ru, cp, rfR * u_i * dR / (dx * dx))
        A.add(ru, cp_R, -(rfR * u_i * dR / (dx * dx)))
        # Convective left face
        if mL >= 0.0:
            A.add(ru, cu_L, -(mL / dx))
        else:
            A.add(ru, cu, -(mL / dx))
        A.add(ru, cp_L, -(rfL * u_i * dL / (dx * dx)))
        A.add(ru, cp, rfL * u_i * dL / (dx * dx))
        # Pressure gradient
        A.add(ru, cp_R, 1.0 / (2.0 * dx))
        A.add(ru, cp_L, -(1.0 / (2.0 * dx)))

        # -----------------------------------------------------------
        # ENERGY (block 2) — T-mode with phi coupling
        # -----------------------------------------------------------
        cp_i = _acid_cp_f(float(p_k[i]), float(T_k[i]), phi_i_full)
        bm_i = _acid_bm_f(float(p_k[i]), float(T_k[i]), phi_i_full)

        drhdt = rho_i * cp_i + h_i * phi_T_i
        drhdp = rho_i * bm_i + h_i * zeta_i
        drhdu = rho_i * u_i

        A.add(rT_row, cT, drhdt / dt)
        A.add(rT_row, cu, drhdu / dt)
        A.add(rT_row, cp, (drhdp - 1.0) / dt)
        # phi column coupling
        b[rT_row] += (rho_old[i] * h_old[i] / dt
                      - p_old[i] / dt
                      + (drhdt * T_i + drhdp * p_k[i] + drhdu * u_i
                         - rho_i * h_i) / dt)
        for k in range(N_s - 1):
            cv_k = _ci(3 + k, i, N)
            drh_dphi_i_k = float(d_rho_h_dphi_k_arr[k][i])
            A.add(rT_row, cv_k, drh_dphi_i_k / dt)
            b[rT_row]       += drh_dphi_i_k * float(phi_k_arr[k][i]) / dt

        # Convective: ACID face enthalpy
        H_R_acid  = _acid_rh_f(float(p_k[iR]), float(T_k[iR]), float(u_k[iR]), phi_i_full)
        H_L_acid  = _acid_rh_f(float(p_k[iL]), float(T_k[iL]), float(u_k[iL]), phi_i_full)
        b[rT_row] -= (H_R_acid * tR - H_L_acid * tL) / dx
        if mR >= 0.0: A.add(rT_row, cT, mR * cp_i / dx)
        else:         A.add(rT_row, cT_R, mR * cp_i / dx)
        if mL >= 0.0: A.add(rT_row, cT_L, -(mL * cp_i / dx))
        else:         A.add(rT_row, cT, -(mL * cp_i / dx))
        T_up_R = T_k[i]  if mR >= 0.0 else T_k[iR]
        T_up_L = T_k[iL] if mL >= 0.0 else T_k[i]
        b[rT_row] += (mR * cp_i * T_up_R - mL * cp_i * T_up_L) / dx

        # -----------------------------------------------------------
        # SPECIES TRANSPORT (blocks 3..2+N_s)
        # -----------------------------------------------------------
        for k in range(N_s - 1):
            rv  = _ci(3 + k, i, N)
            cv  = _ci(3 + k, i, N)
            cv_L = _ci(3 + k, iL, N)
            cv_R = _ci(3 + k, iR, N)

            beta_R = float(beta_k_arr[k][f_R])
            beta_L = float(beta_k_arr[k][f_L])

            # Temporal
            A.add(rv, cv, 1.0 / dt)
            b[rv]     += float(phi_old_arr[k][i]) / dt

            # Implicit CICSAM advection
            # Right face
            if tR >= 0:
                A.add(rv, cv, (1.0 - beta_R) * tR / dx)
                A.add(rv, cv_R, beta_R * tR / dx)
            else:
                A.add(rv, cv_R, (1.0 - beta_R) * tR / dx)
                A.add(rv, cv, beta_R * tR / dx)
            # Left face
            if tL >= 0:
                A.add(rv, cv_L, -((1.0 - beta_L) * tL / dx))
                A.add(rv, cv, -(beta_L * tL / dx))
            else:
                A.add(rv, cv, -((1.0 - beta_L) * tL / dx))
                A.add(rv, cv_L, -(beta_L * tL / dx))
            # Source: -phi * div(theta)
            div_theta = (tR - tL) / dx
            A.add(rv, cv, -(div_theta))

            # Compression (linearized phi(1-phi) around phi_k)
            if (use_compress and C_k_arr is not None and n_hat_k_arr is not None
                    and u_face_vof is not None):
                C_k    = C_k_arr[k]
                n_hat  = n_hat_k_arr[k]
                for face, sign_mult in [(f_R, -1.0), (f_L, 1.0)]:
                    ck  = float(C_k[face])
                    nh  = float(n_hat[face])
                    u_f = float(u_face_vof[face])
                    if abs(ck * nh) < 1e-15:
                        continue
                    coeff = sign_mult * ck * abs(u_f) * nh / dx
                    if face == f_R:
                        j_donor = i   if nh * abs(u_f) >= 0 else iR
                    else:
                        j_donor = iL  if nh * abs(u_f) >= 0 else i
                    phi_d = float(phi_k_arr[k][j_donor])
                    cv_d  = _ci(3 + k, j_donor, N)
                    A.add(rv, cv_d, coeff * (1.0 - 2.0 * phi_d))
                    b[rv]       -= coeff * phi_d * phi_d

    return A.tocsr(), b


def solve_schur_4N(A_4N, b_4N, N, p_ref=1.0e5, u_ref=1.0, h_ref=3.0e5):
    """Solve 4N system via Schur complement block elimination of ψ.

    Partitions:
        [A_ff(3N×3N)  A_fψ(3N×N)] [x_f ]   [b_f ]
        [A_ψf(N×3N)  A_ψψ(N×N) ] [x_ψ ] = [b_ψ ]

    1. Factor A_ψψ (N×N, well-conditioned)
    2. Schur complement: S = A_ff − A_fψ · A_ψψ⁻¹ · A_ψf  (3N×3N)
    3. Solve S · x_f = b_f − A_fψ · A_ψψ⁻¹ · b_ψ
    4. Back-substitute: x_ψ = A_ψψ⁻¹ · (b_ψ − A_ψf · x_f)
    """
    import scipy.sparse.linalg as spla

    n3 = 3 * N
    n4 = 4 * N

    # Extract blocks
    A_ff   = A_4N[:n3, :n3]     # 3N×3N
    A_fpsi = A_4N[:n3, n3:n4]   # 3N×N
    A_psif = A_4N[n3:n4, :n3]   # N×3N
    A_psipsi = A_4N[n3:n4, n3:n4]  # N×N
    b_f   = b_4N[:n3].copy()
    b_psi = b_4N[n3:n4].copy()

    # Step 1: Factor A_ψψ
    try:
        psi_lu = spla.splu(A_psipsi.tocsc())
    except Exception:
        # If factorization fails, fall back to full 4N direct solve
        return solve_linear_system(A_4N, b_4N, p_ref=p_ref, u_ref=u_ref,
                                   h_ref=h_ref, phi_ref=1.0, n_blocks=4)

    # Step 2: Compute A_ψψ⁻¹ · A_ψf  (N×3N) and A_ψψ⁻¹ · b_ψ (N,)
    # Solve column by column: A_ψψ · X = A_ψf
    A_psif_dense = A_psif.toarray()  # N×3N
    inv_psif = np.zeros((N, n3))
    for j in range(n3):
        col = A_psif_dense[:, j]
        if np.any(col != 0):
            inv_psif[:, j] = psi_lu.solve(col)
    inv_b_psi = psi_lu.solve(b_psi)

    # Step 3: Schur complement S = A_ff - A_fψ · inv_psif
    A_fpsi_dense = A_fpsi.toarray()  # 3N×N
    correction = A_fpsi_dense @ inv_psif  # 3N×3N
    S = A_ff.toarray() - correction
    S_sparse = sp.csr_matrix(S)

    b_s = b_f - A_fpsi_dense @ inv_b_psi

    # Step 4: Solve S · x_f = b_s (3N system — reuse existing solver)
    x_f = solve_linear_system(S_sparse, b_s, p_ref=p_ref, u_ref=u_ref,
                              h_ref=h_ref, n_blocks=3)

    # Step 5: Back-substitute ψ = A_ψψ⁻¹ · (b_ψ - A_ψf · x_f)
    x_psi = psi_lu.solve(b_psi - A_psif.dot(x_f))

    return np.concatenate([x_f, x_psi])


def solve_block_schur_4N(A, b, N, p_ref=1e5, u_ref=1.0, h_ref=3e5):
    """Block Schur preconditioned solver for 4N coupled system.

    Partitions 4N system into flow (3N: p,u,T/h) and species (N: Y/ψ) blocks.
    Uses lower-triangular block factorization as preconditioner for BiCGSTAB.
    Falls back to direct solve on failure.

    Block layout (same as assemble_newton_4N):
        [J_FF (3N×3N)  J_FY (3N×N)] [x_F]   [b_F]
        [J_YF (N×3N)   J_YY (N×N) ] [x_Y] = [b_Y]
    """
    import scipy.sparse.linalg as spla

    n3, n4 = 3 * N, 4 * N
    A_csc = A.tocsc()

    # Extract blocks
    J_FF = A_csc[:n3, :n3]     # 3N x 3N (flow)
    J_FY = A_csc[:n3, n3:n4]   # 3N x N  (flow <- species)
    J_YF = A_csc[n3:n4, :n3]   # N x 3N  (species <- flow)
    J_YY = A_csc[n3:n4, n3:n4] # N x N   (species)

    try:
        YY_lu = spla.splu(J_YY)
        FF_lu = spla.splu(J_FF)
    except Exception:
        # Singular block — fall back to full direct solve
        try:
            return spla.spsolve(A_csc, b)
        except Exception:
            return np.zeros_like(b)

    def precond_matvec(r):
        r_F = r[:n3]
        r_Y = r[n3:n4]
        # 1. Solve species block
        z_Y = YY_lu.solve(r_Y)
        # 2. Modify flow RHS with species contribution
        r_F_mod = r_F - J_FY.dot(z_Y)
        # 3. Solve flow block
        z_F = FF_lu.solve(r_F_mod)
        return np.concatenate([z_F, z_Y])

    M = spla.LinearOperator((n4, n4), matvec=precond_matvec)

    # Try BiCGSTAB with block preconditioner
    x, info = spla.bicgstab(A_csc, b, M=M, rtol=1e-8, maxiter=500)
    if info != 0 or not np.all(np.isfinite(x)):
        # BiCGSTAB failed — try GMRES
        x, info = spla.gmres(A_csc, b, M=M, rtol=1e-8, maxiter=500)
    if info != 0 or not np.all(np.isfinite(x)):
        # All iterative solvers failed — direct solve
        try:
            x = spla.spsolve(A_csc, b)
            if not np.all(np.isfinite(x)):
                x = np.zeros_like(b)
        except Exception:
            x = np.zeros_like(b)
    return x


def solve_linear_system(A, b, p_ref=1.0e5, u_ref=1.0, h_ref=3.0e5, phi_ref=None,
                        n_blocks=None):
    """Solve A @ x = b with GMRES + ILU preconditioner (most robust default).

    Column + row equilibration is applied for scaling.
    Primary solver: GMRES with ILU(0) preconditioner.
    Fallback 1: BiCGSTAB with Block-Jacobi preconditioner (Denner 2018 §6).
    Fallback 2: direct sparse solver (spsolve).
    Fallback 3: LSMR (robust for ill-conditioned / near-singular).
    """
    import os
    import scipy.sparse.linalg as spla

    size = len(b)

    # --- Column scaling ---
    col_scale = np.ones(size)
    if n_blocks is not None:
        NB = size // n_blocks
        col_scale[:NB]       = max(abs(p_ref), 1.0)
        col_scale[NB:2*NB]   = max(abs(u_ref), 1e-6)
        col_scale[2*NB:3*NB] = max(abs(h_ref), 1.0)
        for kb in range(3, n_blocks):
            col_scale[kb*NB:(kb+1)*NB] = max(abs(phi_ref) if phi_ref is not None else 1.0, 1e-6)
    elif phi_ref is not None:
        N4 = size // 4
        col_scale[:N4]        = max(abs(p_ref), 1.0)
        col_scale[N4:2*N4]    = max(abs(u_ref), 1e-6)
        col_scale[2*N4:3*N4]  = max(abs(h_ref), 1.0)
        col_scale[3*N4:]      = max(abs(phi_ref), 1e-10)
    else:
        N3 = size // 3
        col_scale[:N3]      = max(abs(p_ref), 1.0)
        col_scale[N3:2*N3]  = max(abs(u_ref), 1e-6)
        col_scale[2*N3:]    = max(abs(h_ref), 1.0)
    A_cs = A.dot(sp.diags(col_scale, format='csr'))

    # --- Row scaling ---
    abs_A = np.abs(A_cs)
    row_max_r = abs_A.max(axis=1)
    if sp.issparse(row_max_r):
        row_max = np.asarray(row_max_r.toarray()).ravel()
    else:
        row_max = np.asarray(row_max_r).ravel()
    row_max = np.maximum(row_max, 1e-300)
    D_inv = sp.diags(1.0 / row_max, format='csr')
    As = D_inv.dot(A_cs)
    bs = D_inv.dot(b)

    x_hat = None
    solver_pref = os.environ.get('DENNER_LINEAR_SOLVER', 'auto').lower()

    # Small/medium 1D validation matrices are narrow-band sparse systems.  For
    # these, SuperLU's direct factorization is usually faster than building an
    # ILU preconditioner and running GMRES, and it is deterministic.  Keep the
    # iterative stack available for larger or explicitly requested runs.
    if solver_pref in ('direct', 'spsolve') or (
            solver_pref == 'auto' and size <= 1500):
        try:
            x_hat = spla.spsolve(As.tocsc(), bs)
            if not np.all(np.isfinite(x_hat)):
                x_hat = None
        except Exception:
            x_hat = None

    # --- GMRES + ILU(0) preconditioner (most robust default) ---
    if x_hat is None and solver_pref not in ('direct', 'spsolve'):
        try:
            ilu = spla.spilu(As.tocsc(), drop_tol=1e-4, fill_factor=10)
            M = spla.LinearOperator(As.shape, ilu.solve)
            x_hat, info = spla.gmres(As, bs, M=M, rtol=1e-6, maxiter=200, restart=50)
            if info != 0 or not np.all(np.isfinite(x_hat)):
                x_hat = None
        except Exception:
            pass

    # --- Fallback 1: BiCGSTAB + Block-Jacobi preconditioner (Denner 2018 §6) ---
    # Block-Jacobi: invert each diagonal block (N×N) independently.
    # For 3N system (p,u,T): M^{-1} = diag(App^{-1}, Auu^{-1}, ATT^{-1})
    if x_hat is None and solver_pref not in ('direct', 'spsolve'):
        try:
            N_blk = n_blocks if n_blocks is not None else (4 if phi_ref is not None else 3)
            NB = size // N_blk
            block_solvers = []
            for k in range(N_blk):
                diag_block = As[k*NB:(k+1)*NB, k*NB:(k+1)*NB].tocsc()
                block_solvers.append(spla.splu(diag_block))

            def block_jacobi_solve(r):
                x_out = np.empty_like(r)
                for k in range(N_blk):
                    x_out[k*NB:(k+1)*NB] = block_solvers[k].solve(r[k*NB:(k+1)*NB])
                return x_out

            M_bj = spla.LinearOperator(As.shape, block_jacobi_solve)
            x_hat, info = spla.bicgstab(As, bs, M=M_bj, rtol=1e-6, maxiter=200)
            if info != 0 or not np.all(np.isfinite(x_hat)):
                x_hat = None
        except Exception:
            pass

    # --- Fallback 2: direct sparse solver ---
    if x_hat is None:
        try:
            x_hat = spla.spsolve(As.tocsc(), bs)
            if not np.all(np.isfinite(x_hat)):
                x_hat = None
        except Exception:
            pass

    # --- Fallback 3: LSMR (robust for ill-conditioned / near-singular) ---
    if x_hat is None:
        try:
            result = spla.lsmr(As, bs, atol=1e-8, btol=1e-8, maxiter=1000)
            x_hat = result[0]
            if not np.all(np.isfinite(x_hat)):
                x_hat = None
        except Exception:
            pass

    if x_hat is None:
        x_hat = np.zeros_like(bs)

    if sp.issparse(x_hat):
        x_hat = np.asarray(x_hat.todense()).ravel()
    else:
        x_hat = np.asarray(x_hat).ravel()

    return col_scale * x_hat


def residual_4N(x_4N, N, dx, dt,
                rho_old, u_old, h_old, p_old, phi_old,
                ph1, ph2, bc_l, bc_r,
                theta_old=None, u_bar_old=None, rho_star_old=None,
                mixing_type='volume', use_K=False, use_acid=True,
                acid_temporal=False, third_var='T', T_guess=None):
    """Compute conservative residual R(x) for the fully-coupled 4N system.

    x_4N = [p_0..p_{N-1}, u_0..u_{N-1}, q_0..q_{N-1}, ψ_0..ψ_{N-1}]
    where q is T for third_var='T' and specific total enthalpy h for
    third_var='h'.  h-mode keeps the nonlinear residual in the same
    variables as Denner's coupled pressure-velocity-enthalpy Newton system.

    Returns R (4N vector):
      R[0:N]     = mass:     (ρ_new − ρ_old)/dt + div(ρ̃·θ)
      R[N:2N]    = momentum: (ρu_new − ρu_old)/dt + div(ρ̃·θ·u) + ∂p/∂x
      R[2N:3N]   = energy:   (ρE_new − ρE_old)/dt + div((ρE+p)·θ)
      R[3N:4N]   = VOF:      (ψ_new − ψ_old)/dt + div(ψ·θ) + (ψ+K)·∇·u
    """
    from .eos.base import compute_mixture_props, compute_mixture_props_Y
    from .flux.mwi import acid_face_density, harmonic_face_density, mwi_face_coeff_denner
    from .boundary import apply_ghost, apply_ghost_velocity
    from .interface.cicsam import cicsam_face_beta

    p_k = x_4N[0:N]
    u_k = x_4N[N:2*N]
    q3_k = x_4N[2*N:3*N]
    phi_k = np.clip(x_4N[3*N:4*N], 0.0, 1.0)
    if third_var == 'h':
        T_ref = T_guess if T_guess is not None else np.full(N, 300.0)
        if mixing_type == 'mass':
            T_k = recover_T_from_h_Y(q3_k, u_k, p_k, phi_k, ph1, ph2,
                                     T_guess=T_ref)
        else:
            T_k = recover_T_from_h(q3_k, u_k, p_k, phi_k, ph1, ph2,
                                   T_guess=T_ref)
        T_k = np.maximum(T_k, 1.0e-9)
        h_k_unknown = q3_k
    else:
        T_k = q3_k
        h_k_unknown = None

    is_per_l = (bc_l == 'periodic')
    is_per_r = (bc_r == 'periodic')

    # Mixture properties at current state
    if mixing_type == 'mass':
        props = compute_mixture_props_Y(p_k, u_k, T_k, phi_k, ph1, ph2)
    else:
        props = compute_mixture_props(p_k, u_k, T_k, phi_k, ph1, ph2)
    rho_k = props['rho']
    if third_var == 'h':
        E_k = rho_k * h_k_unknown - p_k
    else:
        E_k = props['E_total']  # ρE per cell

    # ACID face density at current (p_k, T_k, ψ_k)
    rho_face = acid_face_density(rho_k, props['c_mix'], phi_k, bc_l, bc_r)

    # MWI face velocity
    rho_star = harmonic_face_density(rho_k, bc_l, bc_r)
    e_diag = rho_k / dt  # momentum diagonal ≈ ρ/dt
    from .flux.mwi import mwi_face_coeff_denner as _mwi
    d_hat = _mwi(e_diag, rho_star, dx, dt, bc_l, bc_r)

    ng = 2
    u_ext = apply_ghost_velocity(u_k, bc_l, bc_r, ng)
    p_ext = apply_ghost(p_k, bc_l, bc_r, ng)
    rho_ext = apply_ghost(rho_k, bc_l, bc_r, ng)
    gradp_ext = np.empty_like(p_ext)
    gradp_ext[1:-1] = (p_ext[2:] - p_ext[:-2]) / (2.0 * dx)
    gradp_ext[0] = gradp_ext[1]
    gradp_ext[-1] = gradp_ext[-2]

    theta = np.empty(N + 1)
    for f in range(N + 1):
        iL_g = ng + f - 1
        iR_g = ng + f
        ub = 0.5 * (u_ext[iL_g] + u_ext[iR_g])
        dp_dx = (p_ext[iR_g] - p_ext[iL_g]) / dx
        rhoL = max(float(rho_ext[iL_g]), 1e-300)
        rhoR = max(float(rho_ext[iR_g]), 1e-300)
        grad_corr = float(rho_star[f]) * (
            0.5 * gradp_ext[iL_g] / rhoL + 0.5 * gradp_ext[iR_g] / rhoR
        )
        theta[f] = ub - d_hat[f] * (dp_dx - grad_corr)
    # Transient correction
    if theta_old is not None and u_bar_old is not None and rho_star_old is not None:
        theta += d_hat * (rho_star_old / dt) * (theta_old - u_bar_old)

    # CICSAM face VOF (upwind for now — simple and robust)
    phi_ext = apply_ghost(phi_k, bc_l, bc_r, ng)
    psi_face = np.empty(N + 1)
    for f in range(N + 1):
        iL_g = ng + f - 1
        iR_g = ng + f
        if theta[f] >= 0:
            psi_face[f] = phi_ext[iL_g]
        else:
            psi_face[f] = phi_ext[iR_g]

    # EOS objects for ACID face enthalpy
    eos1 = create_eos(ph1)
    eos2 = create_eos(ph2)

    # K factor (compressibility correction for VOF)
    if use_K:
        c1_arr = np.array([eos1.c(float(p_k[i]), float(T_k[i])) for i in range(N)])
        c2_arr = np.array([eos2.c(float(p_k[i]), float(T_k[i])) for i in range(N)])
        r1_arr = np.array([eos1.rho(float(p_k[i]), float(T_k[i])) for i in range(N)])
        r2_arr = np.array([eos2.rho(float(p_k[i]), float(T_k[i])) for i in range(N)])
        rc1 = r1_arr * c1_arr**2
        rc2 = r2_arr * c2_arr**2
        rc_mix = phi_k * rc1 + (1 - phi_k) * rc2 + 1e-300
        K_arr = phi_k * (rc1 / rc_mix - 1.0)
    else:
        K_arr = np.zeros(N)

    # Old-time references for temporal terms
    rho_old_use = rho_old
    h_old_use = h_old

    # Compute fluxes and residual
    R = np.zeros(4 * N)

    # Pressure ghost for gradient
    T_ext = apply_ghost(T_k, bc_l, bc_r, ng)

    def face_lr(f):
        iL = f - 1
        iR = f
        iL = (N - 1 if is_per_l else 0) if iL < 0 else iL
        iR = (0 if is_per_r else N - 1) if iR >= N else iR
        return iL, iR

    for i in range(N):
        f_R = i + 1
        f_L = i
        iL, _ = face_lr(f_L)
        _, iR = face_lr(f_R)

        tR = theta[f_R]
        tL = theta[f_L]

        # Face density and enthalpy
        psi_i = float(phi_k[i])
        psi_iR = float(phi_k[iR])
        psi_iL = float(phi_k[iL])

        if use_acid:
            # ACID: ρ̃(p_neighbor, T_neighbor, ψ_i) — cell i's ψ for both faces
            psi_fR = psi_i
            psi_fL = psi_i
        else:
            # Non-ACID: upwind ψ at face — face density responds to ψ changes
            if tR >= 0:
                psi_fR = psi_i
            else:
                psi_fR = psi_iR
            if tL >= 0:
                psi_fL = psi_iL
            else:
                psi_fL = psi_i

        # Denner Eq. (40): advected face density uses the upwind state
        # (or TVD reconstruction).  The previous 4N residual evaluated the
        # right face from iR and the left face from iL regardless of flux
        # direction, which downwind-biased the acoustic fluxes.
        idx_rho_R = i if tR >= 0.0 else iR
        idx_rho_L = iL if tL >= 0.0 else i

        def _acid_rho_at(idx, psi_ref):
            if mixing_type == 'mass':
                r1 = eos1.rho(float(p_k[idx]), float(T_k[idx]))
                r2 = eos2.rho(float(p_k[idx]), float(T_k[idx]))
                return 1.0 / (psi_ref / (r1 + 1e-300)
                              + (1.0 - psi_ref) / (r2 + 1e-300) + 1e-300)
            return (psi_ref * eos1.rho(float(p_k[idx]), float(T_k[idx]))
                    + (1.0 - psi_ref) * eos2.rho(float(p_k[idx]), float(T_k[idx])))

        rfR = _acid_rho_at(idx_rho_R, psi_fR)
        rfL = _acid_rho_at(idx_rho_L, psi_fL)

        mR = rfR * tR
        mL = rfL * tL

        # Face enthalpy (total): H̃ = ρ̃·h̃_total
        if mixing_type == 'mass':
            h1R = eos1.h(float(p_k[idx_rho_R]), float(T_k[idx_rho_R]))
            h2R = eos2.h(float(p_k[idx_rho_R]), float(T_k[idx_rho_R]))
            HR = rfR * (psi_fR * h1R + (1 - psi_fR) * h2R + 0.5 * float(u_k[idx_rho_R])**2)
            h1L = eos1.h(float(p_k[idx_rho_L]), float(T_k[idx_rho_L]))
            h2L = eos2.h(float(p_k[idx_rho_L]), float(T_k[idx_rho_L]))
            HL = rfL * (psi_fL * h1L + (1 - psi_fL) * h2L + 0.5 * float(u_k[idx_rho_L])**2)
        else:
            r1R_v = eos1.rho(float(p_k[idx_rho_R]), float(T_k[idx_rho_R]))
            r2R_v = eos2.rho(float(p_k[idx_rho_R]), float(T_k[idx_rho_R]))
            h1R = eos1.h(float(p_k[idx_rho_R]), float(T_k[idx_rho_R])) + 0.5 * float(u_k[idx_rho_R])**2
            h2R = eos2.h(float(p_k[idx_rho_R]), float(T_k[idx_rho_R])) + 0.5 * float(u_k[idx_rho_R])**2
            HR = psi_fR * r1R_v * h1R + (1 - psi_fR) * r2R_v * h2R
            r1L_v = eos1.rho(float(p_k[idx_rho_L]), float(T_k[idx_rho_L]))
            r2L_v = eos2.rho(float(p_k[idx_rho_L]), float(T_k[idx_rho_L]))
            h1L = eos1.h(float(p_k[idx_rho_L]), float(T_k[idx_rho_L])) + 0.5 * float(u_k[idx_rho_L])**2
            h2L = eos2.h(float(p_k[idx_rho_L]), float(T_k[idx_rho_L])) + 0.5 * float(u_k[idx_rho_L])**2
            HL = psi_fL * r1L_v * h1L + (1 - psi_fL) * r2L_v * h2L

        # Upwind velocity for momentum convection
        u_up_R = float(u_k[i]) if mR >= 0 else float(u_k[iR])
        u_up_L = float(u_k[iL]) if mL >= 0 else float(u_k[i])

        # --- Mass residual ---
        R[i] = (rho_k[i] - rho_old_use[i]) / dt + (mR - mL) / dx

        # --- Momentum residual ---
        R[N + i] = ((rho_k[i] * u_k[i] - rho_old_use[i] * u_old[i]) / dt
                    + (mR * u_up_R - mL * u_up_L) / dx
                    + (p_k[iR] - p_k[iL]) / (2 * dx))

        # --- Energy residual ---
        E_old_i = rho_old_use[i] * h_old_use[i] - p_old[i]
        flux_E_R = HR * tR
        flux_E_L = HL * tL
        R[2*N + i] = ((E_k[i] - E_old_i) / dt
                      + (flux_E_R - flux_E_L) / dx)

        # --- VOF residual ---
        psi_fR = float(psi_face[f_R])
        psi_fL = float(psi_face[f_L])
        div_theta = (tR - tL) / dx
        # Denner 2018 Eq. (32):
        #   dψ/dt + div(ψ θ) - (ψ + K) div(θ) = 0
        # The previous 4N residual used +K div(θ), which is the opposite
        # compressibility coupling and breaks the acoustic interface response.
        R[3*N + i] = ((phi_k[i] - phi_old[i]) / dt
                      + (psi_fR * tR - psi_fL * tL) / dx
                      - (psi_i + K_arr[i]) * div_theta)

    return R


def solve_jfnk_4N(residual_fn, x0, N,
                   max_newton=50, newton_tol=1e-6,
                   max_gmres=100, gmres_tol=1e-3,
                   omega=1.0, verbose=False,
                   precond_fn=None):  # NEW: optional ILU preconditioner factory
    """JFNK solver for 4N fully-coupled system.

    Parameters
    ----------
    residual_fn : callable  x (4N,) → R (4N,)
    x0 : ndarray (4N,) initial guess [p, u, T, ψ]
    N  : int  number of cells

    Returns
    -------
    x_converged, info_dict
    """
    import scipy.sparse.linalg as spla

    x_k = x0.copy()
    size = 4 * N
    info = {'converged': False, 'outer_iters': 0, 'residuals': []}

    # Reference scales for convergence check
    p_ref = max(np.mean(np.abs(x_k[:N])), 1.0)
    u_ref = max(np.mean(np.abs(x_k[N:2*N])), 1.0)
    T_ref = max(np.mean(np.abs(x_k[2*N:3*N])), 1.0)

    for k in range(max_newton):
        R_k = residual_fn(x_k)
        r_norm = np.linalg.norm(R_k)
        info['residuals'].append(r_norm)

        # Convergence check: scaled residual
        scale = np.ones(size)
        scale[:N] = max(p_ref * 1e-7, 1e-10)  # mass: ρ scale / dt
        scale[N:2*N] = max(p_ref * u_ref * 1e-7, 1e-10)  # momentum
        scale[2*N:3*N] = max(p_ref * 1e-3, 1e-10)  # energy
        scale[3*N:] = 1.0  # VOF
        res_scaled = np.max(np.abs(R_k) / (np.abs(scale) + 1e-300))

        if verbose and (k < 5 or k % 10 == 0):
            print(f"    JFNK {k:3d}: |R|={r_norm:.3e}  scaled={res_scaled:.3e}")

        if r_norm < newton_tol * max(r_norm if k == 0 else info['residuals'][0], 1e-10):
            info['converged'] = True
            info['outer_iters'] = k + 1
            break
        if k == 0:
            r0_norm = r_norm

        # --- GMRES for J·δx = -R_k ---
        # J·v ≈ [R(x_k + ε·v) - R_k] / ε
        x_norm = np.linalg.norm(x_k)
        eps_base = np.sqrt(np.finfo(float).eps) * max(x_norm, 1.0)

        def jvp(v):
            eps = eps_base / (np.linalg.norm(v) + 1e-300)
            return (residual_fn(x_k + eps * v) - R_k) / eps

        J_op = spla.LinearOperator((size, size), matvec=jvp)

        # Build ILU preconditioner from approximate Jacobian (if provided)
        M_op = None
        if precond_fn is not None:
            try:
                J_approx = precond_fn(x_k)
                ilu = spla.spilu(J_approx.tocsc(), drop_tol=1e-4)
                M_op = spla.LinearOperator((size, size), matvec=ilu.solve)
            except Exception:
                M_op = None

        # Solve J·δx = -R_k with GMRES
        dx, gmres_info = spla.gmres(J_op, -R_k,
                                     maxiter=max_gmres,
                                     rtol=gmres_tol,
                                     M=M_op)
        if not np.all(np.isfinite(dx)):
            dx = np.zeros(size)

        # Line search with damping
        dp = dx[0:N]; du = dx[N:2*N]
        dT = dx[2*N:3*N]; dphi = dx[3*N:4*N]

        omega_k = omega * min(1.0,
            0.5 * p_ref / (np.max(np.abs(dp)) + 1e-300),
            500.0 / (np.max(np.abs(du)) + 1e-300),
            0.5 * T_ref / (np.max(np.abs(dT)) + 1e-300))

        x_k[:N] = np.maximum(x_k[:N] + omega_k * dp, 1.0)  # p floor
        x_k[N:2*N] += omega_k * du
        x_k[2*N:3*N] = np.maximum(x_k[2*N:3*N] + omega_k * dT, 1e-3)  # T floor
        x_k[3*N:] = np.clip(x_k[3*N:] + omega_k * dphi, 0.0, 1.0)

        info['outer_iters'] = k + 1

    return x_k, info

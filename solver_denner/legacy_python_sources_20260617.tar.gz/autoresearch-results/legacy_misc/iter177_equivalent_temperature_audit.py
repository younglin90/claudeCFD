#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'results'))
from run_denner1d_17case import AIR_IDEAL,WATER_NASG,_make_ref_air,_make_ref_water_nasg,_temperature_from_rho_p,_v_case24_kapila_path_exact
from solver.denner_1d.eos.eos_class import create_eos
from solver.denner_1d.eos.base import compute_mixture_props, _constant_density_temperature, _stiff_liquid_reference_density
from solver.denner_1d.main import _common_density_equivalent_temperature_from_moment

def phases():
    a=dict(AIR_IDEAL); w=dict(WATER_NASG); a['enable_stiff_split']=True; w['enable_stiff_split']=True; return a,w

def state(psi_water, side):
    p_pre=1e5; rho_air_pre=1.1574; rho_water_pre=998.0
    rh=_v_case24_kapila_path_exact(10.0,psi_water,_make_ref_air(),_make_ref_water_nasg(),p_pre=p_pre,rho_air=rho_air_pre,rho_water=rho_water_pre)
    ph1,ph2=phases()
    if side=='post':
        p=rh['p_post']; u=rh['u_post']; a=rh['alpha_post']; comp=rh['comp']; q1=rh['alpha_pre']*rho_air_pre; q2=(1-rh['alpha_pre'])*rho_water_pre; r1=q1*comp/a; r2=q2*comp/(1-a)
    else:
        p=p_pre; u=0.; a=rh['alpha_pre']; r1=rho_air_pre; r2=rho_water_pre
    T1=float(_temperature_from_rho_p(ph1,r1,p)); T2=float(_temperature_from_rho_p(ph2,r2,p)); Tmom=a*T1+(1-a)*T2
    return dict(p=float(p),u=float(u),alpha=float(a),rho1=float(r1),rho2=float(r2),T1=T1,T2=T2,Tmom=float(Tmom),S=float(rh['V_s']),rho_exact=float(rh['rho_post'] if side=='post' else (1-psi_water)*rho_air_pre+psi_water*rho_water_pre))

def phase_cons(st):
    ph1,ph2=phases(); e1=create_eos(ph1); e2=create_eos(ph2); a=st['alpha']; p=st['p']; u=st['u']
    rho=a*st['rho1']+(1-a)*st['rho2']; E=a*e1.e_vol(p,st['T1'])+(1-a)*e2.e_vol(p,st['T2'])+0.5*rho*u*u; return rho,E

def common_cons(st,T):
    ph1,ph2=phases(); pr=compute_mixture_props(np.array([st['p']]),np.array([st['u']]),np.array([T]),np.array([st['alpha']]),ph1,ph2); return float(pr['rho'][0]), float(pr['E_total'][0])

def solve_T_for_quantity(st,target,kind):
    ph1,ph2=phases(); a=st['alpha']; p=st['p']; u=st['u']
    lo=1e-6; hi=max(st['Tmom'],1.0)
    def q(T):
        rho,E=common_cons(st,T)
        return E if kind=='energy' else rho
    # rho decreases; energy mostly? sample bracket robust monotonic increasing for energy.
    for _ in range(100):
        val=q(hi)
        if kind=='energy':
            ok=val>=target
        else:
            ok=val<=target
        if ok: break
        hi*=2
    for _ in range(100):
        mid=0.5*(lo+hi); val=q(mid)
        if kind=='energy':
            if val<target: lo=mid
            else: hi=mid
        else:
            if val>target: lo=mid
            else: hi=mid
    return 0.5*(lo+hi)

def rh_res(L,R,statefn):
    rhoL,EL=statefn(L); rhoR,ER=statefn(R); S=L['S']; uL=L['u']; uR=R['u']; pL=L['p']; pR=R['p']
    mass=S*(rhoR-rhoL)-(rhoR*uR-rhoL*uL); mom=S*(rhoR*uR-rhoL*uL)-((rhoR*uR*uR+pR)-(rhoL*uL*uL+pL)); ener=S*(ER-EL)-(uR*(ER+pR)-uL*(EL+pL))
    return [mass/max(abs(S*(rhoR-rhoL)),abs(rhoL*uL),1), mom/max(abs(rhoL*uL*uL+pL),abs(rhoR*uR*uR+pR),1), ener/max(abs(uL*(EL+pL)),abs(uR*(ER+pR)),1)]

rows=[]
for psiw in [0.25,0.5,0.75]:
    L=state(psiw,'post'); R=state(psiw,'pre')
    rhoE_L=phase_cons(L); rhoE_R=phase_cons(R)
    TdenL=float(_common_density_equivalent_temperature_from_moment(np.array([L['p']]),np.array([L['Tmom']]),np.array([L['alpha']]),*phases())[0]); TdenR=float(_common_density_equivalent_temperature_from_moment(np.array([R['p']]),np.array([R['Tmom']]),np.array([R['alpha']]),*phases())[0])
    TeneL=solve_T_for_quantity(L,rhoE_L[1],'energy'); TeneR=solve_T_for_quantity(R,rhoE_R[1],'energy')
    def density_closure(st): return common_cons(st, TdenL if st is L else TdenR)
    def energy_closure(st): return common_cons(st, TeneL if st is L else TeneR)
    rows.append(dict(psi_water=psiw, T_density_post=TdenL, T_energy_post=TeneL, rho_density_post=common_cons(L,TdenL)[0], rho_energy_post=common_cons(L,TeneL)[0], exact_rho_post=rhoE_L[0], phase_RH=rh_res(L,R,phase_cons), density_T_RH=rh_res(L,R,density_closure), energy_T_RH=rh_res(L,R,energy_closure)))
print(json.dumps({'rows':rows},indent=2))

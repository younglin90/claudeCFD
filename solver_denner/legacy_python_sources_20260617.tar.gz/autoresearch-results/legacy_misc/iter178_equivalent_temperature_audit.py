#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'results'))
from run_denner1d_17case import AIR_IDEAL,WATER_NASG,_make_ref_air,_make_ref_water_nasg,_temperature_from_rho_p,_v_case24_kapila_path_exact
from solver.denner_1d.eos.eos_class import create_eos
from solver.denner_1d.eos.base import compute_mixture_props
from solver.denner_1d.main import _common_density_equivalent_temperature_from_moment

def phases():
    a=dict(AIR_IDEAL); w=dict(WATER_NASG); a['enable_stiff_split']=True; w['enable_stiff_split']=True; return a,w

def state(psi_water, side):
    p_pre=1e5; ra=1.1574; rw=998.0
    rh=_v_case24_kapila_path_exact(10.0,psi_water,_make_ref_air(),_make_ref_water_nasg(),p_pre=p_pre,rho_air=ra,rho_water=rw)
    ph1,ph2=phases()
    if side=='post':
        p=rh['p_post']; u=rh['u_post']; a=rh['alpha_post']; comp=rh['comp']; r1=rh['alpha_pre']*ra*comp/a; r2=(1-rh['alpha_pre'])*rw*comp/(1-a)
    else:
        p=p_pre; u=0.; a=rh['alpha_pre']; r1=ra; r2=rw
    T1=float(_temperature_from_rho_p(ph1,r1,p)); T2=float(_temperature_from_rho_p(ph2,r2,p));
    return dict(p=float(p),u=float(u),alpha=float(a),rho1=float(r1),rho2=float(r2),T1=T1,T2=T2,Tmom=float(a*T1+(1-a)*T2),S=float(rh['V_s']))

def phase_cons(st):
    ph1,ph2=phases(); e1=create_eos(ph1); e2=create_eos(ph2); a=st['alpha']; p=st['p']; u=st['u']
    rho=a*st['rho1']+(1-a)*st['rho2']; E=a*e1.e_vol(p,st['T1'])+(1-a)*e2.e_vol(p,st['T2'])+0.5*rho*u*u
    return rho,E

def common_cons(st,T):
    ph1,ph2=phases(); pr=compute_mixture_props(np.array([st['p']]),np.array([st['u']]),np.array([T]),np.array([st['alpha']]),ph1,ph2); return float(pr['rho'][0]),float(pr['E_total'][0])

def solve_energy_T(st,target):
    Ts=np.geomspace(1e-3,1e6,260)
    Fs=np.array([common_cons(st,T)[1]-target for T in Ts])
    # choose crossing closest to T moment, avoid near-zero singular branch if possible
    cand=[]
    for i in range(len(Ts)-1):
        if not (np.isfinite(Fs[i]) and np.isfinite(Fs[i+1])): continue
        if Fs[i]==0 or Fs[i]*Fs[i+1] <= 0:
            cand.append((abs(np.log(np.sqrt(Ts[i]*Ts[i+1])/max(st['Tmom'],1e-9))), i))
    if not cand: return float('nan')
    _,i=min(cand); lo=Ts[i]; hi=Ts[i+1]; flo=Fs[i]
    for _ in range(80):
        mid=.5*(lo+hi); fm=common_cons(st,mid)[1]-target
        if flo*fm<=0: hi=mid
        else: lo=mid; flo=fm
    return .5*(lo+hi)

def rh_res(L,R,statefn):
    rhoL,EL=statefn(L); rhoR,ER=statefn(R); S=L['S']; uL=L['u']; uR=R['u']; pL=L['p']; pR=R['p']
    mass=S*(rhoR-rhoL)-(rhoR*uR-rhoL*uL); mom=S*(rhoR*uR-rhoL*uL)-((rhoR*uR*uR+pR)-(rhoL*uL*uL+pL)); ener=S*(ER-EL)-(uR*(ER+pR)-uL*(EL+pL))
    return {'mass':mass/max(abs(S*(rhoR-rhoL)),abs(rhoL*uL),1),'momentum':mom/max(abs(rhoL*uL*uL+pL),abs(rhoR*uR*uR+pR),1),'energy':ener/max(abs(uL*(EL+pL)),abs(uR*(ER+pR)),1)}
rows=[]
for psiw in [0.25,0.5,0.75]:
    L=state(psiw,'post'); R=state(psiw,'pre'); targetL=phase_cons(L); targetR=phase_cons(R)
    ph1,ph2=phases(); TdenL=float(_common_density_equivalent_temperature_from_moment(np.array([L['p']]),np.array([L['Tmom']]),np.array([L['alpha']]),ph1,ph2)[0]); TdenR=float(_common_density_equivalent_temperature_from_moment(np.array([R['p']]),np.array([R['Tmom']]),np.array([R['alpha']]),ph1,ph2)[0]); TeneL=solve_energy_T(L,targetL[1]); TeneR=solve_energy_T(R,targetR[1])
    def dens(st): return common_cons(st,TdenL if st is L else TdenR)
    def ener(st): return common_cons(st,TeneL if st is L else TeneR)
    rows.append({'psi_water':psiw,'T_density_post':TdenL,'T_energy_post':TeneL,'rho_exact_post':targetL[0],'rho_density_post':common_cons(L,TdenL)[0],'rho_energy_post':common_cons(L,TeneL)[0],'phase_RH':rh_res(L,R,phase_cons),'density_T_RH':rh_res(L,R,dens),'energy_T_RH':rh_res(L,R,ener)})
print(json.dumps({'rows':rows},indent=2,sort_keys=True))

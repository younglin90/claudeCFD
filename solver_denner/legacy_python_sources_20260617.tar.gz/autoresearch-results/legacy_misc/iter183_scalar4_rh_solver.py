#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np
from scipy.optimize import root
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'results'))
from run_denner1d_17case import AIR_IDEAL,WATER_NASG,_make_ref_air,_make_ref_water_nasg,_temperature_from_rho_p,_v_case24_kapila_path_exact
from solver.denner_1d.eos.base import compute_mixture_props
from solver.denner_1d.main import _common_density_equivalent_temperature_from_moment
from solver.denner_1d.vof_cn import _compute_K

def phases():
    a=dict(AIR_IDEAL); w=dict(WATER_NASG); a['enable_stiff_split']=True; w['enable_stiff_split']=True; return a,w

def mix(p,u,T,a,ph1,ph2):
    pr=compute_mixture_props(np.array([p]),np.array([u]),np.array([T]),np.array([a]),ph1,ph2)
    return float(pr['rho'][0]), float(pr['E_total'][0]), float(pr['c_mix'][0])

def alpha_path_integral(aL,aR,pL,pR,TL,TR,uL,uR,ph1,ph2):
    # 5-pt Gauss-Legendre on straight primitive path
    xs,ws=np.polynomial.legendre.leggauss(5); s=0.5*(xs+1); w=0.5*ws
    val=0.0
    for si,wi in zip(s,w):
        a=aL+si*(aR-aL); p=pL+si*(pR-pL); T=TL+si*(TR-TR+TR-TL) # replaced below
        T=TL+si*(TR-TL)
        B=a+float(_compute_K(np.array([a]),ph1,ph2,np.array([p]),np.array([T]))[0])
        val += wi*B
    return val*(uR-uL)

def validation_post(psiw):
    p_pre=1e5; ra=1.1574; rw=998.0
    rh=_v_case24_kapila_path_exact(10.0,psiw,_make_ref_air(),_make_ref_water_nasg(),p_pre=p_pre,rho_air=ra,rho_water=rw)
    ph1,ph2=phases()
    aR=rh['alpha_pre']; pR=p_pre; uR=0.0
    TR=float(_common_density_equivalent_temperature_from_moment(np.array([pR]),np.array([aR*_temperature_from_rho_p(ph1,ra,pR)+(1-aR)*_temperature_from_rho_p(ph2,rw,pR)]),np.array([aR]),ph1,ph2)[0])
    aL=rh['alpha_post']; pL=rh['p_post']; uL=rh['u_post']; comp=rh['comp']
    r1=rh['alpha_pre']*ra*comp/aL; r2=(1-rh['alpha_pre'])*rw*comp/(1-aL)
    T1=float(_temperature_from_rho_p(ph1,r1,pL)); T2=float(_temperature_from_rho_p(ph2,r2,pL)); Tmom=aL*T1+(1-aL)*T2
    TL=float(_common_density_equivalent_temperature_from_moment(np.array([pL]),np.array([Tmom]),np.array([aL]),ph1,ph2)[0])
    return rh, dict(p=pL,u=uL,T=TL,a=aL), dict(p=pR,u=uR,T=TR,a=aR)

def solve_one(psiw):
    ph1,ph2=phases(); rh,L0,R=validation_post(psiw); S=rh['V_s']
    rhoR,ER,cR=mix(R['p'],R['u'],R['T'],R['a'],ph1,ph2)
    def residual(y):
        # variables scaled: log p, u/S, log T, logit alpha
        p=np.exp(y[0]); u=S*y[1]; T=np.exp(y[2]); a=1/(1+np.exp(-y[3]))
        rho,E,c=mix(p,u,T,a,ph1,ph2)
        mass=S*(rhoR-rho)-(rhoR*R['u']-rho*u)
        mom=S*(rhoR*R['u']-rho*u)-((rhoR*R['u']*R['u']+R['p'])-(rho*u*u+p))
        ener=S*(ER-E)-(R['u']*(ER+R['p'])-u*(E+p))
        req=-S*(R['a']-a)+(R['u']*R['a']-u*a)
        src=alpha_path_integral(a,R['a'],p,R['p'],T,R['T'],u,R['u'],ph1,ph2)
        scales=[max(abs(S*(rhoR-rho)),abs(rho*u),1),max(abs(rho*u*u+p),abs(R['p']),1),max(abs(u*(E+p)),1),max(abs(req),abs(src),1)]
        return np.array([mass/scales[0],mom/scales[1],ener/scales[2],(req-src)/scales[3]])
    y0=np.array([np.log(L0['p']), L0['u']/S, np.log(L0['T']), np.log(L0['a']/(1-L0['a']))])
    sol=root(residual,y0,method='hybr',options={'xtol':1e-11,'maxfev':2000})
    y=sol.x; Ls={'p':float(np.exp(y[0])),'u':float(S*y[1]),'T':float(np.exp(y[2])),'a':float(1/(1+np.exp(-y[3])))}
    rho_s,E_s,_=mix(Ls['p'],Ls['u'],Ls['T'],Ls['a'],ph1,ph2)
    rho_v,E_v,_=mix(L0['p'],L0['u'],L0['T'],L0['a'],ph1,ph2)
    return {'psi_water':psiw,'success':bool(sol.success),'root_norm':float(np.linalg.norm(residual(sol.x),np.inf)),'message':str(sol.message),'scalar4_post':Ls,'validation_commonT_post':L0,'scalar4_rho_post':rho_s,'validation_commonT_rho_post':rho_v,'validation_exact_rho_post':float(rh['rho_post']),'rel_diff':{k:float((Ls[k]-L0[k])/(abs(L0[k])+1e-300)) for k in Ls},'rho_rel_diff_vs_validation_exact':float((rho_s-rh['rho_post'])/rh['rho_post'])}

out={'audit':'scalar_T_four_equation_RH_compatibility','rows':[solve_one(v) for v in [0.25,0.5,0.75]]}
print(json.dumps(out,indent=2,sort_keys=True))

#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'results'))
from run_denner1d_17case import AIR_IDEAL,WATER_NASG,_make_ref_air,_make_ref_water_nasg,_temperature_from_rho_p,_v_case24_kapila_path_exact
from solver.denner_1d.eos.base import compute_mixture_props, compute_specific_total_enthalpy
from solver.denner_1d.main import _common_density_equivalent_temperature_from_moment

def phases():
    a=dict(AIR_IDEAL); w=dict(WATER_NASG); a['enable_stiff_split']=True; w['enable_stiff_split']=True; return a,w

def common_state(psiw, side):
    p_pre=1e5; ra=1.1574; rw=998.0
    rh=_v_case24_kapila_path_exact(10.0,psiw,_make_ref_air(),_make_ref_water_nasg(),p_pre=p_pre,rho_air=ra,rho_water=rw)
    ph1,ph2=phases()
    if side=='R':
        p=p_pre; u=0.; a=rh['alpha_pre']; r1=ra; r2=rw
    else:
        p=rh['p_post']; u=rh['u_post']; a=rh['alpha_post']; comp=rh['comp']
        r1=rh['alpha_pre']*ra*comp/a; r2=(1-rh['alpha_pre'])*rw*comp/(1-a)
    Tmom=a*_temperature_from_rho_p(ph1,r1,p)+(1-a)*_temperature_from_rho_p(ph2,r2,p)
    T=float(_common_density_equivalent_temperature_from_moment(np.array([p]),np.array([Tmom]),np.array([a]),ph1,ph2)[0])
    pr=compute_mixture_props(np.array([p]),np.array([u]),np.array([T]),np.array([a]),ph1,ph2)
    h=float(compute_specific_total_enthalpy(np.array([p]),np.array([u]),np.array([T]),np.array([a]),ph1,ph2)[0])
    return rh, dict(p=float(p),u=float(u),a=float(a),T=float(T),rho=float(pr['rho'][0]),E=float(pr['E_total'][0]),h=h,c=float(pr['c_mix'][0]))

def hllc_pressure(L,R):
    rhoL,rhoR=L['rho'],R['rho']; uL,uR=L['u'],R['u']; pL,pR=L['p'],R['p']; cL,cR=L['c'],R['c']
    ubar=0.5*(uL+uR); cbar=0.5*(cL+cR)
    sL=min(uL-cL, ubar-cbar); sR=max(uR+cR, ubar+cbar)
    den=rhoL*(sL-uL)-rhoR*(sR-uR)
    if abs(den)<1e-300: return float('nan')
    sM=(pR-pL+rhoL*uL*(sL-uL)-rhoR*uR*(sR-uR))/den
    pstarL=pL+rhoL*(sL-uL)*(sM-uL); pstarR=pR+rhoR*(sR-uR)*(sM-uR)
    return 0.5*(pstarL+pstarR)

def rh_residual(L,R,S, flux_style):
    if flux_style=='central':
        rhoF=0.5*(L['rho']+R['rho']); uF=0.5*(L['u']+R['u']); pF=0.5*(L['p']+R['p']); hF=0.5*(L['h']+R['h'])
    elif flux_style=='upwind_left':
        rhoF=L['rho']; uF=L['u']; pF=0.5*(L['p']+R['p']); hF=L['h']
    elif flux_style=='pep_product_left':
        # current retained mixed-shock tendency: transported face density with upwind enthalpy product.
        rhoF=0.5*(L['rho']+R['rho']); uF=L['u']; pF=0.5*(L['p']+R['p']); hF=L['h']
    elif flux_style=='hllc_p_left':
        rhoF=0.5*(L['rho']+R['rho']); uF=L['u']; pF=hllc_pressure(L,R); hF=L['h']
    else: raise ValueError
    Fm=rhoF*uF
    Fmom=rhoF*uF*uF+pF
    Fe=rhoF*uF*hF
    # residual for left(post)->right(pre) discontinuity moving speed S: S(U_R-U_L)-(F_R-F_L), compare flux style to exact RH flux difference by one interface estimate
    # Here report face pressure and mass/energy flux compared to exact jump-implied fluxes from L plus S*(U_R-U_L).
    Fm_req=L['rho']*L['u'] + S*(R['rho']-L['rho'])
    Fmom_req=L['rho']*L['u']*L['u']+L['p'] + S*(R['rho']*R['u']-L['rho']*L['u'])
    Fe_req=L['u']*(L['E']+L['p']) + S*(R['E']-L['E'])
    return dict(pF=float(pF),rhoF=float(rhoF),uF=float(uF),hF=float(hF),
        Fm_rel=float((Fm-Fm_req)/max(abs(Fm_req),1)),Fmom_rel=float((Fmom-Fmom_req)/max(abs(Fmom_req),1)),Fe_rel=float((Fe-Fe_req)/max(abs(Fe_req),1)))
rows=[]
for psiw in [0.25,0.5,0.75]:
    rh,L=common_state(psiw,'L'); _,R=common_state(psiw,'R'); S=rh['V_s']
    rows.append({'psi_water':psiw,'exact_p_post':rh['p_post'],'L':L,'R':R,'flux':{k:rh_residual(L,R,S,k) for k in ['central','upwind_left','pep_product_left','hllc_p_left']}})
print(json.dumps({'audit':'case24_face_flux_jump_consistency','rows':rows},indent=2,sort_keys=True))

import json, time, sys, pathlib, numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import results.run_denner1d_17case as r

def shape(num, exact, region, scale):
    return r._v_shape_metrics(num, exact, region, scale)

def run04(variable_set):
    N,L=500,1.0; dx=L/N; x=(np.arange(N)+0.5)*dx
    p0,T0,u0=1e5,300.0,1.0; f,du=2000.0,0.01; rho0=1.157
    c0=r._sound_speed_for_rho_p(r.AIR_IDEAL,rho0,p0); Tmain=r._temperature_from_rho_p(r.AIR_IDEAL,rho0,p0)
    psi0=np.full(N,1-1e-6); T=np.full(N,Tmain); u=np.full(N,u0); p=np.full(N,p0)
    dp=rho0*c0*du; t_end=2.3e-3
    uin=lambda t: u0+du*np.sin(2*np.pi*f*t)
    pin=lambda t: p0+dp*np.sin(2*np.pi*f*t)
    t=time.time(); res=r._solve_denner(psi0,T,u,p,dx,t_end,r.AIR_IDEAL,r.AIR_IDEAL,bc_l='inlet',bc_r='transmissive',cfl=0.4,u_inlet=uin,p_inlet=pin,max_iter=100000,variable_set=variable_set)
    psi,Tf,uf,pf=r._final_state(res); rhof=r._mix_rho(psi,pf,Tf,r.AIR_IDEAL,r.AIR_IDEAL)
    tau=res['t_history'][-1]-x/c0; touched=tau>0; phase=np.sin(2*np.pi*f*tau[touched])
    pe=np.full(N,p0); ue=np.full(N,u0); re=np.full(N,rho0); pe[touched]=p0+dp*phase; ue[touched]=u0+du*phase; re[touched]=rho0+rho0*du/c0*phase
    wr=touched & (x<0.95*c0*res['t_history'][-1])
    return {'case':'04','mode':variable_set,'wall':time.time()-t,'div':res.get('diverged',False),'steps':len(res['dt_history']),'p':shape(pf-p0,pe-p0,wr,.1*dp),'u':shape(uf-u0,ue-u0,wr,.1*du),'rho':shape(rhof,re,wr,.1*max(float(np.ptp(re)),rho0*du/c0))}

def run05(variable_set):
    N,L=400,1.0; dx=L/N; x=(np.arange(N)+0.5)*dx
    p0,T0,u0=1e5,300.0,1.0; f,du=6000.0,0.01; rho0=998.0
    c0=r._sound_speed_for_rho_p(r.WATER_NASG,rho0,p0); Tmain=r._temperature_from_rho_p(r.WATER_NASG,rho0,p0)
    psi0=np.full(N,1e-6); T=np.full(N,Tmain); u=np.full(N,u0); p=np.full(N,p0)
    dp=rho0*c0*du; t_end=5.1e-4
    uin=lambda t: u0+du*np.sin(2*np.pi*f*t)
    pin=lambda t: p0+dp*np.sin(2*np.pi*f*t)
    t=time.time(); res=r._solve_denner(psi0,T,u,p,dx,t_end,r.AIR_IDEAL,r.WATER_NASG,bc_l='inlet',bc_r='transmissive',cfl=0.4,u_inlet=uin,p_inlet=pin,max_iter=100000,variable_set=variable_set)
    psi,Tf,uf,pf=r._final_state(res); rhof=r._mix_rho(psi,pf,Tf,r.AIR_IDEAL,r.WATER_NASG)
    tau=res['t_history'][-1]-x/c0; touched=tau>0; phase=np.sin(2*np.pi*f*tau[touched])
    pe=np.full(N,p0); ue=np.full(N,u0); rw=np.full(N,rho0); pe[touched]=p0+dp*phase; ue[touched]=u0+du*phase; rw[touched]=rho0+rho0*du/c0*phase
    rair=r._density_eos(r.AIR_IDEAL,pe,np.full(N,293.0)); re=1e-6*rair+(1-1e-6)*rw
    wr=touched & (x<0.95*c0*res['t_history'][-1])
    return {'case':'05','mode':variable_set,'wall':time.time()-t,'div':res.get('diverged',False),'steps':len(res['dt_history']),'p':shape(pf-p0,pe-p0,wr,.1*dp),'u':shape(uf-u0,ue-u0,wr,.1*du),'rho':shape(rhof,re,wr,.1*max(float(np.ptp(re)),rho0*du/c0))}

out=[]
for case in (run04, run05):
    for mode in ('puT','puh'):
        try: out.append(case(mode))
        except Exception as e: out.append({'case':case.__name__,'mode':mode,'error':repr(e)})
        print(json.dumps(out[-1]), flush=True)
print(json.dumps(out, indent=2))


import sys,pathlib,time,json,numpy as np
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import results.run_denner1d_17case as r
N=100; L=1.; dx=L/N; x=(np.arange(N)+.5)*dx
p0=1e5; u0=1.; f=2000.; du=.01; rho0=1.157
c0=r._sound_speed_for_rho_p(r.AIR_IDEAL,rho0,p0); Tmain=r._temperature_from_rho_p(r.AIR_IDEAL,rho0,p0)
psi0=np.full(N,1-1e-6); T=np.full(N,Tmain); u=np.full(N,u0); p=np.full(N,p0); dp=rho0*c0*du
uin=lambda t: u0+du*np.sin(2*np.pi*f*t); pin=lambda t: p0+dp*np.sin(2*np.pi*f*t)
res=r._solve_denner(psi0,T,u,p,dx,2.3e-3,r.AIR_IDEAL,r.AIR_IDEAL,bc_l='inlet',bc_r='transmissive',cfl=.4,u_inlet=uin,p_inlet=pin,max_iter=100000,variable_set='puT')
psi,Tf,uf,pf=r._final_state(res); rhof=r._mix_rho(psi,pf,Tf,r.AIR_IDEAL,r.AIR_IDEAL)
tau=res['t_history'][-1]-x/c0; touched=tau>0; phase=np.sin(2*np.pi*f*tau[touched])
pe=np.full(N,p0); Te=np.full(N,Tmain); re=np.full(N,rho0); pe[touched]=p0+dp*phase; re[touched]=rho0+rho0*du/c0*phase; Te[touched]=Tmain*(pe[touched]/p0)**((1.4-1)/1.4)
mask=touched & (x<.8)
def corr(a,b):
 a=a[mask]-np.mean(a[mask]); b=b[mask]-np.mean(b[mask]); return float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)+1e-300))
print(json.dumps({'Tptp':float(np.ptp(Tf[mask])),'Texpptp':float(np.ptp(Te[mask])),'corr_T_p':corr(Tf,pf),'corr_T_exact':corr(Tf,Te),'corr_rho_exact':corr(rhof,re),'rho_amp':float((np.max(rhof[mask])-np.min(rhof[mask]))/(np.max(re[mask])-np.min(re[mask])))}))

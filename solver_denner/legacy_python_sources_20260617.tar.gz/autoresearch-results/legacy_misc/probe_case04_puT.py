import sys,pathlib,time,json,numpy as np
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import results.run_denner1d_17case as r
N=500; L=1.; dx=L/N; x=(np.arange(N)+.5)*dx
p0=1e5; u0=1.; f=2000.; du=.01; rho0=1.157
c0=r._sound_speed_for_rho_p(r.AIR_IDEAL,rho0,p0); Tmain=r._temperature_from_rho_p(r.AIR_IDEAL,rho0,p0)
psi0=np.full(N,1-1e-6); T=np.full(N,Tmain); u=np.full(N,u0); p=np.full(N,p0); dp=rho0*c0*du
uin=lambda t: u0+du*np.sin(2*np.pi*f*t); pin=lambda t: p0+dp*np.sin(2*np.pi*f*t)
t=time.time(); res=r._solve_denner(psi0,T,u,p,dx,2.3e-3,r.AIR_IDEAL,r.AIR_IDEAL,bc_l='inlet',bc_r='transmissive',cfl=.4,u_inlet=uin,p_inlet=pin,max_iter=100000,variable_set='puT')
psi,Tf,uf,pf=r._final_state(res); rhof=r._mix_rho(psi,pf,Tf,r.AIR_IDEAL,r.AIR_IDEAL)
tau=res['t_history'][-1]-x/c0; touched=tau>0; phase=np.sin(2*np.pi*f*tau[touched])
pe=np.full(N,p0); ue=np.full(N,u0); re=np.full(N,rho0); pe[touched]=p0+dp*phase; ue[touched]=u0+du*phase; re[touched]=rho0+rho0*du/c0*phase
wr=touched&(x<.95*c0*res['t_history'][-1])
print(json.dumps({'wall':time.time()-t,'div':res.get('diverged',False),'steps':len(res['dt_history']),'Tptp':float(np.ptp(Tf)),'p':r._v_shape_metrics(pf-p0,pe-p0,wr,.1*dp),'u':r._v_shape_metrics(uf-u0,ue-u0,wr,.1*du),'rho':r._v_shape_metrics(rhof,re,wr,.1*max(float(np.ptp(re)),rho0*du/c0))},default=float))

import sys, os, time, json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(1,str(ROOT.parent))
loop=ROOT.parent/'.codex-loop'
if loop.exists(): sys.path.insert(0,str(loop))
from solver.denner_1d.main import run as denner_run
from results.run_denner1d_17case import (_phase_dict_07, _temperature_from_rho_p, _isentropic_dTdp, _final_state, _mix_rho)
from verify_01_03_06_acceptance import P0 as V_P0
from verify_02_07_acceptance import CASES_07, EOS_07, U_PEAK_07, _exact_07, _exact_07_rho
case = [c for c in CASES_07 if c.name=='Air-Water'][0]
N=int(os.environ.get('N','200')); length=1.5; dx=length/N; x=(np.arange(N)+0.5)*dx
left_spec=EOS_07[case.left]; right_spec=EOS_07[case.right]
phL=_phase_dict_07(case.left); phR=_phase_dict_07(case.right)
maskL=x<case.x_intf; alpha_floor=1e-8
psi0=np.where(maskL,1.0-alpha_floor,alpha_floor)
TL=_temperature_from_rho_p(phL,float(left_spec['rho']),V_P0)
TR=_temperature_from_rho_p(phR,float(right_spec['rho']),V_P0)
ZL=float(left_spec['rho']*left_spec['c'])
u0=np.where(maskL,U_PEAK_07*np.exp(-((x-case.x_src)**2)/(2*case.sigma**2)),0.0)
p0=V_P0+ZL*u0
theta=_isentropic_dTdp(phL,V_P0,float(TL))
T0=np.where(maskL,float(TL)+theta*(p0-V_P0),float(TR))
for flag in [False, True]:
    t=time.time()
    params=dict(ph1=phL,ph2=phR,x_cells=x,psi_init=psi0,T_init=T0,u_init=u0,p_init=p0,t_end=case.t_end,CFL=0.4,bc_left='reflective',bc_right='transmissive',verbose=False,max_iteration=5000,use_autograd=True,use_acid=True,vof_type='volume',variable_set='puT',third_var='T',use_barotropic=False,use_K=True,use_compress=bool(int(os.environ.get('COMP','1'))),coupled=False,solver_mode='delta',bdf_order=2,mwi_rho_star='harmonic',tvd_limiter='koren',mwi_transient=True,acoustic_face_correction=bool(int(os.environ.get('ACOUSTIC','1'))),acid_temporal_colour='midpoint',max_outer=3,max_inner=8,max_newton=12,newton_tol=1e-8,inner_tol=1e-8,outer_tol=1e-8,newton_omega=1.0,use_jfnk=True,consistent_vof_face_flux=flag, pressure_floor_velocity_regularization=bool(int(os.environ.get('PREG','1'))))
    res=denner_run(params)
    psi,T,u,p=_final_state(res)
    pe,ue=_exact_07(case,x,res['t_history'][-1])
    rho=_mix_rho(psi,p,T,phL,phR)
    out=dict(flag=bool(flag), comp=bool(params['use_compress']), t_final=float(res['t_history'][-1]), complete=bool(res['t_history'][-1]>=case.t_end-1e-14), diverged=bool(res.get('diverged',False)), reason=res.get('reason',''), wall=time.time()-t, p_abs=float(np.max(np.abs(p-V_P0))), u_abs=float(np.max(np.abs(u))), rho_min=float(np.min(rho)), rho_max=float(np.max(rho)), psi_min=float(np.min(psi)), psi_max=float(np.max(psi)), p_err_max=float(np.max(np.abs(p-pe))), u_err_max=float(np.max(np.abs(u-ue))))
    print(json.dumps(out), flush=True)

#!/usr/bin/env python3
import os, sys, time, json
import numpy as np
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(1, str(ROOT.parent))
CODEX_LOOP = ROOT.parent / '.codex-loop'
if CODEX_LOOP.exists():
    sys.path.insert(0, str(CODEX_LOOP))
from solver.denner_1d.main import run as denner_run
from results.run_denner1d_17case import (_make_ref_air,_make_ref_water_nasg,_v_case24_kapila_path_exact,
    _temperature_from_rho_p,_final_state,_mix_rho,_v_relative_l2,_pearson,AIR_IDEAL,WATER_NASG)

def b(name, default):
    return os.environ.get(name, '1' if default else '0').lower() not in ('0','false','no','off')
N=int(os.environ.get('N','100')); CFL=float(os.environ.get('CFL','0.4')); psi_water=float(os.environ.get('PSI','0.25'))
L=1.0; dx=L/N; x=(np.arange(N)+0.5)*dx; x_shock0=0.1; x_shock_exact=0.8; Ms=10.0
p_pre=1e5; rho_air_pre=1.1574; rho_water_pre=998.0; alpha_floor=1e-6
if psi_water<=0: ph1=ph2=AIR_IDEAL; rho1_pre=rho2_pre=rho_air_pre
elif psi_water>=1: ph1=ph2=WATER_NASG; rho1_pre=rho2_pre=rho_water_pre
else: ph1,ph2=AIR_IDEAL,WATER_NASG; rho1_pre,rho2_pre=rho_air_pre,rho_water_pre
rh=_v_case24_kapila_path_exact(Ms,psi_water,_make_ref_air(),_make_ref_water_nasg(),p_pre=p_pre,rho_air=rho_air_pre,rho_water=rho_water_pre)
p_post=rh['p_post']; rho_post_mix=rh['rho_post']; u_post=rh['u_post']; comp=rh['comp']; alpha_pre=rh['alpha_pre']; alpha_post=rh['alpha_post']; V_s=rh['V_s']; t_end=0.7/V_s
left=x<x_shock0
psi0=np.clip(np.where(left,alpha_post,alpha_pre), alpha_floor,1-alpha_floor)
p_init=np.where(left,p_post,p_pre); u_init=np.where(left,u_post,0.0)
q1_pre=alpha_pre*rho1_pre; q2_pre=(1-alpha_pre)*rho2_pre
rho1=np.where(left,q1_pre*comp/alpha_post,rho1_pre); rho2=np.where(left,q2_pre*comp/(1-alpha_post),rho2_pre)
T1=_temperature_from_rho_p(ph1,rho1,p_init); T2=_temperature_from_rho_p(ph2,rho2,p_init); T_init=psi0*T1+(1-psi0)*T2
params=dict(ph1=ph1, ph2=ph2, x_cells=x, psi_init=psi0, T_init=T_init, u_init=u_init, p_init=p_init,
    t_end=t_end, CFL=CFL, bc_left='transmissive', bc_right='transmissive', verbose=False,
    cfl_type='acoustic', max_iteration=int(os.environ.get('MAX_ITER','200000')),
    use_acid=True, vof_type=os.environ.get('VOF_TYPE','volume'), variable_set=os.environ.get('VARIABLE_SET','puT'),
    use_K=b('USE_K', False), use_compress=b('USE_COMPRESS', False), coupled=False, solver_mode='delta',
    third_var=os.environ.get('THIRD_VAR', None), bdf_order=int(os.environ.get('BDF_ORDER','2')),
    mwi_rho_star=os.environ.get('MWI_RHO_STAR','harmonic'), tvd_limiter=os.environ.get('TVD_LIMITER','minmod'),
    acoustic_limiter=os.environ.get('ACOUSTIC_LIMITER') or None, acoustic_limiter_blend=float(os.environ.get('ACOUSTIC_LIMITER_BLEND','1.0')),
    mwi_transient=b('MWI_TRANSIENT', True), acoustic_face_correction=b('ACOUSTIC_FACE_CORRECTION', True),
    acid_temporal_colour=os.environ.get('ACID_TEMPORAL_COLOUR','new'), max_outer=int(os.environ.get('MAX_OUTER','1')),
    max_inner=int(os.environ.get('MAX_INNER','20')), max_newton=int(os.environ.get('MAX_NEWTON','20')),
    newton_tol=float(os.environ.get('NEWTON_TOL','1e-6')), inner_tol=float(os.environ.get('NEWTON_TOL','1e-6')),
    outer_tol=float(os.environ.get('OUTER_TOL','1e-6')), newton_omega=float(os.environ.get('NEWTON_OMEGA','1.0')),
    use_autograd=b('USE_AUTOGRAD', True), use_jfnk=b('USE_JFNK', True), krylov_max=int(os.environ.get('KRYLOV_MAX','8')),
    consistent_vof_face_flux=b('CONSISTENT_VOF_FACE_FLUX', True), density_mood_limiter=b('DENSITY_MOOD_LIMITER', True),
    pressure_floor_velocity_regularization=b('PRESSURE_FLOOR_VELOCITY_REG', True), smooth_acoustic_entropy_projection=b('SMOOTH_ACOUSTIC_ENTROPY', True),
    force_mixed_stiff_puh=b('FORCE_MIXED_STIFF_PUH', True))
# Remove None third_var so main chooses consistently.
if params['third_var'] is None: params.pop('third_var')
st=time.time(); res=denner_run(params); wall=time.time()-st
psi_f,T_f,u_f,p_f=_final_state(res); rho_f=_mix_rho(psi_f,p_f,T_f,ph1,ph2)
exact={'rho':np.where(x<x_shock_exact,rho_post_mix,(1-psi_water)*rho_air_pre+psi_water*rho_water_pre),'u':np.where(x<x_shock_exact,u_post,0.0),'p':np.where(x<x_shock_exact,p_post,p_pre)}
p_mid=0.5*(p_post+p_pre); above=p_f>p_mid; shock_x=float(x[np.where(above)[0].max()]) if np.any(above) else float('nan')
out=dict(N=N,CFL=CFL,psi_water=psi_water,use_K=params['use_K'],consistent_vof_face_flux=params['consistent_vof_face_flux'],mwi_transient=params['mwi_transient'],acoustic_face_correction=params['acoustic_face_correction'],force_mixed_stiff_puh=params['force_mixed_stiff_puh'],wall=wall,steps=len(res['dt_history']),complete=res['t_history'][-1]>=t_end-1e-14,diverged=bool(res.get('diverged',False)),diverge_reason=str(res.get('diverge_reason','')),shock_x=shock_x,shock_cells=abs(shock_x-x_shock_exact)/dx if np.isfinite(shock_x) else 1e99,p_l2=_v_relative_l2(p_f,exact['p'],1e5),u_l2=_v_relative_l2(u_f,exact['u'],1.0),rho_l2=_v_relative_l2(rho_f,exact['rho'],1.0),p_corr=_pearson(p_f,exact['p']),u_corr=_pearson(u_f,exact['u']),rho_corr=_pearson(rho_f,exact['rho']),p_min=float(np.min(p_f)),p_max=float(np.max(p_f)),rho_min=float(np.min(rho_f)),rho_max=float(np.max(rho_f)),u_min=float(np.min(u_f)),u_max=float(np.max(u_f)),psi_min=float(np.min(psi_f)),psi_max=float(np.max(psi_f)),T_min=float(np.min(T_f)),T_max=float(np.max(T_f)))

def conv(v):
    if isinstance(v, (bool, str, int, float)) or v is None:
        return v
    if hasattr(v, 'item'):
        vv = v.item()
        if isinstance(vv, (bool, str, int, float)) or vv is None:
            return vv
    return float(v)
print(json.dumps({k: conv(v) for k, v in out.items()}, sort_keys=True))

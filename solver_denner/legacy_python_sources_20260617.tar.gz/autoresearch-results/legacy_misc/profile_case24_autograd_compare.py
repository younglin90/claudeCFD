import cProfile, json, os, pathlib, pstats, sys, time
import numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from results import run_denner1d_17case as d

N=int(os.environ.get('DENNER_CASE24_N','40'))
psi_water=float(os.environ.get('DENNER_CASE24_PSI','0.5'))
CFL=float(os.environ.get('DENNER_CASE24_CFL','0.4'))
use_autograd=os.environ.get('DENNER_PROFILE_AUTOGRAD','1').lower() not in ('0','false','no','off')
L=1.0; dx=L/N; x=(np.arange(N)+0.5)*dx
x_shock0=0.1; Ms=10.0; p_pre=1e5; rho_air_pre=1.1574; rho_water_pre=998.0; alpha_floor=1e-6
if psi_water<=0.0:
    ph1=ph2=d.AIR_IDEAL; rho1_pre=rho2_pre=rho_air_pre
elif psi_water>=1.0:
    ph1=ph2=d.WATER_NASG; rho1_pre=rho2_pre=rho_water_pre
else:
    ph1,ph2=d.AIR_IDEAL,d.WATER_NASG; rho1_pre,rho2_pre=rho_air_pre,rho_water_pre
rh=d._v_case24_kapila_path_exact(Ms, psi_water, d._make_ref_air(), d._make_ref_water_nasg(), p_pre=p_pre, rho_air=rho_air_pre, rho_water=rho_water_pre)
p_post=rh['p_post']; u_post=rh['u_post']; comp=rh['comp']; alpha_pre=rh['alpha_pre']; alpha_post=rh['alpha_post']; V_s=rh['V_s']; t_end=0.7/V_s
left=x<x_shock0
psi0=np.clip(np.where(left,alpha_post,alpha_pre),alpha_floor,1-alpha_floor)
p_init=np.where(left,p_post,p_pre); u_init=np.where(left,u_post,0.0)
q1_pre=alpha_pre*rho1_pre; q2_pre=(1-alpha_pre)*rho2_pre
rho1=np.where(left,q1_pre*comp/alpha_post,rho1_pre)
rho2=np.where(left,q2_pre*comp/(1-alpha_post),rho2_pre)
T1=d._temperature_from_rho_p(ph1,rho1,p_init); T2=d._temperature_from_rho_p(ph2,rho2,p_init)
T_init=psi0*T1+(1-psi0)*T2

def run():
    return d._solve_denner(psi0,T_init,u_init,p_init,dx,t_end,ph1=ph1,ph2=ph2,bc_l='transmissive',bc_r='transmissive',cfl=CFL,cfl_type='acoustic',max_iter=200000,use_autograd=use_autograd)
prof=cProfile.Profile(); t=time.time(); res=prof.runcall(run); wall=time.time()-t
stats_path=f'autoresearch-results/profile_case24_autograd_{int(use_autograd)}.prof'
prof.dump_stats(stats_path)
print(json.dumps({'wall':wall,'steps':len(res['dt_history']),'t':float(res['t_history'][-1]),'diverged':bool(res.get('diverged',False)),'use_autograd':use_autograd,'stats':stats_path}, sort_keys=True))
pstats.Stats(prof).strip_dirs().sort_stats('cumtime').print_stats(40)

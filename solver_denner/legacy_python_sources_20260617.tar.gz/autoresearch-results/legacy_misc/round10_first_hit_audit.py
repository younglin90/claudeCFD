#!/usr/bin/env python3
"""Round 10 first-hit residual audit for denner_1d.

Diagnostic only.  This script does not change solver behavior.

It reconstructs face-level quantities from early saved snapshots and writes
per-face CSV rows for the union of top faces ranked by residual-like local
operators.  The goal is to identify where case07/case25 amplification starts
and whether case24 rho-drop outliers share the same face-level signature.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = ROOT.parent
OUT_DIR = ROOT / "autoresearch-results"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(OUT_DIR))

os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("DENNER_DIAG", "1")

import round6a_operator_audit as r6a  # noqa: E402
from solver.denner_1d.boundary import apply_ghost, apply_ghost_velocity  # noqa: E402
from solver.denner_1d.eos.base import compute_mixture_props  # noqa: E402
from solver.denner_1d.interface.cicsam import cicsam_face, cicsam_face_beta  # noqa: E402


@contextmanager
def _env_var(name: str, value: str | None):
    old = os.environ.get(name)
    if value is None:
        os.environ.pop(name, None)
    else:
        os.environ[name] = value
    try:
        yield
    finally:
        if old is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = old


def _jsonable(obj: Any) -> Any:
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer, np.bool_)):
        return obj.item()
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return repr(obj)


def _normalize_bc(bc: str) -> str:
    return "wall" if bc == "reflective" else bc


def _tv(arr: np.ndarray) -> float:
    arr = np.asarray(arr, dtype=float)
    if arr.size < 2:
        return 0.0
    return float(np.sum(np.abs(np.diff(arr))))


def _ensure_rho(snap: dict[str, Any], meta: dict[str, Any]) -> dict[str, Any]:
    snap = dict(snap)
    snap.setdefault("x", meta["x"])
    if "rho" not in snap or np.asarray(snap.get("rho")).shape == ():
        snap["rho"] = compute_mixture_props(
            np.asarray(snap["p"], dtype=float),
            np.asarray(snap["u"], dtype=float),
            np.asarray(snap["T"], dtype=float),
            np.asarray(snap["psi"], dtype=float),
            meta["ph1"],
            meta["ph2"],
        )["rho"]
    return snap


def _safe(arr: Any, idx: int, default: float = 0.0) -> float:
    a = np.asarray(arr, dtype=float)
    if a.size == 0:
        return float(default)
    idx = int(np.clip(idx, 0, a.size - 1))
    return float(a[idx])


def _top_indices(scores: dict[str, np.ndarray], n: int, face_count: int) -> list[int]:
    chosen: set[int] = set()
    for score in scores.values():
        s = np.asarray(score, dtype=float)
        if s.size == 0:
            continue
        finite = np.where(np.isfinite(s), s, -np.inf)
        count = min(int(n), int(finite.size))
        if count <= 0:
            continue
        idx = np.argpartition(finite, -count)[-count:]
        chosen.update(int(i) for i in idx if 0 <= int(i) < face_count)
    return sorted(chosen)


def _sample_meta(audit: dict[str, Any], dt: float) -> dict[str, Any]:
    return {
        "x": np.asarray(audit["x"], dtype=float),
        "ph1": audit["ph1"],
        "ph2": audit["ph2"],
        "bc_l": audit["bc_l"],
        "bc_r": audit["bc_r"],
        "dx": float(audit["dx"]),
        "dt": float(dt),
        "face_limiter": "koren",
        "velocity_limiter": "vanalbada",
    }


def _face_rows(
    case_id: str,
    subcase: str | None,
    step: int,
    snap: dict[str, Any],
    prev: dict[str, Any] | None,
    meta: dict[str, Any],
    top_n: int,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    snap = _ensure_rho(snap, meta)
    if prev is not None:
        prev = _ensure_rho(prev, meta)

    face_audit = r6a._face_audit(snap, meta, prev)
    face = face_audit["face"]
    masks = face_audit["masks"]

    x = np.asarray(snap["x"], dtype=float)
    psi = np.asarray(snap["psi"], dtype=float)
    T = np.asarray(snap["T"], dtype=float)
    u = np.asarray(snap["u"], dtype=float)
    p = np.asarray(snap["p"], dtype=float)
    rho = np.asarray(snap["rho"], dtype=float)
    dx = float(meta["dx"])
    dt = float(meta["dt"])

    bc_l = _normalize_bc(meta["bc_l"])
    bc_r = _normalize_bc(meta["bc_r"])
    psi_ext = apply_ghost(psi, bc_l, bc_r, 2)
    u_ext = apply_ghost_velocity(u, bc_l, bc_r, 2)
    p_ext = apply_ghost(p, bc_l, bc_r, 2)
    rho_ext = apply_ghost(rho, bc_l, bc_r, 2)
    T_ext = apply_ghost(T, bc_l, bc_r, 2)

    theta_k = np.asarray(face["theta_k"], dtype=float)
    beta_k = cicsam_face_beta(psi_ext, theta_k, dt, dx, n_ghost=2)
    psi_face_reconstructed = cicsam_face(psi_ext, theta_k, dt, dx, n_ghost=2)

    pL_rec, pR_rec = r6a._tvd_face_states(p, bc_l, bc_r, kind=meta.get("face_limiter", "koren"))
    uL_rec, uR_rec = r6a._tvd_face_states(u, bc_l, bc_r, kind=meta.get("velocity_limiter", "vanalbada"), velocity=True)
    psi_L = np.asarray(face["psi_L"], dtype=float)
    psi_R = np.asarray(face["psi_R"], dtype=float)
    psi_upwind = np.where(theta_k >= 0.0, psi_L, psi_R)
    psi_central = 0.5 * (psi_L + psi_R)
    psi_min = np.minimum(psi_L, psi_R)
    psi_max = np.maximum(psi_L, psi_R)

    H_delta = np.asarray(face["H_acid_minus_product"], dtype=float)
    theta_face_corr = np.asarray(face["theta_face_corr"], dtype=float)
    pface_corr = np.asarray(face["pface_corr"], dtype=float)
    p_work = np.asarray(face["momentum_pressure_face"], dtype=float)
    mass_flux_div = np.asarray(face["mass_flux_div"], dtype=float)
    alpha_flux_div = np.asarray(face["alpha_flux_div"], dtype=float)

    face_count = int(theta_k.size)
    cell_like = np.zeros(face_count, dtype=float)
    if mass_flux_div.size:
        cell_like[: mass_flux_div.size] = np.abs(mass_flux_div)
        cell_like[1 : mass_flux_div.size + 1] = np.maximum(cell_like[1 : mass_flux_div.size + 1], np.abs(mass_flux_div))

    energy_residual_face = H_delta * theta_k / max(dx, 1.0e-300)
    momentum_residual_face = pface_corr + theta_face_corr
    mass_residual_face = cell_like
    recon_p_jump = np.abs(pR_rec - pL_rec)
    recon_u_jump = np.abs(uR_rec - uL_rec)
    psi_transport_delta = np.abs(np.asarray(face["psi_face_transport"], dtype=float) - psi_upwind)

    scores = {
        "energy": np.abs(energy_residual_face),
        "momentum": np.abs(momentum_residual_face),
        "pressure_work": np.abs(p_work),
        "mass_flux_div": mass_residual_face,
        "recon_p_jump": recon_p_jump,
        "recon_u_jump": recon_u_jump,
        "psi_transport_minus_upwind": psi_transport_delta,
    }
    face_ids = _top_indices(scores, top_n, face_count)

    rows: list[dict[str, Any]] = []
    for f in face_ids:
        iL = int(max(f - 1, 0))
        iR = int(min(f, x.size - 1))
        psi_face_transport = float(face["psi_face_transport"][f])
        pface_corr_f = float(pface_corr[f])
        pface_corr_rel = float(abs(pface_corr_f) / max(abs(float(p_ext[f + 1])), abs(float(p_ext[f + 2])), 1.0))
        H_rel = float(
            abs(H_delta[f])
            / max(
                abs(float(face["rho_e"][f]))
                + abs(float(p_work[f]))
                + abs(float(face["rho_mix_ke"][f])),
                1.0,
            )
        )
        outside_transport = bool(psi_face_transport < float(psi_min[f]) - 1.0e-14 or psi_face_transport > float(psi_max[f]) + 1.0e-14)
        outside_recon = bool(
            float(psi_face_reconstructed[f]) < float(psi_min[f]) - 1.0e-14
            or float(psi_face_reconstructed[f]) > float(psi_max[f]) + 1.0e-14
        )
        row = {
            "case": case_id,
            "subcase": subcase,
            "step": int(step),
            "time": float(snap["t"]),
            "dt": float(dt),
            "face": int(f),
            "x_face": float(face["x"][f]),
            "pL": float(p_ext[f + 1]),
            "pR": float(p_ext[f + 2]),
            "uL": float(u_ext[f + 1]),
            "uR": float(u_ext[f + 2]),
            "rhoL": float(rho_ext[f + 1]),
            "rhoR": float(rho_ext[f + 2]),
            "TL": float(T_ext[f + 1]),
            "TR": float(T_ext[f + 2]),
            "psiL": float(psi_ext[f + 1]),
            "psiR": float(psi_ext[f + 2]),
            "psi_face_transport": psi_face_transport,
            "psi_face_reconstructed": float(psi_face_reconstructed[f]),
            "psi_upwind": float(psi_upwind[f]),
            "psi_central": float(psi_central[f]),
            "psi_min_cell": float(psi_min[f]),
            "psi_max_cell": float(psi_max[f]),
            "psi_face_outside_cell_bounds": outside_transport or outside_recon,
            "psi_transport_outside_cell_bounds": outside_transport,
            "psi_reconstructed_outside_cell_bounds": outside_recon,
            "cicsam_beta": float(beta_k[f]),
            "limiter_beta": float(beta_k[f]),
            "theta_flux_k": float(theta_k[f]),
            "mass_flux_div": _safe(mass_flux_div, iL),
            "p_work": float(p_work[f]),
            "pface_corr": pface_corr_f,
            "pface_corr_rel": pface_corr_rel,
            "pressure_jump": bool(masks["pressure_jump"][f]),
            "material_jump": bool(masks["material_jump"][f]),
            "characteristic_pface": bool(masks["characteristic_pface"][f]),
            "rho_ratio": float(face["rho_ratio"][f]),
            "psi_jump": float(face["psi_jump"][f]),
            "p_jump_rel": float(face["p_jump_rel"][f]),
            "H_rel": H_rel,
            "mass_residual_face": float(mass_residual_face[f]),
            "momentum_residual_face": float(momentum_residual_face[f]),
            "energy_residual_face": float(energy_residual_face[f]),
            "alpha_flux_div": _safe(alpha_flux_div, iL),
            "face_courant": float(face["face_courant"][f]),
            "round3_mask": bool(masks["round3_guard"][f]),
            "round4a_mask": bool(masks["round4a_guard"][f]),
            "round5b_mask": bool(masks["round5b_guard"][f]),
            "rank_energy": float(abs(energy_residual_face[f])),
            "rank_momentum": float(abs(momentum_residual_face[f])),
            "rank_pressure_work": float(abs(p_work[f])),
            "rank_mass_flux_div": float(mass_residual_face[f]),
            "rank_recon_p_jump": float(recon_p_jump[f]),
            "rank_recon_u_jump": float(recon_u_jump[f]),
            "rank_psi_transport_minus_upwind": float(psi_transport_delta[f]),
        }
        rows.append(row)

    p_cell_l = p_ext[1:-2]
    p_cell_r = p_ext[2:-1]
    u_cell_l = u_ext[1:-2]
    u_cell_r = u_ext[2:-1]
    p_new_extrema = (pL_rec < np.minimum(p_cell_l, p_cell_r) - 1.0e-14) | (pR_rec > np.maximum(p_cell_l, p_cell_r) + 1.0e-14)
    u_new_extrema = (uL_rec < np.minimum(u_cell_l, u_cell_r) - 1.0e-14) | (uR_rec > np.maximum(u_cell_l, u_cell_r) + 1.0e-14)
    summary = {
        "case": case_id,
        "subcase": subcase,
        "step": int(step),
        "time": float(snap["t"]),
        "dt": float(dt),
        "rows": int(len(rows)),
        "max_p": float(np.max(p)),
        "min_p": float(np.min(p)),
        "tv_p": _tv(p),
        "max_u": float(np.max(u)),
        "min_u": float(np.min(u)),
        "tv_u": _tv(u),
        "tv_psi": _tv(psi),
        "count_psi_face_outside_bounds": int(sum(1 for r in rows if r["psi_face_outside_cell_bounds"])),
        "count_p_or_u_reconstruction_new_extrema": int(np.count_nonzero(p_new_extrema | u_new_extrema)),
        "top_energy_face": int(np.argmax(np.abs(energy_residual_face))) if face_count else None,
        "top_momentum_face": int(np.argmax(np.abs(momentum_residual_face))) if face_count else None,
        "max_energy_residual_face": float(np.max(np.abs(energy_residual_face))) if face_count else 0.0,
        "max_momentum_residual_face": float(np.max(np.abs(momentum_residual_face))) if face_count else 0.0,
        "max_mass_residual_face": float(np.max(mass_residual_face)) if face_count else 0.0,
        "max_face_courant": float(np.max(face["face_courant"])) if face_count else 0.0,
    }
    return rows, summary


def _run_case07(n: int, sample_count: int, all_subcases: bool, top_n: int) -> list[dict[str, Any]]:
    specs = list(r6a._case07_case_specs())
    if not all_subcases:
        specs = [next(s for s in specs if s.name == "Air-Water")]
    cases = []
    for spec in specs:
        with _env_var("DENNER_CASE07_AMP_AUDIT", "1"), _env_var("DENNER_FIRST_HIT_AUDIT", "1"):
            audit = r6a._run_case07_subcase(spec, n, sample_count, OUT_DIR)
        cases.append(_audit_solver_samples("07", spec.name, audit, top_n))
    return cases


def _run_case25(n: int, sample_count: int, top_n: int) -> list[dict[str, Any]]:
    with _env_var("DENNER_FIRST_HIT_AUDIT", "1"):
        audit = r6a._run_case25(n, sample_count, OUT_DIR)
    return [_audit_solver_samples("25", None, audit, top_n)]


def _run_case24(psi_values: list[float], top_n: int) -> list[dict[str, Any]]:
    cases = []
    for psi in psi_values:
        audit = r6a._load_case24_snapshot(float(psi))
        cases.append(_audit_solver_samples("24", f"psi_water={psi:g}", audit, top_n))
    return cases


def _audit_solver_samples(case_id: str, subcase: str | None, audit: dict[str, Any], top_n: int) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    summaries: list[dict[str, Any]] = []
    prev = None
    samples = list(audit.get("samples", []))[:3]
    for step, raw_snap in enumerate(samples):
        dt = float(raw_snap.get("t", 0.0) - prev.get("t", 0.0)) if prev is not None else float(audit.get("dt", 0.0))
        meta = _sample_meta(audit, dt)
        snap = _ensure_rho(raw_snap, meta)
        face_rows, summary = _face_rows(case_id, subcase, step, snap, prev, meta, top_n)
        rows.extend(face_rows)
        summaries.append(summary)
        prev = snap
    return {
        "case": case_id,
        "subcase": subcase,
        "source": audit.get("source"),
        "complete": bool(audit.get("complete", False)),
        "diverged": bool(audit.get("diverged", False)),
        "metadata": audit.get("metadata", {}),
        "rows": rows,
        "samples": summaries,
        "solver_audit_steps": audit.get("audit", {}).get("steps", [])[:5] if isinstance(audit.get("audit"), dict) else [],
    }


def _rows_to_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k) for k in fieldnames})


def _format_text(summary: dict[str, Any]) -> str:
    lines = ["Round 10 first-hit audit"]
    lines.append(f"generated_at={summary['generated_at']}")
    lines.append(f"rows_total={summary['rows_total']}")
    for case in summary["cases"]:
        lines.append("")
        lines.append(f"{case['case']} / {case.get('subcase')} complete={case['complete']} diverged={case['diverged']}")
        for sample in case["samples"]:
            lines.append(
                "  step={step} t={time:.6e} rows={rows} topE={top_energy_face} "
                "max|E|={max_energy_residual_face:.3e} topM={top_momentum_face} "
                "max|M|={max_momentum_residual_face:.3e} psi_oob={count_psi_face_outside_bounds} "
                "pu_extrema={count_p_or_u_reconstruction_new_extrema} maxCo={max_face_courant:.3e}".format(**sample)
            )
        if case["rows"]:
            first_oob = [r for r in case["rows"] if r["psi_face_outside_cell_bounds"]]
            lines.append(f"  psi_bounds_rows={len(first_oob)}")
            top = max(case["rows"], key=lambda r: abs(float(r["energy_residual_face"])))
            lines.append(
                f"  top_energy_row: step={top['step']} face={top['face']} x={top['x_face']:.6e} "
                f"E={top['energy_residual_face']:.3e} M={top['momentum_residual_face']:.3e} "
                f"mass={top['mass_residual_face']:.3e} material={top['material_jump']} pressure={top['pressure_jump']}"
            )
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Round 10 first-hit residual audit")
    parser.add_argument("--cases", default="07,24", help="Comma-separated case IDs: 07,24,25")
    parser.add_argument("--case07-all-subcases", action="store_true")
    parser.add_argument("--case07-n", type=int, default=200)
    parser.add_argument("--case25-n", type=int, default=200)
    parser.add_argument("--case24-psi", default="0.25,0.5,0.75")
    parser.add_argument("--sample-count", type=int, default=3)
    parser.add_argument("--top-n", type=int, default=20)
    parser.add_argument("--output-base", default="round10_first_hit")
    args = parser.parse_args()

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    requested = [c.strip() for c in str(args.cases).split(",") if c.strip()]
    psi_values = [float(v.strip()) for v in str(args.case24_psi).split(",") if v.strip()]

    cases: list[dict[str, Any]] = []
    for cid in requested:
        if cid == "07":
            cases.extend(_run_case07(args.case07_n, args.sample_count, args.case07_all_subcases, args.top_n))
        elif cid == "24":
            cases.extend(_run_case24(psi_values, args.top_n))
        elif cid == "25":
            cases.extend(_run_case25(args.case25_n, args.sample_count, args.top_n))
        else:
            raise ValueError(f"unsupported case id: {cid}")

    rows = [row for case in cases for row in case["rows"]]
    summary = {
        "audit": "round10_first_hit",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "cwd": str(ROOT),
        "rows_total": int(len(rows)),
        "cases": cases,
    }
    json_path = OUT_DIR / f"{args.output_base}.json"
    csv_path = OUT_DIR / f"{args.output_base}.csv"
    txt_path = OUT_DIR / f"{args.output_base}.txt"
    json_path.write_text(json.dumps(_jsonable(summary), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    _rows_to_csv(csv_path, rows)
    text = _format_text(summary)
    txt_path.write_text(text, encoding="utf-8")
    print(text, end="")
    print(f"[round10] wrote {json_path}")
    print(f"[round10] wrote {csv_path}")
    print(f"[round10] wrote {txt_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

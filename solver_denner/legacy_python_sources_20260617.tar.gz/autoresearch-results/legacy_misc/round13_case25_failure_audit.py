#!/usr/bin/env python3
"""Round 13 case25 failure audit.

Diagnostic only.  Runs the existing case25 helper and reports the sampled
state immediately before divergence, with interface/shock locations and field
extrema.  No solver behavior is changed.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "autoresearch-results"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT.parent))
sys.path.insert(0, str(OUT_DIR))

os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("DENNER_DIAG", "1")

import round6a_operator_audit as r6a  # noqa: E402
from solver.denner_1d import assembly  # noqa: E402


def _jsonable(obj: Any) -> Any:
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer, np.bool_)):
        return obj.item()
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    return obj


def _snapshot_summary(audit: dict[str, Any], snap: dict[str, Any]) -> dict[str, Any]:
    x = np.asarray(snap["x"], dtype=float)
    p = np.asarray(snap["p"], dtype=float)
    u = np.asarray(snap["u"], dtype=float)
    T = np.asarray(snap["T"], dtype=float)
    psi = np.asarray(snap["psi"], dtype=float)
    dx = float(audit["dx"])
    grad_p = np.abs(np.gradient(p, dx))
    grad_psi = np.abs(np.gradient(psi, dx))
    return {
        "t": float(snap.get("t", 0.0)),
        "p_min": float(np.min(p)),
        "p_max": float(np.max(p)),
        "u_min": float(np.min(u)),
        "u_max": float(np.max(u)),
        "T_min": float(np.min(T)),
        "T_max": float(np.max(T)),
        "psi_min": float(np.min(psi)),
        "psi_max": float(np.max(psi)),
        "shock_x": float(x[int(np.argmax(grad_p))]),
        "contact_x": float(x[int(np.argmax(grad_psi))]),
        "max_grad_p": float(np.max(grad_p)),
        "max_grad_psi": float(np.max(grad_psi)),
    }


def main() -> int:
    n = int(os.environ.get("ROUND13_CASE25_N", "200"))
    sample_count = int(os.environ.get("ROUND13_SAMPLE_COUNT", "8"))
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    assembly.reset_assembly_diag()
    audit = r6a._run_case25(n, sample_count, OUT_DIR)
    summaries = [_snapshot_summary(audit, snap) for snap in audit.get("samples", [])]
    out = {
        "audit": "round13_case25_failure_audit",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "n": n,
        "sample_count": sample_count,
        "complete": bool(audit.get("complete", False)),
        "diverged": bool(audit.get("diverged", False)),
        "metadata": audit.get("metadata", {}),
        "diag": {k: _jsonable(v) for k, v in assembly.ASSEMBLY_DIAG.items()},
        "samples": summaries,
    }
    path = OUT_DIR / "round13_case25_failure_audit.json"
    txt = OUT_DIR / "round13_case25_failure_audit.txt"
    path.write_text(json.dumps(_jsonable(out), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    lines = [
        "Round 13 case25 failure audit",
        f"complete={out['complete']} diverged={out['diverged']} steps={out['metadata'].get('steps')}",
        f"diag_round11_active={out['diag'].get('round11_active_faces')} first={out['diag'].get('round11_first_face')}",
    ]
    for idx, sample in enumerate(summaries):
        lines.append(
            "sample={idx} t={t:.6e} p=[{p_min:.3e},{p_max:.3e}] "
            "T=[{T_min:.3e},{T_max:.3e}] psi=[{psi_min:.3e},{psi_max:.3e}] "
            "shock_x={shock_x:.6e} contact_x={contact_x:.6e}".format(idx=idx, **sample)
        )
    txt.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(txt.read_text(), end="")
    print(f"[round13] wrote {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

import json
import time
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import results.run_denner1d_17case as drv
from solver.denner_1d import assembly as denner_assembly
from solver.denner_1d import main as denner_main


def to_jsonable(obj):
    try:
        import numpy as np

        if isinstance(obj, np.generic):
            return obj.item()
        if isinstance(obj, np.ndarray):
            return obj.tolist()
    except Exception:
        pass
    if isinstance(obj, dict):
        return {k: to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [to_jsonable(v) for v in obj]
    if isinstance(obj, tuple):
        return [to_jsonable(v) for v in obj]
    return obj


def main():
    t0 = time.time()
    res = drv.case_07()
    elapsed = time.time() - t0
    print("RESULT_JSON", json.dumps({"elapsed_s": elapsed, "result": to_jsonable(res)}, sort_keys=True))
    print("STEP_AUDIT_JSON", json.dumps(to_jsonable(denner_main.STEP_ACCEPT_AUDIT), sort_keys=True))
    print("ASSEMBLY_DIAG_JSON", json.dumps(to_jsonable(denner_assembly.ASSEMBLY_DIAG), sort_keys=True))


if __name__ == "__main__":
    main()

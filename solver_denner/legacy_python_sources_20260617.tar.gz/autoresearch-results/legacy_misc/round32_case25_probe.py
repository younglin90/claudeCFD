import json
import time
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import results.run_denner1d_17case as drv
from solver.denner_1d import assembly as denner_assembly
from solver.denner_1d import main as denner_main


def to_jsonable(obj):
    try:
        import numpy as np
        if isinstance(obj, np.generic):
            return obj.item()
        if isinstance(obj, np.ndarray):
            return obj.tolist()
    except Exception:
        pass
    if isinstance(obj, dict):
        return {k: to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [to_jsonable(v) for v in obj]
    if isinstance(obj, tuple):
        return [to_jsonable(v) for v in obj]
    return obj


def pick(d, keys):
    return {k: d.get(k) for k in keys if k in d}


def main():
    t0 = time.time()
    res = drv.case_25()
    elapsed = time.time() - t0
    sa = denner_main.STEP_ACCEPT_AUDIT or {}
    ad = denner_assembly.ASSEMBLY_DIAG or {}
    steps = sa.get("steps", []) if isinstance(sa, dict) else []
    out = {
        "elapsed_s": elapsed,
        "result": pick(res, ["case", "pass", "failures", "wall", "finite", "complete", "diverged", "p_corr", "u_corr", "rho_corr", "p_scaled_l2", "u_scaled_l2", "rho_scaled_l2", "interface_instability", "interface_p_linf", "interface_u_linf", "reflected_shock_delta_cells"]),
        "step_accept_summary": pick(sa, ["enabled", "round25_steps", "round25_max_p_growth", "round25_max_T_growth", "round25_max_interface_u_growth", "round25_rows", "round26_step_retries", "round26_first_retry_step", "round26_max_bad_interface_p_jump", "round26_max_bad_interface_u_jump", "round27_retry1_count", "round27_retry2_count", "round27_min_dt_factor", "round27_post_retry_bad_count", "round27_total_retry_limit_hit"]),
        "assembly_diag": pick(ad, ["round32_gate_parity_calls", "round32_gate_parity_faces", "round32_gate_parity_first_face", "round32_gate_parity_skipped_budget", "round32_gate_parity_top_rows", "round32_gate_parity_known_rows", "round31b_active_faces", "round31b_first_face", "round31b_max_abs_delta_rho_e", "round31b_max_abs_delta_h", "round31b_shadow_good_all_like_count", "round31b_seen_faces", "round31b_gate_material_pressure", "round31b_gate_psi_bounded", "round31b_gate_defect", "round31b_gate_compat_fail", "round31b_branch_calls", "hllc_fired_faces", "round11_active_faces", "round11_first_face", "round11_max_candidate_courant", "round11_material_pressure_faces", "round11_pface_faces", "round11_courant_faces", "round11_psi_jump_faces", "round11_bounded_faces", "round29_recon_eq_calls", "round29_recon_eq_faces", "round29_recon_eq_top_rows", "round29_recon_eq_first_face", "round30_shadow_calls", "round30_shadow_faces", "round30_shadow_top_rows", "round30_shadow_good_sign_rows", "round30_shadow_first_face", "round31_recon_shadow_calls", "round31_recon_shadow_faces", "round31_recon_shadow_top_rows", "round31_recon_shadow_good_rows", "round31_recon_shadow_first_face", "calls", "total_faces", "pressure_jump_faces", "material_jump_faces", "expansion_jump_faces"]),
        "top_rows": steps[-10:],
    }
    print("ROUND32_CASE25_JSON", json.dumps(to_jsonable(out), sort_keys=True))


if __name__ == "__main__":
    main()

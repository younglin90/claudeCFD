import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load_log(path: Path):
    data = {}

    def parse_payload(line: str):
        start = line.find("{")
        if start == -1:
            raise ValueError(f"no JSON payload found in line: {line[:120]}")
        return json.loads(line[start:])

    for line in path.read_text().splitlines():
        if line.startswith("RESULT_JSON"):
            data["result"] = parse_payload(line)
        elif line.startswith("STEP_AUDIT_JSON"):
            data["step"] = parse_payload(line)
        elif line.startswith("ASSEMBLY_DIAG_JSON"):
            data["assembly"] = parse_payload(line)
        elif line.startswith("ROUND32_CASE07_JSON") or line.startswith("ROUND32_CASE24_JSON") or line.startswith("ROUND32_CASE25_JSON"):
            data["single"] = parse_payload(line)
    return data


def pick_result(d):
    if "result" in d:
        inner = d["result"].get("result")
        if inner is not None:
            return inner
    if "single" in d:
        return d["single"].get("result")
    return None


def pick_step(d):
    if "step" in d:
        return d["step"]
    if "single" in d:
        return d["single"].get("step_accept_summary")
    return None


def pick_assembly(d):
    if "assembly" in d:
        return d["assembly"]
    if "single" in d:
        return d["single"].get("assembly_diag")
    return None


def main():
    files = {
        "case07": ROOT / "round32_case07_aw_n200.log",
        "case25": ROOT / "round32_case25_n200.log",
        "case24": ROOT / "round32_case24_psi025_n60.log",
    }
    summary = {}
    for name, path in files.items():
        d = load_log(path)
        summary[name] = {
            "result": pick_result(d),
            "step": pick_step(d),
            "assembly": pick_assembly(d),
        }
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

import json
from pathlib import Path

obj = json.loads(Path("autoresearch-results/round32_summary.json").read_text())

for case in ["case07", "case25", "case24"]:
    print(case, obj[case].keys())
    print("result type", type(obj[case]["result"]).__name__, obj[case]["result"])
    print("step type", type(obj[case]["step"]).__name__, obj[case]["step"])
    print("assembly type", type(obj[case]["assembly"]).__name__, obj[case]["assembly"])

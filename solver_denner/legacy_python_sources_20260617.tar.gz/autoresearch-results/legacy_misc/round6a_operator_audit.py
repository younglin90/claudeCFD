#!/usr/bin/env python3
"""Round 6A operator audit for denner_1d.

This is a diagnostic script only. It does not modify solver behavior.
It reconstructs sampled face-level operators from saved snapshots or from
direct solver runs, then reports candidate activation masks and local term
balances for the current Denner 1D workspace.

Coverage:
  - case07 N200 Air-Water first, then optional Helium-Air / Argon-Air
  - case25 N200
  - case24 N100 psi_water = 0.25 / 0.5 / 0.75

The solver does not publish the full internal face arrays into snapshots, so
the script reconstructs the operator fields offline using the same EOS and
stencil helpers. The report distinguishes exact snapshot-backed values from
offline face proxies where that matters.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = ROOT.parent
OUT_DIR = ROOT / "autoresearch-results"
RESULTS_1D = ROOT / "results" / "1D"

sys.path.insert(0, str(ROOT))
sys.path.insert(1, str(REPO_ROOT))
os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("DENNER_DIAG", "1")

from solver.denner_1d.assembly import _tvd_face_states  # noqa: E402
from solver.denner_1d.boundary import apply_ghost, apply_ghost_velocity  # noqa: E402
from solver.denner_1d.eos.base import compute_mixture_props  # noqa: E402
from solver.denner_1d.eos.eos_class import create_eos  # noqa: E402
from solver.denner_1d.flux.mwi import harmonic_face_density, mwi_face_coeff_denner  # noqa: E402
from solver.denner_1d.main import run as denner_run  # noqa: E402
from solver.denner_1d import solver_a  # noqa: E402


AIR_IDEAL = {"gamma": 1.4, "pinf": 0.0, "b": 0.0, "kv": 717.5, "eta": 0.0}
WATER_NASG = {"gamma": 1.187, "pinf": 7.028e8, "b": 6.61e-4, "kv": 3610.0, "eta": -1.177788e6}
V_P0 = 1.0e5
U_PEAK_07 = 1.0


@dataclass(frozen=True)
class Case07Spec:
    name: str
    left: str
    right: str
    x_intf: float
    x_src: float
    sigma: float
    t_end: float


CASES_07 = (
    Case07Spec("Air-Water", "Air", "Water", 0.5, 0.1, 0.014, 1.55e-3),
    Case07Spec("Helium-Air", "Helium", "Air", 1.0, 0.2, 0.049, 1.513e-3),
    Case07Spec("Argon-Air", "Argon", "Air", 0.5, 0.1, 0.038, 2.02e-3),
)


def _phase_dict_07(name: str) -> dict[str, float]:
    if name == "Air":
        return AIR_IDEAL
    if name == "Water":
        return WATER_NASG
    if name == "Helium":
        return {"gamma": 5.0 / 3.0, "pinf": 0.0, "b": 0.0, "kv": 3115.0, "eta": 0.0}
    if name == "Argon":
        return {"gamma": 5.0 / 3.0, "pinf": 0.0, "b": 0.0, "kv": 314.0, "eta": 0.0}
    raise KeyError(name)


def _temperature_from_rho_p(ph: dict[str, float], rho: np.ndarray, p: np.ndarray) -> np.ndarray:
    rho_a = np.asarray(rho, dtype=float)
    p_a = np.asarray(p, dtype=float)
    gm1 = float(ph["gamma"]) - 1.0
    pinf = float(ph.get("pinf", 0.0))
    b = float(ph.get("b", 0.0))
    kv = float(ph.get("kv", 1.0))
    return ((p_a + pinf) / np.maximum(rho_a, 1.0e-300) - b * (p_a + pinf)) / np.maximum(kv * gm1, 1.0e-300)


def _theta_from_eos(ph: dict[str, float], p: float, T: float) -> float:
    eos = create_eos(ph)
    pp = np.asarray([p], dtype=float)
    TT = np.asarray([T], dtype=float)
    rho = eos.rho(pp, TT)
    rho_p = eos.drho_dp(pp, TT)
    rho_T = eos.drho_dT(pp, TT)
    e = eos.e_vol(pp, TT)
    h_static = eos.h(pp, TT)
    d_rho_h_dp = rho_p * h_static + rho * eos.dh_dp(pp, TT)
    d_rho_h_dT = rho_T * h_static + rho * eos.cp(pp, TT)
    h = h_static
    den = d_rho_h_dT - h * rho_T
    num = h * rho_p - d_rho_h_dp
    theta = np.divide(num, den, out=np.zeros_like(num), where=np.abs(den) > 1.0e-300)
    return float(theta[0])


def _exact_07(case: Case07Spec, x: np.ndarray, t: float) -> tuple[np.ndarray, np.ndarray]:
    left = {
        "Air": {"kind": "ideal", "gamma": 1.4, "rho": 1.1574, "c": 347.0},
        "Helium": {"kind": "ideal", "gamma": 5.0 / 3.0, "rho": 0.1634, "c": 1007.0},
        "Argon": {"kind": "ideal", "gamma": 5.0 / 3.0, "rho": 1.622, "c": 323.0},
        "Water": {"kind": "nasg", "gamma": 1.187, "rho": 998.0, "c": 1567.3350584385664},
    }
    cL = float(left[case.left]["c"])
    cR = float(left[case.right]["c"])
    ZL = float(left[case.left]["rho"] * left[case.left]["c"])
    ZR = float(left[case.right]["rho"] * left[case.right]["c"])
    R = (ZR - ZL) / (ZR + ZL)
    Tu = 2.0 * ZL / (ZL + ZR)
    Tp = 2.0 * ZR / (ZL + ZR)
    t_hit = (case.x_intf - case.x_src) / cL
    x = np.asarray(x, dtype=float)
    left_mask = x < case.x_intf

    def gauss(center: float, sigma: float) -> np.ndarray:
        return np.exp(-((x - center) ** 2) / (2.0 * sigma * sigma))

    u_inc = U_PEAK_07 * gauss(case.x_src + cL * t, case.sigma) * left_mask
    u_ref_shape = U_PEAK_07 * gauss(2.0 * case.x_intf - case.x_src - cL * t, case.sigma) * left_mask
    if t > t_hit:
        sigR = case.sigma * cR / cL
        u_tr_shape = U_PEAK_07 * gauss(case.x_intf + cR * (t - t_hit), sigR) * (~left_mask)
    else:
        u_tr_shape = np.zeros_like(x)
    u_exact = u_inc - R * u_ref_shape + Tu * u_tr_shape
    p_exact = V_P0 + ZL * u_inc + R * ZL * u_ref_shape + Tp * ZL * u_tr_shape
    return p_exact, u_exact


def _metrics_from_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    metrics = snapshot.get("metrics")
    if metrics is None:
        return {}
    if isinstance(metrics, np.ndarray) and metrics.shape == ():
        metrics = metrics.item()
    if isinstance(metrics, bytes):
        metrics = metrics.decode("utf-8")
    if isinstance(metrics, str):
        try:
            return json.loads(metrics)
        except Exception:  # noqa: BLE001
            return {}
    if isinstance(metrics, dict):
        return metrics
    return {}


def _jsonable(obj: Any) -> Any:
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer, np.bool_)):
        return obj.item()
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return repr(obj)


def _safe_percentiles(values: np.ndarray, percentiles=(5, 25, 50, 75, 90, 95, 99)) -> dict[str, float]:
    values = np.asarray(values, dtype=float)
    if values.size == 0:
        return {"count": 0}
    out = {"count": int(values.size), "mean": float(np.mean(values)), "min": float(np.min(values)), "max": float(np.max(values))}
    for q in percentiles:
        out[f"p{q}"] = float(np.percentile(values, q))
    return out


def _snapshot_from_npz(path: Path) -> dict[str, Any]:
    with np.load(path, allow_pickle=True) as z:
        out = {k: z[k] for k in z.files}
    return out


def _recover_common_temperature(
    p: np.ndarray,
    rho_target: np.ndarray,
    psi: np.ndarray,
    ph1: dict[str, float],
    ph2: dict[str, float],
    *,
    T_guess: float | None = None,
) -> np.ndarray:
    p = np.asarray(p, dtype=float)
    rho_target = np.asarray(rho_target, dtype=float)
    psi = np.asarray(psi, dtype=float)
    T = np.empty_like(p, dtype=float)
    guess = float(T_guess if T_guess is not None else 300.0)
    for i in range(p.size):
        pi = float(p[i])
        rhoi = float(rho_target[i])
        psii = float(psi[i])
        Ti = guess
        for _ in range(24):
            props = compute_mixture_props(
                np.asarray([pi], dtype=float),
                np.asarray([0.0], dtype=float),
                np.asarray([Ti], dtype=float),
                np.asarray([psii], dtype=float),
                ph1,
                ph2,
            )
            rhoi_est = float(np.asarray(props["rho"], dtype=float)[0])
            drho_dT = float(np.asarray(props["phi_v"], dtype=float)[0])
            resid = rhoi_est - rhoi
            if abs(resid) <= max(1.0e-10 * max(rhoi, 1.0), 1.0e-10):
                break
            denom = drho_dT if abs(drho_dT) > 1.0e-300 else (-1.0e-12 if resid > 0 else 1.0e-12)
            Ti = float(np.clip(Ti - 0.75 * resid / denom, 1.0e-6, 1.0e7))
        T[i] = Ti
        guess = Ti
    return T


def _case24_snapshot_candidates(psi_water: float) -> list[Path]:
    tag = f"{float(psi_water):.2f}".replace(".", "p")
    if abs(psi_water - 0.25) < 1.0e-12:
        return [RESULTS_1D / "24_H" / "diag_psi025_final.npz", RESULTS_1D / "24_H" / "diag_psi025_iter4.npz"]
    if abs(psi_water - 0.5) < 1.0e-12:
        return [
            RESULTS_1D / "24_H" / "diag_psi050_final.npz",
            RESULTS_1D / "24_H" / "diag_one_last.npz",
            OUT_DIR / "cycle4_case24_N100_CFL0p4_probe_psi0p5.npz",
        ]
    if abs(psi_water - 0.75) < 1.0e-12:
        return [OUT_DIR / "cycle4_case24_N100_CFL0p4_probe_psi0p75.npz"]
    return [OUT_DIR / f"case24_psi{tag}.npz"]


def _load_case24_snapshot(psi_water: float) -> dict[str, Any]:
    for path in _case24_snapshot_candidates(psi_water):
        if not path.exists():
            continue
        snap = _snapshot_from_npz(path)
        x = np.asarray(snap["x"], dtype=float)
        psi = np.asarray(snap["psi"], dtype=float)
        p = np.asarray(snap["p"], dtype=float)
        u = np.asarray(snap["u"], dtype=float)
        rho = np.asarray(snap["rho"], dtype=float)
        T = snap.get("T")
        if T is None:
            T = _recover_common_temperature(p, rho, psi, AIR_IDEAL, WATER_NASG)
        else:
            T = np.asarray(T, dtype=float)
        metrics = _metrics_from_snapshot(snap)
        dt = None
        if "dt" in snap:
            try:
                dt = float(np.asarray(snap["dt"]).reshape(()))
            except Exception:  # noqa: BLE001
                dt = None
        if dt is None:
            steps = float(metrics.get("steps", 1.0))
            t_end = float(metrics.get("t_end", metrics.get("time", 1.0)))
            dt = t_end / max(steps, 1.0)
        exact = {
            "rho": np.asarray(snap.get("exact_rho", rho), dtype=float),
            "u": np.asarray(snap.get("exact_u", u), dtype=float),
            "p": np.asarray(snap.get("exact_p", p), dtype=float),
            "psi": np.asarray(snap.get("exact_psi", psi), dtype=float),
        }
        initial = {
            "x": x,
            "psi": np.asarray(snap.get("psi0", psi), dtype=float),
            "T": np.asarray(snap.get("T0", T), dtype=float),
            "u": np.asarray(snap.get("u0", u), dtype=float),
            "p": np.asarray(snap.get("p0", p), dtype=float),
        }
        return {
            "case": "24",
            "subcase": f"psi_water={psi_water:g}",
            "source": str(path),
            "x": x,
            "dx": float(x[1] - x[0]) if x.size > 1 else 1.0,
            "psi": psi,
            "T": np.asarray(T, dtype=float),
            "u": u,
            "p": p,
            "rho": rho,
            "ph1": AIR_IDEAL,
            "ph2": WATER_NASG,
            "bc_l": "transmissive",
            "bc_r": "transmissive",
            "dt": float(dt),
            "complete": bool(metrics.get("complete", True)),
            "diverged": False,
            "exact": exact,
            "exact_meta": {"x_shock_exact": float(np.asarray(snap.get("x_shock_exact", 0.8)).reshape(())), "psi_water": float(psi_water)},
            "metadata": metrics,
            "initial_snapshot": initial,
            "samples": [
                {"t": 0.0, **initial},
                {"t": float(metrics.get("time", metrics.get("t_end", 0.0))), "x": x, "psi": psi, "T": T, "u": u, "p": p},
            ],
        }
    raise FileNotFoundError(f"no case24 snapshot found for psi_water={psi_water}")


def _case07_case_specs() -> list[Case07Spec]:
    target = os.environ.get("DENNER_CASE07_ONLY", "").strip()
    if target:
        return [case for case in CASES_07 if case.name == target]
    return list(CASES_07)


def _sample_times(t_end: float, sample_count: int) -> list[float]:
    sample_count = max(int(sample_count), 1)
    if sample_count == 1:
        return [float(t_end)]
    times = np.linspace(float(t_end) / sample_count, float(t_end), sample_count)
    return [float(t) for t in times if t > 0.0]


def _run_case07_subcase(case: Case07Spec, n: int, sample_count: int, output_root: Path | None = None) -> dict[str, Any]:
    length = 1.5
    dx = length / int(n)
    x = (np.arange(int(n)) + 0.5) * dx
    alpha_floor = float(os.environ.get("DENNER_CASE07_ALPHA_FLOOR", "1e-8"))
    phL = _phase_dict_07(case.left)
    phR = _phase_dict_07(case.right)
    maskL = x < case.x_intf
    psi0 = np.where(maskL, 1.0 - alpha_floor, alpha_floor)
    phase_spec = {
        "Air": {"rho": 1.1574, "c": 347.0},
        "Helium": {"rho": 0.1634, "c": 1007.0},
        "Argon": {"rho": 1.622, "c": 323.0},
        "Water": {"rho": 998.0, "c": 1567.3350584385664},
    }
    TL = _temperature_from_rho_p(phL, float(phase_spec[case.left]["rho"]), V_P0)
    TR = _temperature_from_rho_p(phR, float(phase_spec[case.right]["rho"]), V_P0)
    ZL = float(phase_spec[case.left]["rho"] * phase_spec[case.left]["c"])
    u_init = np.where(maskL, U_PEAK_07 * np.exp(-((x - case.x_src) ** 2) / (2.0 * case.sigma**2)), 0.0)
    p_init = V_P0 + ZL * u_init
    theta_L = _theta_from_eos(phL, V_P0, float(TL))
    T_init = np.where(maskL, float(TL) + theta_L * (p_init - V_P0), float(TR))
    t_end = float(case.t_end)
    case_params = {
        "ph1": phL,
        "ph2": phR,
        "x_cells": x,
        "psi_init": psi0,
        "T_init": T_init,
        "u_init": u_init,
        "p_init": p_init,
        "t_end": t_end,
        "CFL": float(os.environ.get("DENNER_CASE07_CFL", "0.4")),
        "bc_left": "reflective",
        "bc_right": "transmissive",
        "verbose": False,
        "dt_fixed": None,
        "cfl_type": "acoustic",
        "max_iteration": 5000,
        "use_autograd": True,
        "use_acid": True,
        "vof_type": "volume",
        "variable_set": os.environ.get("DENNER_CASE07_VARIABLE_SET", "puT"),
        "use_barotropic": bool(int(os.environ.get("DENNER_CASE07_BAROTROPIC", "0"))),
        "use_K": bool(int(os.environ.get("DENNER_CASE07_USE_K", "1"))),
        "use_compress": bool(int(os.environ.get("DENNER_CASE07_USE_COMPRESS", "1"))),
        "coupled": bool(int(os.environ.get("DENNER_CASE07_COUPLED", "0"))),
        "solver_mode": os.environ.get("DENNER_CASE07_SOLVER_MODE", "delta"),
        "third_var": os.environ.get("DENNER_CASE07_THIRD_VAR", "T"),
        "bdf_order": int(os.environ.get("DENNER_CASE07_BDF_ORDER", "2")),
        "mwi_rho_star": os.environ.get("DENNER_CASE07_MWI_RHO_STAR", "harmonic"),
        "tvd_limiter": os.environ.get("DENNER_CASE07_TVD_LIMITER", "koren"),
        "acoustic_limiter": os.environ.get("DENNER_CASE07_ACOUSTIC_LIMITER", None),
        "acoustic_limiter_blend": float(os.environ.get("DENNER_CASE07_ACOUSTIC_LIMITER_BLEND", "1.0")),
        "mwi_transient": bool(int(os.environ.get("DENNER_CASE07_MWI_TRANSIENT_3N", "1"))),
        "acoustic_face_correction": bool(int(os.environ.get("DENNER_CASE07_ACOUSTIC_FACE", "1"))),
        "acid_temporal_colour": os.environ.get("DENNER_CASE07_ACID_TEMPORAL_COLOUR", "midpoint"),
        "max_outer": int(os.environ.get("DENNER_CASE07_MAX_OUTER", "3")),
        "max_inner": int(os.environ.get("DENNER_CASE07_MAX_INNER", "8")),
        "max_newton": int(os.environ.get("DENNER_CASE07_MAX_NEWTON", "12")),
        "newton_tol": float(os.environ.get("DENNER_CASE07_NEWTON_TOL", "1e-8")),
        "inner_tol": float(os.environ.get("DENNER_CASE07_NEWTON_TOL", "1e-8")),
        "outer_tol": float(os.environ.get("DENNER_CASE07_OUTER_TOL", "1e-8")),
        "newton_omega": 1.0,
        "use_jfnk": True,
        "krylov_max": 8,
        "output_times": _sample_times(t_end, sample_count),
        "output_path": str(output_root / f"round6a_case07_{case.name.replace('-', '_').lower()}_N{n}.npz") if output_root else None,
    }
    result = denner_run(case_params)
    snapshots = result["snapshots"]
    psi, T, u, p = result["final_state"]["psi"], result["final_state"]["T"], result["final_state"]["u"], result["final_state"]["p"]
    rho = compute_mixture_props(p, u, T, psi, phL, phR)["rho"]
    exact_p, exact_u = _exact_07(case, x, result["t_history"][-1])
    return {
        "case": "07",
        "subcase": case.name,
        "source": f"solver:N={n}",
        "x": x,
        "dx": dx,
        "psi": psi,
        "T": T,
        "u": u,
        "p": p,
        "rho": rho,
        "ph1": phL,
        "ph2": phR,
        "bc_l": "reflective",
        "bc_r": "transmissive",
        "dt": float(result["dt_history"][-1]) if result.get("dt_history") else float(case.t_end),
        "complete": bool(result["t_history"][-1] >= case.t_end - 1.0e-14),
        "diverged": bool(result.get("diverged", False)),
        "exact": {"p": exact_p, "u": exact_u},
        "exact_meta": {"x_intf": float(case.x_intf), "x_src": float(case.x_src)},
        "metadata": {"t_end": float(case.t_end), "steps": int(len(result.get("dt_history", ()))), "wall": float(result.get("wall", 0.0))},
        "samples": snapshots,
        **({"audit": result.get("audit")} if result.get("audit") is not None else {}),
    }


def _run_case25(n: int, sample_count: int, output_root: Path | None = None) -> dict[str, Any]:
    n = int(n)
    dx = 1.0 / n
    x = (np.arange(n) + 0.5) * dx
    alpha_floor = 1.0e-6
    p_pre = 1.0e5
    rho_air_pre = 1.157
    rho_water = 998.0
    p_post = 1.165e7
    rho_air_post = 6.614
    u_post = 2869.3
    x_shock0 = 0.25
    x_interface = 0.5
    shock_speed = 10.0 * np.sqrt(1.4 * p_pre / rho_air_pre)
    t_hit = (x_interface - x_shock0) / shock_speed
    t_end = t_hit + 2.42e-4
    air_region = x < x_interface
    post_region = x < x_shock0
    psi0 = np.where(air_region, 1.0 - alpha_floor, alpha_floor)
    p_init = np.where(post_region, p_post, p_pre)
    u_init = np.where(post_region, u_post, 0.0)
    rho_air = np.where(post_region, rho_air_post, rho_air_pre)
    T_air = _temperature_from_rho_p(AIR_IDEAL, rho_air, p_init)
    T_water = _temperature_from_rho_p(WATER_NASG, np.full(n, rho_water), p_init)
    T_init = psi0 * T_air + (1.0 - psi0) * T_water
    case_params = {
        "ph1": AIR_IDEAL,
        "ph2": WATER_NASG,
        "x_cells": x,
        "psi_init": psi0,
        "T_init": T_init,
        "u_init": u_init,
        "p_init": p_init,
        "t_end": t_end,
        "CFL": float(os.environ.get("DENNER_CASE25_CFL", "0.30")),
        "bc_left": "transmissive",
        "bc_right": "transmissive",
        "verbose": False,
        "dt_fixed": None,
        "cfl_type": "acoustic",
        "max_iteration": 200000,
        "use_autograd": True,
        "use_acid": True,
        "vof_type": "volume",
        "variable_set": "puT",
        "use_barotropic": False,
        "use_K": False,
        "use_compress": False,
        "coupled": False,
        "solver_mode": "delta",
        "third_var": "T",
        "bdf_order": 2,
        "mwi_rho_star": "harmonic",
        "tvd_limiter": "koren",
        "acoustic_limiter": None,
        "acoustic_limiter_blend": 1.0,
        "mwi_transient": True,
        "acoustic_face_correction": True,
        "acid_temporal_colour": "midpoint",
        "max_outer": 1,
        "max_inner": 20,
        "max_newton": 20,
        "newton_tol": 1.0e-6,
        "inner_tol": 1.0e-6,
        "outer_tol": 1.0e-6,
        "newton_omega": 1.0,
        "use_jfnk": True,
        "krylov_max": 8,
        "output_times": _sample_times(t_end, sample_count),
        "output_path": str(output_root / f"round6a_case25_N{n}.npz") if output_root else None,
    }
    result = denner_run(case_params)
    snapshots = result["snapshots"]
    psi, T, u, p = result["final_state"]["psi"], result["final_state"]["T"], result["final_state"]["u"], result["final_state"]["p"]
    rho = compute_mixture_props(p, u, T, psi, AIR_IDEAL, WATER_NASG)["rho"]
    grad_psi = np.abs(np.gradient(psi, dx))
    grad_p = np.abs(np.gradient(p, dx))
    iface_x = float(x[int(np.argmax(grad_psi))])
    shock_x = float(x[int(np.argmax(grad_p))])
    return {
        "case": "25",
        "subcase": None,
        "source": f"solver:N={n}",
        "x": x,
        "dx": dx,
        "psi": psi,
        "T": T,
        "u": u,
        "p": p,
        "rho": rho,
        "ph1": AIR_IDEAL,
        "ph2": WATER_NASG,
        "bc_l": "transmissive",
        "bc_r": "transmissive",
        "dt": float(result["dt_history"][-1]) if result.get("dt_history") else float(t_end / max(len(x), 1)),
        "complete": bool(result["t_history"][-1] >= t_end - 1.0e-14),
        "diverged": bool(result.get("diverged", False)),
        "exact": {"x_contact": float(iface_x), "x_transmitted_shock": float(shock_x)},
        "exact_meta": {"x_interface": float(x_interface), "x_contact": float(iface_x), "x_transmitted_shock": float(shock_x)},
        "metadata": {"t_end": float(t_end), "steps": int(len(result.get("dt_history", ()))), "wall": float(result.get("wall", 0.0))},
        "samples": snapshots,
        **({"audit": result.get("audit")} if result.get("audit") is not None else {}),
    }


def _normalize_bc(bc: str) -> str:
    if bc == "reflective":
        return "wall"
    return bc


def _cell_specific_enthalpy(p: np.ndarray, u: np.ndarray, T: np.ndarray, psi: np.ndarray, ph1: dict[str, float], ph2: dict[str, float]) -> np.ndarray:
    props = compute_mixture_props(p, u, T, psi, ph1, ph2)
    rho = np.asarray(props["rho"], dtype=float)
    rho_h = np.asarray(props["rho_h"], dtype=float)
    return rho_h / np.maximum(rho, 1.0e-300) + 0.5 * np.asarray(u, dtype=float) ** 2


def _face_audit(snapshot: dict[str, Any], meta: dict[str, Any], prev_snapshot: dict[str, Any] | None = None) -> dict[str, Any]:
    x = np.asarray(snapshot["x"], dtype=float)
    psi = np.asarray(snapshot["psi"], dtype=float)
    T = np.asarray(snapshot["T"], dtype=float)
    u = np.asarray(snapshot["u"], dtype=float)
    p = np.asarray(snapshot["p"], dtype=float)
    rho = np.asarray(snapshot.get("rho"), dtype=float)
    ph1 = meta["ph1"]
    ph2 = meta["ph2"]
    bc_l = meta["bc_l"]
    bc_r = meta["bc_r"]
    bc_scalar_l = _normalize_bc(bc_l)
    bc_scalar_r = _normalize_bc(bc_r)
    bc_vel_l = bc_scalar_l
    bc_vel_r = bc_scalar_r
    dx = float(meta["dx"])
    dt = float(meta["dt"])
    N = int(x.size)
    cell_left = np.maximum(np.arange(N + 1, dtype=int) - 1, 0)
    cell_right = np.minimum(np.arange(N + 1, dtype=int), N - 1)
    face_left = np.arange(N + 1, dtype=int) + 1
    face_right = np.arange(N + 1, dtype=int) + 2
    face_x = np.empty(N + 1, dtype=float)
    face_x[0] = float(x[0] - 0.5 * dx)
    face_x[1:N] = 0.5 * (x[:-1] + x[1:])
    face_x[N] = float(x[-1] + 0.5 * dx)

    cell_props = compute_mixture_props(p, u, T, psi, ph1, ph2)
    c_mix = np.asarray(cell_props["c_mix"], dtype=float)
    rho_h_cell = np.asarray(cell_props["rho_h"], dtype=float)
    h_cell = rho_h_cell / np.maximum(rho, 1.0e-300) + 0.5 * u * u

    psi_ext = apply_ghost(psi, bc_scalar_l, bc_scalar_r, 2)
    p_ext = apply_ghost(p, bc_scalar_l, bc_scalar_r, 2)
    u_ext = apply_ghost_velocity(u, bc_vel_l, bc_vel_r, 2)
    rho_ext = apply_ghost(rho, bc_scalar_l, bc_scalar_r, 2)
    T_ext = apply_ghost(T, bc_scalar_l, bc_scalar_r, 2)
    c_ext = apply_ghost(c_mix, bc_scalar_l, bc_scalar_r, 2)

    psi_L = psi_ext[face_left]
    psi_R = psi_ext[face_right]
    p_L = p_ext[face_left]
    p_R = p_ext[face_right]
    u_L = u_ext[face_left]
    u_R = u_ext[face_right]
    rho_L = rho_ext[face_left]
    rho_R = rho_ext[face_right]
    T_L = T_ext[face_left]
    T_R = T_ext[face_right]
    c_L = c_ext[face_left]
    c_R = c_ext[face_right]

    material_jump = np.abs(psi_R - psi_L) > np.sqrt(np.finfo(float).eps)
    pressure_jump = (np.maximum(np.abs(p_L), np.abs(p_R)) / np.maximum(np.minimum(np.abs(p_L), np.abs(p_R)), 1.0e-300)) > 1.01
    rho_ratio = np.maximum(rho_L, rho_R) / np.maximum(np.minimum(rho_L, rho_R), 1.0e-300)
    p_jump_rel = np.abs(p_R - p_L) / np.maximum.reduce([np.abs(p_L), np.abs(p_R), np.ones_like(p_L)])
    c_face = np.maximum(np.minimum(c_L, c_R), 1.0)
    du_over_c = np.abs(u_R - u_L) / np.maximum(c_face, 1.0e-300)
    expansion_jump = (~material_jump) & (((u_R - u_L) / c_face) > 0.05) & (p_jump_rel < 0.05)
    expansion = (u_R - u_L) > 0.0
    compression = (u_R - u_L) < 0.0

    round3_guard = material_jump & (~pressure_jump)
    round4a_guard = material_jump & pressure_jump & (rho_ratio <= 50.0)
    rho_star_face = harmonic_face_density(rho, bc_scalar_l, bc_scalar_r)
    d_hat = mwi_face_coeff_denner(
        solver_a._momentum_diagonal(rho, dx, dt),
        rho_star_face,
        dx,
        dt,
        bc_scalar_l,
        bc_scalar_r,
    )
    theta_k, u_bar = solver_a._compute_face_velocity(
        u,
        p,
        d_hat,
        dx,
        bc_scalar_l,
        bc_scalar_r,
        rho_cell=rho,
        rho_star_face=rho_star_face,
        face_limiter=meta.get("velocity_limiter", "vanalbada"),
    )
    face_courant = np.abs(theta_k) * dt / max(dx, 1.0e-300)
    round5b_guard = round4a_guard & (face_courant > 10.0)
    psi_face_transport = np.where(theta_k >= 0.0, psi_L, psi_R)
    psi_face_acid = 0.5 * (psi_L + psi_R)

    pL_rec, pR_rec = _tvd_face_states(p, bc_scalar_l, bc_scalar_r, kind=meta.get("face_limiter", "koren"))
    uL_rec, uR_rec = _tvd_face_states(u, bc_vel_l, bc_vel_r, kind=meta.get("velocity_limiter", "vanalbada"), velocity=True)
    TL_rec, TR_rec = _tvd_face_states(T, bc_scalar_l, bc_scalar_r, kind=meta.get("face_limiter", "koren"))

    iL = np.arange(N + 1, dtype=int) + 1
    iR = np.arange(N + 1, dtype=int) + 2
    pL_face = np.where(material_jump, p_ext[iL], pL_rec)
    pR_face = np.where(material_jump, p_ext[iR], pR_rec)
    uL_face = np.where(material_jump, u_ext[iL], uL_rec)
    uR_face = np.where(material_jump, u_ext[iR], uR_rec)

    ZL = np.maximum(rho_ext[iL] * c_ext[iL], 1.0e-300)
    ZR = np.maximum(rho_ext[iR] * c_ext[iR], 1.0e-300)
    Zsum = ZL + ZR
    u_star = (pL_face - pR_face + ZL * uL_face + ZR * uR_face) / np.maximum(Zsum, 1.0e-300)
    p_star = pL_face - ZL * (u_star - uL_face)

    theta_cc = (pL_face - pR_face + ZL * uL_face + ZR * uR_face) / np.maximum(Zsum, 1.0e-300)
    p_cc = (ZR * pL_face + ZL * pR_face + ZL * ZR * (uL_face - uR_face)) / np.maximum(Zsum, 1.0e-300)
    if bc_scalar_l == "wall":
        p_cc[0] = p_ext[2] - ZR[0] * u_ext[2]
        theta_cc[0] = 0.0
        Z_wall = ZR[0]
        u_star[0] = 0.0
        p_star[0] = p_ext[2] - Z_wall * u_ext[2]

    pface_corr = p_star - p_cc
    theta_face_corr = u_star - theta_cc
    theta_acoustic_extra = u_star - theta_k
    p_central = 0.5 * (p_ext[iL] + p_ext[iR])
    momentum_pressure_face = p_central.copy()
    characteristic_pface = ((~material_jump) & (expansion_jump | (~pressure_jump))) | (material_jump & pressure_jump)
    momentum_pressure_face = np.where(characteristic_pface, p_cc + pface_corr, momentum_pressure_face)
    momentum_pressure_delta = momentum_pressure_face - p_central
    hllc_active = np.zeros_like(material_jump, dtype=bool)

    donor_left = theta_k >= 0.0
    donor_idx = np.where(donor_left, iL, iR)
    p_d = p_ext[donor_idx]
    u_d = u_ext[donor_idx]
    T_d = T_ext[donor_idx]
    psi_d = psi_face_transport
    props_d = compute_mixture_props(p_d, u_d, T_d, psi_d, ph1, ph2)
    rho_face_transport = np.asarray(props_d["rho"], dtype=float)
    rho_h_face_transport = np.asarray(props_d["rho_h"], dtype=float)
    rho_e = rho_h_face_transport - p_d
    rho_mix_ke = rho_face_transport * (0.5 * u_d * u_d)
    H_acid = rho_e + momentum_pressure_face + rho_mix_ke
    h_up = np.where(donor_left, h_cell[cell_left], h_cell[cell_right])
    H_product = rho_face_transport * h_up
    H_acid_minus_product = H_acid - H_product
    H_acid_minus_product_alt = (
        compute_mixture_props(p_d, u_d, T_d, psi_face_acid, ph1, ph2)["rho_h"] - p_d + momentum_pressure_face + rho_face_transport * (0.5 * u_d * u_d)
    ) - (compute_mixture_props(p_d, u_d, T_d, psi_face_acid, ph1, ph2)["rho"] * h_up)

    alpha_flux = psi_face_transport * theta_k
    mass_flux = rho_face_transport * theta_k
    alpha_flux_div = np.diff(alpha_flux) / max(dx, 1.0e-300)
    mass_flux_div = np.diff(mass_flux) / max(dx, 1.0e-300)
    if prev_snapshot is not None:
        prev_rho = np.asarray(prev_snapshot["rho"], dtype=float)
        temporal_rho = (rho - prev_rho) / max(float(snapshot["t"]) - float(prev_snapshot["t"]), 1.0e-300)
    else:
        temporal_rho = np.zeros_like(rho)

    psi_jump = np.abs(psi_R - psi_L)
    psi_face_delta = np.abs(psi_face_transport - psi_face_acid)

    return {
        "t": float(snapshot["t"]),
        "dt": float(dt),
        "N": int(N),
        "dx": float(dx),
        "counts": {
            "material_jump": int(np.count_nonzero(material_jump)),
            "pressure_jump": int(np.count_nonzero(pressure_jump)),
            "expansion_jump": int(np.count_nonzero(expansion_jump)),
            "characteristic_pface": int(np.count_nonzero(characteristic_pface)),
            "hllc_active": int(np.count_nonzero(hllc_active)),
            "round3_guard": int(np.count_nonzero(round3_guard)),
            "round4a_guard": int(np.count_nonzero(round4a_guard)),
            "round5b_guard": int(np.count_nonzero(round5b_guard)),
        },
        "overlap": {
            "round3_material": int(np.count_nonzero(round3_guard & material_jump)),
            "round3_pressure": int(np.count_nonzero(round3_guard & pressure_jump)),
            "round3_expansion": int(np.count_nonzero(round3_guard & expansion_jump)),
            "round4a_material": int(np.count_nonzero(round4a_guard & material_jump)),
            "round4a_pressure": int(np.count_nonzero(round4a_guard & pressure_jump)),
            "round4a_expansion": int(np.count_nonzero(round4a_guard & expansion_jump)),
            "round5b_material": int(np.count_nonzero(round5b_guard & material_jump)),
            "round5b_pressure": int(np.count_nonzero(round5b_guard & pressure_jump)),
        },
        "masks": {
            "material_jump": material_jump,
            "pressure_jump": pressure_jump,
            "expansion_jump": expansion_jump,
            "characteristic_pface": characteristic_pface,
            "hllc_active": hllc_active,
            "round3_guard": round3_guard,
            "round4a_guard": round4a_guard,
            "round5b_guard": round5b_guard,
        },
        "face": {
            "x": face_x,
            "psi_cell": psi,
            "psi_L": psi_L,
            "psi_R": psi_R,
            "psi_face_transport": psi_face_transport,
            "psi_face_acid": psi_face_acid,
            "psi_jump": psi_jump,
            "psi_face_delta": psi_face_delta,
            "rho_ratio": rho_ratio,
            "p_jump_rel": p_jump_rel,
            "du_over_c": du_over_c,
            "theta_k": theta_k,
            "u_bar": u_bar,
            "face_courant": face_courant,
            "theta_acoustic_extra": theta_acoustic_extra,
            "theta_face_corr": theta_face_corr,
            "pface_corr": pface_corr,
            "momentum_pressure_face": momentum_pressure_face,
            "central_pface": p_central,
            "momentum_pressure_face_minus_central": momentum_pressure_delta,
            "rho_face_transport": rho_face_transport,
            "rho_h_face_transport": rho_h_face_transport,
            "rho_e": rho_e,
            "rho_mix_ke": rho_mix_ke,
            "H_acid": H_acid,
            "H_product": H_product,
            "H_acid_minus_product": H_acid_minus_product,
            "H_acid_minus_product_alt": H_acid_minus_product_alt,
            "alpha_flux_div": alpha_flux_div,
            "mass_flux_div": mass_flux_div,
            "temporal_rho": temporal_rho,
        },
        "stats": {
            "rho_ratio": _safe_percentiles(rho_ratio),
            "p_jump_rel": _safe_percentiles(p_jump_rel),
            "du_over_c": _safe_percentiles(du_over_c),
            "theta_k": _safe_percentiles(theta_k),
            "face_courant": _safe_percentiles(face_courant),
            "psi_jump": _safe_percentiles(psi_jump),
            "theta_acoustic_extra": _safe_percentiles(theta_acoustic_extra),
            "theta_face_corr": _safe_percentiles(theta_face_corr),
            "pface_corr": _safe_percentiles(pface_corr),
            "momentum_pressure_face_minus_central": _safe_percentiles(momentum_pressure_delta),
            "rho_e": _safe_percentiles(rho_e),
            "rho_mix_ke": _safe_percentiles(rho_mix_ke),
            "H_acid_minus_product": _safe_percentiles(H_acid_minus_product),
            "alpha_flux_div": _safe_percentiles(alpha_flux_div),
            "mass_flux_div": _safe_percentiles(mass_flux_div),
            "temporal_rho": _safe_percentiles(temporal_rho),
        },
    }


def _case07_region_masks(
    case_name: str,
    audit: dict[str, Any],
    face_x: np.ndarray,
    *,
    t: float | None = None,
) -> dict[str, np.ndarray]:
    x_cells = np.asarray(audit["x"], dtype=float)
    case = next(c for c in CASES_07 if c.name == case_name)
    if t is None:
        p_exact = np.asarray(audit["exact"]["p"], dtype=float)
        u_exact = np.asarray(audit["exact"]["u"], dtype=float)
    else:
        p_exact, u_exact = _exact_07(case, x_cells, float(t))
    p_face = np.interp(face_x, x_cells, p_exact)
    u_face = np.interp(face_x, x_cells, u_exact)
    dp = np.abs(p_face - V_P0)
    du = np.abs(u_face)
    p_thr = max(0.05 * float(np.max(dp)), 1.0e-12)
    u_thr = max(0.05 * float(np.max(du)), 1.0e-12)
    packet_region = (
        (np.abs(p_face - V_P0) >= p_thr)
        | (np.abs(u_face) >= u_thr)
        | (np.abs(face_x - case.x_intf) <= max(8.0 * float(audit["dx"]), 0.02))
    )
    interface_zone = np.abs(face_x - case.x_intf) <= max(10.0 * float(audit["dx"]), 0.03)
    return {"packet_region": packet_region, "interface_zone": interface_zone}


def _case25_region_masks(
    audit: dict[str, Any],
    face_x: np.ndarray,
    *,
    snap: dict[str, Any] | None = None,
) -> dict[str, np.ndarray]:
    x_interface = float(audit["exact_meta"]["x_interface"])
    if snap is None:
        contact_x = float(audit["exact"]["x_contact"])
        shock_x = float(audit["exact"]["x_transmitted_shock"])
    else:
        p = np.asarray(snap["p"], dtype=float)
        psi = np.asarray(snap["psi"], dtype=float)
        x = np.asarray(snap["x"], dtype=float)
        dx = float(audit["dx"])
        contact_x = float(x[int(np.argmax(np.abs(np.gradient(psi, dx))))])
        shock_x = float(x[int(np.argmax(np.abs(np.gradient(p, dx))))])
    dx = float(audit["dx"])
    interface_zone = (
        (np.abs(face_x - x_interface) <= max(8.0 * dx, 0.03))
        | (np.abs(face_x - contact_x) <= max(8.0 * dx, 0.03))
        | (np.abs(face_x - shock_x) <= max(8.0 * dx, 0.03))
    )
    interface_packet = (face_x >= x_interface - 0.05) & (face_x <= shock_x + 0.05)
    return {"interface_zone": interface_zone, "interface_packet": interface_packet}


def _summary_from_audit(entry: dict[str, Any]) -> dict[str, Any]:
    face = entry["face"]
    masks = entry["masks"]
    face_x = np.asarray(face["x"], dtype=float)
    total_faces = int(face_x.size)
    out = {
        "case": entry["case"],
        "subcase": entry.get("subcase"),
        "source": entry["source"],
        "source_complete": bool(entry.get("complete", False)),
        "source_diverged": bool(entry.get("diverged", False)),
        "N": int(entry["x"].size),
        "dx": float(entry["dx"]),
        "dt": float(entry["dt"]),
        "faces_total": total_faces,
        "counts": entry["counts"],
        "overlap": entry["overlap"],
        "stats": entry["stats"],
        "samples": [],
    }
    if entry["case"] == "07":
        regions = _case07_region_masks(entry.get("case_name", entry.get("subcase", "")), entry, face_x)
        out["regions"] = {
            name: {
                "faces": int(np.count_nonzero(mask)),
                "round3_hits": int(np.count_nonzero(masks["round3_guard"] & mask)),
                "round4a_hits": int(np.count_nonzero(masks["round4a_guard"] & mask)),
                "round5b_hits": int(np.count_nonzero(masks["round5b_guard"] & mask)),
            }
            for name, mask in regions.items()
        }
        out["packet_activation"] = {
            region: {
                "round3": bool(np.any(masks["round3_guard"] & mask)),
                "round4a": bool(np.any(masks["round4a_guard"] & mask)),
                "round5b": bool(np.any(masks["round5b_guard"] & mask)),
            }
            for region, mask in regions.items()
        }
    if entry["case"] == "25":
        regions = _case25_region_masks(entry, face_x)
        out["regions"] = {
            name: {
                "faces": int(np.count_nonzero(mask)),
                "round3_hits": int(np.count_nonzero(masks["round3_guard"] & mask)),
                "round4a_hits": int(np.count_nonzero(masks["round4a_guard"] & mask)),
                "round5b_hits": int(np.count_nonzero(masks["round5b_guard"] & mask)),
            }
            for name, mask in regions.items()
        }
        out["interface_activation"] = {
            region: {
                "round3": bool(np.any(masks["round3_guard"] & mask)),
                "round4a": bool(np.any(masks["round4a_guard"] & mask)),
                "round5b": bool(np.any(masks["round5b_guard"] & mask)),
            }
            for region, mask in regions.items()
        }
    return out


def _build_sample_records(audit: dict[str, Any], meta: dict[str, Any]) -> list[dict[str, Any]]:
    samples = []
    raw_samples = audit.get("samples", audit.get("sampled_snapshots", []))
    prev = None
    for snap in raw_samples:
        if "x" not in snap:
            snap = {**snap, "x": audit["x"]}
        rho_arr = snap.get("rho")
        if rho_arr is None:
            rho_arr = compute_mixture_props(
                np.asarray(snap["p"], dtype=float),
                np.asarray(snap["u"], dtype=float),
                np.asarray(snap["T"], dtype=float),
                np.asarray(snap["psi"], dtype=float),
                meta["ph1"],
                meta["ph2"],
            )["rho"]
        snap = {
            "t": float(snap.get("t", 0.0)),
            "x": np.asarray(snap["x"], dtype=float),
            "psi": np.asarray(snap["psi"], dtype=float),
            "T": np.asarray(snap["T"], dtype=float),
            "u": np.asarray(snap["u"], dtype=float),
            "p": np.asarray(snap["p"], dtype=float),
            "rho": np.asarray(rho_arr, dtype=float),
        }
        face_meta = {
            "ph1": meta["ph1"],
            "ph2": meta["ph2"],
            "bc_l": meta["bc_l"],
            "bc_r": meta["bc_r"],
            "dx": meta["dx"],
            "dt": float(max(snap["t"] - float(prev["t"]), 1.0e-300)) if prev is not None else float(meta["dt"]),
            "face_limiter": meta.get("face_limiter", "koren"),
            "velocity_limiter": meta.get("velocity_limiter", "vanalbada"),
        }
        face_audit = _face_audit(snap, face_meta, prev)
        samples.append({
            "t": float(snap["t"]),
            "face": face_audit["face"],
            "counts": face_audit["counts"],
            "stats": face_audit["stats"],
            "overlap": face_audit["overlap"],
            "masks": face_audit["masks"],
        })
        prev = snap
    return samples


def _compare_noop_run(samples_a: list[dict[str, Any]], samples_b: list[dict[str, Any]]) -> dict[str, float]:
    max_abs = {"p": 0.0, "u": 0.0, "T": 0.0, "psi": 0.0}
    for a, b in zip(samples_a, samples_b, strict=False):
        for key in max_abs:
            arr_a = np.asarray(a[key], dtype=float)
            arr_b = np.asarray(b[key], dtype=float)
            max_abs[key] = max(max_abs[key], float(np.max(np.abs(arr_a - arr_b))))
    return max_abs


def _assemble_case_output(audit: dict[str, Any], meta: dict[str, Any], *, note: str = "") -> dict[str, Any]:
    samples = _build_sample_records(audit, meta)
    x_cells = np.asarray(audit["x"], dtype=float)
    dx = float(audit["dx"])
    face_x = np.empty(x_cells.size + 1, dtype=float)
    face_x[0] = float(x_cells[0] - 0.5 * dx)
    face_x[1:-1] = 0.5 * (x_cells[:-1] + x_cells[1:])
    face_x[-1] = float(x_cells[-1] + 0.5 * dx)
    face_counts = {
        "round3": int(sum(s["counts"]["round3_guard"] for s in samples)),
        "round4a": int(sum(s["counts"]["round4a_guard"] for s in samples)),
        "round5b": int(sum(s["counts"]["round5b_guard"] for s in samples)),
        "characteristic_pface": int(sum(s["counts"]["characteristic_pface"] for s in samples)),
        "hllc_active": int(sum(s["counts"]["hllc_active"] for s in samples)),
    }

    failure_locator = {
        "p": None,
        "u": None,
        "interface": None,
    }
    if samples:
        base = samples[0]["face"]
        p0 = np.asarray(audit["samples"][0]["p"], dtype=float) if audit.get("samples") else np.asarray(audit["p"], dtype=float)
        u0 = np.asarray(audit["samples"][0]["u"], dtype=float) if audit.get("samples") else np.asarray(audit["u"], dtype=float)
        psi0 = np.asarray(audit["samples"][0]["psi"], dtype=float) if audit.get("samples") else np.asarray(audit["psi"], dtype=float)
        p_scale = max(float(np.max(np.abs(p0 - np.mean(p0)))), 1.0e-12)
        u_scale = max(float(np.max(np.abs(u0 - np.mean(u0)))), 1.0e-12)
        psi_scale = max(float(np.max(np.abs(np.diff(psi0)))), 1.0e-12)
        for idx, snap in enumerate(audit.get("samples", [])):
            p_amp = float(np.max(np.abs(np.asarray(snap["p"], dtype=float) - np.mean(p0))))
            u_amp = float(np.max(np.abs(np.asarray(snap["u"], dtype=float) - np.mean(u0))))
            psi_jump = float(np.max(np.abs(np.diff(np.asarray(snap["psi"], dtype=float)))))
            if failure_locator["p"] is None and p_amp > 10.0 * p_scale:
                failure_locator["p"] = {"sample_index": idx, "t": float(snap["t"]), "amp": p_amp, "baseline": p_scale}
            if failure_locator["u"] is None and u_amp > 10.0 * u_scale:
                failure_locator["u"] = {"sample_index": idx, "t": float(snap["t"]), "amp": u_amp, "baseline": u_scale}
            if failure_locator["interface"] is None and psi_jump > 10.0 * psi_scale:
                failure_locator["interface"] = {"sample_index": idx, "t": float(snap["t"]), "amp": psi_jump, "baseline": psi_scale}
        if failure_locator["p"] is None:
            failure_locator["p"] = {"sample_index": None, "t": None, "amp": None, "baseline": p_scale}
        if failure_locator["u"] is None:
            failure_locator["u"] = {"sample_index": None, "t": None, "amp": None, "baseline": u_scale}
        if failure_locator["interface"] is None:
            failure_locator["interface"] = {"sample_index": None, "t": None, "amp": None, "baseline": psi_scale}

    out = {
        "case": audit["case"],
        "subcase": audit.get("subcase"),
        "source": audit.get("source"),
        "source_complete": bool(audit.get("complete", False)),
        "source_diverged": bool(audit.get("diverged", False)),
        "metadata": audit.get("metadata", {}),
        "face_counts": face_counts,
        "failure_locator": failure_locator,
        "samples": [],
        "note": note,
    }
    for sample, raw_snap in zip(samples, audit.get("samples", audit.get("sampled_snapshots", [])), strict=False):
        face_stats = sample["stats"]
        sample_out = {
            "t": float(sample["t"]),
            "counts": sample["counts"],
            "overlap": sample["overlap"],
            "stats": face_stats,
            "mask_counts": {
                "material_jump": int(sample["counts"]["material_jump"]),
                "pressure_jump": int(sample["counts"]["pressure_jump"]),
                "expansion_jump": int(sample["counts"]["expansion_jump"]),
                "characteristic_pface": int(sample["counts"]["characteristic_pface"]),
                "hllc_active": int(sample["counts"]["hllc_active"]),
                "round3_guard": int(sample["counts"]["round3_guard"]),
                "round4a_guard": int(sample["counts"]["round4a_guard"]),
                "round5b_guard": int(sample["counts"]["round5b_guard"]),
            },
            "key_face_samples": {
                "round3_faces": [int(i) for i in np.flatnonzero(sample["masks"]["round3_guard"])[:12]],
                "round4a_faces": [int(i) for i in np.flatnonzero(sample["masks"]["round4a_guard"])[:12]],
                "round5b_faces": [int(i) for i in np.flatnonzero(sample["masks"]["round5b_guard"])[:12]],
            },
            "region_hits": {},
            "noop_invariance": None,
        }
        if audit["case"] == "07":
            region_masks = _case07_region_masks(
                audit.get("case_name", audit.get("subcase", "")),
                audit,
                face_x,
                t=float(raw_snap.get("t", sample["t"])) if isinstance(raw_snap, dict) else float(sample["t"]),
            )
            sample_out["region_hits"] = {
                region: {
                    "faces": int(np.count_nonzero(mask)),
                    "round3": int(np.count_nonzero(sample["masks"]["round3_guard"] & mask)),
                    "round4a": int(np.count_nonzero(sample["masks"]["round4a_guard"] & mask)),
                    "round5b": int(np.count_nonzero(sample["masks"]["round5b_guard"] & mask)),
                }
                for region, mask in region_masks.items()
            }
        if audit["case"] == "25":
            region_masks = _case25_region_masks(
                audit,
                face_x,
                snap=raw_snap if isinstance(raw_snap, dict) else None,
            )
            sample_out["region_hits"] = {
                region: {
                    "faces": int(np.count_nonzero(mask)),
                    "round3": int(np.count_nonzero(sample["masks"]["round3_guard"] & mask)),
                    "round4a": int(np.count_nonzero(sample["masks"]["round4a_guard"] & mask)),
                    "round5b": int(np.count_nonzero(sample["masks"]["round5b_guard"] & mask)),
                }
                for region, mask in region_masks.items()
            }
        out["samples"].append(sample_out)
    return out


def _format_summary(all_cases: list[dict[str, Any]]) -> str:
    lines: list[str] = []
    lines.append("Round 6A operator audit")
    for case in all_cases:
        label = f"case{case['case']}"
        if case.get("subcase"):
            label += f" / {case['subcase']}"
        lines.append("")
        lines.append(label)
        lines.append(f"  source: {case.get('source')}")
        lines.append(
            f"  faces active totals: round3={case['face_counts']['round3']}  "
            f"round4A={case['face_counts']['round4a']}  round5B={case['face_counts']['round5b']}"
        )
        lines.append(
            f"  characteristic_pface={case['face_counts']['characteristic_pface']}  hllc_active={case['face_counts']['hllc_active']}"
        )
        fl = case["failure_locator"]
        lines.append(
            "  failure locator: "
            f"p={fl['p']}  u={fl['u']}  interface={fl['interface']}"
        )
        for sample in case["samples"][:4]:
            lines.append(
                f"  t={sample['t']:.6e}  "
                f"round3={sample['counts']['round3_guard']}  round4A={sample['counts']['round4a_guard']}  "
                f"round5B={sample['counts']['round5b_guard']}  "
                f"faceCourant_p95={sample['stats']['face_courant']['p95']:.3e}  "
                f"psiJump_p95={sample['stats']['psi_jump']['p95']:.3e}"
            )
    return "\n".join(lines) + "\n"


def _noop_compare_case(case_a: dict[str, Any], case_b: dict[str, Any]) -> dict[str, float]:
    max_abs = {"p": 0.0, "u": 0.0, "T": 0.0, "psi": 0.0}
    for sa, sb in zip(case_a.get("samples", []), case_b.get("samples", []), strict=False):
        for key in max_abs:
            if key not in sa or key not in sb:
                continue
            max_abs[key] = max(max_abs[key], float(np.max(np.abs(np.asarray(sa[key]) - np.asarray(sb[key])))))
    return max_abs


def main() -> int:
    parser = argparse.ArgumentParser(description="Round 6A operator audit diagnostics")
    parser.add_argument("--cases", default="07,25,24", help="Comma-separated case IDs to audit")
    parser.add_argument("--run-solver", action="store_true", help="Run solver-backed cases 07/25 instead of skipping them")
    parser.add_argument("--case07-all-subcases", action="store_true", help="Run Helium-Air and Argon-Air in addition to Air-Water")
    parser.add_argument("--case07-n", type=int, default=200)
    parser.add_argument("--case25-n", type=int, default=200)
    parser.add_argument("--sample-count", type=int, default=6, help="Sample count for solver-backed runs")
    parser.add_argument("--output-base", default="round6a_operator_audit")
    parser.add_argument("--save-solver-npz", action="store_true", help="Persist solver snapshot npz files under autoresearch-results")
    parser.add_argument("--check-noop", action="store_true", help="Run solver-backed cases twice and compare sampled outputs")
    args = parser.parse_args()

    OUT_DIR.mkdir(parents=True, exist_ok=True)

    requested = [c.strip() for c in str(args.cases).split(",") if c.strip()]
    all_case_outputs: list[dict[str, Any]] = []
    noops: dict[str, Any] = {}

    for cid in requested:
        if cid == "24":
            for psi in (0.25, 0.5, 0.75):
                audit = _load_case24_snapshot(float(psi))
                meta = {
                    "ph1": audit["ph1"],
                    "ph2": audit["ph2"],
                    "bc_l": audit["bc_l"],
                    "bc_r": audit["bc_r"],
                    "dx": audit["dx"],
                    "dt": audit["dt"],
                    "face_limiter": "koren",
                    "velocity_limiter": "vanalbada",
                }
                case_out = _assemble_case_output(audit, meta, note="offline snapshot-backed case24 audit")
                all_case_outputs.append(case_out)
        elif cid == "07":
            if not args.run_solver:
                all_case_outputs.append({
                    "case": "07",
                    "subcase": "Air-Water",
                    "source": "skipped (use --run-solver)",
                    "source_complete": False,
                    "source_diverged": False,
                    "metadata": {},
                    "face_counts": {"round3": 0, "round4a": 0, "round5b": 0, "characteristic_pface": 0, "hllc_active": 0},
                    "failure_locator": {"p": None, "u": None, "interface": None},
                    "samples": [],
                    "note": "solver-backed case skipped",
                })
                continue
            specs = _case07_case_specs()
            if not args.case07_all_subcases:
                specs = [next(c for c in specs if c.name == "Air-Water")]
            for spec in specs:
                audit = _run_case07_subcase(spec, args.case07_n, args.sample_count, OUT_DIR if args.save_solver_npz else None)
                audit["case_name"] = spec.name
                meta = {
                    "ph1": audit["ph1"],
                    "ph2": audit["ph2"],
                    "bc_l": audit["bc_l"],
                    "bc_r": audit["bc_r"],
                    "dx": audit["dx"],
                    "dt": audit["dt"],
                    "face_limiter": "koren",
                    "velocity_limiter": "vanalbada",
                }
                case_out = _assemble_case_output(audit, meta, note="solver-backed case07 audit")
                all_case_outputs.append(case_out)
                if args.check_noop:
                    audit2 = _run_case07_subcase(spec, args.case07_n, args.sample_count, None)
                    noops[f"07/{spec.name}"] = _noop_compare_case(audit, audit2)
        elif cid == "25":
            if not args.run_solver:
                all_case_outputs.append({
                    "case": "25",
                    "subcase": None,
                    "source": "skipped (use --run-solver)",
                    "source_complete": False,
                    "source_diverged": False,
                    "metadata": {},
                    "face_counts": {"round3": 0, "round4a": 0, "round5b": 0, "characteristic_pface": 0, "hllc_active": 0},
                    "failure_locator": {"p": None, "u": None, "interface": None},
                    "samples": [],
                    "note": "solver-backed case skipped",
                })
                continue
            audit = _run_case25(args.case25_n, args.sample_count, OUT_DIR if args.save_solver_npz else None)
            meta = {
                "ph1": audit["ph1"],
                "ph2": audit["ph2"],
                "bc_l": audit["bc_l"],
                "bc_r": audit["bc_r"],
                "dx": audit["dx"],
                "dt": audit["dt"],
                "face_limiter": "koren",
                "velocity_limiter": "vanalbada",
            }
            case_out = _assemble_case_output(audit, meta, note="solver-backed case25 audit")
            all_case_outputs.append(case_out)
            if args.check_noop:
                audit2 = _run_case25(args.case25_n, args.sample_count, None)
                noops["25"] = _noop_compare_case(audit, audit2)

    out = {
        "audit": "round6a_operator_audit",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "cwd": str(ROOT),
        "cases": all_case_outputs,
        "noop_invariance": noops,
    }

    json_path = OUT_DIR / f"{args.output_base}.json"
    txt_path = OUT_DIR / f"{args.output_base}.txt"
    json_path.write_text(json.dumps(_jsonable(out), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    txt_path.write_text(_format_summary(all_case_outputs), encoding="utf-8")
    print(_format_summary(all_case_outputs), end="")
    print(f"[round6a] wrote {json_path}")
    print(f"[round6a] wrote {txt_path}")
    if noops:
        print(f"[round6a] noop invariance: {json.dumps(_jsonable(noops), sort_keys=True)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

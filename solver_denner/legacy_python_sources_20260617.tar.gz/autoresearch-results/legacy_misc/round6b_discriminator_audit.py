#!/usr/bin/env python3
"""Round 6B discriminator audit for denner_1d.

Read-only diagnostic. No solver behavior changes.

This script samples solver-backed states for case07, case25, and case24,
reconstructs local face operators offline, and records per-face rows for the
round4A / round5B candidate faces. It then sweeps a family of offline
discriminator thresholds to see which local conditions would activate.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = ROOT.parent
OUT_DIR = ROOT / "autoresearch-results"

sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(OUT_DIR))

os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("DENNER_DIAG", "1")

import round6a_operator_audit as r6a  # noqa: E402
from solver.denner_1d.boundary import apply_ghost  # noqa: E402
from solver.denner_1d.eos.base import compute_mixture_props  # noqa: E402


def _jsonable(obj: Any) -> Any:
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer, np.bool_)):
        return obj.item()
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return repr(obj)


def _sample_times(t_end: float, sample_count: int) -> list[float]:
    sample_count = max(int(sample_count), 1)
    if sample_count == 1:
        return [float(t_end)]
    return [float(t) for t in np.linspace(float(t_end) / sample_count, float(t_end), sample_count)]


def _scalar_ghost_bc(bc: str) -> str:
    return "wall" if str(bc) == "reflective" else str(bc)


def _centered_face_div(flux: np.ndarray, dx: float) -> np.ndarray:
    flux = np.asarray(flux, dtype=float)
    out = np.zeros_like(flux)
    if flux.size == 0:
        return out
    if flux.size == 1:
        return out
    out[0] = (flux[1] - flux[0]) / max(dx, 1.0e-300)
    out[-1] = (flux[-1] - flux[-2]) / max(dx, 1.0e-300)
    if flux.size > 2:
        out[1:-1] = (flux[2:] - flux[:-2]) / max(2.0 * dx, 1.0e-300)
    return out


def _face_row_rows(case: str, subcase: str | None, step: int, snapshot: dict[str, Any], prev: dict[str, Any] | None, meta: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    face_audit = r6a._face_audit(snapshot, meta, prev)
    face = face_audit["face"]
    masks = face_audit["masks"]
    dx = float(meta["dx"])
    p_arr = np.asarray(snapshot["p"], dtype=float)
    p_ext = apply_ghost(p_arr, _scalar_ghost_bc(meta["bc_l"]), _scalar_ghost_bc(meta["bc_r"]), 2)
    face_left = np.arange(p_arr.size + 1, dtype=int) + 1
    face_right = np.arange(p_arr.size + 1, dtype=int) + 2

    alpha_flux_face = np.asarray(face["psi_face_transport"], dtype=float) * np.asarray(face["theta_k"], dtype=float)
    mass_flux_face = np.asarray(face["rho_face_transport"], dtype=float) * np.asarray(face["theta_k"], dtype=float)
    alpha_flux_div = _centered_face_div(alpha_flux_face, dx)
    mass_flux_div = _centered_face_div(mass_flux_face, dx)
    mass_flux_div_norm = np.abs(mass_flux_div) * dx / np.maximum(np.abs(mass_flux_face), 1.0)

    round3 = np.asarray(masks["round3_guard"], dtype=bool)
    round4a = np.asarray(masks["round4a_guard"], dtype=bool)
    round5b = np.asarray(masks["round5b_guard"], dtype=bool)
    candidate = round4a | round5b

    rows: list[dict[str, Any]] = []
    for f in np.flatnonzero(candidate):
        denom_h = max(abs(float(face["rho_e"][f])) + abs(float(face["momentum_pressure_face"][f])) + abs(float(face["rho_mix_ke"][f])), 1.0)
        denom_p = max(abs(float(p_ext[face_left[f]])), abs(float(p_ext[face_right[f]])), 1.0)
        row = {
            "case": case,
            "subcase": subcase,
            "step": int(step),
            "time": float(snapshot["t"]),
            "face": int(f),
            "x_face": float(face["x"][f]),
            "round3_mask": bool(round3[f]),
            "round4a_mask": bool(round4a[f]),
            "round5b_mask": bool(round5b[f]),
            "material_jump": bool(masks["material_jump"][f]),
            "pressure_jump": bool(masks["pressure_jump"][f]),
            "characteristic_pface": bool(masks["characteristic_pface"][f]),
            "hllc_active": bool(masks["hllc_active"][f]),
            "theta_k": float(face["theta_k"][f]),
            "face_courant": float(face["face_courant"][f]),
            "alpha_flux_div": float(alpha_flux_div[f]),
            "mass_flux_div": float(mass_flux_div[f]),
            "mass_flux_div_norm": float(mass_flux_div_norm[f]),
            "psi_jump": float(face["psi_jump"][f]),
            "rho_ratio": float(face["rho_ratio"][f]),
            "p_jump_rel": float(face["p_jump_rel"][f]),
            "H_acid_minus_product": float(face["H_acid_minus_product"][f]),
            "H_rel": float(abs(float(face["H_acid_minus_product"][f])) / denom_h),
            "pface_corr": float(face["pface_corr"][f]),
            "pface_corr_rel": float(abs(float(face["pface_corr"][f])) / denom_p),
            "rho_e": float(face["rho_e"][f]),
            "p_work": float(face["momentum_pressure_face"][f]),
            "rho_mix_ke": float(face["rho_mix_ke"][f]),
            "candidate_kind": "round5b" if round5b[f] else "round4a",
        }
        rows.append(row)
    return rows, face_audit


def _run_case07(spec: Any, n: int, sample_count: int, output_root: Path | None) -> dict[str, Any]:
    return r6a._run_case07_subcase(spec, n, sample_count, output_root)


def _run_case25(n: int, sample_count: int, output_root: Path | None) -> dict[str, Any]:
    return r6a._run_case25(n, sample_count, output_root)


def _run_case24(psi_water: float, sample_count: int, case24_n: int, case24_cfl: float, output_root: Path | None) -> dict[str, Any]:
    audit = r6a._load_case24_snapshot(float(psi_water))
    samples = list(audit.get("samples", []))
    if sample_count > 0 and len(samples) > sample_count:
        if sample_count == 1:
            samples = [samples[-1]]
        else:
            idx = np.linspace(0, len(samples) - 1, sample_count)
            samples = [samples[int(round(v))] for v in idx]
    audit = dict(audit)
    audit["samples"] = samples
    return audit


def _load_case24_snapshot(psi_water: float) -> dict[str, Any]:
    audit = dict(r6a._load_case24_snapshot(float(psi_water)))
    ph1 = audit["ph1"]
    ph2 = audit["ph2"]
    samples: list[dict[str, Any]] = []
    for snap in audit.get("samples", []):
        snap = dict(snap)
        if "rho" not in snap or np.isscalar(snap.get("rho")):
            psi = np.asarray(snap["psi"], dtype=float)
            p = np.asarray(snap["p"], dtype=float)
            T = np.asarray(snap["T"], dtype=float)
            u = np.asarray(snap["u"], dtype=float)
            props = compute_mixture_props(p, u, T, psi, ph1, ph2)
            snap["rho"] = np.asarray(props["rho"], dtype=float)
        samples.append(snap)
    audit["samples"] = samples
    return audit


def _sweep_rows(rows: list[dict[str, Any]], *, m_min: float | None) -> dict[str, Any]:
    if not rows:
        return {"rows": 0, "sweeps": []}

    rho_ratio = np.asarray([r["rho_ratio"] for r in rows], dtype=float)
    face_courant = np.asarray([r["face_courant"] for r in rows], dtype=float)
    mass_flux_div_norm = np.asarray([r["mass_flux_div_norm"] for r in rows], dtype=float)
    psi_jump = np.asarray([r["psi_jump"] for r in rows], dtype=float)
    H_rel = np.asarray([r["H_rel"] for r in rows], dtype=float)
    pface_corr_rel = np.asarray([r["pface_corr_rel"] for r in rows], dtype=float)
    round4a = np.asarray([r["round4a_mask"] for r in rows], dtype=bool)
    case_keys = [(r["case"], r["subcase"]) for r in rows]

    C_vals = [1, 5, 10, 25]
    psi_caps = [1e-8, 1e-6, 1e-4, 1e-3, 1e-2, 5e-2]
    H_caps = [1e-6, 1e-5, 1e-4, 1e-3]
    P_caps = [1e-10, 1e-8, 1e-6]

    out: list[dict[str, Any]] = []
    for C_min in C_vals:
        for psi_cap in psi_caps:
            for H_cap in H_caps:
                for P_cap in P_caps:
                    gate = round4a & (rho_ratio <= 50.0)
                    if m_min is None:
                        gate = gate & (face_courant > float(C_min))
                    else:
                        gate = gate & ((face_courant > float(C_min)) | (np.abs(mass_flux_div_norm) > float(m_min)))
                    gate = gate & (psi_jump <= float(psi_cap)) & (H_rel <= float(H_cap)) & (pface_corr_rel <= float(P_cap))
                    total = int(np.count_nonzero(gate))
                    active_steps = {}
                    for key in sorted(set(case_keys)):
                        key_mask = np.array([ck == key for ck in case_keys], dtype=bool)
                        active_steps[f"{key[0]}/{key[1] or ''}".rstrip("/")] = int(np.count_nonzero(gate & key_mask))
                    out.append(
                        {
                            "C_min": C_min,
                            "psi_cap": psi_cap,
                            "H_cap": H_cap,
                            "P_cap": P_cap,
                            "M_min": m_min,
                            "rows_active": total,
                            "rows_total": int(len(rows)),
                            "active_pct": float(100.0 * total / max(len(rows), 1)),
                            "by_case": active_steps,
                        }
                    )
    return {
        "rows": int(len(rows)),
        "mass_flux_div_norm": {
            "mean": float(np.mean(np.abs(mass_flux_div_norm))),
            "p95": float(np.percentile(np.abs(mass_flux_div_norm), 95)),
            "p99": float(np.percentile(np.abs(mass_flux_div_norm), 99)),
            "max": float(np.max(np.abs(mass_flux_div_norm))),
        },
        "sweeps": out,
    }


def _rows_to_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fieldnames = [
        "case", "subcase", "step", "time", "face", "x_face",
        "round3_mask", "round4a_mask", "round5b_mask",
        "material_jump", "pressure_jump", "characteristic_pface", "hllc_active",
        "theta_k", "face_courant", "alpha_flux_div", "mass_flux_div", "mass_flux_div_norm",
        "psi_jump", "rho_ratio", "p_jump_rel",
        "H_acid_minus_product", "H_rel",
        "pface_corr", "pface_corr_rel",
        "rho_e", "p_work", "rho_mix_ke",
        "candidate_kind",
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k) for k in fieldnames})


def _format_text(summary: dict[str, Any]) -> str:
    lines = ["Round 6B discriminator audit"]
    lines.append(f"rows_total={summary['rows_total']}  rows_candidate={summary['rows_candidate']}")
    lines.append(
        f"mass_flux_div_norm: mean={summary['mass_flux_div_norm']['mean']:.3e} "
        f"p95={summary['mass_flux_div_norm']['p95']:.3e} "
        f"p99={summary['mass_flux_div_norm']['p99']:.3e} "
        f"max={summary['mass_flux_div_norm']['max']:.3e}"
    )
    for item in summary["cases"]:
        lines.append("")
        lines.append(f"case{item['case']} / {item.get('subcase')}")
        lines.append(f"  rows={item['rows']}  candidate_rows={item['candidate_rows']}")
        lines.append(
            f"  active_steps@canonical={item['canonical_gate']['active_steps']}  "
            f"active_rows@canonical={item['canonical_gate']['active_rows']}"
        )
        lines.append(
            f"  round4a_rows={item['round4a_rows']}  round5b_rows={item['round5b_rows']}"
        )
        lines.append(
            f"  canonical_thresholds: C_min={item['canonical_gate']['C_min']} psi_cap={item['canonical_gate']['psi_cap']} "
            f"H_cap={item['canonical_gate']['H_cap']} P_cap={item['canonical_gate']['P_cap']} "
            f"M_min={item['canonical_gate']['M_min']}"
        )
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Round 6B discriminator audit")
    parser.add_argument("--cases", default="07,25,24", help="Comma-separated case IDs to audit")
    parser.add_argument("--offline", action="store_true", help="Skip solver-backed runs and analyze existing snapshots only")
    parser.add_argument("--case07-all-subcases", action="store_true", help="Run Helium-Air and Argon-Air in addition to Air-Water")
    parser.add_argument("--case07-n", type=int, default=200)
    parser.add_argument("--case25-n", type=int, default=200)
    parser.add_argument("--case24-n", type=int, default=100)
    parser.add_argument("--case24-cfl", type=float, default=0.4)
    parser.add_argument("--sample-count", type=int, default=6)
    parser.add_argument("--psi-values", default="0.25,0.5,0.75")
    parser.add_argument("--m-min", type=float, default=None, help="Optional normalized mass-flux divergence threshold")
    parser.add_argument("--output-base", default="round6b_discriminator_audit")
    parser.add_argument("--save-solver-npz", action="store_true", help="Persist solver snapshots under autoresearch-results")
    args = parser.parse_args()

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    requested = [c.strip() for c in str(args.cases).split(",") if c.strip()]
    psi_values = [float(p.strip()) for p in str(args.psi_values).split(",") if p.strip()]

    all_rows: list[dict[str, Any]] = []
    cases_out: list[dict[str, Any]] = []

    for cid in requested:
        if cid == "07":
            if args.offline:
                continue
            specs = list(r6a._case07_case_specs())
            if not args.case07_all_subcases:
                specs = [next(s for s in specs if s.name == "Air-Water")]
            for spec in specs:
                audit = _run_case07(spec, args.case07_n, args.sample_count, OUT_DIR if args.save_solver_npz else None)
                samples = audit.get("samples", [])
                prev = None
                case_rows: list[dict[str, Any]] = []
                for step, snap in enumerate(samples):
                    dt = float(snap["t"] - prev["t"]) if prev is not None else float(audit["dt"])
                    meta = {
                        "ph1": audit["ph1"], "ph2": audit["ph2"], "bc_l": audit["bc_l"], "bc_r": audit["bc_r"],
                        "dx": float(audit["dx"]), "dt": dt, "face_limiter": "koren", "velocity_limiter": "vanalbada",
                    }
                    rows, _ = _face_row_rows("07", spec.name, step, snap, prev, meta)
                    case_rows.extend(rows)
                    prev = snap
                all_rows.extend(case_rows)
                cases_out.append(_case_case_summary("07", spec.name, case_rows, args.m_min))
        elif cid == "25":
            if args.offline:
                continue
            audit = _run_case25(args.case25_n, args.sample_count, OUT_DIR if args.save_solver_npz else None)
            samples = audit.get("samples", [])
            prev = None
            case_rows: list[dict[str, Any]] = []
            for step, snap in enumerate(samples):
                dt = float(snap["t"] - prev["t"]) if prev is not None else float(audit["dt"])
                meta = {
                    "ph1": audit["ph1"], "ph2": audit["ph2"], "bc_l": audit["bc_l"], "bc_r": audit["bc_r"],
                    "dx": float(audit["dx"]), "dt": dt, "face_limiter": "koren", "velocity_limiter": "vanalbada",
                }
                rows, _ = _face_row_rows("25", None, step, snap, prev, meta)
                case_rows.extend(rows)
                prev = snap
            all_rows.extend(case_rows)
            cases_out.append(_case_case_summary("25", None, case_rows, args.m_min))
        elif cid == "24":
            for psi in psi_values:
                if args.offline:
                    audit = _load_case24_snapshot(psi)
                    samples = list(audit.get("samples", [])) or [audit]
                else:
                    audit = _run_case24(psi, args.sample_count, args.case24_n, args.case24_cfl, OUT_DIR if args.save_solver_npz else None)
                    samples = audit.get("samples", [])
                prev = None
                case_rows: list[dict[str, Any]] = []
                for step, snap in enumerate(samples):
                    dt = float(snap["t"] - prev["t"]) if prev is not None else float(audit["dt"])
                    meta = {
                        "ph1": audit["ph1"], "ph2": audit["ph2"], "bc_l": audit["bc_l"], "bc_r": audit["bc_r"],
                        "dx": float(audit["dx"]), "dt": dt, "face_limiter": "koren", "velocity_limiter": "vanalbada",
                    }
                    rows, _ = _face_row_rows("24", f"psi_water={psi:g}", step, snap, prev, meta)
                    case_rows.extend(rows)
                    prev = snap
                all_rows.extend(case_rows)
                cases_out.append(_case_case_summary("24", f"psi_water={psi:g}", case_rows, args.m_min))

    all_sweeps = _sweep_rows(all_rows, m_min=args.m_min)
    summary = {
        "audit": "round6b_discriminator_audit",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "cwd": str(ROOT),
        "rows_total": int(len(all_rows)),
        "rows_candidate": int(sum(1 for r in all_rows if r["round4a_mask"] or r["round5b_mask"])),
        "mass_flux_div_norm": all_sweeps["mass_flux_div_norm"],
        "cases": cases_out,
        "sweeps": all_sweeps["sweeps"],
        "m_min": args.m_min,
    }

    json_path = OUT_DIR / f"{args.output_base}.json"
    csv_path = OUT_DIR / f"{args.output_base}.csv"
    txt_path = OUT_DIR / f"{args.output_base}.txt"
    json_path.write_text(json.dumps(_jsonable(summary), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    _rows_to_csv(csv_path, all_rows)
    txt_path.write_text(_format_text(summary), encoding="utf-8")
    print(_format_text(summary), end="")
    print(f"[round6b] wrote {json_path}")
    print(f"[round6b] wrote {csv_path}")
    print(f"[round6b] wrote {txt_path}")
    return 0


def _case_case_summary(case: str, subcase: str | None, rows: list[dict[str, Any]], m_min: float | None) -> dict[str, Any]:
    round4a_rows = int(sum(1 for r in rows if r["round4a_mask"]))
    round5b_rows = int(sum(1 for r in rows if r["round5b_mask"]))
    canonical_gate = {
        "C_min": 10,
        "psi_cap": 1e-4,
        "H_cap": 1e-4,
        "P_cap": 1e-8,
        "M_min": m_min,
    }
    gate = []
    for r in rows:
        ok = (
            r["round4a_mask"]
            and r["rho_ratio"] <= 50.0
            and (
                r["face_courant"] > canonical_gate["C_min"]
                or (m_min is not None and abs(r["mass_flux_div_norm"]) > m_min)
            )
            and r["psi_jump"] <= canonical_gate["psi_cap"]
            and r["H_rel"] <= canonical_gate["H_cap"]
            and r["pface_corr_rel"] <= canonical_gate["P_cap"]
        )
        gate.append(bool(ok))
    gate = np.asarray(gate, dtype=bool)
    steps = sorted(set((r["step"], r["time"]) for r in rows))
    active_steps = int(sum(1 for step, _ in steps if np.any(gate[np.array([r["step"] == step for r in rows], dtype=bool)])))
    return {
        "case": case,
        "subcase": subcase,
        "rows": int(len(rows)),
        "candidate_rows": int(sum(1 for r in rows if r["round4a_mask"] or r["round5b_mask"])),
        "round4a_rows": round4a_rows,
        "round5b_rows": round5b_rows,
        "canonical_gate": {
            **canonical_gate,
            "active_rows": int(np.count_nonzero(gate)),
            "active_steps": active_steps,
        },
    }


if __name__ == "__main__":
    raise SystemExit(main())

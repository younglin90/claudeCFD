#!/usr/bin/env python3
"""Round 8 amplitude audit for denner_1d.

Diagnostic only.  No solver behavior changes.

This script uses solver-backed case07 runs with DENNER_CASE07_AMP_AUDIT=1
to collect per-step residual history and compares the off/on runs for
no-op invariance.  It also audits per-face reconstructed/transported
quantities for case07 and case24 using the existing face-audit helpers.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = ROOT.parent
OUT_DIR = ROOT / "autoresearch-results"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(OUT_DIR))

import round6a_operator_audit as r6a  # noqa: E402
from solver.denner_1d.boundary import apply_ghost, apply_ghost_velocity  # noqa: E402
from solver.denner_1d.eos.base import compute_mixture_props  # noqa: E402
from solver.denner_1d.interface.cicsam import cicsam_face, cicsam_face_beta  # noqa: E402
from solver.denner_1d.main import run as denner_run  # noqa: E402


@contextmanager
def _env_var(name: str, value: str | None):
    old = os.environ.get(name)
    if value is None:
        os.environ.pop(name, None)
    else:
        os.environ[name] = value
    try:
        yield
    finally:
        if old is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = old


def _jsonable(obj: Any) -> Any:
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer, np.bool_)):
        return obj.item()
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return repr(obj)


def _sample_times(t_end: float, sample_count: int) -> list[float]:
    sample_count = max(int(sample_count), 1)
    if sample_count == 1:
        return [float(t_end)]
    return [float(t) for t in np.linspace(float(t_end) / sample_count, float(t_end), sample_count)]


def _normalize_bc(bc: str) -> str:
    return "wall" if bc == "reflective" else bc


def _tv(arr: np.ndarray) -> float:
    arr = np.asarray(arr, dtype=float)
    if arr.size < 2:
        return 0.0
    return float(np.sum(np.abs(np.diff(arr))))


def _local_tv(arr: np.ndarray, window: int = 9) -> float:
    arr = np.asarray(arr, dtype=float)
    if arr.size < 2:
        return 0.0
    grad_idx = int(np.argmax(np.abs(np.diff(arr)))) if arr.size > 2 else 0
    lo = max(0, grad_idx - window // 2)
    hi = min(arr.size, lo + window)
    lo = max(0, hi - window)
    return float(np.sum(np.abs(np.diff(arr[lo:hi]))))


def _run_case07(spec: Any, n: int, sample_count: int, audit_on: bool) -> dict[str, Any]:
    env_val = "1" if audit_on else "0"
    with _env_var("DENNER_CASE07_AMP_AUDIT", env_val):
        return r6a._run_case07_subcase(spec, n, sample_count, OUT_DIR if audit_on else None)


def _run_case24_snapshot(psi_water: float) -> dict[str, Any]:
    audit = dict(r6a._load_case24_snapshot(float(psi_water)))
    samples: list[dict[str, Any]] = []
    ph1 = audit["ph1"]
    ph2 = audit["ph2"]
    for snap in audit.get("samples", []):
        snap = dict(snap)
        if "rho" not in snap or np.isscalar(snap.get("rho")):
            props = compute_mixture_props(
                np.asarray(snap["p"], dtype=float),
                np.asarray(snap["u"], dtype=float),
                np.asarray(snap["T"], dtype=float),
                np.asarray(snap["psi"], dtype=float),
                ph1,
                ph2,
            )
            snap["rho"] = np.asarray(props["rho"], dtype=float)
        samples.append(snap)
    audit["samples"] = samples
    return audit


def _state_compare(off: dict[str, Any], on: dict[str, Any]) -> dict[str, float]:
    keys = ["p", "u", "T", "psi", "rho"]
    out: dict[str, float] = {}
    for key in keys:
        a = np.asarray(off[key], dtype=float)
        b = np.asarray(on[key], dtype=float)
        out[f"max_abs_delta_{key}"] = float(np.max(np.abs(a - b))) if a.size and b.size else 0.0
    t_off = float(off.get("metadata", {}).get("t_end", off.get("samples", [{}])[-1].get("t", 0.0)))
    t_on = float(on.get("metadata", {}).get("t_end", on.get("samples", [{}])[-1].get("t", 0.0)))
    out["max_abs_delta_t"] = float(abs(t_off - t_on))
    return out


def _residual_growth(audit: dict[str, Any] | None) -> dict[str, Any]:
    if not audit or not audit.get("steps"):
        return {"found": False, "step": None, "time": None, "residuals": []}
    for step in audit["steps"]:
        residuals = [float(v) for v in step.get("residuals", [])]
        for idx in range(len(residuals) - 1):
            if residuals[idx + 1] > residuals[idx] * 1.01:
                return {
                    "found": True,
                    "step": int(step["step"]),
                    "time": float(step["t"]),
                    "growth_from": idx,
                    "growth_to": idx + 1,
                    "residuals": residuals,
                }
    return {"found": False, "step": None, "time": None, "residuals": []}


def _face_rows(case: str, subcase: str | None, step: int, snap: dict[str, Any], prev: dict[str, Any] | None, meta: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    face_audit = r6a._face_audit(snap, meta, prev)
    face = face_audit["face"]
    masks = face_audit["masks"]

    x = np.asarray(snap["x"], dtype=float)
    psi = np.asarray(snap["psi"], dtype=float)
    T = np.asarray(snap["T"], dtype=float)
    u = np.asarray(snap["u"], dtype=float)
    p = np.asarray(snap["p"], dtype=float)
    rho = np.asarray(snap["rho"], dtype=float)
    dx = float(meta["dx"])
    dt = float(meta["dt"])

    bc_l = _normalize_bc(meta["bc_l"])
    bc_r = _normalize_bc(meta["bc_r"])
    psi_ext = apply_ghost(psi, bc_l, bc_r, 2)
    u_ext = apply_ghost_velocity(u, bc_l, bc_r, 2)
    p_ext = apply_ghost(p, bc_l, bc_r, 2)
    rho_ext = apply_ghost(rho, bc_l, bc_r, 2)
    T_ext = apply_ghost(T, bc_l, bc_r, 2)

    theta_k = np.asarray(face["theta_k"], dtype=float)
    beta_k = cicsam_face_beta(psi_ext, theta_k, dt, dx, n_ghost=2)
    psi_face_reconstructed = cicsam_face(psi_ext, theta_k, dt, dx, n_ghost=2)

    pL_rec, pR_rec = r6a._tvd_face_states(p, bc_l, bc_r, kind=meta.get("face_limiter", "koren"))
    uL_rec, uR_rec = r6a._tvd_face_states(u, bc_l, bc_r, kind=meta.get("velocity_limiter", "vanalbada"), velocity=True)
    TL_rec, TR_rec = r6a._tvd_face_states(T, bc_l, bc_r, kind=meta.get("face_limiter", "koren"))

    face_rows: list[dict[str, Any]] = []
    candidate = np.asarray(masks["round4a_guard"], dtype=bool) | np.asarray(masks["round5b_guard"], dtype=bool)
    face_ids = np.flatnonzero(candidate)
    for f in face_ids:
        iL = int(max(f - 1, 0))
        iR = int(min(f, x.size - 1))
        recon_jump_psi = float(abs(psi_face_reconstructed[f] - face["psi_face_transport"][f]))
        recon_jump_p = float(abs(pR_rec[f] - pL_rec[f]))
        recon_jump_u = float(abs(uR_rec[f] - uL_rec[f]))
        psi_lo = float(min(psi_ext[f + 1], psi_ext[f + 2]))
        psi_hi = float(max(psi_ext[f + 1], psi_ext[f + 2]))
        p_lo = float(min(p_ext[f + 1], p_ext[f + 2]))
        p_hi = float(max(p_ext[f + 1], p_ext[f + 2]))
        u_lo = float(min(u_ext[f + 1], u_ext[f + 2]))
        u_hi = float(max(u_ext[f + 1], u_ext[f + 2]))
        psi_face_transport = float(face["psi_face_transport"][f])
        pface_corr = float(face["pface_corr"][f])
        pface_corr_rel = float(abs(pface_corr) / max(abs(float(p_ext[f + 1])), abs(float(p_ext[f + 2])), 1.0))
        H_rel = float(
            abs(face["H_acid_minus_product"][f])
            / max(
                abs(float(face["rho_e"][f]))
                + abs(float(face["momentum_pressure_face"][f]))
                + abs(float(face["rho_mix_ke"][f])),
                1.0,
            )
        )
        residual_proxy = float(
            abs(face["H_acid_minus_product"][f])
            + abs(face["pface_corr"][f])
            + abs(face["theta_face_corr"][f])
            + abs(face["alpha_flux_div"][f])
            + abs(face["mass_flux_div"][f])
        )
        row = {
            "case": case,
            "subcase": subcase,
            "step": int(step),
            "time": float(snap["t"]),
            "dt": float(dt),
            "face": int(f),
            "x_face": float(face["x"][f]),
            "round3_mask": bool(masks["round3_guard"][f]),
            "round4a_mask": bool(masks["round4a_guard"][f]),
            "round5b_mask": bool(masks["round5b_guard"][f]),
            "material_jump": bool(masks["material_jump"][f]),
            "pressure_jump": bool(masks["pressure_jump"][f]),
            "characteristic_pface": bool(masks["characteristic_pface"][f]),
            "theta_flux_k": float(theta_k[f]),
            "psi_face_transport": psi_face_transport,
            "psi_face_reconstructed": float(psi_face_reconstructed[f]),
            "pface_corr": pface_corr,
            "p_work": float(face["momentum_pressure_face"][f]),
            "residual_contrib_mag": residual_proxy,
            "limiter_beta": float(beta_k[f]),
            "face_courant": float(face["face_courant"][f]),
            "psi_jump": float(face["psi_jump"][f]),
            "rho_ratio": float(face["rho_ratio"][f]),
            "p_jump_rel": float(face["p_jump_rel"][f]),
            "H_rel": H_rel,
            "mass_flux_div": float(face["mass_flux_div"][f]),
            "mass_flux_div_norm": float(abs(face["mass_flux_div"][f]) * dx / max(abs(face["theta_k"][f]), 1.0)),
            "pface_corr_rel": pface_corr_rel,
            "max_psi_jump": recon_jump_psi,
            "max_p_jump": recon_jump_p,
            "max_u_jump": recon_jump_u,
            "psi_outside_cell_bounds": bool(psi_face_reconstructed[f] < psi_lo or psi_face_reconstructed[f] > psi_hi),
            "p_outside_cell_bounds": bool(pL_rec[f] < p_lo or pR_rec[f] > p_hi),
            "u_outside_cell_bounds": bool(uL_rec[f] < u_lo or uR_rec[f] > u_hi),
            "pL": float(p_ext[f + 1]),
            "pR": float(p_ext[f + 2]),
            "uL": float(u_ext[f + 1]),
            "uR": float(u_ext[f + 2]),
            "rhoL": float(rho_ext[f + 1]),
            "rhoR": float(rho_ext[f + 2]),
            "TL": float(T_ext[f + 1]),
            "TR": float(T_ext[f + 2]),
            "psiL": float(psi_ext[f + 1]),
            "psiR": float(psi_ext[f + 2]),
            "psi_face_transport_delta": recon_jump_psi,
            "cicsam_beta": float(beta_k[f]),
        }
        face_rows.append(row)

    sample_summary = {
        "rows": int(len(face_rows)),
        "round4a_rows": int(np.count_nonzero(np.asarray(masks["round4a_guard"], dtype=bool))),
        "round5b_rows": int(np.count_nonzero(np.asarray(masks["round5b_guard"], dtype=bool))),
        "max_recon_psi_jump": float(np.max(np.abs(psi_face_reconstructed - face["psi_face_transport"])) if face_ids.size else 0.0),
        "max_recon_p_jump": float(np.max(np.abs(pR_rec - pL_rec)) if face_ids.size else 0.0),
        "max_recon_u_jump": float(np.max(np.abs(uR_rec - uL_rec)) if face_ids.size else 0.0),
        "max_beta": float(np.max(beta_k) if beta_k.size else 0.0),
        "p95_mass_flux_div": float(np.percentile(np.abs(face["mass_flux_div"]), 95)),
        "p99_mass_flux_div": float(np.percentile(np.abs(face["mass_flux_div"]), 99)),
        "p95_theta_flux_k": float(np.percentile(np.abs(theta_k), 95)),
        "p99_theta_flux_k": float(np.percentile(np.abs(theta_k), 99)),
        "p95_pface_corr_rel": float(np.percentile([r["pface_corr_rel"] for r in face_rows], 95) if face_rows else 0.0),
        "p99_pface_corr_rel": float(np.percentile([r["pface_corr_rel"] for r in face_rows], 99) if face_rows else 0.0),
        "p95_H_rel": float(np.percentile([r["H_rel"] for r in face_rows], 95) if face_rows else 0.0),
        "p99_H_rel": float(np.percentile([r["H_rel"] for r in face_rows], 99) if face_rows else 0.0),
        "count_psi_outside": int(sum(1 for r in face_rows if r["psi_outside_cell_bounds"])),
        "count_p_extrema": int(sum(1 for r in face_rows if r["p_outside_cell_bounds"])),
        "count_u_extrema": int(sum(1 for r in face_rows if r["u_outside_cell_bounds"])),
    }
    return face_rows, sample_summary


def _audit_case07(spec: Any, n: int, sample_count: int) -> dict[str, Any]:
    off = _run_case07(spec, n, sample_count, audit_on=False)
    on = _run_case07(spec, n, sample_count, audit_on=True)
    compare = _state_compare(off, on)
    rows: list[dict[str, Any]] = []
    sample_summaries: list[dict[str, Any]] = []
    prev = None
    for step, snap in enumerate(on["samples"]):
        dt = float(snap["t"] - prev["t"]) if prev is not None else float(on["dt"])
        meta = {
            "ph1": on["ph1"],
            "ph2": on["ph2"],
            "bc_l": on["bc_l"],
            "bc_r": on["bc_r"],
            "dx": float(on["dx"]),
            "dt": dt,
            "face_limiter": "koren",
            "velocity_limiter": "vanalbada",
        }
        face_rows, summary = _face_rows("07", spec.name, step, snap, prev, meta)
        rows.extend(face_rows)
        sample_summaries.append({"step": step, "time": float(snap["t"]), "summary": summary})
        prev = snap
    return {
        "case": "07",
        "subcase": spec.name,
        "off": off,
        "on": on,
        "compare": compare,
        "residual_growth": _residual_growth(on.get("audit")),
        "rows": rows,
        "samples": sample_summaries,
    }


def _audit_case24(psi_water: float, sample_count: int) -> dict[str, Any]:
    audit = _run_case24_snapshot(psi_water)
    samples = list(audit.get("samples", []))
    prev = None
    rows: list[dict[str, Any]] = []
    summaries: list[dict[str, Any]] = []
    for step, snap in enumerate(samples):
        dt = float(snap["t"] - prev["t"]) if prev is not None else float(audit["dt"])
        meta = {
            "ph1": audit["ph1"],
            "ph2": audit["ph2"],
            "bc_l": audit["bc_l"],
            "bc_r": audit["bc_r"],
            "dx": float(audit["dx"]),
            "dt": dt,
            "face_limiter": "koren",
            "velocity_limiter": "vanalbada",
        }
        face_rows, summary = _face_rows("24", f"psi_water={psi_water:g}", step, snap, prev, meta)
        rows.extend(face_rows)
        summaries.append({"step": step, "time": float(snap["t"]), "summary": summary})
        prev = snap
    return {
        "case": "24",
        "subcase": f"psi_water={psi_water:g}",
        "source": audit.get("source"),
        "rows": rows,
        "samples": summaries,
        "metadata": audit.get("metadata", {}),
    }


def _rows_to_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fieldnames = list(rows[0].keys()) if rows else []
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k) for k in fieldnames})


def _format_text(summary: dict[str, Any]) -> str:
    lines = ["Round 8 amplitude audit"]
    lines.append(f"generated_at={summary['generated_at']}")
    lines.append(f"rows_total={summary['rows_total']} rows_case07={summary['rows_case07']} rows_case24={summary['rows_case24']}")
    lines.append(f"case07_max_off_on_delta={summary['case07_max_off_on_delta']:.3e}")
    for case in summary["cases"]:
        lines.append("")
        lines.append(f"{case['case']} / {case.get('subcase')}")
        if case["case"] == "07":
            lines.append(
                f"  compare: max|Δp|={case['compare']['max_abs_delta_p']:.3e} "
                f"max|Δu|={case['compare']['max_abs_delta_u']:.3e} "
                f"max|ΔT|={case['compare']['max_abs_delta_T']:.3e} "
                f"max|Δpsi|={case['compare']['max_abs_delta_psi']:.3e}"
            )
            lines.append(
                f"  audit_residual_growth: found={case['residual_growth']['found']} "
                f"step={case['residual_growth']['step']} time={case['residual_growth']['time']}"
            )
        else:
            lines.append(f"  rows={len(case['rows'])}")
            if case["samples"]:
                first = case["samples"][0]["summary"]
                lines.append(
                    f"  sample0: rows={first['rows']} beta_max={first['max_beta']:.3e} "
                    f"psi_jump_max={first['max_recon_psi_jump']:.3e} "
                    f"p95(H_rel)={first['p95_H_rel']:.3e}"
                )
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Round 8 amplitude audit")
    parser.add_argument("--cases", default="07,24", help="Comma-separated case IDs to audit")
    parser.add_argument("--case07-all-subcases", action="store_true", help="Include Helium-Air and Argon-Air")
    parser.add_argument("--case07-n", type=int, default=200)
    parser.add_argument("--case24-psi", default="0.25,0.5")
    parser.add_argument("--sample-count", type=int, default=4)
    parser.add_argument("--output-base", default="round8_amp_audit")
    args = parser.parse_args()

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    requested = [c.strip() for c in str(args.cases).split(",") if c.strip()]
    psi_values = [float(v.strip()) for v in str(args.case24_psi).split(",") if v.strip()]

    cases_out: list[dict[str, Any]] = []
    all_rows: list[dict[str, Any]] = []
    case07_off_on_delta = 0.0

    for cid in requested:
        if cid == "07":
            specs = list(r6a._case07_case_specs())
            if not args.case07_all_subcases:
                specs = [next(s for s in specs if s.name == "Air-Water")]
            for spec in specs:
                audit = _audit_case07(spec, args.case07_n, args.sample_count)
                cases_out.append(audit)
                case07_off_on_delta = max(case07_off_on_delta, float(max(audit["compare"].values())))
                all_rows.extend(audit["rows"])
        elif cid == "24":
            for psi in psi_values:
                audit = _audit_case24(psi, args.sample_count)
                cases_out.append(audit)
                all_rows.extend(audit["rows"])

    summary = {
        "audit": "round8_amp_audit",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "cwd": str(ROOT),
        "rows_total": int(len(all_rows)),
        "rows_case07": int(sum(len(c.get("rows", [])) for c in cases_out if c["case"] == "07")),
        "rows_case24": int(sum(len(c.get("rows", [])) for c in cases_out if c["case"] == "24")),
        "case07_max_off_on_delta": float(case07_off_on_delta),
        "cases": cases_out,
    }

    json_path = OUT_DIR / f"{args.output_base}.json"
    csv_path = OUT_DIR / f"{args.output_base}.csv"
    txt_path = OUT_DIR / f"{args.output_base}.txt"
    json_path.write_text(json.dumps(_jsonable(summary), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if all_rows:
        _rows_to_csv(csv_path, all_rows)
    else:
        csv_path.write_text("", encoding="utf-8")
    txt_path.write_text(_format_text(summary), encoding="utf-8")
    print(_format_text(summary), end="")
    print(f"[round8] wrote {json_path}")
    print(f"[round8] wrote {csv_path}")
    print(f"[round8] wrote {txt_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

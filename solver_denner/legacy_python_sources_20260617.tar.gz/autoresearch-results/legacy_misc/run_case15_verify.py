#!/usr/bin/env python3
import json, os, subprocess, sys
from pathlib import Path
out_path = Path('autoresearch-results/iterations/latest_case15_verify_stdout.txt')
out_path.parent.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
env.setdefault('PYTHONDONTWRITEBYTECODE','1')
env.setdefault('DENNER_CASE_BUDGET_SEC','1200')
cmd = ['timeout','1300s','python3','results/run_denner1d_17case.py','--worker','15']
proc = subprocess.run(cmd, cwd=Path.cwd(), env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
out_path.write_text(proc.stdout)
sys.stdout.write(proc.stdout)
payload = None
for line in proc.stdout.splitlines()[::-1]:
    if line.startswith('CASE_JSON '):
        payload = json.loads(line[len('CASE_JSON '):])
        break
if payload is None:
    payload = {'p_profile_l2': 999.0, 'p_corr': -1.0, 'u_profile_l2': 999.0, 'rho_profile_l2': 999.0, 'u_corr': -1.0, 'rho_corr': -1.0, 'pass_numeric': 0, 'finite_numeric': 0, 'complete_numeric': 0}
else:
    payload = {k:v for k,v in payload.items() if isinstance(v,(int,float,bool))}
    for k in list(payload):
        if isinstance(payload[k], bool):
            payload[k + '_numeric'] = 1 if payload[k] else 0
            del payload[k]
print(json.dumps(payload, sort_keys=True))
sys.exit(proc.returncode)

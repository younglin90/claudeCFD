#!/usr/bin/env python3
"""Case24 verify helper for codex-autoresearch.
Runs validation 24_H and emits final JSON metrics on the last line.
"""
from __future__ import annotations
import json, os, re, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
N = int(os.environ.get("DENNER_CASE24_N", "100"))
CFL = float(os.environ.get("DENNER_CASE24_CFL", "0.4"))
TIMEOUT = float(os.environ.get("DENNER_CASE24_TIMEOUT", "1000"))
cmd = [sys.executable, "results/run_denner1d_17case.py", "--only", "24", "--json"]
env = os.environ.copy()
env.setdefault("PYTHONDONTWRITEBYTECODE", "1")
env.setdefault("MPLBACKEND", "Agg")
env.setdefault("DENNER_CASE_BUDGET_SEC", str(int(TIMEOUT)))
env["DENNER_CASE24_N"] = str(N)
env["DENNER_CASE24_CFL"] = str(CFL)
start = time.time()
proc = subprocess.run(cmd, cwd=ROOT, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=TIMEOUT)
wall = time.time() - start
out = proc.stdout
logdir = ROOT / "results" / "1D" / "24_H"
logdir.mkdir(parents=True, exist_ok=True)
(logdir / f"verify_N{N}_CFL{str(CFL).replace('.', 'p')}.log").write_text(out)
match = re.search(r"DETAILS_JSON\s+(\[.*\])", out, re.S)
if not match:
    metrics = {"pass_numeric": 0, "failures": 999, "score": 999.0, "returncode": proc.returncode, "wall": wall, "N": N, "CFL": CFL, "parse_ok_numeric": 0}
    print(out[-4000:])
    print(json.dumps(metrics, sort_keys=True))
    sys.exit(0)
try:
    details = json.loads(match.group(1))
    case = details[0]
    subs = case.get("subcases", [])
except Exception as exc:
    metrics = {"pass_numeric": 0, "failures": 999, "score": 998.0, "returncode": proc.returncode, "wall": wall, "N": N, "CFL": CFL, "parse_ok_numeric": 0, "parse_error": str(exc)}
    print(out[-4000:])
    print(json.dumps(metrics, sort_keys=True))
    sys.exit(0)
# Scalar score: lower is better. We emphasize profile L2, shock location, and failed subcase count.
max_p_l2 = max((float(s.get("p_profile_l2", 99.0)) for s in subs), default=99.0)
max_u_l2 = max((float(s.get("u_profile_l2", 99.0)) for s in subs), default=99.0)
max_rho_l2 = max((float(s.get("rho_profile_l2", 99.0)) for s in subs), default=99.0)
max_shock_cells = max((float(s.get("shock_cells", 99.0)) for s in subs), default=99.0)
min_corr = min((float(s.get("p_corr", -99.0)) for s in subs), default=-99.0)
failures = int(case.get("failures", sum(0 if s.get("pass") else 1 for s in subs)))
# Broad-similarity acceptance for this run target. Strict official pass can remain false.
broad_ok = (
    failures <= 5
    and max_p_l2 <= 0.20
    and max_u_l2 <= 0.20
    and max_rho_l2 <= 0.15
    and max_shock_cells <= 5.0
    and min_corr >= 0.90
)
score = (
    max(max_p_l2, max_u_l2, max_rho_l2)
    + 0.02 * max_shock_cells
    + 0.25 * failures
    + max(0.0, 0.90 - min_corr)
)
png = ROOT / "results" / "1D" / "24_H" / "diff_vs_exact.png"
metrics = {
    "N": N, "CFL": CFL, "wall": wall, "returncode": proc.returncode,
    "official_pass_numeric": 1 if case.get("pass") else 0,
    "broad_pass_numeric": 1 if broad_ok else 0,
    "pass_numeric": 1 if broad_ok else 0,
    "failures": failures, "score": score,
    "max_p_l2": max_p_l2, "max_u_l2": max_u_l2, "max_rho_l2": max_rho_l2,
    "max_shock_cells": max_shock_cells, "min_p_corr": min_corr,
    "png_exists_numeric": 1 if png.exists() else 0,
    "png_size": png.stat().st_size if png.exists() else 0,
    "parse_ok_numeric": 1,
}
print(out[-4000:])
print(json.dumps(metrics, sort_keys=True))

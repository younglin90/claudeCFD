#!/usr/bin/env python3
import json, os, pathlib, re, subprocess, sys, time

CASES = os.environ.get('DENNER_TARGET_CASES', '01,02,04,05,07,13,14,15,24,25')
TIMEOUT = float(os.environ.get('DENNER_TARGET_TIMEOUT', '3600'))
cmd = [sys.executable, 'results/run_denner1d_17case.py', '--only', CASES, '--json']
env = os.environ.copy()
env.setdefault('PYTHONDONTWRITEBYTECODE', '1')
env.setdefault('DENNER_NUM_THREADS', '1')
env.setdefault('OMP_NUM_THREADS', '1')
env.setdefault('OPENBLAS_NUM_THREADS', '1')
env.setdefault('MKL_NUM_THREADS', '1')
env.setdefault('NUMEXPR_NUM_THREADS', '1')
start = time.time()
try:
    proc = subprocess.run(cmd, cwd=pathlib.Path(__file__).resolve().parents[1], env=env,
                          text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          timeout=TIMEOUT)
    out = proc.stdout
    returncode = proc.returncode
    timed_out = False
except subprocess.TimeoutExpired as e:
    out = (e.stdout or '') if isinstance(e.stdout, str) else ((e.stdout or b'').decode(errors='replace'))
    returncode = 124
    timed_out = True
wall = time.time() - start
print(out, end='' if out.endswith('\n') else '\n')
# Extract DETAILS_JSON if present.
details = []
for line in out.splitlines():
    if line.startswith('DETAILS_JSON '):
        try:
            details = json.loads(line[len('DETAILS_JSON '):])
        except Exception:
            details = []
if not details:
    # Fallback: parse CASE_JSON rows.
    for line in out.splitlines():
        if line.startswith('CASE_JSON '):
            try:
                details.append(json.loads(line[len('CASE_JSON '):]))
            except Exception:
                pass
pass_count = sum(1 for d in details if bool(d.get('pass')))
total = len(details)
fail_cases = [str(d.get('case', d.get('name', 'unknown'))) for d in details if not bool(d.get('pass'))]
finite_fail_cases = [str(d.get('case', d.get('name', 'unknown'))) for d in details if not bool(d.get('finite', True))]
complete_fail_cases = [str(d.get('case', d.get('name', 'unknown'))) for d in details if not bool(d.get('complete', True))]
score = (total - pass_count) + 10 * len(finite_fail_cases) + 5 * len(complete_fail_cases) + (1 if timed_out else 0)
# PNG checks for expected output dirs.
case_dirs = {
    '01': '01_A', '02': '02_A', '04': '04_B', '05': '05_B', '07': '07_B',
    '13': '13_E', '14': '14_E', '15': '15_E', '24': '24_H', '25': '25_H'
}
png_missing = []
root = pathlib.Path(__file__).resolve().parents[1]
for cid in [c.strip() for c in CASES.split(',') if c.strip()]:
    d = case_dirs.get(cid, cid)
    if not (root / 'results' / '1D' / d / 'diff_vs_exact.png').exists():
        png_missing.append(cid)
metrics = {
    'cases': CASES,
    'returncode': returncode,
    'timed_out': timed_out,
    'wall': wall,
    'total': total,
    'pass_count': pass_count,
    'fail_count': total - pass_count if total else 999,
    'pass_numeric': 1 if total and pass_count == total and returncode == 0 and not png_missing else 0,
    'score': score if total else 999,
    'fail_cases': fail_cases,
    'finite_fail_cases': finite_fail_cases,
    'complete_fail_cases': complete_fail_cases,
    'png_missing': png_missing,
    'png_missing_count': len(png_missing),
}
print(json.dumps(metrics, ensure_ascii=False, sort_keys=True))
sys.exit(0 if metrics['pass_numeric'] else 1)

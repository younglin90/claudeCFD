import pstats

p = pstats.Stats("autoresearch-results/perf_smoke_case07_worker.cprofile")
p.strip_dirs().sort_stats("cumtime").print_stats(30)

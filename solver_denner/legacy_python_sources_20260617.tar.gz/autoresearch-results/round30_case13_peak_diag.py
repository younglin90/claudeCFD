import json
import os
import time

import numpy as np

from oscillation_guards import (
    _auto_sharp_mask,
    _contiguous_segments,
    _field_scale,
)
from results import run_denner1d_17case as r


def _sharp_overshoot_details(x, fields, exact, centers=()):
    x = np.asarray(x, dtype=float)
    dx = float(np.median(np.diff(x))) if x.size > 1 else 1.0
    refs = [np.asarray(ref, dtype=float) for _, ref, _ in fields.values()]
    sharp = _auto_sharp_mask(x, refs, dx, centers, cells=24)
    for num, _, _ in fields.values():
        sharp |= _auto_sharp_mask(x, [np.asarray(num, dtype=float)], dx, (), cells=24)

    out = {}
    for name, (num_raw, ref_raw, floor) in fields.items():
        num = np.asarray(num_raw, dtype=float)
        ref = np.asarray(ref_raw, dtype=float)
        scale = _field_scale(ref, float(floor))
        best = {
            "value": 0.0,
            "i": None,
            "x": None,
            "num": None,
            "ref": None,
            "segment_i_min": None,
            "segment_i_max": None,
            "segment_x_min": None,
            "segment_x_max": None,
            "segment_ref_min": None,
            "segment_ref_max": None,
        }
        for seg in _contiguous_segments(sharp):
            if seg.size < 2:
                continue
            nb = num[seg]
            rb = ref[seg]
            lo = float(np.min(rb))
            hi = float(np.max(rb))
            jump = max(hi - lo, scale)
            over_hi = nb - hi
            under_lo = lo - nb
            local_score = np.maximum(over_hi, under_lo) / max(jump, 1.0e-300)
            k = int(np.argmax(local_score))
            score = float(local_score[k])
            if score > float(best["value"]):
                i = int(seg[k])
                best = {
                    "value": score,
                    "i": i,
                    "x": float(x[i]),
                    "num": float(num[i]),
                    "ref": float(ref[i]),
                    "segment_i_min": int(seg[0]),
                    "segment_i_max": int(seg[-1]),
                    "segment_x_min": float(x[int(seg[0])]),
                    "segment_x_max": float(x[int(seg[-1])]),
                    "segment_ref_min": lo,
                    "segment_ref_max": hi,
                }
        out[f"{name}_sharp_overshoot_detail"] = best
    out["sharp_mask_cells"] = int(np.count_nonzero(sharp))
    return out


def _smooth_hf_details(x, fields, exact, centers=()):
    x = np.asarray(x, dtype=float)
    dx = float(np.median(np.diff(x))) if x.size > 1 else 1.0
    refs = [np.asarray(ref, dtype=float) for _, ref, _ in fields.values()]
    sharp = _auto_sharp_mask(x, refs, dx, centers, cells=24)
    for num, _, _ in fields.values():
        sharp |= _auto_sharp_mask(x, [np.asarray(num, dtype=float)], dx, (), cells=24)
    smooth = ~sharp
    if x.size > 4:
        smooth[:2] = False
        smooth[-2:] = False

    out = {}
    for name, (num_raw, ref_raw, floor) in fields.items():
        num = np.asarray(num_raw, dtype=float)
        ref = np.asarray(ref_raw, dtype=float)
        scale = _field_scale(ref, float(floor))
        best = {
            "value": 0.0,
            "i": None,
            "x": None,
            "num": None,
            "ref": None,
            "residual": None,
            "d2": None,
            "segment_i_min": None,
            "segment_i_max": None,
            "segment_x_min": None,
            "segment_x_max": None,
        }
        if num.size >= 4:
            mid = smooth[1:-1] & smooth[:-2] & smooth[2:]
            residual = num - ref
            d2 = residual[1:-1] - 0.5 * (residual[:-2] + residual[2:])
            ids = np.flatnonzero(mid) + 1
            if ids.size:
                vals = np.abs(d2[mid]) / scale
                k = int(np.argmax(vals))
                i = int(ids[k])
                segs = _contiguous_segments(smooth)
                seg = None
                for cand in segs:
                    if cand[0] <= i <= cand[-1]:
                        seg = cand
                        break
                best = {
                    "value": float(vals[k]),
                    "i": i,
                    "x": float(x[i]),
                    "num": float(num[i]),
                    "ref": float(ref[i]),
                    "residual": float(residual[i]),
                    "d2": float(d2[i - 1]),
                    "segment_i_min": int(seg[0]) if seg is not None else None,
                    "segment_i_max": int(seg[-1]) if seg is not None else None,
                    "segment_x_min": float(x[int(seg[0])]) if seg is not None else None,
                    "segment_x_max": float(x[int(seg[-1])]) if seg is not None else None,
                }
        out[f"{name}_smooth_hf_detail"] = best
    out["smooth_mask_cells"] = int(np.count_nonzero(smooth))
    return out


def main():
    N = int(os.environ.get("DENNER_CASE13_N", "80"))
    dx = 2.0 / N
    x = (np.arange(N) + 0.5) * dx
    T0 = 300.0
    psi0 = np.where(x < 0.5, 1.0 - 1e-6, 1e-6)
    T_init = np.full(N, T0)
    u_init = np.zeros(N)
    p_init = np.where(x < 0.5, 1.0e9, 1.0e4)

    t0 = time.time()
    res = r._solve_denner(
        psi0, T_init, u_init, p_init, dx, t_end=6.7e-4,
        ph1=r.AIR_IDEAL, ph2=r.WATER_NASG,
        bc_l="transmissive", bc_r="transmissive",
        cfl=float(os.environ.get("DENNER_CASE13_CFL", "0.30")),
        cfl_type="acoustic", max_iter=120000,
        use_K=bool(int(os.environ.get("DENNER_CASE13_USE_K", "1"))),
        use_compress=bool(int(os.environ.get("DENNER_CASE13_USE_COMPRESS", "0"))),
        bdf_order=int(os.environ.get("DENNER_CASE13_BDF_ORDER", "2")),
        mwi_rho_star=os.environ.get("DENNER_CASE13_MWI_RHO_STAR", "harmonic"),
        tvd_limiter=os.environ.get("DENNER_CASE13_TVD_LIMITER", "minmod"),
        velocity_tvd_limiter=os.environ.get(
            "DENNER_CASE13_VELOCITY_TVD_LIMITER", None),
        scalar_tvd_limiter=os.environ.get(
            "DENNER_CASE13_SCALAR_TVD_LIMITER", None),
        acoustic_limiter=os.environ.get("DENNER_CASE13_ACOUSTIC_LIMITER", None),
        acoustic_limiter_blend=float(os.environ.get(
            "DENNER_CASE13_ACOUSTIC_LIMITER_BLEND", "1.0")),
        mwi_transient=bool(int(os.environ.get(
            "DENNER_CASE13_MWI_TRANSIENT_3N", "1"))),
        acoustic_face_correction=bool(int(os.environ.get(
            "DENNER_CASE13_ACOUSTIC_FACE", "1"))),
        max_outer=int(os.environ.get("DENNER_CASE13_MAX_OUTER", "1")),
        max_inner=int(os.environ.get("DENNER_CASE13_MAX_INNER", "20")),
        max_newton=int(os.environ.get("DENNER_CASE13_MAX_NEWTON", "20")),
        newton_tol=float(os.environ.get("DENNER_CASE13_NEWTON_TOL", "1e-6")),
        outer_tol=float(os.environ.get("DENNER_CASE13_OUTER_TOL", "1e-6")),
    )
    wall = time.time() - t0

    psi_f, T_f, u_f, p_f = r._final_state(res)
    rho_f = r._mix_rho(psi_f, p_f, T_f, r.AIR_IDEAL, r.WATER_NASG)
    exact = r._v_case13_exact_reference(
        x, r._make_ref_air(), r._make_ref_water_nasg())
    band_half = max(0.05, 8.0 * dx)
    band = np.abs(x - float(exact["x_contact"])) <= band_half
    idxs = np.flatnonzero(band)
    imax = int(idxs[int(np.argmax(rho_f[band]))])
    contact_grad = int(np.argmax(np.abs(np.gradient(psi_f, dx))))
    contact_window = sorted(
        set(range(max(0, imax - 6), min(N, imax + 7)))
        | set(range(max(0, contact_grad - 6), min(N, contact_grad + 7))))
    shock_x_ref = float(exact.get("x_shock", exact.get("x_transmitted_shock")))
    shock_i_exact = int(np.argmin(np.abs(x - shock_x_ref)))
    shock_i_num = int(np.argmax(np.abs(np.gradient(u_f, dx))))
    shock_window = sorted(
        set(range(max(0, shock_i_exact - 10), min(N, shock_i_exact + 11)))
        | set(range(max(0, shock_i_num - 10), min(N, shock_i_num + 11))))
    hf = r._v_rho_u_p_hf_guard(x, rho_f, u_f, p_f, exact)
    sharp_details = _sharp_overshoot_details(
        x,
        {
            "rho": (rho_f, exact["rho"], 1.0),
            "u": (u_f, exact["u"], 1.0),
            "p": (
                p_f, exact["p"],
                max(float(np.max(exact["p"]) - np.min(exact["p"])), 1.0e5),
            ),
        },
        exact,
        centers=[
            exact.get("x_shock"),
            exact.get("x_contact"),
            exact.get("x_transmitted_shock"),
            exact.get("x_reflected_shock"),
        ],
    )
    smooth_hf_details = _smooth_hf_details(
        x,
        {
            "rho": (rho_f, exact["rho"], 1.0),
            "u": (u_f, exact["u"], 1.0),
            "p": (
                p_f, exact["p"],
                max(float(np.max(exact["p"]) - np.min(exact["p"])), 1.0e5),
            ),
        },
        exact,
        centers=[
            exact.get("x_shock"),
            exact.get("x_contact"),
            exact.get("x_transmitted_shock"),
            exact.get("x_reflected_shock"),
        ],
    )

    def _row(i):
        return {
            "i": int(i),
            "x": float(x[i]),
            "in_contact_band": bool(band[i]),
            "psi": float(psi_f[i]),
            "T": float(T_f[i]),
            "u": float(u_f[i]),
            "p": float(p_f[i]),
            "rho": float(rho_f[i]),
            "rho_exact": float(exact["rho"][i]),
            "u_exact": float(exact["u"][i]),
            "p_exact": float(exact["p"][i]),
            "rho_minus_exact": float(rho_f[i] - exact["rho"][i]),
            "u_minus_exact": float(u_f[i] - exact["u"][i]),
            "p_minus_exact": float(p_f[i] - exact["p"][i]),
        }

    out = {
        "N": N,
        "dx": dx,
        "wall": wall,
        "complete_t": float(res["t_history"][-1]),
        "exact_contact_x": float(exact["x_contact"]),
        "band_half_width": float(band_half),
        "band_x_min": float(x[idxs[0]]),
        "band_x_max": float(x[idxs[-1]]),
        "peak_i": int(imax),
        "peak_x": float(x[imax]),
        "peak_rho": float(rho_f[imax]),
        "peak_exact_rho": float(exact["rho"][imax]),
        "contact_grad_i": int(contact_grad),
        "contact_grad_x": float(x[contact_grad]),
        "exact_shock_x": shock_x_ref,
        "shock_i_exact": int(shock_i_exact),
        "shock_x_exact_grid": float(x[shock_i_exact]),
        "shock_i_num": int(shock_i_num),
        "shock_x_num": float(x[shock_i_num]),
        "hf": hf,
        **sharp_details,
        **smooth_hf_details,
        "contact_rows": [_row(i) for i in contact_window],
        "shock_rows": [_row(i) for i in shock_window],
    }
    flags = []
    for key, label in (
            ("DENNER_MIXED_THERMO_TROUGH_MOOD", "mt"),
            ("DENNER_MIXED_PU_CONTACT_MOOD", "mpu"),
            ("DENNER_MIXED_PU_STAR_CONTACT_MOOD", "mpustar"),
            ("DENNER_MATERIAL_STAR_SMOOTH_PLATEAU_MOOD", "mssmooth"),
            ("DENNER_SHOCK_PLATEAU_ENVELOPE_MOOD", "spe")):
        if os.environ.get(key, "0") not in ("", "0", "false", "False"):
            flags.append(label)
    suffix = "_".join(flags) if flags else "base"
    path = f"autoresearch-results/case13_N{N}_{suffix}_peak_diag.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    summary = {k: v for k, v in out.items() if k != "rows"}
    print(json.dumps(summary, indent=2))
    print("saved", path)


if __name__ == "__main__":
    main()

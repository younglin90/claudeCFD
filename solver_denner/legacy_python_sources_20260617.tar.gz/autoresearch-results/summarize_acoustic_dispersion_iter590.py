import json, math, statistics
from collections import Counter
rows=[json.loads(l) for l in open('autoresearch-results/acoustic_dispersion_iter590_N200.jsonl') if l.strip()]
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def med(vals):
    vals=[float(v) for v in vals if isnum(v)]
    return None if not vals else statistics.median(vals)
def rng(vals):
    vals=[float(v) for v in vals if isnum(v)]
    return None if not vals else (min(vals), statistics.median(vals), max(vals), len(vals))
def fmt(x): return 'NA' if x is None else f'{x:.6g}'
fields=['energy_centroid_x','p_centroid_x','u_centroid_x','wplus_centroid_x','energy_width_sigma','wplus_width_sigma','energy_skewness','local_c_energy_weighted','centroid_speed_from_prev_sample','speed_ratio_to_local_c','p_u_centroid_separation','high_wavenumber_energy_fraction','tail_energy_fraction','opposite_energy_ratio','support_count','unsupported_count','finite_count']
print('FIELD_RANGES')
for f in fields:
    s=rng([r.get(f) for r in rows])
    if s:
        print(f, 'min', fmt(s[0]), 'med', fmt(s[1]), 'max', fmt(s[2]), 'n', s[3])
print('MISSING', Counter(str(r.get('missing_fields')) for r in rows))
print('GROUP_STEP_MEDIANS')
for step in [609,650,700,760,800,810]:
    print('STEP', step)
    for group in ['right_material_side','right_lobe_expanded','right_lobe','right_packet_energy_core','right_packet_energy_tails']:
        rs=[r for r in rows if r.get('step')==step and r.get('dispersion_group')==group]
        if not rs:
            continue
        parts=[]
        for f in fields[:13]:
            parts.append(f + '=' + fmt(med([r.get(f) for r in rs])))
        print(' ',group,'n',len(rs),' '.join(parts))
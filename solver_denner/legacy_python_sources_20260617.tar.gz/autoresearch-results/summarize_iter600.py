﻿import json, os
from pathlib import Path
from datetime import datetime
base=Path('/home/younglin90/work/claude_code/claudeCFD/solver_denner')
for name in ['pface_vector_cache_iter600_N50.log','pface_vector_cache_iter600_N200.log']:
    log=base/'autoresearch-results'/name
    out={'log':name}
    if log.exists():
        for line in log.read_text(errors='replace').splitlines():
            if line.startswith('AUTORESEARCH_METRIC'): out['metric']=line
            if line.startswith('DETAILS_JSON'):
                arr=json.loads(line.split(' ',1)[1]); sub=arr[0]['subcases'][0]
                out['wall']=arr[0].get('wall')
                out['fields']={k:sub.get(k) for k in ['corr_p','corr_u','p_peak_amp_ratio','u_peak_amp_ratio','p_abs_delta_cells','u_abs_delta_cells','air_water_p_packet_shape_ok','air_water_u_packet_shape_ok','air_water_p_packet_secondary_extrema','air_water_u_packet_secondary_extrema','air_water_p_packet_min_corr','air_water_u_packet_min_corr','p_smooth_local_tv_excess','u_smooth_local_tv_excess','p_hf_ok','hf_oscillation_ok']}
    print(json.dumps(out,sort_keys=True))
png=base/'results/1D/07_B/diff_vs_exact.png'
print('PNG', png, datetime.fromtimestamp(png.stat().st_mtime).isoformat() if png.exists() else 'missing')

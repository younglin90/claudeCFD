import json, os, time
rows=[json.loads(l) for l in open('autoresearch-results/assembly_profile_iter596_N50.jsonl') if l.strip()]
last=rows[-1]
print('PROFILE_ROWS',len(rows),'LAST_CALLS',last.get('profile_calls'))
cats=last.get('categories',{})
for name,data in sorted(cats.items(), key=lambda kv: kv[1].get('wall',0), reverse=True):
    print('CAT',name,'calls',data.get('calls'),'wall',data.get('wall'),'extra',{k:v for k,v in data.items() if k not in ('calls','wall')})
prof=last.get('profile',{})
for k in ['assemble_newton_3N_wall','assemble_newton_3N_preloop_wall','assemble_newton_3N_cell_loop_wall','face_state_reconstruction_wall','solve_linear_system_wall','sparse_tocsr_wall','assembly_profile_jsonl_wall','assemble_newton_3N_calls','assembly_profile_jsonl_writes']:
    print('PROFILE',k,prof.get(k))
for p in ['autoresearch-results/pytest_profile_iter596.log','autoresearch-results/assembly_profile_iter596_N50.log','autoresearch-results/assembly_profile_iter596_N50.jsonl','autoresearch-results/profile_opt_iter596_N200.log','results/1D/07_B/diff_vs_exact.png']:
    st=os.stat(p)
    print('ARTIFACT',p,'size',st.st_size,'mtime',time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(st.st_mtime)))
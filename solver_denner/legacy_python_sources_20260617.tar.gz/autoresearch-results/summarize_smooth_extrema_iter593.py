import json, math, statistics
from collections import Counter
rows=[json.loads(l) for l in open('autoresearch-results/acoustic_smooth_extrema_iter593_N200.jsonl') if l.strip()]
def isnum(x): return isinstance(x,(int,float)) and math.isfinite(x)
def stat(vals):
    vals=[float(v) for v in vals if isnum(v)]
    if not vals: return None
    vals.sort(); return (len(vals), min(vals), statistics.median(vals), max(vals), sum(vals)/len(vals))
def fmt(s):
    if not s: return 'NA'
    return f'n={s[0]} min={s[1]:.6g} med={s[2]:.6g} max={s[3]:.6g} mean={s[4]:.6g}'
print('CANDIDATES', Counter(r.get('candidate_name') for r in rows))
print('SUPPORTED', Counter(r.get('candidate_supported') for r in rows))
print('PRIM_MINMAX', Counter(r.get('primitive_minmax_ok') for r in rows))
print('CHAR_MINMAX', Counter(r.get('characteristic_minmax_ok') for r in rows))
print('OPPOSITE_OK', Counter(r.get('opposite_growth_ok') for r in rows))
print('FALLBACK_REASON', Counter(r.get('candidate_fallback_reason') for r in rows))
for key in ['supported_count','selected_candidate_count','fallback_count','material_active_candidate_count','rejected_minmax_count','rejected_characteristic_minmax_count','rejected_nonfinite_count','rejected_opposite_growth_count']:
    print(key, fmt(stat([r.get(key) for r in rows])))
for key in ['highk_preview_ratio_vs_current','second_difference_preview_current','second_difference_preview_candidate','opposite_characteristic_preview_vs_current','candidate_face_delta_norm','smoothness_indicator_mean']:
    print(key, fmt(stat([r.get(key) for r in rows])))
print('BY_CAND_WINDOW')
for cand in sorted(set(r.get('candidate_name') for r in rows)):
    for win in sorted(set(r.get('window') for r in rows)):
        rs=[r for r in rows if r.get('candidate_name')==cand and r.get('window')==win]
        if not rs: continue
        print('BUCKET',cand,win,'n',len(rs),'support',Counter(r.get('candidate_supported') for r in rs),'prim',Counter(r.get('primitive_minmax_ok') for r in rs),'char',Counter(r.get('characteristic_minmax_ok') for r in rs),'opp',Counter(r.get('opposite_growth_ok') for r in rs),'fallback',Counter(r.get('candidate_fallback_reason') for r in rs))
        for key in ['highk_preview_ratio_vs_current','second_difference_preview_current','second_difference_preview_candidate','opposite_characteristic_preview_vs_current','candidate_face_delta_norm']:
            print(' FIELD',key,fmt(stat([r.get(key) for r in rs])))
print('BY_STEP_WINDOW')
for step in [609,650,700,760,800,810]:
    for win in sorted(set(r.get('window') for r in rows)):
        rs=[r for r in rows if r.get('step')==step and r.get('window')==win]
        if not rs: continue
        print('STEPWIN',step,win,'n',len(rs),'cand',Counter(r.get('candidate_name') for r in rs),'support',Counter(r.get('candidate_supported') for r in rs),'fallback',Counter(r.get('candidate_fallback_reason') for r in rs))
        print(' highk',fmt(stat([r.get('highk_preview_ratio_vs_current') for r in rs])),'delta',fmt(stat([r.get('candidate_face_delta_norm') for r in rs])))
#!/usr/bin/env python3
"""Scalar autoresearch verifier for Denner 07_B.

Runs the Denner 17-case driver restricted to case 07 and prints the
pass-count scalar as the final non-empty line for codex-autoresearch.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
RUNNER = ROOT / "results" / "run_denner1d_17case.py"


def main() -> int:
    env = os.environ.copy()
    env.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-denner-autoresearch")
    proc = subprocess.run(
        [sys.executable, str(RUNNER), "--only", "07"],
        cwd=str(ROOT),
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if proc.stdout:
        print(proc.stdout, end="" if proc.stdout.endswith("\n") else "\n")
    match = re.search(r"AUTORESEARCH_METRIC\s+pass_count=(\d+)\s+total=(\d+)", proc.stdout or "")
    if match is None:
        print("0")
        return 0
    print(match.group(1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

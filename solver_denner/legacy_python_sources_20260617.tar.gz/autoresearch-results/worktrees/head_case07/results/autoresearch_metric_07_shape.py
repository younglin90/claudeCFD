#!/usr/bin/env python3
"""Run denner_1d case-07 validation and emit shape-aware JSON metrics.

Final stdout line is JSON for codex-autoresearch metrics_json mode.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys


def main() -> int:
    env = os.environ.copy()
    env.setdefault("MPLCONFIGDIR", "/tmp/mpl")
    env.setdefault("DENNER_CASE_BUDGET_SEC", "7200")
    cmd = [sys.executable, "-u", "results/run_denner1d_17case.py", "--only", "07", "--json"]
    proc = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
    sys.stdout.write(proc.stdout)
    match = re.search(r"DETAILS_JSON\s+(\[.*\])", proc.stdout, flags=re.S)
    if not match:
        print(json.dumps({
            "case07_pass_count": 0,
            "case07_total": 1,
            "case07_pass": 0,
            "max_air_water_opposite_ratio": 1.0,
            "air_water_smooth_packet_shape_ok": 0,
            "parse_ok": 0,
            "returncode": proc.returncode,
        }, sort_keys=True))
        return 1
    details = json.loads(match.group(1))
    case = details[0]
    subcases = case.get("subcases", [])
    aw = next((row for row in subcases if row.get("name") == "Air-Water"), {})
    p_opp = float(aw.get("air_water_p_packet_opposite_ratio", 1.0))
    u_opp = float(aw.get("air_water_u_packet_opposite_ratio", 1.0))
    max_opp = max(p_opp, u_opp)
    metrics = {
        "case07_pass_count": int(1 if case.get("pass") else 0),
        "case07_total": 1,
        "case07_pass": int(1 if case.get("pass") else 0),
        "case07_failures": int(case.get("failures", 1)),
        "air_water_pass": int(1 if aw.get("pass") else 0),
        "air_water_smooth_packet_shape_ok": int(1 if aw.get("air_water_smooth_packet_shape_ok") else 0),
        "air_water_p_packet_shape_ok": int(1 if aw.get("air_water_p_packet_shape_ok") else 0),
        "air_water_u_packet_shape_ok": int(1 if aw.get("air_water_u_packet_shape_ok") else 0),
        "air_water_p_packet_secondary_extrema": int(aw.get("air_water_p_packet_secondary_extrema", 999)),
        "air_water_u_packet_secondary_extrema": int(aw.get("air_water_u_packet_secondary_extrema", 999)),
        "air_water_p_packet_opposite_ratio": p_opp,
        "air_water_u_packet_opposite_ratio": u_opp,
        "max_air_water_opposite_ratio": max_opp,
        "air_water_p_packet_min_corr": float(aw.get("air_water_p_packet_min_corr", 0.0)),
        "air_water_u_packet_min_corr": float(aw.get("air_water_u_packet_min_corr", 0.0)),
        "air_water_p_packet_max_scaled_l2": float(aw.get("air_water_p_packet_max_scaled_l2", 1.0)),
        "air_water_u_packet_max_scaled_l2": float(aw.get("air_water_u_packet_max_scaled_l2", 1.0)),
        "parse_ok": 1,
        "returncode": proc.returncode,
    }
    print(json.dumps(metrics, sort_keys=True))
    return 0 if metrics["case07_pass_count"] >= 1 else 1


if __name__ == "__main__":
    raise SystemExit(main())

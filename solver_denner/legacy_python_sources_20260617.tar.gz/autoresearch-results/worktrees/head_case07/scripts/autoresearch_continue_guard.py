#!/usr/bin/env python3
"""Project-local guard: prevent false autoresearch completion.

This script is intentionally conservative. It does not claim scientific success;
it only says whether the local state is allowed to stop.
"""
from __future__ import annotations
import json
import pathlib
import subprocess
import sys
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parents[1]
STATE = ROOT / "autoresearch-results" / "state.json"
CONTEXT = ROOT / "autoresearch-results" / "context.json"
POINTER = ROOT / ".codex-autoresearch" / "pointer.json"
RESULTS = ROOT / "autoresearch-results" / "results.tsv"


def load_json(path: pathlib.Path) -> dict:
    if not path.exists():
        raise SystemExit(f"ERROR missing {path}")
    with path.open() as f:
        return json.load(f)


def git_clean_solver() -> bool:
    cp = subprocess.run(
        ["git", "status", "--short", "--", "solver/denner_1d"],
        cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    if cp.returncode != 0:
        return False
    return cp.stdout.strip() == ""


def tracker_guard_ok() -> bool:
    cp = subprocess.run(
        ["grep", "-R", r"is_final_step\|feature.*tracker\|exact.*tracker", "-n", "solver/denner_1d", "--include=*.py"],
        cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    return cp.returncode == 1


def latest_result_status() -> tuple[str | None, str]:
    if not RESULTS.exists():
        return None, ""
    rows = [ln.strip().split("\t") for ln in RESULTS.read_text().splitlines() if ln.strip()]
    if not rows:
        return None, ""
    # TSV schema used here: iteration, commit, metric, delta, guard, status, description
    status = rows[-1][5] if len(rows[-1]) > 5 else None
    desc = rows[-1][6] if len(rows[-1]) > 6 else ""
    return status, desc


def main() -> int:
    st = load_json(STATE)
    state = st.get("state", {})
    cfg = st.get("config", {})
    current_metrics = state.get("current_metrics", {}) or {}
    latest_trial_metrics = state.get("last_trial_metrics", {}) or {}
    latest_trial_labels = state.get("last_trial_labels", []) or []
    # Drift records may intentionally become the retained/current metrics in the
    # helper state.  For stop guarding, prefer the latest validation-pass trial
    # when it exists so the printed metric and pass flag reflect the most recent
    # verified state rather than an older drift/audit snapshot.
    effective_metrics = current_metrics
    if (
        "validation-pass" in latest_trial_labels
        and latest_trial_metrics.get("pass_numeric") == 1
    ):
        effective_metrics = latest_trial_metrics
    pass_ok = (
        effective_metrics.get("pass_numeric") == 1
        or effective_metrics.get("pass") is True
        or state.get("current_acceptance") is True
    )
    current_failure = effective_metrics.get(
        "case14_failure_count",
        effective_metrics.get(cfg.get("primary_metric_key", ""), state.get("current_metric")),
    )
    try:
        current_failure_num = float(current_failure)
    except Exception:
        current_failure_num = 1.0

    guard_ok = tracker_guard_ok()
    clean_solver = git_clean_solver()
    last_status, last_desc = latest_result_status()
    # Older case-14 runs used a zero-valued failure count and status=keep.
    # Current codex-autoresearch case targets use explicit pass metrics and
    # record status=pass.  Accept either representation while retaining the
    # no-feature/exact-tracker guard.
    metric_stop = current_failure_num == 0.0
    pass_stop = bool(pass_ok)
    terminal_record_ok = last_status in ("keep", "pass") or (
        last_status == "no-op" and "validation-pass" in last_desc
    )
    active_stop = (
        (metric_stop or pass_stop)
        and guard_ok
        and terminal_record_ok
    )

    out = {
        "workspace": str(ROOT),
        "goal": cfg.get("goal"),
        "stop_condition": cfg.get("stop_condition"),
        "current_failure_count": current_failure_num,
        "effective_metric_source": (
            "last_trial_metrics" if effective_metrics is latest_trial_metrics else "current_metrics"
        ),
        "pass_ok": pass_stop,
        "guard_ok_no_final_or_tracker": guard_ok,
        "solver_worktree_clean": clean_solver,
        "latest_record_status": last_status,
        "latest_record_terminal_ok": terminal_record_ok,
        "allowed_to_stop": active_stop,
        "checked_at": datetime.now(timezone.utc).isoformat(),
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))
    if active_stop:
        return 0
    return 10


if __name__ == "__main__":
    raise SystemExit(main())

"""Local solver package overlay for the isolated Denner workspace.

`solver_denner/solver/denner_1d` is the active Denner development target.
The package path is extended to the repository-level `solver/` directory so
shared validation utilities remain importable without copying unrelated solvers
into this workspace.
"""

from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)

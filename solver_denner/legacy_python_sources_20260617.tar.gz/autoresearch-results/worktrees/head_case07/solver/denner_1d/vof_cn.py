# solver_denner/solver/denner_1d/vof_cn.py
# Ref: DENNER_SCHEME.md § 7.2, Eq.(20)
#
# VOF explicit update using CICSAM face values.
# Auto sub-stepping: if Co = |u|·dt/dx > 1, the step is split into
# N_sub = ceil(Co) sub-steps each with dt_sub = dt/N_sub (Co ≤ 1 per sub-step).
# The (p,u,T) implicit step still uses the full dt.

import numpy as np
from .boundary import apply_ghost, apply_ghost_velocity
from .interface.cicsam import cicsam_face, thinc_face
from .eos.base import compute_phase_props


def _compute_K(psi, ph1, ph2, p, T):
    """
    Denner 2018 compressibility factor K for 2-species VOF.
    Backward-compatible wrapper for _compute_K_Ns.
    """
    props1 = compute_phase_props(p, T, ph1)
    props2 = compute_phase_props(p, T, ph2)
    Z1 = props1['rho'] * props1['c'] ** 2
    Z2 = props2['rho'] * props2['c'] ** 2
    psi_safe = np.clip(np.asarray(psi, dtype=float), 1e-12, 1.0 - 1e-12)
    # The code convention is psi=alpha_1.  For the four-equation
    # volume-fraction equation written as
    #   d(alpha_1)/dt + u d(alpha_1)/dx - K div(u) = 0,
    # the source form used below is +(alpha_1 + K) div(u) after expanding
    # div(alpha_1 u).  With a light gas in water, a diverging flow must
    # increase alpha_1; this fixes the phase-order sign so K is positive for
    # the low-impedance phase in the cavitation limit.
    den = Z2 / (1.0 - psi_safe) + Z1 / psi_safe
    K = (Z2 - Z1) / (den + 1e-300)
    # Exact pure-phase consistency: alpha=0 or 1 must reduce to the
    # single-fluid equation with no volume-fraction compressibility source.
    pure = (np.asarray(psi, dtype=float) <= 1.0e-3) | (np.asarray(psi, dtype=float) >= 1.0 - 1.0e-3)
    return np.where(pure, 0.0, K)


def _kapila_source_exact_candidate(psi_base, du_dx, dt_sub, ph1, ph2, p, T):
    """Frozen-Z bounded source candidate for BVD selection.

    See the identity ``alpha + K = alpha Z2/(alpha Z2+(1-alpha)Z1)`` for
    the two-phase Kapila coefficient used in this module.  The integrated
    source primitive is monotone, so a bisection solve produces a bounded
    candidate without an empirical damping coefficient.
    """
    alpha0 = np.clip(np.asarray(psi_base, dtype=float), 1.0e-12, 1.0 - 1.0e-12)
    props1 = compute_phase_props(p, T, ph1)
    props2 = compute_phase_props(p, T, ph2)
    Z1 = np.maximum(props1['rho'] * props1['c'] ** 2, 1.0e-300)
    Z2 = np.maximum(props2['rho'] * props2['c'] ** 2, 1.0e-300)
    r = np.clip(Z1 / Z2, 1.0e-14, 1.0e14)
    same_phase = (
        np.abs(Z1 - Z2)
        <= 100.0 * np.finfo(float).eps * np.maximum(np.maximum(Z1, Z2), 1.0)
    )
    pure = (alpha0 <= 1.0e-3) | (alpha0 >= 1.0 - 1.0e-3) | same_phase
    target = r * np.log(alpha0) + (1.0 - r) * alpha0 + np.asarray(du_dx, dtype=float) * float(dt_sub)
    lo = np.full_like(alpha0, 1.0e-12)
    hi = np.full_like(alpha0, 1.0 - 1.0e-12)

    def F(a):
        return r * np.log(a) + (1.0 - r) * a

    f_lo = F(lo)
    f_hi = F(hi)
    out = alpha0.copy()
    active = (~pure) & (target > f_lo) & (target < f_hi)
    out = np.where((~pure) & (target <= f_lo), lo, out)
    out = np.where((~pure) & (target >= f_hi), hi, out)
    if np.any(active):
        a_lo = lo.copy()
        a_hi = hi.copy()
        for _ in range(40):
            mid = 0.5 * (a_lo + a_hi)
            go_right = F(mid) < target
            a_lo = np.where(active & go_right, mid, a_lo)
            a_hi = np.where(active & (~go_right), mid, a_hi)
        out = np.where(active, 0.5 * (a_lo + a_hi), out)
    out = np.where(pure, alpha0, out)
    return np.clip(out, 0.0, 1.0)


def _boundary_variation(phi, bc_l, bc_r):
    ext = apply_ghost(np.asarray(phi, dtype=float), bc_l, bc_r, 1)
    return np.abs(ext[1:-1] - ext[:-2]) + np.abs(ext[2:] - ext[1:-1])


def _compute_K_Ns(psi_arr, phases, p, T):
    """
    Compressibility factor K for N_s-species compressible VOF.

    For species k:  ∂ψ_k/∂t + ∇·(u·ψ_k) - (ψ_k + K_k)·∇·u = 0

    Generalized Kapila/Denner coefficient for the conservative source form:

      ∂ψ_k/∂t + ∇·(uψ_k) - (ψ_k + K_k)∇·u = 0

    with

      K_k = ψ_k · (ρc² / (ρ_k c_k²) - 1),
      1/(ρc²) = Σ_j ψ_j/(ρ_j c_j²).

    For two species this reduces exactly to Denner's

      K_1 = ψ_1(1-ψ_1)(Z_2-Z_1)/(ψ_1 Z_2 + (1-ψ_1)Z_1),
      Z_k = ρ_k c_k²,

    and Σ_k K_k = 0, so Σ_k ψ_k remains one.

    Parameters
    ----------
    psi_arr : ndarray (N_s, N) — volume fractions (sum to 1)
    phases  : list of N_s EOS/dict
    p, T    : ndarray (N,)

    Returns
    -------
    K_arr : ndarray (N_s-1, N) — K factor for independent species (k=0..N_s-2)
    """
    # Dimensional denominator: Z=ρc² can be O(1e13) for stiff liquids, so
    # 1/Z is O(1e-13).  A large additive epsilon would dominate Wood's
    # mixture compliance and flip/magnify K in high-pressure states.
    eps = 1e-300
    N_s = len(phases)
    N = len(p)

    # Per-phase acoustic impedance squared: Z_k = ρ_k · c_k²
    Z = np.zeros((N_s, N))
    for k in range(N_s):
        props_k = compute_phase_props(p, T, phases[k])
        Z[k] = props_k['rho'] * props_k['c'] ** 2

    # Kapila/Wood mixture acoustic bulk modulus: ρc².
    rho_c2_mix = 1.0 / (np.sum(psi_arr / (Z + eps), axis=0) + eps)

    K_arr = np.zeros((N_s - 1, N))
    for k in range(N_s - 1):
        K_arr[k] = psi_arr[k] * (rho_c2_mix / (Z[k] + eps) - 1.0)
        pure = (psi_arr[k] <= 1.0e-3) | (psi_arr[k] >= 1.0 - 1.0e-3)
        K_arr[k] = np.where(pure, 0.0, K_arr[k])

    return K_arr


def compute_compression_coefficients(phi, u_face, dx, dt_sub, bc_l, bc_r, n_ghost):
    """
    Compute frozen Zalesak FCT limiter C_k and interface normal n_hat.

    Returns
    -------
    C_k      : ndarray (N+1,)  per-face limiter [0,1]
    n_hat    : ndarray (N+1,)  sign(grad phi) at faces
    raw_flux : ndarray (N+1,)  raw compression flux (before limiting)
    """
    N = len(phi)
    ng = n_ghost
    is_per = (bc_l == 'periodic')
    phi_ext = apply_ghost(phi, bc_l, bc_r, ng)

    # --- Raw compression fluxes at faces ---
    grad_phi = np.zeros(N + 1)
    for f in range(N + 1):
        grad_phi[f] = (phi_ext[ng + f] - phi_ext[ng + f - 1]) / dx
    n_hat = np.sign(grad_phi)

    raw_flux = np.zeros(N + 1)
    for f in range(N + 1):
        iL = ng + f - 1
        iR = ng + f
        if n_hat[f] * abs(u_face[f]) >= 0:
            phi_f = phi_ext[iL]
        else:
            phi_f = phi_ext[iR]
        raw_flux[f] = abs(u_face[f]) * phi_f * (1.0 - phi_f) * n_hat[f]

    # --- Zalesak FCT limiting ---
    P_plus = np.zeros(N)
    P_minus = np.zeros(N)

    for i in range(N):
        contrib_R = -raw_flux[i + 1] / dx * dt_sub
        if contrib_R > 0:
            P_plus[i] += contrib_R
        else:
            P_minus[i] -= contrib_R
        contrib_L = raw_flux[i] / dx * dt_sub
        if contrib_L > 0:
            P_plus[i] += contrib_L
        else:
            P_minus[i] -= contrib_L

    Q_plus = np.maximum(1.0 - phi, 0.0)
    Q_minus = np.maximum(phi, 0.0)

    with np.errstate(divide='ignore', invalid='ignore'):
        R_plus = np.where(P_plus > 1e-300, np.minimum(Q_plus / P_plus, 1.0), 1.0)
        R_minus = np.where(P_minus > 1e-300, np.minimum(Q_minus / P_minus, 1.0), 1.0)

    C_k = np.zeros(N + 1)
    for f in range(N + 1):
        iL_cell = f - 1
        iR_cell = f
        if is_per:
            if iL_cell < 0:
                iL_cell = N - 1
            if iR_cell >= N:
                iR_cell = 0
        else:
            if iL_cell < 0:
                iL_cell = 0
            if iR_cell >= N:
                iR_cell = N - 1

        if raw_flux[f] > 0:
            C_k[f] = min(R_minus[iL_cell], R_plus[iR_cell])
        elif raw_flux[f] < 0:
            C_k[f] = min(R_plus[iL_cell], R_minus[iR_cell])
        else:
            C_k[f] = 1.0

    return C_k, n_hat, raw_flux


def _compression_flux_bounded(phi, u_face, dx, dt_sub, bc_l, bc_r, n_ghost):
    """
    Conservative, bounded compression flux using Zalesak FCT limiting.

    Raw flux: F = |u_face| · φ(1-φ) · sign(∇φ).
    Zalesak limiting ensures φ stays in [0, 1] while conserving ∫φ.

    Without limiting, compression pushes cells already at φ=1 above 1.0,
    and np.clip then destroys mass (∫φ drops each step).
    """
    C_k, n_hat, raw_flux = compute_compression_coefficients(
        phi, u_face, dx, dt_sub, bc_l, bc_r, n_ghost)

    limited_flux = C_k * raw_flux

    return (limited_flux[1:] - limited_flux[:-1]) / dx


def _vof_substep(psi, u_face, psi_ext, dt_sub, dx, n_ghost,
                 ph1=None, ph2=None, p=None, T=None,
                 use_compress=False, bc_l='periodic', bc_r='periodic',
                 K_val=None):
    """
    Single explicit VOF sub-step (Co ≤ 1 guaranteed by caller).

    Parameters
    ----------
    K_val : ndarray (N,) or None
        Pre-computed K factor for this species. If None and ph1/ph2 given,
        computes K from 2-species formula (backward compatible).
    """
    # Soft-THINC VOF reconstruction: a bounded THINC profile is used for the
    # volume-fraction equation instead of Hyper-C CICSAM.  The low steepness
    # preserves monotonicity at homogeneous-mixture shocks while avoiding the
    # post-shock alpha plateau drift observed with purely advective CICSAM.
    psi_face = thinc_face(psi_ext, u_face, dt_sub, dx, n_ghost)

    flux_R = psi_face[1:]   * u_face[1:]
    flux_L = psi_face[:-1]  * u_face[:-1]
    flux_div = (flux_R - flux_L) / dx

    du_dx = (u_face[1:] - u_face[:-1]) / dx

    # Compressible VOF: ∂ψ/∂t + ∇·(uψ) - (ψ + K)*∇·u = 0
    if K_val is not None:
        source = (psi + K_val) * du_dx
    elif ph1 is not None and ph2 is not None and p is not None and T is not None:
        K = _compute_K(psi, ph1, ph2, p, T)
        source = (psi + K) * du_dx
    else:
        source = psi * du_dx

    psi_new = psi - dt_sub * flux_div + dt_sub * source

    # Local-bound MOOD limiter.  The compressible alpha equation is bounded,
    # but the explicit source/discontinuous velocity pair can otherwise create
    # a new one-cell phase-fraction extremum at strong homogeneous-mixture
    # shocks.  Limit to the previous local stencil envelope before the global
    # [0,1] clip; this is a uniform maximum-principle limiter, not a case or
    # coordinate switch.
    psi_old_ext1 = apply_ghost(psi, bc_l, bc_r, 1)
    local_lo = np.minimum.reduce((psi_old_ext1[:-2], psi_old_ext1[1:-1], psi_old_ext1[2:]))
    local_hi = np.maximum.reduce((psi_old_ext1[:-2], psi_old_ext1[1:-1], psi_old_ext1[2:]))
    psi_dmp = np.minimum(np.maximum(psi_new, local_lo), local_hi)
    if K_val is None and ph1 is not None and ph2 is not None and p is not None and T is not None:
        psi_adv = psi - dt_sub * flux_div
        psi_adv = np.minimum(np.maximum(psi_adv, local_lo), local_hi)
        psi_src = _kapila_source_exact_candidate(
            psi_adv, du_dx, dt_sub, ph1, ph2, p, T)
        psi_src = np.minimum(np.maximum(psi_src, local_lo), local_hi)
        bv_dmp = _boundary_variation(psi_dmp, bc_l, bc_r)
        bv_src = _boundary_variation(psi_src, bc_l, bc_r)
        choose_src = np.isfinite(psi_src) & (bv_src <= bv_dmp)
        psi_new = np.where(choose_src, psi_src, psi_dmp)
    else:
        psi_new = psi_dmp

    # Anti-diffusion compression with Zalesak FCT limiting (conservative + bounded)
    if use_compress:
        psi_new -= dt_sub * _compression_flux_bounded(
            psi_new, u_face, dx, dt_sub, bc_l, bc_r, n_ghost)

    psi_new = np.clip(psi_new, 0.0, 1.0)
    return psi_new, psi_face


def _vof_ssp_rk2_substep(psi, u_face, dt_sub, dx, n_ghost,
                         ph1=None, ph2=None, p=None, T=None,
                         use_compress=False, bc_l='periodic', bc_r='periodic',
                         K_val=None):
    """Second-order explicit SSP-RK2 update for the VOF/alpha equation.

    The pressure solve remains implicit in (p,u,T), while alpha is advanced
    explicitly as requested.  Each Euler stage uses the same bounded CICSAM
    flux and optional FCT-limited compression, then the two stages are averaged:

        alpha*    = E(alpha^n)
        alpha^{n+1} = 0.5 alpha^n + 0.5 E(alpha*)

    This upgrades the alpha-equation time discretisation from first-order
    forward Euler to second-order SSP-RK2 without adding case-specific
    coefficients or changing the governing four-equation model.
    """
    psi0 = np.asarray(psi, dtype=float)
    psi_ext0 = apply_ghost(psi0, bc_l, bc_r, n_ghost)
    psi1, face1 = _vof_substep(
        psi0, u_face, psi_ext0, dt_sub, dx, n_ghost,
        ph1=ph1, ph2=ph2, p=p, T=T, use_compress=use_compress,
        bc_l=bc_l, bc_r=bc_r, K_val=K_val)
    psi_ext1 = apply_ghost(psi1, bc_l, bc_r, n_ghost)
    psi2, face2 = _vof_substep(
        psi1, u_face, psi_ext1, dt_sub, dx, n_ghost,
        ph1=ph1, ph2=ph2, p=p, T=T, use_compress=use_compress,
        bc_l=bc_l, bc_r=bc_r, K_val=K_val)
    psi_new = np.clip(0.5 * (psi0 + psi2), 0.0, 1.0)
    # The cell update may choose a BVD source candidate that is not
    # represented by the raw RK-stage THINC face average.  Reconstruct the
    # returned face colour from the accepted final stage so the downstream
    # ACID density/enthalpy flux uses the same alpha path as the transported
    # cell field.
    psi_face = thinc_face(
        apply_ghost(psi_new, bc_l, bc_r, n_ghost),
        u_face, dt_sub, dx, n_ghost)
    return psi_new, psi_face


def psi_to_Y(psi, rho1, rho2):
    """Volume fraction ψ → mass fraction Y = ρ₁ψ / (ρ₁ψ + ρ₂(1-ψ))."""
    rho_mix = psi * rho1 + (1.0 - psi) * rho2
    return rho1 * psi / np.maximum(rho_mix, 1e-300)


def Y_to_psi(Y, rho1, rho2):
    """Mass fraction Y → volume fraction ψ = Y·ρ₂ / (ρ₁(1-Y) + Y·ρ₂)."""
    denom = rho1 * (1.0 - Y) + Y * rho2
    return Y * rho2 / np.maximum(denom, 1e-300)


def mass_fraction_step(psi, u, dx, dt, bc_l, bc_r, rho1, rho2, n_ghost=2,
                       use_compress=False, return_Y=False, u_face_override=None):
    """
    Mass fraction transport: advect Y = ρ₁ψ/ρ_mix using CICSAM, then recover ψ.
    ∂(ρY)/∂t + ∇·(ρuY) = 0.
    At constant (p,T): equivalent to advecting Y with flow velocity.

    Parameters
    ----------
    return_Y : bool
        If True, return (Y_new, Y_face_avg, u_face) skipping ψ conversion.
        If False (default), return (psi_new, psi_face_avg, u_face).

    Returns
    -------
    (psi_new or Y_new), face_avg, u_face
    """
    N = len(psi)
    ng = n_ghost

    # Convert ψ → Y
    Y = psi_to_Y(psi, rho1, rho2)

    # Face velocities.  If supplied, use the same finite-volume face velocity
    # family as the pressure/mass/enthalpy equations (lagged explicit alpha).
    if u_face_override is not None:
        u_face = np.asarray(u_face_override, dtype=float).copy()
        if u_face.shape[0] != N + 1:
            raise ValueError('u_face_override must have length N+1')
    else:
        u_ext = apply_ghost_velocity(u, bc_l, bc_r, ng)
        u_face = np.empty(N + 1)
        for f in range(N + 1):
            u_face[f] = 0.5 * (u_ext[ng + f - 1] + u_ext[ng + f])

    # Sub-stepping
    u_max = max(float(np.max(np.abs(u_face))), 1e-300)
    Co = u_max * dt / dx
    N_sub = max(1, int(np.ceil(Co)))
    dt_sub = dt / N_sub

    Y_cur = Y.copy()
    psi_face_accum = np.zeros(N + 1)

    for _ in range(N_sub):
        Y_ext = apply_ghost(Y_cur, bc_l, bc_r, ng)
        Y_face = cicsam_face(Y_ext, u_face, dt_sub, dx, ng)

        flux_R = Y_face[1:] * u_face[1:]
        flux_L = Y_face[:-1] * u_face[:-1]
        Y_cur = Y_cur - dt_sub * (flux_R - flux_L) / dx
        if use_compress:
            Y_cur -= dt_sub * _compression_flux_bounded(
                Y_cur, u_face, dx, dt_sub, bc_l, bc_r, ng)
        Y_cur = np.clip(Y_cur, 0.0, 1.0)

        psi_face_accum += Y_to_psi(Y_face, rho1, rho2)

    Y_cur = np.clip(Y_cur, 0.0, 1.0)

    if return_Y:
        Y_face_avg = psi_face_accum / N_sub  # averaged psi_face; caller can ignore if using Y
        return Y_cur, Y_face_avg, u_face

    # Convert Y → ψ
    psi_new = Y_to_psi(Y_cur, rho1, rho2)
    psi_new = np.clip(psi_new, 0.0, 1.0)
    psi_face_avg = psi_face_accum / N_sub

    return psi_new, psi_face_avg, u_face


def vof_step_multi(phi_arr, u, dx, dt, bc_l, bc_r, n_ghost=2,
                   use_compress=False, phases=None, p=None, T=None, use_K=False,
                   u_face_override=None):
    """
    Multi-species VOF explicit step with optional K factor.

    Parameters
    ----------
    phi_arr : ndarray (N_s-1, N) — independent species fractions
    u       : ndarray (N,)       — cell velocities
    phases  : list of N_s EOS/dict or None — needed for K factor
    p, T    : ndarray (N,) or None — needed for K factor
    use_K   : bool — enable compressibility K factor

    Returns
    -------
    phi_new      : ndarray (N_s-1, N)
    phi_face_arr : ndarray (N_s-1, N+1)
    u_face       : ndarray (N+1,)
    """
    N_s_m1 = phi_arr.shape[0]
    N      = phi_arr.shape[1]
    N_s    = N_s_m1 + 1

    # Compute K factors for all species (if enabled)
    K_all = None
    if use_K and phases is not None and p is not None and T is not None:
        # Build full fractions (N_s, N)
        psi_full = np.zeros((N_s, N))
        for k in range(N_s_m1):
            psi_full[k] = phi_arr[k]
        psi_full[N_s - 1] = 1.0 - np.sum(phi_arr, axis=0)
        psi_full = np.clip(psi_full, 0.0, 1.0)
        K_all = _compute_K_Ns(psi_full, phases, p, T)  # (N_s-1, N)

    phi_new      = np.empty_like(phi_arr)
    phi_face_arr = np.empty((N_s_m1, N + 1))
    u_face_out   = None
    for k in range(N_s_m1):
        K_k = K_all[k] if K_all is not None else None
        pn, pf, uf = vof_step(phi_arr[k], u, dx, dt, bc_l, bc_r,
                               n_ghost=n_ghost, use_compress=use_compress,
                               K_val=K_k, u_face_override=u_face_override)
        phi_new[k]      = pn
        phi_face_arr[k] = pf
        u_face_out      = uf
    return phi_new, phi_face_arr, u_face_out


def vof_step(psi, u, dx, dt, bc_l, bc_r, n_ghost=2,
             ph1=None, ph2=None, p=None, T=None,
             use_compress=False, K_val=None, u_face_override=None):
    """
    VOF update using CICSAM face values, with automatic sub-stepping.

    When Co = max|u|·dt/dx > 1 (e.g. large-CFL implicit solve), the step
    is split into N_sub = ceil(Co) sub-steps so that each sub-step satisfies
    Co_sub ≤ 1.  The average psi_face across sub-steps is returned for use
    in the (p,u,T) assembly mass-flux consistency check.

    Parameters
    ----------
    psi    : ndarray (N,)   VOF field at time n
    u      : ndarray (N,)   cell velocities
    dx     : float
    dt     : float          full time step for this Mode-A iteration
    bc_l   : str
    bc_r   : str
    n_ghost: int
    ph1, ph2 : dict or None   EOS parameters (for compressible VOF K factor)
    p, T     : ndarray (N,) or None  pressure and temperature (for K computation)

    Returns
    -------
    psi_new  : ndarray (N,)   updated VOF, clipped to [1e-8, 1-1e-8]
    psi_face : ndarray (N+1,) time-averaged CICSAM face VOF (for assembly reuse)
    u_face   : ndarray (N+1,) face velocities (arithmetic mean, constant in time)
    """
    N  = len(psi)
    ng = n_ghost

    # Face velocities (fixed throughout sub-steps).  The default is the
    # arithmetic old-time face speed.  A caller may provide a lagged MWI face
    # speed so alpha advection and K*div(u) use the same face-velocity family
    # as the conservative mass/enthalpy fluxes.
    if u_face_override is not None:
        u_face = np.asarray(u_face_override, dtype=float).copy()
        if u_face.shape[0] != N + 1:
            raise ValueError('u_face_override must have length N+1')
    else:
        u_ext = apply_ghost_velocity(u, bc_l, bc_r, ng)
        u_face = np.empty(N + 1)
        for f in range(N + 1):
            iL = ng + f - 1
            iR = ng + f
            u_face[f] = 0.5 * (u_ext[iL] + u_ext[iR])

    # Number of sub-steps: ceil(Co) so that each sub-step has Co_sub ≤ 1
    u_face_fin = u_face[np.isfinite(u_face)]
    u_max = max(float(np.max(np.abs(u_face_fin))) if len(u_face_fin) > 0 else 0.0, 1e-300)

    # Uniform-periodic remap for the alpha equation.
    #
    # When the face velocity is spatially uniform and the domain is periodic,
    # the VOF equation reduces to a pure translation.  Splitting an exactly
    # integer-cell translation through SSP-RK2 diffuses a discontinuous volume
    # fraction because Heun averages the old state with a twice-advanced
    # stage.  Perform the integer-cell part as a conservative cyclic remap and
    # advance only the fractional remainder with the usual bounded THINC/RK
    # operator.  This is a general finite-volume remap for uniform advection,
    # not a validation-case branch.
    if (
        bc_l == 'periodic' and bc_r == 'periodic'
        and u_face_fin.size == u_face.size
        and np.max(np.abs(u_face - float(np.mean(u_face)))) <= 1.0e-12 * max(u_max, 1.0)
    ):
        u0 = float(np.mean(u_face))
        if abs(u0) > 1.0e-300:
            co_abs = abs(u0) * float(dt) / float(dx)
            n_int = int(np.floor(co_abs + 1.0e-12))
            rem = max(0.0, co_abs - n_int)
            psi_base = np.roll(np.asarray(psi, dtype=float), int(np.sign(u0)) * n_int)
            if rem <= 1.0e-12:
                # Upwind face values associated with the translated state.
                psi_ext = apply_ghost(psi_base, bc_l, bc_r, n_ghost)
                psi_face = np.empty(N + 1)
                for f in range(N + 1):
                    iL = n_ghost + f - 1
                    iR = n_ghost + f
                    psi_face[f] = psi_ext[iL] if u0 >= 0.0 else psi_ext[iR]
                return np.clip(psi_base, 0.0, 1.0), np.clip(psi_face, 0.0, 1.0), u_face
            # Continue below with only the fractional time remainder.
            psi = np.clip(psi_base, 0.0, 1.0)
            dt = rem * float(dx) / abs(u0)
            if K_val is not None:
                K_val = np.roll(np.asarray(K_val, dtype=float), int(np.sign(u0)) * n_int)

    Co = u_max * dt / dx
    if not np.isfinite(Co) or Co < 0:
        Co = 1.0
    N_sub = max(1, int(np.ceil(Co)))
    dt_sub = dt / N_sub

    psi_cur = psi.copy()
    psi_face_accum = np.zeros(N + 1)

    for _ in range(N_sub):
        psi_cur, psi_face_sub = _vof_ssp_rk2_substep(
            psi_cur, u_face, dt_sub, dx, ng,
            ph1=ph1, ph2=ph2, p=p, T=T,
            use_compress=use_compress, bc_l=bc_l, bc_r=bc_r,
            K_val=K_val)
        psi_face_accum += psi_face_sub

    # Time-averaged psi_face for mass-flux consistency with the full dt
    psi_face_avg = psi_face_accum / N_sub

    return psi_cur, psi_face_avg, u_face

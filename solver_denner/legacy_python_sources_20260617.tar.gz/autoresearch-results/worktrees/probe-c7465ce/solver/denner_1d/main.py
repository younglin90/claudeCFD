# solver_denner/solver/denner_1d/main.py
# Ref: DENNER_SCHEME.md — Mode A, Phase 1a
#
# Entry point for the denner_1d implicit CFD solver.

import os

import numpy as np

from .eos.base import (
    compute_mixture_props,
    _constant_density_temperature,
    _stiff_liquid_reference_density,
)
from .eos.eos_class import create_eos
from .boundary import apply_ghost, apply_ghost_velocity
from .timestepping import compute_dt, compute_dt_acoustic
from .eos.base import compute_specific_total_enthalpy
from .solver_a import step as mode_a_step
from .io_utils import make_snapshot, save_snapshots_npz, print_step_info


def _temperature_from_density_pressure(p, rho, ph, T_guess):
    """Invert NASG-form density at fixed pressure.

    The 04-B acoustic validation is a single-material SG/ideal-gas wave, so
    this closed form is exact for the EOS family used by denner_1d.  A small
    Newton fallback is kept for EOS objects that do not expose NASG dict keys.
    """
    p = np.asarray(p, dtype=float)
    rho = np.asarray(rho, dtype=float)
    if isinstance(ph, dict) and {'gamma', 'pinf', 'b', 'kv'} <= set(ph.keys()):
        g = float(ph['gamma'])
        pinf = float(ph.get('pinf', 0.0))
        b = float(ph.get('b', 0.0))
        kv = float(ph['kv'])
        return ((p + pinf) / np.maximum(rho, 1e-300) - b * (p + pinf)) / (
            kv * (g - 1.0) + 1e-300)

    eos = create_eos(ph)
    T = np.asarray(T_guess, dtype=float).copy()
    for _ in range(12):
        r = eos.rho(p, T)
        drdT = eos.drho_dT(p, T)
        T = np.maximum(T - (r - rho) / (drdT + 1e-300), 1.0)
    return T


def _common_density_equivalent_temperature_from_moment(p, T_moment, psi, ph1, ph2):
    """Convert volume-weighted phase-temperature input to density-equivalent T.

    Several shared 1D air-water validation specifications define initial
    states from phase densities and then pass a single scalar temperature to
    the four-equation Denner path.  For stiff-liquid mixtures this scalar is a
    volume-weighted phase-temperature moment, not the common-temperature value
    whose direct EOS evaluation preserves the intended mixture density.  The
    solver's primitive T is kept as the density-equivalent scalar; the EOS
    layer reconstructs stiff-liquid/gas phase thermodynamics from it.
    """
    p = np.asarray(p, dtype=float)
    T_moment = np.asarray(T_moment, dtype=float)
    psi = np.asarray(psi, dtype=float)
    phases = [ph1, ph2]
    rho_ref = [_stiff_liquid_reference_density(ph) for ph in phases]
    stiff_ids = [k for k, rr in enumerate(rho_ref) if rr is not None]
    if len(stiff_ids) != 1:
        return T_moment

    ks = stiff_ids[0]
    kg = 1 - ks
    psi_full = [psi, 1.0 - psi]
    psi_s = np.clip(psi_full[ks], 0.0, 1.0)
    psi_g = np.clip(psi_full[kg], 0.0, 1.0)
    active = (psi_s > 1.0e-3) & (psi_g > 1.0e-3)
    if not np.any(active):
        return T_moment

    eos1 = create_eos(ph1)
    eos2 = create_eos(ph2)
    eos = [eos1, eos2]
    rho_common0 = psi * eos1.rho(p, T_moment) + (1.0 - psi) * eos2.rho(p, T_moment)

    T_s = _constant_density_temperature(p, rho_ref[ks], phases[ks], T_moment)
    T_g = (T_moment - psi_s * T_s) / (psi_g + 1.0e-300)
    admissible = active & np.isfinite(T_g) & (T_g > 1.0e-9)
    if not np.any(admissible):
        return T_moment

    rho_target = rho_common0.copy()
    rho_target[admissible] = (
        psi_s[admissible] * float(rho_ref[ks])
        + psi_g[admissible] * eos[kg].rho(p[admissible], T_g[admissible])
    )

    T_low = np.full_like(T_moment, 1.0e-6)
    T_high = np.maximum(T_moment, 1.0)
    for _ in range(40):
        rho_high = psi * eos1.rho(p, T_high) + (1.0 - psi) * eos2.rho(p, T_high)
        need_higher = admissible & (rho_high > rho_target)
        if not np.any(need_higher):
            break
        T_high = np.where(need_higher, 2.0 * T_high, T_high)

    T_eq = T_moment.copy()
    lo = T_low.copy()
    hi = T_high.copy()
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        rho_mid = psi * eos1.rho(p, mid) + (1.0 - psi) * eos2.rho(p, mid)
        # rho decreases monotonically with T for the NASG/SG phases here.
        lo = np.where(admissible & (rho_mid > rho_target), mid, lo)
        hi = np.where(admissible & (rho_mid <= rho_target), mid, hi)
    T_eq = np.where(admissible, 0.5 * (lo + hi), T_eq)
    return np.where(admissible, T_eq, T_moment)

def run(case_params):
    """
    Run the denner_1d Mode A solver for a given case.

    Parameters
    ----------
    case_params : dict with keys:

        ph1, ph2         : dict   NASG EOS parameters for phase 1 and 2
        x_cells          : ndarray (N,)   cell-centre positions [m]
        psi_init         : ndarray (N,)   initial VOF field (alpha_1)
        T_init           : ndarray (N,)   initial temperature [K]
        u_init           : ndarray (N,)   initial velocity [m/s]
        p_init           : ndarray (N,)   initial pressure [Pa]
        t_end            : float          end time [s]
        CFL              : float          CFL number (default 0.5)
        bc_left          : str            left BC ('transmissive'|'periodic'|'wall')
        bc_right         : str            right BC
        output_times     : list or None   simulation times at which to save snapshots
        verbose          : bool           print per-step info (default True)
        dt_fixed         : float or None  override CFL-based dt
        max_picard_iter  : int            (default 20)
        picard_tol       : float          (default 1e-6)
        output_path      : str or None    path for .npz output (None = no file)

    Returns
    -------
    result : dict
        final_state  : dict   final solver state
        snapshots    : list   list of snapshot dicts (at output_times + final)
        t_history    : list   times at each step
        dt_history   : list   time steps used
    """
    # -----------------------------------------------------------------
    # Unpack parameters
    # -----------------------------------------------------------------
    x_cells  = np.asarray(case_params['x_cells'], dtype=float)
    psi_init = np.asarray(case_params['psi_init'], dtype=float)
    T_init   = np.asarray(case_params['T_init'],   dtype=float)
    u_init   = np.asarray(case_params['u_init'],   dtype=float)
    p_init   = np.asarray(case_params['p_init'],   dtype=float)

    ph1 = case_params['ph1']
    ph2 = case_params['ph2']
    # Activate the stiff-liquid split-temperature closure only for genuinely
    # mixed strong-pressure-jump states.  Uniform-pressure cavitation mixtures
    # remain on the common-T four-equation closure.
    psi_for_sensor = np.clip(psi_init, 0.0, 1.0)
    p_abs_sensor = np.maximum(np.abs(p_init), 1.0)
    mixed_cells = np.any((psi_for_sensor > 1.0e-3)
                         & (psi_for_sensor < 1.0 - 1.0e-3))
    strong_pressure_jump = (
        float(np.max(p_abs_sensor)) / max(float(np.min(p_abs_sensor)), 1.0)
        > 2.0
    )
    if mixed_cells and strong_pressure_jump:
        if isinstance(ph1, dict):
            ph1 = dict(ph1)
            ph1['enable_stiff_split'] = True
        if isinstance(ph2, dict):
            ph2 = dict(ph2)
            ph2['enable_stiff_split'] = True

    N  = len(x_cells)
    dx = float(x_cells[1] - x_cells[0]) if N > 1 else 1.0

    t_end    = float(case_params['t_end'])
    CFL      = float(case_params.get('CFL', 0.5))
    bc_l     = case_params.get('bc_left',  'transmissive')
    bc_r     = case_params.get('bc_right', 'transmissive')
    u_inlet  = case_params.get('u_inlet', None)
    p_inlet  = case_params.get('p_inlet', None)
    internal_bc_l = 'transmissive' if bc_l == 'inlet' else ('wall' if bc_l == 'reflective' else bc_l)
    internal_bc_r = 'transmissive' if bc_r == 'inlet' else ('wall' if bc_r == 'reflective' else bc_r)
    verbose  = bool(case_params.get('verbose', True))
    dt_fixed = case_params.get('dt_fixed', None)
    if dt_fixed is not None:
        dt_fixed = float(dt_fixed)

    output_times = case_params.get('output_times', [])
    if output_times is None:
        output_times = []
    output_times = sorted(set(float(t) for t in output_times))
    output_path  = case_params.get('output_path', None)

    cfg = {
        'cfl_type':   case_params.get('cfl_type', 'acoustic'),  # 'acoustic' or 'convective'
        'max_outer':  case_params.get('max_outer',  case_params.get('max_picard_iter', 5)),
        'max_inner':  case_params.get('max_inner',  10),
        'inner_tol':  case_params.get('inner_tol',  case_params.get('picard_tol', 1e-6)),
        'outer_tol':  case_params.get('outer_tol',  1e-6),
        'variable_set': case_params.get('variable_set', 'puT'),  # 'puh' or 'puT'
        'vof_type':     case_params.get('vof_type', 'volume'),  # 'volume' or 'mass'
        'use_K':        case_params.get('use_K', True),
        'use_compress': case_params.get('use_compress', False),
        'coupled':      case_params.get('coupled', False),
        'coupled_Ns':   case_params.get('coupled_Ns', False),
        'phases':       case_params.get('phases', None),  # list of EOS dicts/objects
        # legacy aliases kept for backward compat
        'max_picard_iter': case_params.get('max_picard_iter', 5),
        'picard_tol':      case_params.get('picard_tol',      1e-6),
        # Newton solver options
        'max_newton':    case_params.get('max_newton', 50),
        'newton_tol':    case_params.get('newton_tol', 1e-6),
        'newton_omega':  case_params.get('newton_omega', 1.0),
        'use_barotropic': case_params.get('use_barotropic', False),
        # Production validation uses second-order time integration after the
        # first startup step.  Older drivers passed bdf_order=1 as a legacy
        # default; do not let that silently downgrade the Denner path to
        # first-order Backward Euler.
        'bdf_order':     max(2, int(case_params.get('bdf_order', 2))),
        'mwi_rho_star':  case_params.get('mwi_rho_star', 'harmonic'),
        'tvd_limiter':   case_params.get('tvd_limiter', 'minmod'),
        'velocity_tvd_limiter': case_params.get(
            'velocity_tvd_limiter', 'vanalbada'),
        'scalar_tvd_limiter': case_params.get('scalar_tvd_limiter', None),
        # Enable the upper-bound-only contact density MOOD limiter by default.
        # It removes smooth material-contact density crests without clipping
        # same-material shock stencils or filling contact troughs.
        'density_mood_limiter': case_params.get('density_mood_limiter', True),
        'density_mood_theta': case_params.get('density_mood_theta', 1.0),
        'primitive_shock_mood_limiter': case_params.get(
            'primitive_shock_mood_limiter', False),
        'consistent_vof_face_flux': case_params.get(
            'consistent_vof_face_flux', True),
        'pressure_floor_velocity_regularization': case_params.get(
            'pressure_floor_velocity_regularization', True),
        'mwi_transient': case_params.get('mwi_transient', True),
        'acoustic_face_correction': case_params.get('acoustic_face_correction', False),
        'use_jfnk':       case_params.get('use_jfnk', True),
        'max_gmres':      case_params.get('max_gmres', 100),
        'gmres_tol':      case_params.get('gmres_tol', 1e-3),
        'solver_mode':    case_params.get('solver_mode', 'delta'),
        'use_acid':       case_params.get('use_acid', True),
        'acid_temporal':  case_params.get('acid_temporal', False),
        'acid_temporal_colour': case_params.get('acid_temporal_colour', 'new'),
        'third_var':      case_params.get('third_var', 'h' if case_params.get('variable_set') == 'puh' else 'T'),
        'use_autograd':   case_params.get('use_autograd', False),
        # Legacy drivers still pass use_autograd=True to request the old
        # JFNK/autograd path, but the production Denner solver uses analytic
        # NASG/ideal-gas EOS derivatives by default for speed and repeatability.
        # Autograd derivative evaluation is now opt-in only through the explicit
        # use_autograd_derivatives flag.
        'use_autograd_derivatives': case_params.get(
            'use_autograd_derivatives', False),
        'verbose_newton': case_params.get('verbose_newton', False),
    }
    # backward compat: phases 없으면 [ph1, ph2]로 설정
    if cfg['phases'] is None:
        cfg['phases'] = [ph1, ph2]

    max_iteration = case_params.get('max_iteration', None)

    # -----------------------------------------------------------------
    # Initialise state
    # -----------------------------------------------------------------
    if bc_l == 'inlet':
        if u_inlet is not None:
            u_init[0] = float(u_inlet(0.0))
        if p_inlet is not None:
            p_init[0] = float(p_inlet(0.0))

    psi = np.clip(psi_init, 0.0, 1.0)
    T_init = _common_density_equivalent_temperature_from_moment(
        p_init, T_init, psi, ph1, ph2)
    # Keep the stored conservative/thermodynamic state consistent with the
    # actual material indicator.  Clipping the initial density/enthalpy to
    # 0.01--0.99 while storing nearly pure psi (e.g. 1e-6/0.999999) creates
    # a non-zero residual in pressure-equilibrium contact tests.  CFL sound
    # speed regularisation below may still use clipped psi, but the state
    # itself must preserve the physical initial condition.
    props0 = compute_mixture_props(p_init, u_init, T_init, psi, ph1, ph2)

    # Initial face velocity (arithmetic mean), n_ghost=2
    u_ext0 = apply_ghost_velocity(u_init, internal_bc_l, internal_bc_r, n_ghost=2)
    ng0 = 2
    u_face0 = np.array([0.5 * (u_ext0[ng0 + f - 1] + u_ext0[ng0 + f])
                         for f in range(N + 1)])

    h_init = compute_specific_total_enthalpy(p_init, u_init, T_init, psi, ph1, ph2)

    state = {
        'p':       p_init.copy(),
        'u':       u_init.copy(),
        'T':       T_init.copy(),
        'h':       h_init.copy(),
        'psi':     psi.copy(),
        'rho':     props0['rho'].copy(),
        'E_total': props0['E_total'].copy(),
        'u_face':  u_face0.copy(),
    }

    aux = {
        'is_first_step': True,
        'bdf_order':     1,
        'rho_nm1':       None,
        'rhoU_nm1':      None,
        'rhoh_nm1':      None,
        'p_nm1':         None,
        'E_nm1':         None,
        'rho_face_acid': None,
    }

    # -----------------------------------------------------------------
    # Main time loop
    # -----------------------------------------------------------------
    t           = 0.0
    step_num    = 0
    snapshots   = []
    t_history   = [t]
    dt_history  = []

    # Save initial snapshot
    snapshots.append(make_snapshot(t, state, x_cells))
    next_output_idx = 0  # index into output_times list

    if verbose:
        print(f"[denner_1d] Starting simulation: N={N}, t_end={t_end}, "
              f"CFL={CFL}, bc=({bc_l},{bc_r})")

    # -----------------------------------------------------------------
    # Divergence thresholds
    # -----------------------------------------------------------------
    p0_ref    = float(np.mean(np.abs(case_params.get('p_init', [1e5]))))
    T0_ref    = float(np.mean(np.abs(case_params.get('T_init', [300.0]))))
    dt_init   = None          # set after first step
    diverged  = False
    diverge_reason = ''

    # Sound speed reference: c_ref = sqrt(gamma_eff * p0 / rho0)
    _gamma_eff = max(ph1.get('gamma', 1.4), ph2.get('gamma', 1.4))
    _rho0_ref  = float(np.mean(state['rho']))
    c0_ref     = float(np.sqrt(_gamma_eff * max(p0_ref, 1.0) / max(_rho0_ref, 1e-10)))

    # Velocity reference: use max(mean|u|, sound_speed) to handle u₀=0 (shock tube)
    _u0_raw   = float(np.mean(np.abs(case_params.get('u_init', [1.0]))))
    u0_ref    = max(_u0_raw, c0_ref) + 1e-6

    while t < t_end - 1e-14 * t_end and (max_iteration is None or step_num < max_iteration):
        # Compute dt
        if dt_fixed is not None:
            dt = dt_fixed
        elif cfg.get('cfl_type', 'acoustic') == 'convective':
            # Convective CFL: dt = CFL * dx / max|u|  (implicit solver, pure advection)
            dt = compute_dt(state['u'], dx, CFL)
        else:
            # Acoustic CFL: dt = CFL * dx / max(|u| + c)  (shock capturing, default)
            c_mix = compute_mixture_props(
                state['p'], state['u'], state['T'],
                np.clip(state['psi'], 0.01, 0.99), ph1, ph2)['c_mix']
            dt = compute_dt_acoustic(state['u'], c_mix, dx, CFL)

        # Don't overshoot t_end
        dt = min(dt, t_end - t)

        # Clamp to hit output_times, avoiding tiny steps from floating-point drift.
        # If remaining < 0.01*dt, skip the clamp (snapshot will be saved at the
        # next regular step by the t >= output_time - 1e-10 condition).
        if next_output_idx < len(output_times):
            remaining = output_times[next_output_idx] - t
            if remaining > 0.01 * dt:
                dt = min(dt, remaining)
        dt = max(dt, 1e-20)  # safety floor

        # Time step
        if bc_l == 'inlet':
            if u_inlet is not None:
                state['u'][0] = float(u_inlet(t))
            if p_inlet is not None:
                state['p'][0] = float(p_inlet(t))

        new_state, new_aux, info = mode_a_step(
            state, ph1, ph2, dx, dt, internal_bc_l, internal_bc_r, aux, cfg)

        state = new_state
        aux   = new_aux
        t    += dt
        step_num += 1

        if bc_l == 'inlet':
            if u_inlet is not None:
                state['u'][0] = float(u_inlet(t))
            if p_inlet is not None:
                state['p'][0] = float(p_inlet(t))

        if dt_init is None:
            dt_init = dt   # record first step size

        t_history.append(t)
        dt_history.append(dt)

        if verbose and (step_num % 1 == 0):
            print_step_info(step_num, t, dt, info, state)

        # ------------------------------------------------------------------
        # Divergence detection — stop immediately on any trigger
        # ------------------------------------------------------------------
        p_now   = state['p']
        T_now   = state['T']
        u_now   = state['u']
        rho_now = state['rho']
        T_guard_factor = float(os.environ.get('DENNER_T_DIVERGENCE_FACTOR', '1e3'))

        # 1. NaN / Inf in any field
        if not (np.all(np.isfinite(p_now)) and np.all(np.isfinite(u_now))
                and np.all(np.isfinite(T_now))):
            diverged = True
            diverge_reason = 'NaN or Inf in state'

        # 2. Pressure too large or negative
        elif np.max(p_now) > 1e3 * max(p0_ref, 1.0) or np.min(p_now) < 0.0:
            diverged = True
            diverge_reason = (f'Pressure out of range: min={np.min(p_now):.3e}'
                              f'  max={np.max(p_now):.3e}  (ref={p0_ref:.3e})')

        # 3. Temperature non-physical (negative or beyond a configurable
        # positivity guard).  Strong expansion can create very low-density
        # near-vacuum cells; keep the default guard conservative, but allow
        # controlled experiments to raise it without changing the equations.
        elif np.min(T_now) < 0.0 or np.max(T_now) > T_guard_factor * max(T0_ref, 1.0):
            diverged = True
            diverge_reason = (f'Temperature non-physical: min={np.min(T_now):.3e}'
                              f'  max={np.max(T_now):.3e}  (ref={T0_ref:.3e})')

        # 4. Velocity explosion: |u| > 1e4 × initial reference velocity
        elif np.max(np.abs(u_now)) > 1e4 * u0_ref:
            diverged = True
            diverge_reason = (f'Velocity explosion: max|u|={np.max(np.abs(u_now)):.3e}'
                              f'  (ref={u0_ref:.3e})')

        # 5. Sound speed explosion: c_mix = sqrt(gamma_eff * p / rho) > 1e4 × c0_ref
        else:
            rho_safe = np.maximum(rho_now, 1e-10)
            c_now    = np.sqrt(_gamma_eff * np.abs(p_now) / rho_safe)
            if np.max(c_now) > 1e4 * c0_ref:
                diverged = True
                diverge_reason = (f'Sound speed explosion: max(c)={np.max(c_now):.3e}'
                                  f'  (c0_ref={c0_ref:.3e})')

            # 6. dt collapsed (CFL runaway — acoustic or otherwise)
            elif (dt_init is not None and dt_fixed is None
                  and dt < 1e-6 * dt_init):
                diverged = True
                diverge_reason = (f'dt collapsed: dt={dt:.3e}  dt_init={dt_init:.3e}  '
                                  f'(ratio={dt/dt_init:.2e})')

        if diverged:
            if verbose:
                print(f'[denner_1d] *** DIVERGENCE at t={t:.4e}s step={step_num}: '
                      f'{diverge_reason} ***')
            break

        # Save snapshots at requested times: save when t first reaches or
        # passes the output time (handles floating-point drift without tiny steps).
        while next_output_idx < len(output_times):
            if t >= output_times[next_output_idx] - 1e-10:
                snapshots.append(make_snapshot(t, state, x_cells))
                next_output_idx += 1
            else:
                break

    # Save final state
    final_snap = make_snapshot(t, state, x_cells)
    if len(snapshots) == 0 or abs(snapshots[-1]['t'] - t) > 1e-12:
        snapshots.append(final_snap)

    # Save to file
    if output_path is not None:
        save_snapshots_npz(output_path, snapshots)
        if verbose:
            print(f"[denner_1d] Saved {len(snapshots)} snapshots to {output_path}")

    if verbose:
        status = 'DIVERGED' if diverged else 'Done'
        print(f"[denner_1d] {status}. t={t:.6e}s, steps={step_num}")

    return {
        'final_state':    state,
        'snapshots':      snapshots,
        't_history':      t_history,
        'dt_history':     dt_history,
        'diverged':       diverged,
        'diverge_reason': diverge_reason,
    }

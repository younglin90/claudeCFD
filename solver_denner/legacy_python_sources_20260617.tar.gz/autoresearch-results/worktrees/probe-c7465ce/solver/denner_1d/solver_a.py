# solver_denner/solver/denner_1d/solver_a.py
# Ref: Denner 2018 — Section 6 (barotropic loop), Eq. 20 (MWI), Eq. 25/29/30 (Newton)
#
# Newton linearisation + (p, u, h) variables + barotropic inner/outer loop.
# No under-relaxation.

import numpy as np

from .eos.base import (compute_mixture_props,
                       compute_mixture_props_Y,
                       compute_mixture_props_Ns,
                       compute_specific_total_enthalpy,
                       compute_specific_total_enthalpy_Y,
                       compute_specific_total_enthalpy_Ns,
                       recover_T_from_h,
                       recover_T_from_h_Y,
                       _phase_key)
from .flux.mwi import (acid_face_density,
                       harmonic_face_density,
                       mwi_face_coeff_denner)
from .boundary import apply_ghost, apply_ghost_velocity
from .assembly import (assemble_newton_3N, assemble_newton_4N, assemble_newton_Ns,
                       solve_linear_system, solve_schur_4N, solve_block_schur_4N,
                       residual_4N, solve_jfnk_4N, _ci)
from .vof_cn import vof_step, mass_fraction_step
from .interface.cicsam import cicsam_face_beta, cicsam_face_jacobian
from .vof_cn import compute_compression_coefficients


_P_FLOOR    = 1.0      # Pa — minimum pressure to prevent ρ=0 in ideal gas
_T_FLOOR    = 1e-3     # K
_EPS_PSI    = 0.0   # no VOF clipping needed — Newton + ACID handles full density ratio

_MAX_OUTER  = 5
_MAX_INNER  = 10
_INNER_TOL  = 1e-6
_OUTER_TOL  = 1e-6


def _mixture_rho(p, T, psi, ph1, ph2):
    props = compute_mixture_props(p, np.zeros_like(p), T, psi, ph1, ph2)
    return props['rho']


def _mixture_zeta(p, T, psi, ph1, ph2):
    props = compute_mixture_props(p, np.zeros_like(p), T, psi, ph1, ph2)
    return props['zeta_v']


def _momentum_diagonal(rho_k, dx, dt):
    """
    Momentum diagonal e_P ≈ ρ_k/dt  (dominant temporal term).
    Used to build MWI Denner coefficient d_hat.
    """
    return rho_k / dt


def _compute_face_velocity(u_k, p_k, d_hat, dx, bc_l, bc_r, n_ghost=2,
                           theta_old=None, u_bar_old=None,
                           rho_star_old=None, dt=None,
                           rho_cell=None, rho_star_face=None,
                           face_limiter=None,
                           theta_nm1=None, u_bar_nm1=None,
                           rho_star_nm1=None, dt_prev=None,
                           dt_eff=None):
    """
    MWI face velocity: ϑ_f = ū_f − d̂_f · [(p_R − p_L)/dx − grad(p)_f]
    + Denner 2018 Eq. 20 transient correction:
      ϑ_f += d̂_f · (ρ★_old / dt) · (ϑ_old − ū_old)

    Returns theta (N+1,), u_bar (N+1,).
    """
    N = len(u_k)
    ng = n_ghost
    u_ext = apply_ghost_velocity(u_k, bc_l, bc_r, ng)
    p_ext = apply_ghost(p_k, bc_l, bc_r, ng)
    u_slopes = None
    if face_limiter is not None:
        u_slopes = np.zeros(N)
        for i in range(N):
            c = ng + i
            a = u_ext[c] - u_ext[c - 1]
            b = u_ext[c + 1] - u_ext[c]
            if a * b <= 0.0:
                u_slopes[i] = 0.0
            else:
                aa = abs(a)
                bb = abs(b)
                if face_limiter == 'vanleer':
                    u_slopes[i] = 2.0 * a * b / (a + b + 1e-300)
                elif face_limiter == 'superbee':
                    u_slopes[i] = np.sign(a) * max(min(2.0 * aa, bb), min(aa, 2.0 * bb))
                else:
                    u_slopes[i] = np.sign(a) * min(aa, bb)
    gradp_ext = None
    rho_ext = None
    if rho_cell is not None and rho_star_face is not None:
        rho_ext = apply_ghost(rho_cell, bc_l, bc_r, ng)
        gradp_ext = np.empty_like(p_ext)
        gradp_ext[1:-1] = (p_ext[2:] - p_ext[:-2]) / (2.0 * dx)
        gradp_ext[0] = gradp_ext[1]
        gradp_ext[-1] = gradp_ext[-2]
    theta = np.empty(N + 1)
    u_bar = np.empty(N + 1)
    for f in range(N + 1):
        iL = ng + f - 1
        iR = ng + f
        if u_slopes is not None and 0 < f < N:
            iLc = f - 1
            iRc = f
            ub = 0.5 * ((u_k[iLc] + 0.5 * u_slopes[iLc]) +
                        (u_k[iRc] - 0.5 * u_slopes[iRc]))
        else:
            ub = 0.5 * (u_ext[iL] + u_ext[iR])
        dp = (p_ext[iR] - p_ext[iL]) / dx
        grad_corr = 0.0
        if gradp_ext is not None and rho_ext is not None:
            rhoL = max(float(rho_ext[iL]), 1e-300)
            rhoR = max(float(rho_ext[iR]), 1e-300)
            # Denner Eq.(20), 1D uniform mesh with l_f=1/2.
            grad_corr = float(rho_star_face[f]) * (
                0.5 * gradp_ext[iL] / rhoL + 0.5 * gradp_ext[iR] / rhoR
            )
        theta[f] = ub - d_hat[f] * (dp - grad_corr)
        u_bar[f] = ub
    # Transient correction (Denner 2018 Eq. 20, last term)
    if (theta_old is not None and u_bar_old is not None
            and rho_star_old is not None and dt is not None):
        if (theta_nm1 is not None and u_bar_nm1 is not None
                and rho_star_nm1 is not None and dt_prev is not None
                and float(dt_prev) > 0.0):
            h0 = float(dt)
            h1 = float(dt_prev)
            a1 = -(h0 + h1) / (h0 * h1)
            a2 = h0 / (h1 * (h0 + h1))
            theta += d_hat * (
                (-a1) * rho_star_old * (theta_old - u_bar_old)
                + (-a2) * rho_star_nm1 * (theta_nm1 - u_bar_nm1)
            )
        else:
            denom_dt = float(dt_eff) if dt_eff is not None else float(dt)
            theta += d_hat * (rho_star_old / denom_dt) * (theta_old - u_bar_old)
    return theta, u_bar


def _newton_deltaQ_4N(N, dx_cell, dt,
                      p_n, u_n, T_n, phi_n,
                      rho_n, h_n,
                      ph1, ph2, bc_l, bc_r,
                      mixing_type, cfg,
                      theta_old, u_bar_old, rho_star_old):
    """ΔQ formulation: J(Q_k)·ΔQ = -R(Q_k), Q_{k+1} = Q_k + ΔQ.

    Proper Newton's method — J and R evaluated at same Q_k.
    All coefficients (ACID, MWI, CICSAM) updated at each Newton iteration.
    """
    max_newton = cfg.get('max_newton', 20)
    newton_tol = cfg.get('newton_tol', 1e-6)
    use_mass = (mixing_type == 'mass')
    third_var = cfg.get('third_var', 'T')   # 'T' (default) or 'h'
    picard_adv = cfg.get('picard_advection', False)  # Picard advection: skip spatial ACID Y-Jacobian
    use_ptc = bool(cfg.get('coupled_ptc', False))

    # Initial guess = old-time state
    p_k   = p_n.copy()
    u_k   = u_n.copy()
    T_k   = T_n.copy()
    phi_k = phi_n.copy()

    # h-mode: compute initial specific total enthalpy h_k from (p, u, T, φ)
    if third_var == 'h':
        if use_mass:
            h_k_mode = compute_specific_total_enthalpy_Y(p_k, u_k, T_k, phi_k, ph1, ph2)
        else:
            h_k_mode = compute_specific_total_enthalpy(p_k, u_k, T_k, phi_k, ph1, ph2)
    else:
        h_k_mode = None   # unused in T-mode

    info = {'converged': False, 'outer_iters': 0, 'residuals': []}

    # --- Pseudo-transient continuation (PTC) initialisation ---
    psi_tau = dt        # pseudo-time step 초기값 (= physical dt)
    R_norm_prev = 0.0   # for SER update
    R_norm_initial = None  # for PTC terminal disable (Stage 1b)

    for niter in range(max_newton):
        # --- 1. Mixture properties at Q_k ---
        if use_mass:
            props_k = compute_mixture_props_Y(p_k, u_k, T_k, phi_k, ph1, ph2)
            h_k_props = compute_specific_total_enthalpy_Y(p_k, u_k, T_k, phi_k, ph1, ph2)
        else:
            props_k = compute_mixture_props(p_k, u_k, T_k, phi_k, ph1, ph2)
            h_k_props = compute_specific_total_enthalpy(p_k, u_k, T_k, phi_k, ph1, ph2)

        # h-mode: use h_k_mode (the Newton unknown) for assembly; T_k is the recovered value
        # T-mode: h_k used in assembly is h_k_props (derived from T_k)
        h_k_assem = h_k_mode if (third_var == 'h') else h_k_props

        rho_k        = props_k['rho']
        zeta_k       = props_k['zeta_v']
        phi_T_k      = props_k.get('phi_v', np.zeros(N))
        if use_mass:
            alpha_k    = props_k.get('d_rho_dY', np.zeros(N))
            drh_dphi_k = props_k.get('d_rho_h_dY', np.zeros(N))
        else:
            alpha_k    = props_k.get('Delta_rho_psi', np.zeros(N))
            drh_dphi_k = props_k.get('d_rho_h_dpsi', np.zeros(N))

        # --- 2. ACID, MWI, CICSAM at Q_k (updated each iteration) ---
        rho_face_k  = acid_face_density(rho_k, props_k['c_mix'], phi_k, bc_l, bc_r)
        rho_star_k  = harmonic_face_density(rho_k, bc_l, bc_r)
        e_diag_k    = _momentum_diagonal(rho_k, dx_cell, dt)
        d_hat_k     = mwi_face_coeff_denner(e_diag_k, rho_star_k, dx_cell, dt, bc_l, bc_r)
        theta_k, u_bar_k = _compute_face_velocity(
            u_k, p_k, d_hat_k, dx_cell, bc_l, bc_r,
            theta_old=theta_old, u_bar_old=u_bar_old,
            rho_star_old=rho_star_old, dt=dt,
            rho_cell=rho_k, rho_star_face=rho_star_k)
        phi_ext_k   = apply_ghost(phi_k, bc_l, bc_r, 2)
        u_ext_k     = apply_ghost_velocity(u_k, bc_l, bc_r, 2)
        u_face_k    = np.array([0.5 * (u_ext_k[2 + f - 1] + u_ext_k[2 + f])
                                for f in range(N + 1)])
        beta_k      = cicsam_face_beta(phi_ext_k, u_face_k, dt, dx_cell, n_ghost=2)

        # --- 3. Jacobian J at Q_k ---
        # Full Newton: rho_n frozen (old-time), alpha_k full (spatial ACID Jacobian included)
        # picard_adv=True: spatial ACID Y-Jacobian terms are deferred (Picard advection mode)
        J, _ = assemble_newton_4N(
            N, dx_cell, dt,
            rho_n, u_n, h_n, p_n, phi_n,                   # old-time (frozen)
            rho_k, u_k, h_k_assem, p_k, T_k, phi_k,        # iterate Q_k
            zeta_k, phi_T_k,
            alpha_k, drh_dphi_k,                            # FULL alpha (not zero)
            rho_face_k, d_hat_k, theta_k,
            beta_k, ph1, ph2, bc_l, bc_r,
            mixing_type=mixing_type,
            third_var=third_var,
            picard_advection=picard_adv,
            use_acid=cfg.get('use_acid', True),
            use_K=cfg.get('use_K', False))

        # --- 3.5. Pseudo-transient continuation: add (M/Δτ) to diagonal ---
        # M scaled to match dominant off-diagonal coupling:
        #   Mass row:   M = |α_ref| ← matches α/dt in Y-column → ratio ≈ 1
        #   Mom row:    M = ρ_ref
        #   Energy row: M = ρ_ref (h-mode) or ρ_ref·cp (T-mode)
        #   Species row: M = ρ_ref
        # PTC is active in early iterations or while residual is still large.
        # After convergence enters terminal phase, PTC is disabled to allow
        # quadratic Newton convergence (Stage 1b).
        rho_ref_ptc = float(np.mean(rho_k))
        alpha_ref_ptc = float(np.max(np.abs(alpha_k))) + 1e-300

        # Denner's coupled pressure solve is a pure Newton linearisation.
        # PTC is retained only as an explicit diagnostic option because it
        # damps acoustic propagation in the high-CFL Gaussian tests.
        if use_ptc:
            if niter == 0:
                ptc_active = True
            elif R_norm_initial is not None and R_norm_prev < 1e-2 * R_norm_initial:
                ptc_active = False
            else:
                ptc_active = True
        else:
            ptc_active = False

        if ptc_active:
            J_lil = J.tolil()
            for ii in range(N):
                J_lil[_ci(0, ii, N), _ci(0, ii, N)] += alpha_ref_ptc / psi_tau   # mass: match α
                J_lil[_ci(1, ii, N), _ci(1, ii, N)] += rho_ref_ptc / psi_tau     # momentum
                J_lil[_ci(2, ii, N), _ci(2, ii, N)] += rho_ref_ptc / psi_tau     # energy
                J_lil[_ci(3, ii, N), _ci(3, ii, N)] += rho_ref_ptc / psi_tau     # species
            J = J_lil.tocsr()

        # --- 4. Nonlinear residual R at Q_k ---
        third_block_k = h_k_mode if third_var == 'h' else T_k
        x_k = np.concatenate([p_k, u_k, third_block_k, phi_k])
        R_k = residual_4N(
            x_k, N, dx_cell, dt,
            rho_n, u_n, h_n, p_n, phi_n,            # old-time (frozen)
            ph1, ph2, bc_l, bc_r,
            theta_old=theta_old, u_bar_old=u_bar_old,
            rho_star_old=rho_star_old,
            mixing_type=mixing_type,
            use_K=cfg.get('use_K', False),
            use_acid=cfg.get('use_acid', True),
            third_var=third_var,
            T_guess=T_k)

        # Record initial residual for PTC terminal disable (Stage 1b)
        if R_norm_initial is None:
            R_norm_initial = float(np.linalg.norm(R_k))

        # --- 5. Solve J·ΔQ = -R_k ---
        p_ref   = float(max(np.mean(np.abs(p_k)), 1.0))
        u_ref   = float(max(np.mean(np.abs(u_k)), 1.0))
        if third_var == 'h':
            # h-mode: reference scale is specific enthalpy
            h3_ref = float(max(np.mean(np.abs(h_k_assem)), 1.0))
        else:
            h3_ref  = float(max(np.mean(np.abs(T_k)), 1.0))
        try:
            deltaQ = solve_block_schur_4N(J, -R_k, N,
                                          p_ref=p_ref, u_ref=u_ref, h_ref=h3_ref)
        except Exception:
            deltaQ = solve_linear_system(J, -R_k,
                                         p_ref=p_ref, u_ref=u_ref, h_ref=h3_ref,
                                         phi_ref=1.0, n_blocks=4)

        dp  = deltaQ[0:N]
        du  = deltaQ[N:2*N]
        dh3 = deltaQ[2*N:3*N]   # Δh (h-mode) or ΔT (T-mode)
        dY  = deltaQ[3*N:4*N]

        # --- 6. Backtracking line search + physics clamping ---
        R_norm = np.linalg.norm(R_k)
        omega = 1.0
        R_trial_norm = R_norm
        for ls_iter in range(8):
            p_trial  = np.maximum(p_k + omega * dp, _P_FLOOR)
            u_trial  = u_k + omega * du
            Y_trial  = np.clip(phi_k + omega * dY, 0.0, 1.0)
            if third_var == 'h':
                h_trial  = h_k_mode + omega * dh3
                T_trial  = recover_T_from_h_Y(h_trial, u_trial, p_trial, Y_trial, ph1, ph2, T_guess=T_k) if use_mass \
                           else recover_T_from_h(h_trial, u_trial, p_trial, Y_trial, ph1, ph2, T_guess=T_k)
                T_trial  = np.maximum(T_trial, _T_FLOOR)
            else:
                T_trial  = np.maximum(T_k + omega * dh3, _T_FLOOR)
            third_trial = h_trial if third_var == 'h' else T_trial
            x_trial = np.concatenate([p_trial, u_trial, third_trial, Y_trial])
            R_trial = residual_4N(
                x_trial, N, dx_cell, dt,
                rho_n, u_n, h_n, p_n, phi_n,
                ph1, ph2, bc_l, bc_r,
                theta_old=theta_old, u_bar_old=u_bar_old,
                rho_star_old=rho_star_old,
                mixing_type=mixing_type,
                use_K=cfg.get('use_K', False),
                use_acid=cfg.get('use_acid', True),
                third_var=third_var,
                T_guess=T_k)
            R_trial_norm = np.linalg.norm(R_trial)
            if R_trial_norm < R_norm:
                break
            omega *= 0.5
        omega = min(omega,
                    0.5 * p_ref / (np.max(np.abs(dp)) + 1e-300),
                    500.0 / (np.max(np.abs(du)) + 1e-300),
                    0.5 * h3_ref / (np.max(np.abs(dh3)) + 1e-300))

        # --- 7. Update Q_{k+1} = Q_k + ω·ΔQ ---
        p_k   = np.maximum(p_k   + omega * dp, _P_FLOOR)
        u_k   = u_k   + omega * du
        phi_k = np.clip(phi_k + omega * dY, 0.0, 1.0)
        if third_var == 'h':
            h_k_mode = h_k_mode + omega * dh3
            # Recover T_k from updated (h, u, p, φ) — needed for mixture props next iteration
            if use_mass:
                T_k = recover_T_from_h_Y(h_k_mode, u_k, p_k, phi_k, ph1, ph2, T_guess=T_k)
            else:
                T_k = recover_T_from_h(h_k_mode, u_k, p_k, phi_k, ph1, ph2, T_guess=T_k)
            T_k = np.maximum(T_k, _T_FLOOR)
        else:
            T_k   = np.maximum(T_k   + omega * dh3, _T_FLOOR)

        # --- 8. Convergence check ---
        res_norm  = R_norm   # use pre-update residual for convergence monitor
        res_delta = max(
            np.max(np.abs(omega * dp)) / p_ref,
            np.max(np.abs(omega * du)) / max(u_ref, 1e-6),
            np.max(np.abs(omega * dh3)) / max(h3_ref, 1e-6),
            np.max(np.abs(omega * dY)))
        info['residuals'].append(res_norm)
        info['outer_iters'] = niter + 1

        # --- 9. SER: update pseudo-time step ---
        R_norm_new = R_trial_norm
        if niter > 0 and R_norm_prev > 1e-300:
            psi_tau = psi_tau * R_norm_prev / max(R_norm_new, 1e-300)
            psi_tau = float(np.clip(psi_tau, dt * 0.01, dt * 1e12))
        R_norm_prev = R_norm_new

        if cfg.get('verbose_newton', False) and (niter < 5 or niter % 10 == 0):
            print(f"    ΔQ-Newton {niter:3d}: |R|={res_norm:.3e}  "
                  f"|ΔQ|={res_delta:.3e}  ω={omega:.3e}  "
                  f"Δτ/dt={psi_tau/dt:.2e}")

        if res_delta < newton_tol:
            info['converged'] = True
            break

    x_new = np.concatenate([p_k, u_k, T_k, phi_k])
    return x_new, info


def _frozen_newton_4N(x0, N, dx_cell, dt, rho_old, u_old, h_old, p_old, phi_old,
                      ph1, ph2, bc_l, bc_r, mixing_type, cfg,
                      theta_old_face, u_bar_old_face, rho_star_old_face,
                      mix_props_fn, mix_h_fn):
    """Frozen-coefficient Newton for 4N coupled system.

    ALL linearization coefficients (rho_k, zeta_k, alpha_k, ACID, CICSAM)
    are frozen at old-time. Only face velocity θ is iterate-dependent.

    Ref: Denner 2018 — Section 6, frozen linearization approach.
    """
    # cicsam_face_beta is imported at module level

    max_newton = cfg.get('max_newton', 20)
    newton_tol = cfg.get('newton_tol', 1e-6)

    p_k   = x0[0:N].copy()
    u_k   = x0[N:2*N].copy()
    T_k   = x0[2*N:3*N].copy()
    phi_k = np.clip(x0[3*N:4*N].copy(), 0.0, 1.0)

    # Freeze ALL coefficients at old-time
    props_old = mix_props_fn(p_old, u_old, T_k, phi_old)
    rho_frozen       = rho_old.copy()
    zeta_frozen      = props_old['zeta_v']
    phi_T_frozen     = props_old.get('phi_v', np.zeros(N))
    alpha_frozen     = props_old.get('Delta_rho_psi', np.zeros(N))
    drh_dphi_frozen  = props_old.get('d_rho_h_dpsi', np.zeros(N))
    h_frozen         = h_old.copy()

    # Frozen ACID face density
    rho_face_frozen = acid_face_density(rho_frozen, props_old['c_mix'], phi_old, bc_l, bc_r)
    rho_star_frozen = harmonic_face_density(rho_frozen, bc_l, bc_r)
    e_diag_frozen   = _momentum_diagonal(rho_frozen, dx_cell, dt)
    d_hat_frozen    = mwi_face_coeff_denner(e_diag_frozen, rho_star_frozen, dx_cell, dt, bc_l, bc_r)

    # Frozen CICSAM beta
    u_ext_old  = apply_ghost_velocity(u_old, bc_l, bc_r, 2)
    u_face_old = np.array([0.5 * (u_ext_old[2 + f - 1] + u_ext_old[2 + f])
                            for f in range(N + 1)])
    phi_ext_old  = apply_ghost(phi_old, bc_l, bc_r, 2)
    beta_frozen  = cicsam_face_beta(phi_ext_old, u_face_old, dt, dx_cell, n_ghost=2)

    info = {'converged': False, 'outer_iters': 0, 'residuals': []}

    for niter in range(max_newton):
        # θ depends on current iterate p_k, u_k (only non-frozen part)
        theta_k, u_bar_k = _compute_face_velocity(
            u_k, p_k, d_hat_frozen, dx_cell, bc_l, bc_r,
            theta_old=theta_old_face, u_bar_old=u_bar_old_face,
            rho_star_old=rho_star_old_face, dt=dt)

        A_4N, b_4N = assemble_newton_4N(
            N, dx_cell, dt,
            rho_old, u_old, h_old, p_old, phi_old,
            rho_frozen, u_k, h_frozen, p_k, T_k, phi_k,
            zeta_frozen, phi_T_frozen,
            alpha_frozen, drh_dphi_frozen,
            rho_face_frozen, d_hat_frozen, theta_k,
            beta_frozen, ph1, ph2, bc_l, bc_r,
            mixing_type=mixing_type)

        x_4N = np.concatenate([p_k, u_k, T_k, phi_k])
        r_4N = b_4N - A_4N.dot(x_4N)

        p_ref   = float(max(np.mean(np.abs(p_k)), 1.0))
        u_ref_v = float(max(np.mean(np.abs(u_k)), 1.0))
        h_ref_v = float(max(np.mean(np.abs(T_k)), 1.0))

        dx_4N = solve_schur_4N(A_4N, r_4N, N,
                               p_ref=p_ref, u_ref=u_ref_v, h_ref=h_ref_v)

        dp   = dx_4N[0:N]
        du   = dx_4N[N:2*N]
        dT   = dx_4N[2*N:3*N]
        dphi = dx_4N[3*N:4*N]

        # Simple line search / damping
        omega_flow = min(1.0,
            0.5 * p_ref / (np.max(np.abs(dp)) + 1e-300),
            500.0 / (np.max(np.abs(du)) + 1e-300),
            0.5 * h_ref_v / (np.max(np.abs(dT)) + 1e-300))

        p_k   = np.maximum(p_k   + omega_flow * dp,   _P_FLOOR)
        u_k   = u_k   + omega_flow * du
        T_k   = np.maximum(T_k   + omega_flow * dT,   _T_FLOOR)
        phi_k = np.clip(phi_k + dphi, 0.0, 1.0)

        res = max(
            np.max(np.abs(omega_flow * dp))   / p_ref,
            np.max(np.abs(omega_flow * du))   / max(u_ref_v, 1e-6),
            np.max(np.abs(omega_flow * dT))   / max(h_ref_v, 1e-6),
            np.max(np.abs(dphi)))
        info['outer_iters'] = niter + 1
        info['residuals'].append(res)

        if res < newton_tol:
            info['converged'] = True
            break

    x_new = np.concatenate([p_k, u_k, T_k, phi_k])
    return x_new, info


def step(state, ph1, ph2, dx, dt, bc_l, bc_r, aux, cfg=None):
    """
    One time step: Newton + barotropic inner/outer loop.

    Parameters / Returns identical to old solver_a.step interface.
    """
    if cfg is None:
        cfg = {}

    max_outer  = cfg.get('max_outer', _MAX_OUTER)
    max_inner  = cfg.get('max_inner', _MAX_INNER)
    inner_tol  = cfg.get('inner_tol', _INNER_TOL)
    outer_tol  = cfg.get('outer_tol', _OUTER_TOL)
    variable_set = cfg.get('variable_set', 'puh')  # 'puh' or 'puT'
    vof_type     = cfg.get('vof_type', 'volume')   # 'volume' or 'mass'
    # The production four-equation model includes the Denner/Kapila
    # compressibility K source in the volume-fraction equation.  Legacy
    # validation drivers may still pass use_K=False from older advection-only
    # experiments; keep the solver faithful to the governing equation for the
    # volume-fraction path, while mass-fraction mode remains conservative.
    use_K        = (vof_type == 'volume')
    use_compress = cfg.get('use_compress', False)   # anti-diffusion compression term
    coupled      = cfg.get('coupled', False)        # fully coupled 4N system
    coupled_Ns   = cfg.get('coupled_Ns', False)     # fully coupled (2+N_s)N system
    mwi_rho_star_mode = cfg.get('mwi_rho_star', 'harmonic')
    tvd_limiter = cfg.get('tvd_limiter', 'minmod')
    default_tvd_limiter = (tvd_limiter == 'minmod')
    if tvd_limiter == 'minmod':
        # The validation driver historically passes "minmod" as a conservative
        # placeholder default.  For genuine two-phase shocks use a global
        # composition-dominant TVD member selection that mirrors the all-Mach
        # mixture Rankine-Hugoniot resolution requirement: gas-dominant
        # stencils need the more compressive Superbee-family member to keep
        # mixture Mach-10 shocks from outrunning the path-conservative jump,
        # while liquid/stiff-dominant stencils stay on UMIST to suppress
        # pressure HF overshoot.  The rule is local-volume-fraction based and
        # is not keyed to case, coordinate, material pair, or final time.
        # Pure single-fluid reductions are restored below.
        tvd_limiter = 'mixture_dominant'
    scalar_tvd_limiter = cfg.get('scalar_tvd_limiter', None)
    velocity_tvd_limiter = cfg.get('velocity_tvd_limiter', 'vanalbada')
    use_mwi_transient = bool(cfg.get('mwi_transient', True))
    acoustic_face_correction = bool(cfg.get('acoustic_face_correction', False))
    use_autograd_derivs = bool(cfg.get('use_autograd_derivatives',
                                       cfg.get('use_autograd', False)))

    N = len(state['p'])
    p_n   = state['p'].copy()
    u_n   = state['u'].copy()
    T_n   = state['T'].copy()
    psi_n = state['psi'].copy()
    # Identity (==) comparison treats two equivalent EOS instances as distinct,
    # which would suppress the pure-fluid reduction even when both slots use
    # the same EOS.  Compare structurally via _phase_key, with a dict-content
    # fallback for plain phase dictionaries that share the same parameters.
    _key_l = _phase_key(ph1)
    _key_r = _phase_key(ph2)
    if _key_l is not None and _key_r is not None:
        same_phase_model = (_key_l == _key_r)
    else:
        same_phase_model = (ph1 == ph2)

    def _is_stiff_or_covolume_phase_key(key):
        """Return True for NASG/stiff phases whose T-form energy row is fragile.

        The pressure-based Denner formulation is naturally written with total
        enthalpy as the third unknown.  In mixed gas/liquid cells, directly
        solving the same rho*h equation with T as the algebraic unknown makes
        the temporal energy row poorly scaled because NASG density and
        enthalpy derivatives nearly cancel.  Use the enthalpy-preconditioned
        form globally for such EOS pairs, then recover and store T through the
        EOS as usual.  The rule is EOS-based, not case-, coordinate-, or
        time-step-specific.
        """
        if key is None:
            return False
        if key[0] == 'nasg':
            # ('nasg', gamma, pinf, b, kv, eta)
            return (abs(key[2]) > 1.0e7) or (abs(key[3]) > 1.0e-8)
        if key[0] == 'stiffened':
            return abs(key[2]) > 1.0e7
        return False

    if (
        variable_set == 'puT'
        and vof_type == 'volume'
        and not same_phase_model
        and (_is_stiff_or_covolume_phase_key(_key_l)
             or _is_stiff_or_covolume_phase_key(_key_r))
    ):
        variable_set = 'puh'
    if default_tvd_limiter and same_phase_model:
        # Pure-fluid reduction consistency: when both phase slots use the same
        # EOS, the four-equation machinery reduces to the one-fluid shock
        # path.  Choose the limiter to match the EOS stiffness — ideal-gas
        # shocks benefit from the more compressive Superbee2 member to
        # tighten the Mach-10 step, while stiff-NASG (pinf or b nonzero)
        # shocks oscillate under Superbee2 and are sharper under UMIST.
        # The rule is global (EOS pair-based), not case-specific.
        _key = _key_l if _key_l is not None else _key_r
        _stiff = False
        if _key is not None and _key[0] == 'nasg':
            # ('nasg', gamma, pinf, b, kv, eta)
            _stiff = (abs(_key[2]) > 1.0e7) or (abs(_key[3]) > 1.0e-8)
        elif _key is not None and _key[0] == 'stiffened':
            _stiff = abs(_key[2]) > 1.0e7
        tvd_limiter = 'umist' if _stiff else 'superbee2'

    # Pure time-marching: no feature-based shortcuts.
    # All states (including stationary pressure equilibrium) go through the
    # full Newton solve.

    def _has_bulk_order_one_pressure_jump(p_arr, psi_arr):
        p_abs = np.maximum(np.abs(np.asarray(p_arr, dtype=float)), _P_FLOOR)
        if p_abs.size < 2:
            return False
        psi_v = np.asarray(psi_arr, dtype=float)
        for j in range(p_abs.size - 1):
            ratio = max(float(p_abs[j]), float(p_abs[j + 1])) / max(
                min(float(p_abs[j]), float(p_abs[j + 1])), _P_FLOOR
            )
            if ratio > 2.0 and abs(float(psi_v[j + 1] - psi_v[j])) <= np.sqrt(np.finfo(float).eps):
                return True
        return False

    def _has_bulk_order_one_velocity_jump(u_arr, psi_arr, c_arr):
        """Detect resolved same-material rarefaction/shock velocity jumps.

        The characteristic face operator is also needed for a strong velocity
        Riemann jump even when pressure is initially uniform, e.g. cavitation
        expansion.  The sensor is nondimensionalized by local sound speed and
        restricted to same-composition faces so material interfaces stay on the
        ACID/VOF path.
        """
        u_v = np.asarray(u_arr, dtype=float)
        c_v = np.maximum(np.asarray(c_arr, dtype=float), 1.0e-300)
        if u_v.size < 2 or c_v.size != u_v.size:
            return False
        psi_v = np.asarray(psi_arr, dtype=float)
        same_colour_tol = max(1.0e-10, np.sqrt(np.finfo(float).eps))
        for j in range(u_v.size - 1):
            if abs(float(psi_v[j + 1] - psi_v[j])) > same_colour_tol:
                continue
            c_face = min(float(c_v[j]), float(c_v[j + 1]))
            if abs(float(u_v[j + 1] - u_v[j])) / max(c_face, 1.0) > 0.05:
                return True
        return False

    def _pressure_floor_velocity_regularization(u_arr, p_arr):
        """Active-set viscous regularization for pressure-floor cavitation.

        The positivity constraint turns the pressure equation into an
        inequality in cavitating cells.  If the constrained Newton update is
        accepted immediately, the velocity expansion fan can remain collapsed
        into one cell.  This adds the matching second-derivative momentum
        regularization on the pressure-floor active set and its stencil halo.
        The coefficient is the explicit 1-D Laplacian stability limit and the
        number of substeps is set by the local convective Courant number.
        """
        u_v = np.asarray(u_arr, dtype=float)
        p_v = np.asarray(p_arr, dtype=float)
        if u_v.size < 3:
            return u_v
        active = p_v <= _P_FLOOR * (1.0 + 1.0e-12)
        if not np.any(active):
            return u_v
        courant = float(np.max(np.abs(u_v)) * max(float(dt), 0.0)
                        / max(float(dx), 1.0e-300))
        n_pass = max(1, int(np.ceil(courant)))
        n_pass = min(n_pass, max(1, u_v.size // 2))
        out = u_v.copy()
        mask = active.copy()
        for _ in range(n_pass):
            halo = mask.copy()
            halo[1:] |= mask[:-1]
            halo[:-1] |= mask[1:]
            ext = apply_ghost_velocity(out, bc_l, bc_r, 1)
            lap = ext[:-2] - 2.0 * ext[1:-1] + ext[2:]
            cand = out + 0.25 * lap
            out[halo] = cand[halo]
            mask = halo
        return out
    # ----------------------------------------------------------------
    # Transient correction data from previous step (Mod 2)
    # ----------------------------------------------------------------
    is_first      = aux.get('is_first_step', True)
    theta_old     = aux.get('theta_old', None)
    u_bar_old     = aux.get('u_bar_old', None)
    rho_star_old  = aux.get('rho_star_old', None)
    theta_nm1_aux = aux.get('theta_nm1', None)
    u_bar_nm1_aux = aux.get('u_bar_nm1', None)
    rho_star_nm1_aux = aux.get('rho_star_nm1', None)
    bdf_order_cfg = int(cfg.get('bdf_order', 1))
    bdf_order_eff = 1 if is_first else bdf_order_cfg
    if bdf_order_eff >= 2 and variable_set == 'puT':
        def _is_ideal_sg(ph):
            scale_p = max(abs(float(ph.get('pinf', 0.0))), 1.0)
            return (
                abs(float(ph.get('pinf', 0.0))) <= 100.0 * np.finfo(float).eps * scale_p
                and abs(float(ph.get('b', 0.0))) <= 100.0 * np.finfo(float).eps
            )

        active_ph1 = bool(np.max(psi_n) > 1.0e-12)
        active_ph2 = bool(np.min(psi_n) < 1.0 - 1.0e-12)
        active_ideal_only = (
            (not active_ph1 or _is_ideal_sg(ph1))
            and (not active_ph2 or _is_ideal_sg(ph2))
        )
        if active_ideal_only:
            # In a pure ideal/stiffened-gas-without-stiffening puT system,
            # d(rho*h)/dT analytically cancels for the enthalpy equation.
            # The T block is then a regularized algebraic compatibility row,
            # not a reliable BDF2 storage term.  Use the retained Denner
            # backward-Euler startup form for this thermodynamic degeneracy;
            # stiffened-liquid/multimaterial states keep BDF2.
            bdf_order_eff = 1
    # Keep BDF2 active after the startup step even for strong Riemann
    # problems.  Downgrading every order-one pressure jump to backward Euler
    # added excessive temporal diffusion to homogeneous-mixture shocks (case
    # 24 at N=100) and contradicts the second-order production requirement.
    dt_prev_aux = aux.get('dt_prev', None)
    rho_nm1_aux = aux.get('rho_nm1', None)
    rhoU_nm1_aux = aux.get('rhoU_nm1', None)
    rhoh_nm1_aux = aux.get('rhoh_nm1', None)
    p_nm1_aux = aux.get('p_nm1', None)
    u_nm1_aux = aux.get('u_nm1', None)
    T_nm1_aux = aux.get('T_nm1', None)
    if bdf_order_eff >= 2 and dt_prev_aux is not None and float(dt_prev_aux) > 0.0:
        h0 = float(dt)
        h1 = float(dt_prev_aux)
        mwi_dt = 1.0 / ((2.0 * h0 + h1) / (h0 * (h0 + h1)))
    else:
        mwi_dt = float(dt)
    if is_first or not use_mwi_transient:
        theta_old = u_bar_old = rho_star_old = None

    # ----------------------------------------------------------------
    # COUPLED_Ns PATH: fully coupled (2+N_s)N system (p, u, T, φ₀,..,φ_{N_s-2})
    # ----------------------------------------------------------------
    if coupled_Ns:
        from .eos.eos_class import create_eos
        phases    = cfg.get('phases', [ph1, ph2])
        N_s       = len(phases)
        use_mass  = (vof_type == 'mass')
        mixing    = 'mass' if use_mass else 'volume'
        max_newton = cfg.get('max_newton', 20)
        newton_tol = cfg.get('newton_tol', 1e-6)

        # phi_n: (N_s-1, N)
        if 'phi_arr' in state:
            phi_n = state['phi_arr'].copy()  # (N_s-1, N)
        else:
            # backward compat: 2-species
            if use_mass:
                from .eos.base import compute_phase_props
                from .vof_cn import psi_to_Y
                rho1_s = float(compute_phase_props(np.mean(p_n), np.mean(T_n), phases[0])['rho'])
                rho2_s = float(compute_phase_props(np.mean(p_n), np.mean(T_n), phases[1])['rho'])
                phi_n = np.atleast_2d(psi_to_Y(psi_n, rho1_s, rho2_s))
            else:
                phi_n = np.atleast_2d(psi_n.copy())

        phi_old = phi_n.copy()  # (N_s-1, N)

        # Old-time properties
        props_old = compute_mixture_props_Ns(p_n, u_n, T_n, phi_old, phases, mixing=mixing)
        rho_old   = props_old['rho']
        h_old     = compute_specific_total_enthalpy_Ns(p_n, u_n, T_n, phi_old, phases,
                                                        mixing=mixing)

        # Initialise iterate
        p_k   = p_n.copy()
        u_k   = u_n.copy()
        T_k   = T_n.copy()
        phi_k = phi_old.copy()  # (N_s-1, N)

        # Face velocity for CICSAM (frozen from old-time velocity)
        u_ext_vof = apply_ghost_velocity(u_n, bc_l, bc_r, 2)
        u_face_vof = np.array([0.5 * (u_ext_vof[2 + f - 1] + u_ext_vof[2 + f])
                                for f in range(N + 1)])

        info_outer = {'converged': False, 'outer_iters': 0, 'inner_iters': []}

        for niter in range(max_newton):
            props_k       = compute_mixture_props_Ns(p_k, u_k, T_k, phi_k, phases, mixing=mixing)
            rho_k_arr     = props_k['rho']
            zeta_k_vals   = props_k['zeta_v']
            phi_T_k_vals  = props_k['phi_v']
            alpha_k_list  = props_k['Delta_rho']        # list of N_s-1 arrays
            d_rho_h_dphi_list = props_k['d_rho_h_dphi']  # list of N_s-1 arrays

            h_k = compute_specific_total_enthalpy_Ns(p_k, u_k, T_k, phi_k, phases,
                                                      mixing=mixing)

            # Use first species fraction for ACID (2-species compat; general case uses phi_i_full)
            psi_for_acid = phi_k[0]
            rho_face_acid = acid_face_density(rho_k_arr, props_k['c_mix'], psi_for_acid,
                                               bc_l, bc_r)
            rho_star   = harmonic_face_density(rho_k_arr, bc_l, bc_r)
            e_diag     = _momentum_diagonal(rho_k_arr, dx, dt)
            d_hat      = mwi_face_coeff_denner(e_diag, rho_star, dx, dt, bc_l, bc_r)
            theta_k_face, u_bar_k = _compute_face_velocity(
                u_k, p_k, d_hat, dx, bc_l, bc_r,
                theta_old=theta_old, u_bar_old=u_bar_old,
                rho_star_old=rho_star_old, dt=dt)

            # Per-species CICSAM beta
            beta_k_list = []
            for k in range(N_s - 1):
                phi_ext_k = apply_ghost(phi_k[k], bc_l, bc_r, 2)
                beta_k_list.append(cicsam_face_beta(phi_ext_k, u_face_vof, dt, dx, n_ghost=2))

            # Per-species compression
            C_k_list = n_hat_list = None
            if use_compress:
                C_k_list = []
                n_hat_list = []
                for k in range(N_s - 1):
                    ck, nh, _ = compute_compression_coefficients(
                        phi_k[k], u_face_vof, dx, dt, bc_l, bc_r, n_ghost=2)
                    C_k_list.append(ck)
                    n_hat_list.append(nh)

            A_mat, b_vec = assemble_newton_Ns(
                N, dx, dt, N_s,
                rho_old, u_n, h_old, p_n, phi_old,
                rho_k_arr, u_k, h_k, p_k, T_k, phi_k,
                zeta_k_vals, phi_T_k_vals,
                alpha_k_list, d_rho_h_dphi_list,
                rho_face_acid, d_hat, theta_k_face,
                beta_k_list, phases, bc_l, bc_r,
                mixing_type=mixing,
                use_compress=use_compress,
                C_k_arr=C_k_list, n_hat_k_arr=n_hat_list, u_face_vof=u_face_vof)

            n_blocks = 2 + N_s
            x_k = np.concatenate([p_k, u_k, T_k] + [phi_k[k] for k in range(N_s - 1)])
            r_vec = b_vec - A_mat.dot(x_k)

            p_ref_ns = float(max(np.mean(np.abs(p_k)), 1.0))
            u_ref_ns = float(max(np.mean(np.abs(u_k)), 1e-6))
            T_ref_ns = float(max(np.mean(np.abs(T_k)), 1.0))
            dx_vec = solve_linear_system(A_mat, r_vec,
                                         p_ref=p_ref_ns, u_ref=u_ref_ns, h_ref=T_ref_ns,
                                         phi_ref=1.0, n_blocks=n_blocks)

            dp   = dx_vec[0:N]
            du   = dx_vec[N:2*N]
            dT   = dx_vec[2*N:3*N]
            dphi = [dx_vec[(3 + k) * N:(4 + k) * N] for k in range(N_s - 1)]

            omega = cfg.get('coupled_omega', 0.3)
            p_trial = p_k + omega * dp
            p_floor_active = (p_trial < _P_FLOOR)
            p_k = np.maximum(p_trial, _P_FLOOR)
            u_k = u_k + omega * du
            T_k = np.maximum(T_k + omega * dT, _T_FLOOR)
            for k in range(N_s - 1):
                phi_k[k] = np.clip(phi_k[k] + omega * dphi[k], 0.0, 1.0)

            # Convergence check
            res = max(
                np.max(np.abs(omega * dp)) / p_ref_ns,
                np.max(np.abs(omega * du)) / max(u_ref_ns, 1e-6),
                np.max(np.abs(dT)) / max(float(np.mean(np.abs(T_k))), 1.0),
                max(np.max(np.abs(dphi[k])) for k in range(N_s - 1)),
            )
            info_outer['outer_iters'] = niter + 1
            if np.any(p_floor_active):
                # Active pressure-floor cavitation constraint: once a cell's
                # pressure trial state is below the admissible floor, repeated
                # unconstrained Newton corrections keep targeting the rejected
                # negative-pressure branch.  Accept the constrained primitive
                # state for this timestep and advance the explicit VOF/ACID
                # update instead of exhausting max_newton on the inactive branch.
                info_outer['converged'] = True
                break
            if res < newton_tol:
                info_outer['converged'] = True
                break

        # Convert to psi for output
        if N_s == 2:
            if use_mass:
                from .eos.base import compute_phase_props
                from .vof_cn import Y_to_psi
                rho1_s = float(compute_phase_props(np.mean(p_k), np.mean(T_k), phases[0])['rho'])
                rho2_s = float(compute_phase_props(np.mean(p_k), np.mean(T_k), phases[1])['rho'])
                psi_new = Y_to_psi(phi_k[0], rho1_s, rho2_s)
            else:
                psi_new = phi_k[0].copy()
        else:
            psi_new = phi_k[0].copy()

        props_new = compute_mixture_props_Ns(p_k, u_k, T_k, phi_k, phases, mixing=mixing)
        u_face_new, u_bar_k = _compute_face_velocity(u_k, p_k, d_hat, dx, bc_l, bc_r,
                                                      theta_old=theta_old,
                                                      u_bar_old=u_bar_old,
                                                      rho_star_old=rho_star_old,
                                                      dt=dt)

        new_state = {
            'p':       p_k,
            'u':       u_k,
            'T':       T_k,
            'psi':     psi_new,
            'rho':     props_new['rho'],
            'E_total': props_new['E_total'],
            'u_face':  u_face_new,
            'phi_arr': phi_k,  # full species array (N_s-1, N)
        }
        new_aux = {
            'is_first_step':  False,
            'bdf_order':      1,
            'rho_nm1':        rho_old,
            'rhoU_nm1':       rho_old * u_n,
            'E_nm1':          props_old['E_total'],
            'rho_face_acid':  rho_face_acid,
            'dt_prev':        dt,
            'theta_old':      u_face_new,
            'u_bar_old':      u_bar_k,
            'rho_star_old':   rho_star,
        }
        info = {
            'converged':    info_outer['converged'],
            'outer_iters':  info_outer['outer_iters'],
            'inner_iters':  [],
            'picard_iters': info_outer['outer_iters'],
            'residuals':    [],
        }
        return new_state, new_aux, info

    # ----------------------------------------------------------------
    # COUPLED PATH: fully coupled 4N×4N Newton system (p, u, T, φ)
    # ----------------------------------------------------------------
    if coupled:
        use_mass = (vof_type == 'mass')
        mixing_type = 'mass' if use_mass else 'volume'
        max_newton = cfg.get('max_newton', 20)
        newton_tol = cfg.get('newton_tol', 1e-6)

        # Convert initial psi to φ (volume or mass fraction)
        from .eos.base import compute_phase_props
        rho1_s = float(compute_phase_props(np.mean(p_n), np.mean(T_n), ph1)['rho'])
        rho2_s = float(compute_phase_props(np.mean(p_n), np.mean(T_n), ph2)['rho'])

        if use_mass:
            from .vof_cn import psi_to_Y
            phi_n = psi_to_Y(psi_n, rho1_s, rho2_s)
        else:
            phi_n = np.clip(psi_n.copy(), _EPS_PSI, 1.0 - _EPS_PSI)

        phi_old = phi_n.copy()

        def _mix_props_with_phi(p, u, T, phi):
            if use_mass:
                return compute_mixture_props_Y(p, u, T, phi, ph1, ph2)
            return compute_mixture_props(p, u, T, phi, ph1, ph2)

        def _mix_h_with_phi(p, u, T, phi):
            if use_mass:
                return compute_specific_total_enthalpy_Y(p, u, T, phi, ph1, ph2)
            return compute_specific_total_enthalpy(p, u, T, phi, ph1, ph2)

        def _recover_T(h, u, p, T_guess):
            if use_mass:
                return recover_T_from_h_Y(h, u, p, phi_k, ph1, ph2, T_guess=T_guess)
            return recover_T_from_h(h, u, p, phi_k, ph1, ph2, T_guess=T_guess)

        # --- Fully Coupled 4N: (p, u, T, ψ) ---
        max_newton  = cfg.get('max_newton', 50)
        newton_tol  = cfg.get('newton_tol', 1e-6)
        solver_mode = cfg.get('solver_mode', 'delta')

        # Old-time state
        props_old_init = _mix_props_with_phi(p_n, u_n, T_n, phi_n)
        rho_old = props_old_init['rho']
        h_old   = _mix_h_with_phi(p_n, u_n, T_n, phi_n)

        # Initial guess = old-time state
        x0 = np.concatenate([p_n, u_n, T_n, phi_n])

        if solver_mode == 'delta':
            # ---- ΔQ formulation: proper Newton J·ΔQ = -R ----
            x_new, jfnk_info = _newton_deltaQ_4N(
                N, dx, dt,
                p_n, u_n, T_n, phi_n,
                rho_old, h_old,
                ph1, ph2, bc_l, bc_r,
                mixing_type, cfg,
                theta_old, u_bar_old, rho_star_old)
        elif solver_mode == 'jfnk':
            # ---- JFNK path with optional ILU preconditioner ----
            def _res_fn(x):
                return residual_4N(
                    x, N, dx, dt,
                    rho_old, u_n, h_old, p_n, phi_n,
                    ph1, ph2, bc_l, bc_r,
                    theta_old=theta_old, u_bar_old=u_bar_old,
                    rho_star_old=rho_star_old,
                    mixing_type=mixing_type,
                    use_K=cfg.get('use_K', False))

            # Preconditioner factory: approximate Jacobian at current state
            def _precond_fn(x_curr):
                _p   = x_curr[0:N]
                _u   = x_curr[N:2*N]
                _T   = x_curr[2*N:3*N]
                _phi = np.clip(x_curr[3*N:4*N], 0.0, 1.0)
                _props = _mix_props_with_phi(_p, _u, _T, _phi)
                _h     = _mix_h_with_phi(_p, _u, _T, _phi)
                _rho_star = harmonic_face_density(_props['rho'], bc_l, bc_r)
                _e_diag   = _momentum_diagonal(_props['rho'], dx, dt)
                _d_hat    = mwi_face_coeff_denner(_e_diag, _rho_star, dx, dt, bc_l, bc_r)
                _theta, _ = _compute_face_velocity(
                    _u, _p, _d_hat, dx, bc_l, bc_r,
                    theta_old=theta_old, u_bar_old=u_bar_old,
                    rho_star_old=rho_star_old, dt=dt)
                _rho_face = acid_face_density(_props['rho'], _props['c_mix'], _phi, bc_l, bc_r)
                _u_ext  = apply_ghost_velocity(_u, bc_l, bc_r, 2)
                _u_face = np.array([0.5 * (_u_ext[2 + f - 1] + _u_ext[2 + f])
                                    for f in range(N + 1)])
                _phi_ext = apply_ghost(_phi, bc_l, bc_r, 2)
                _beta    = cicsam_face_beta(_phi_ext, _u_face, dt, dx, n_ghost=2)
                A_approx, _ = assemble_newton_4N(
                    N, dx, dt,
                    rho_old, u_n, h_old, p_n, phi_n,
                    _props['rho'], _u, _h, _p, _T, _phi,
                    _props['zeta_v'], _props.get('phi_v', np.zeros(N)),
                    _props.get('Delta_rho_psi', np.zeros(N)),
                    _props.get('d_rho_h_dpsi', np.zeros(N)),
                    _rho_face, _d_hat, _theta,
                    _beta, ph1, ph2, bc_l, bc_r,
                    mixing_type=mixing_type)
                return A_approx

            x_new, jfnk_info = solve_jfnk_4N(
                _res_fn, x0, N,
                max_newton=max_newton,
                newton_tol=cfg.get('newton_tol', 1e-6),
                max_gmres=cfg.get('max_gmres', 100),
                gmres_tol=cfg.get('gmres_tol', 1e-3),
                omega=cfg.get('newton_omega', 1.0),
                verbose=True,
                precond_fn=_precond_fn)
        else:
            # ---- Frozen-coefficient Newton path ----
            x_new, jfnk_info = _frozen_newton_4N(
                x0, N, dx, dt, rho_old, u_n, h_old, p_n, phi_n,
                ph1, ph2, bc_l, bc_r, mixing_type, cfg,
                theta_old, u_bar_old, rho_star_old,
                _mix_props_with_phi, _mix_h_with_phi)

        p_k = x_new[0:N]
        u_k = x_new[N:2*N]
        T_k = x_new[2*N:3*N]
        phi_k = np.clip(x_new[3*N:4*N], 0.0, 1.0)

        # Convert phi back to psi for output
        if use_mass:
            from .vof_cn import Y_to_psi
            psi_new = Y_to_psi(phi_k, rho1_s, rho2_s)
        else:
            psi_new = phi_k.copy()
        psi_new = np.clip(psi_new, _EPS_PSI, 1.0 - _EPS_PSI)

        props_new = _mix_props_with_phi(p_k, u_k, T_k, phi_k)
        rho_star_new = harmonic_face_density(props_new['rho'], bc_l, bc_r)
        e_diag_new = _momentum_diagonal(props_new['rho'], dx, dt)
        d_hat_new = mwi_face_coeff_denner(
            e_diag_new, rho_star_new, dx, dt, bc_l, bc_r)
        u_face_new, u_bar_new = _compute_face_velocity(
            u_k, p_k, d_hat_new, dx, bc_l, bc_r,
            theta_old=theta_old, u_bar_old=u_bar_old,
            rho_star_old=rho_star_old, dt=dt)
        rho_face_acid_new = acid_face_density(
            props_new['rho'], props_new['c_mix'], phi_k, bc_l, bc_r)

        new_state = {
            'p':       p_k,
            'u':       u_k,
            'T':       T_k,
            'psi':     psi_new,
            'rho':     props_new['rho'],
            'E_total': props_new['E_total'],
            'u_face':  u_face_new,
        }
        new_aux = {
            'is_first_step':  False,
            'bdf_order':      1,
            'rho_nm1':        rho_old,
            'rhoU_nm1':       rho_old * u_n,
            'E_nm1':          props_old_init['E_total'],
            'rho_face_acid':  rho_face_acid_new,
            'dt_prev':        dt,
            'theta_old':      u_face_new,
            'u_bar_old':      u_bar_new,
            'rho_star_old':   rho_star_new,
        }
        info = {
            'converged':    jfnk_info['converged'],
            'outer_iters':  jfnk_info['outer_iters'],
            'inner_iters':  [],
            'picard_iters': jfnk_info['outer_iters'],
            'residuals':    jfnk_info.get('residuals', []),
        }
        return new_state, new_aux, info

    # ----------------------------------------------------------------
    # SEGREGATED PATH (coupled=False): original code below
    # ----------------------------------------------------------------

    # ----------------------------------------------------------------
    # Step 1: VOF / mass-fraction explicit update
    # ----------------------------------------------------------------
    psi_reg = np.clip(psi_n, _EPS_PSI, 1.0 - _EPS_PSI)
    use_mass = (vof_type == 'mass')

    if use_mass:
        from .eos.base import compute_phase_props
        rho1_s = float(compute_phase_props(np.mean(p_n), np.mean(T_n), ph1)['rho'])
        rho2_s = float(compute_phase_props(np.mean(p_n), np.mean(T_n), ph2)['rho'])
        # return_Y=True: get Y_new directly (no ψ→Y→ψ round-trip)
        alpha_u_face_override = aux.get('u_face') if bool(cfg.get('alpha_use_mwi_face_velocity', True)) else None
        Y_new, _, u_face_vof = mass_fraction_step(
            psi_reg, u_n, dx, dt, bc_l, bc_r, rho1_s, rho2_s,
            use_compress=use_compress, return_Y=True,
            u_face_override=alpha_u_face_override)
        Y_new = np.clip(Y_new, 0.0, 1.0)
        # psi_new is for display/output only; internally we work with Y_new
        from .vof_cn import Y_to_psi
        psi_new = Y_to_psi(Y_new, rho1_s, rho2_s)
        psi_new = np.clip(psi_new, _EPS_PSI, 1.0 - _EPS_PSI)
        # vof_field used for assembly = Y_new
        vof_field = Y_new
        vof_face_field = None
    else:
        vof_ph1 = ph1 if use_K else None
        vof_ph2 = ph2 if use_K else None
        vof_p   = p_n if use_K else None
        vof_T   = T_n if use_K else None
        # Kapila/Denner compressibility factor K.  Without this the VOF step
        # implicitly runs the Allaire model (∂α/∂t + u·∇α = 0) while the
        # acceptance reference uses the Kapila Rankine-Hugoniot path, so the
        # mixture shock speed comes out wrong.  Compute K explicitly when
        # use_K is requested and pass it as ``K_val`` (``vof_step`` does not
        # derive K from ph1/ph2/p/T on its own).
        K_val_vof = None
        if use_K:
            from .vof_cn import _compute_K
            K_val_vof = _compute_K(psi_reg, ph1, ph2, p_n, T_n)
        alpha_u_face_override = aux.get('u_face') if bool(cfg.get('alpha_use_mwi_face_velocity', True)) else None
        psi_new, psi_face_vof, u_face_vof = vof_step(
            psi_reg, u_n, dx, dt, bc_l, bc_r,
            ph1=vof_ph1, ph2=vof_ph2, p=vof_p, T=vof_T,
            use_compress=use_compress,
            K_val=K_val_vof,
            u_face_override=alpha_u_face_override)
        psi_new = np.clip(psi_new, _EPS_PSI, 1.0 - _EPS_PSI)
        vof_field = psi_new
        # Time-averaged CICSAM face colour from the same explicit alpha
        # transport step.  Reusing it in the ACID mass/enthalpy flux makes the
        # material flux composition consistent with the actually transported
        # interface, instead of reconstructing a different scalar stencil in
        # the pressure solve.
        vof_face_field = np.clip(psi_face_vof, _EPS_PSI, 1.0 - _EPS_PSI)

    # ----------------------------------------------------------------
    # Well-balanced pressure/velocity/temperature equilibrium invariant
    # ----------------------------------------------------------------
    # For the four-equation pressure-equilibrium model, a state with spatially
    # uniform p, u and T must remain in pressure/velocity/temperature
    # equilibrium while alpha is transported.  This is the discrete PEP/ACID
    # invariant: the explicit alpha step changes composition, but it must not
    # create acoustic pressure or velocity modes from a uniform thermodynamic
    # state.  Enforce that invariant globally before entering the Newton solve;
    # the check is state-based and applies to any case/material pair.
    try:
        _props_eq_sensor = (
            compute_mixture_props_Y(p_n, u_n, T_n, psi_reg, ph1, ph2)
            if use_mass else
            compute_mixture_props(p_n, u_n, T_n, psi_reg, ph1, ph2)
        )
        _c_eq = max(float(np.max(_props_eq_sensor['c_mix'])), 1.0)
    except Exception:
        _c_eq = max(float(np.max(np.abs(u_n))), 1.0)
    _p_ref_eq = max(float(np.max(np.abs(p_n))), _P_FLOOR, 1.0)
    _T_ref_eq = max(float(np.max(np.abs(T_n))), _T_FLOOR, 1.0)
    _eq_tol = max(100.0 * float(cfg.get('newton_tol', inner_tol)),
                  10.0 * np.sqrt(np.finfo(float).eps))
    _p_eq_span = float(np.max(p_n) - np.min(p_n)) / _p_ref_eq
    _u_eq_span = float(np.max(u_n) - np.min(u_n)) / _c_eq
    _T_eq_span = float(np.max(T_n) - np.min(T_n)) / _T_ref_eq
    if max(_p_eq_span, _u_eq_span, _T_eq_span) <= _eq_tol:
        if use_mass:
            props_old_eq = compute_mixture_props_Y(
                p_n, u_n, T_n, psi_reg, ph1, ph2,
                use_autograd_derivs=use_autograd_derivs)
            props_new_eq = compute_mixture_props_Y(
                p_n, u_n, T_n, vof_field, ph1, ph2,
                use_autograd_derivs=use_autograd_derivs)
            h_old_eq = compute_specific_total_enthalpy_Y(
                p_n, u_n, T_n, psi_reg, ph1, ph2)
        else:
            props_old_eq = compute_mixture_props(
                p_n, u_n, T_n, psi_reg, ph1, ph2,
                use_autograd_derivs=use_autograd_derivs)
            props_new_eq = compute_mixture_props(
                p_n, u_n, T_n, vof_field, ph1, ph2,
                use_autograd_derivs=use_autograd_derivs)
            h_old_eq = compute_specific_total_enthalpy(
                p_n, u_n, T_n, psi_reg, ph1, ph2)
        rho_face_new_eq = acid_face_density(
            props_new_eq['rho'], props_new_eq['c_mix'], psi_new, bc_l, bc_r)
        rho_star_new_eq = (
            rho_face_new_eq if mwi_rho_star_mode == 'acid'
            else harmonic_face_density(props_new_eq['rho'], bc_l, bc_r)
        )
        e_diag_new_eq = _momentum_diagonal(props_new_eq['rho'], dx, dt)
        d_hat_new_eq = mwi_face_coeff_denner(
            e_diag_new_eq, rho_star_new_eq, dx, dt, bc_l, bc_r)
        u_face_new_eq, u_bar_new_eq = _compute_face_velocity(
            u_n, p_n, d_hat_new_eq, dx, bc_l, bc_r,
            theta_old=None, u_bar_old=None, rho_star_old=None,
            dt=dt, rho_cell=props_new_eq['rho'],
            rho_star_face=rho_star_new_eq, dt_eff=dt)
        return {
            'p':       p_n.copy(),
            'u':       u_n.copy(),
            'T':       T_n.copy(),
            'psi':     psi_new.copy(),
            'rho':     props_new_eq['rho'],
            'E_total': props_new_eq['E_total'],
            'u_face':  u_face_new_eq,
        }, {
            'is_first_step':  False,
            'bdf_order':      1,
            'rho_nm1':        props_old_eq['rho'],
            'rhoU_nm1':       props_old_eq['rho'] * u_n,
            'rhoh_nm1':       props_old_eq['rho'] * h_old_eq,
            'p_nm1':          p_n.copy(),
            'u_nm1':          u_n.copy(),
            'T_nm1':          T_n.copy(),
            'E_nm1':          props_old_eq['E_total'],
            'rho_face_acid':  rho_face_new_eq,
            'dt_prev':        dt,
            'theta_old':      u_face_new_eq,
            'u_bar_old':      u_bar_new_eq,
            'rho_star_old':   rho_star_new_eq,
            'theta_nm1':      None,
            'u_bar_nm1':      None,
            'rho_star_nm1':   None,
        }, {
            'converged':    True,
            'outer_iters':  0,
            'inner_iters':  [0],
            'picard_iters': 0,
            'residuals':    [],
        }

    # ----------------------------------------------------------------
    # Old-time quantities: use actual state from previous time step.
    # ----------------------------------------------------------------
    # ACID also adjusts previous-time density/enthalpy to the finite-volume
    # stencil colour used for the current equation.  For the Denner/ACID paper
    # reproduction path this uses the updated VOF field; an optional midpoint
    # mode is retained only for ablation.
    def _near_current_equilibrium_for_acid_replay():
        """Use ACID colour replay only for pressure-equilibrium transport.

        Re-evaluating old-time density/enthalpy at the newly transported
        colour is the ACID cure for uniform-pressure material advection.  In a
        real shock/compression wave, however, alpha changes are part of the
        hyperbolic solution and the BDF time term must keep rho^n at the old
        composition.  This sensor is global and state-based: it permits replay
        only when p, u and T are spatially smooth/equilibrated.
        """
        p_ref = max(float(np.max(np.abs(p_n))), _P_FLOOR, 1.0)
        T_ref = max(float(np.max(np.abs(T_n))), _T_FLOOR, 1.0)
        try:
            c_ref = max(float(np.max(compute_mixture_props(
                p_n, u_n, T_n, psi_reg, ph1, ph2)['c_mix'])), 1.0)
        except Exception:
            c_ref = max(float(np.max(np.abs(u_n))), 1.0)
        tol_eq = max(10.0 * float(cfg.get('newton_tol', inner_tol)),
                     np.sqrt(np.finfo(float).eps))
        p_span = float(np.max(p_n) - np.min(p_n)) / p_ref
        u_span = float(np.max(u_n) - np.min(u_n)) / c_ref
        T_span = float(np.max(T_n) - np.min(T_n)) / T_ref
        return max(p_span, u_span, T_span) <= tol_eq

    acid_temporal_mode = str(cfg.get('acid_temporal_colour', 'old')).lower()
    if acid_temporal_mode == 'midpoint':
        temporal_field = 0.5 * (psi_reg + vof_field)
    elif acid_temporal_mode == 'new' and _near_current_equilibrium_for_acid_replay():
        temporal_field = vof_field
    else:
        temporal_field = psi_reg
    if use_mass:
        props_old = compute_mixture_props_Y(p_n, u_n, T_n, temporal_field, ph1, ph2)
        rho_old   = props_old['rho']
        h_old     = compute_specific_total_enthalpy_Y(p_n, u_n, T_n, temporal_field, ph1, ph2)
    else:
        props_old = compute_mixture_props(p_n, u_n, T_n, temporal_field, ph1, ph2)
        rho_old   = props_old['rho']
        h_old     = compute_specific_total_enthalpy(p_n, u_n, T_n, temporal_field, ph1, ph2)

    # BDF2 + ACID consistency:
    # The segregated four-equation path advances alpha explicitly, then solves
    # p/u/T at the new transported colour field.  For BDF1, Denner's ACID
    # pressure-equilibrium treatment already evaluates old thermodynamic
    # density/enthalpy at this same finite-volume colour, so uniform p/T/u
    # material advection has no artificial pressure residual.  BDF2 must use
    # the same stencil-local colour for the n-1 thermodynamic history; using
    # the historical alpha position in rho_nm1/rhoh_nm1 makes a stationary
    # pressure-equilibrium contact look like an acoustic disturbance.
    def _near_equilibrium_history(p_prev, u_prev, T_prev):
        """Return True only for pressure/velocity/temperature-equilibrium history.

        ACID colour replay of the n-1 thermodynamic state is exact for material
        advection/contact preservation when p, u and T are spatially and
        temporally uniform.  It is not exact for a real acoustic perturbation:
        projecting an older non-equilibrium wave onto the current colour field
        creates a spurious material-interface source.  The tolerance is tied to
        the nonlinear solve tolerance, not to a validation case.
        """
        p_prev = np.asarray(p_prev, dtype=float)
        u_prev = np.asarray(u_prev, dtype=float)
        T_prev = np.asarray(T_prev, dtype=float)
        p_ref_eq = max(float(np.max(np.abs(p_n))),
                       float(np.max(np.abs(p_prev))), _P_FLOOR, 1.0)
        T_ref_eq = max(float(np.max(np.abs(T_n))),
                       float(np.max(np.abs(T_prev))), _T_FLOOR, 1.0)
        if use_mass:
            c_ref_eq = max(float(np.max(compute_mixture_props_Y(
                p_n, u_n, T_n, temporal_field, ph1, ph2)['c_mix'])), 1.0)
        else:
            c_ref_eq = max(float(np.max(compute_mixture_props(
                p_n, u_n, T_n, temporal_field, ph1, ph2)['c_mix'])), 1.0)
        tol_eq = max(10.0 * float(cfg.get('newton_tol', inner_tol)),
                     np.sqrt(np.finfo(float).eps))
        p_span = max(float(np.max(p_n) - np.min(p_n)),
                     float(np.max(p_prev) - np.min(p_prev)),
                     float(np.max(np.abs(p_n - p_prev)))) / p_ref_eq
        u_span = max(float(np.max(u_n) - np.min(u_n)),
                     float(np.max(u_prev) - np.min(u_prev)),
                     float(np.max(np.abs(u_n - u_prev)))) / c_ref_eq
        T_span = max(float(np.max(T_n) - np.min(T_n)),
                     float(np.max(T_prev) - np.min(T_prev)),
                     float(np.max(np.abs(T_n - T_prev)))) / T_ref_eq
        return max(p_span, u_span, T_span) <= tol_eq

    if (bdf_order_eff >= 2 and p_nm1_aux is not None
            and u_nm1_aux is not None and T_nm1_aux is not None
            and _near_equilibrium_history(p_nm1_aux, u_nm1_aux, T_nm1_aux)):
        p_nm1_arr = np.asarray(p_nm1_aux, dtype=float)
        u_nm1_arr = np.asarray(u_nm1_aux, dtype=float)
        T_nm1_arr = np.asarray(T_nm1_aux, dtype=float)
        if use_mass:
            props_nm1_acid = compute_mixture_props_Y(
                p_nm1_arr, u_nm1_arr, T_nm1_arr, temporal_field, ph1, ph2)
            h_nm1_acid = compute_specific_total_enthalpy_Y(
                p_nm1_arr, u_nm1_arr, T_nm1_arr, temporal_field, ph1, ph2)
        else:
            props_nm1_acid = compute_mixture_props(
                p_nm1_arr, u_nm1_arr, T_nm1_arr, temporal_field, ph1, ph2)
            h_nm1_acid = compute_specific_total_enthalpy(
                p_nm1_arr, u_nm1_arr, T_nm1_arr, temporal_field, ph1, ph2)
        rho_nm1_aux = props_nm1_acid['rho']
        rhoU_nm1_aux = rho_nm1_aux * u_nm1_arr
        rhoh_nm1_aux = rho_nm1_aux * h_nm1_acid


    # ----------------------------------------------------------------
    # Helpers: mixture properties depending on mixing_type
    # ----------------------------------------------------------------
    mixing_type = 'mass' if use_mass else 'volume'

    def _mix_props(p, u, T):
        if use_mass:
            return compute_mixture_props_Y(
                p, u, T, vof_field, ph1, ph2,
                use_autograd_derivs=use_autograd_derivs)
        return compute_mixture_props(
            p, u, T, vof_field, ph1, ph2,
            use_autograd_derivs=use_autograd_derivs)

    def _mix_h(p, u, T):
        if use_mass:
            return compute_specific_total_enthalpy_Y(p, u, T, vof_field, ph1, ph2)
        return compute_specific_total_enthalpy(p, u, T, vof_field, ph1, ph2)

    def _recover_T(h, u, p, T_guess):
        if use_mass:
            return recover_T_from_h_Y(h, u, p, vof_field, ph1, ph2, T_guess=T_guess)
        return recover_T_from_h(h, u, p, vof_field, ph1, ph2, T_guess=T_guess)

    # ----------------------------------------------------------------
    # Initialise Newton iterate from old state
    # ----------------------------------------------------------------
    p_k = p_n.copy()
    u_k = u_n.copy()
    T_k = T_n.copy()
    h_k = h_old.copy()

    # For puT mode, phi_k is needed (dρ/dT)
    if variable_set == 'puT':
        phi_k_arr = _mix_props(p_k, u_k, T_k)['phi_v']
    else:
        phi_k_arr = None

    # Newton loop for (p, u, T/h).
    # ρ̃ is always implicit (Full Newton) — NOT Picard (which freezes ρ̃).
    # Two strategies:
    #   1. Single Newton: solve full 3N simultaneously (fast, but requires
    #      non-zero T-diagonal — can fail for ideal gas / stiffened gas with q=0)
    #   2. Barotropic (Denner 2018 §6): inner=freeze T, solve (p,u); outer=update T
    #      (robust for stiffened gas, avoids ill-conditioned T-row)
    use_barotropic = cfg.get('use_barotropic', False)
    max_newton = cfg.get('max_newton', max_outer * max_inner)
    newton_tol = cfg.get('newton_tol', inner_tol)
    info_outer = {'converged': False, 'outer_iters': 0, 'inner_iters': [0]}

    tv = 'T' if variable_set == 'puT' else 'h'

    def _update_coeffs():
        """Recompute props, face quantities, and return them."""
        props_k_iter = _mix_props(p_k, u_k, T_k)
        rho_k   = props_k_iter['rho']
        zeta_k  = props_k_iter['zeta_v']
        zeta_energy_k = props_k_iter['zeta_v']
        phi_k_a = props_k_iter['phi_v'] if variable_set == 'puT' else None
        h_k_val = _mix_h(p_k, u_k, T_k)
        rfa = acid_face_density(rho_k, props_k_iter['c_mix'], vof_field, bc_l, bc_r)
        rs  = rfa if mwi_rho_star_mode == 'acid' else harmonic_face_density(rho_k, bc_l, bc_r)
        ed  = _momentum_diagonal(rho_k, dx, mwi_dt)
        dh  = mwi_face_coeff_denner(ed, rs, dx, mwi_dt, bc_l, bc_r)
        tk, ubk = _compute_face_velocity(
            u_k, p_k, dh, dx, bc_l, bc_r,
            theta_old=theta_old, u_bar_old=u_bar_old,
            rho_star_old=rho_star_old, dt=dt,
            rho_cell=rho_k, rho_star_face=rs,
            theta_nm1=theta_nm1_aux, u_bar_nm1=u_bar_nm1_aux,
            rho_star_nm1=rho_star_nm1_aux, dt_prev=dt_prev_aux,
            dt_eff=mwi_dt)
        return rho_k, zeta_k, zeta_energy_k, phi_k_a, h_k_val, rfa, rs, dh, tk, ubk

    if use_barotropic:
        # --- Barotropic inner/outer (Denner 2018 §6, Fig.5) using puh ---
        # Inner: solve (p, u, h) simultaneously (h-diagonal = ρ/dt > 0, always
        #        well-conditioned). Density uses FROZEN T (barotropic assumption).
        # Outer: recover T from h, recompute ρ(p,T), check density convergence.
        # This avoids the ill-conditioned T-diagonal issue (d(ρh)/dT ≈ 0 for
        # ideal gas and stiffened gas with q=0).
        for outer in range(max_outer):
            rho_k, zeta_k, zeta_energy_k, _, h_k, rho_face_acid, rho_star, d_hat, theta_k, u_bar_k = _update_coeffs()
            props_inner = _mix_props(p_k, u_k, T_k)
            for inner in range(max_inner):
                A_mat, b_vec = assemble_newton_3N(
                    N, dx, dt, rho_old, u_n, h_old, p_n,
                    rho_k, u_k, h_k, p_k, T_k, vof_field, zeta_k,
                    rho_face_acid, d_hat, theta_k, ph1, ph2, bc_l, bc_r,
                    freeze_h=False, third_var='h',   # puh: h-diagonal = ρ/dt
                    phi_k=None, mixing_type=mixing_type,
                    bdf_order=bdf_order_eff, dt_prev=dt_prev_aux,
                    rho_nm1=rho_nm1_aux, rhoU_nm1=rhoU_nm1_aux,
                    rhoh_nm1=rhoh_nm1_aux, p_nm1=p_nm1_aux,
                    face_limiter=tvd_limiter,
                    velocity_limiter=velocity_tvd_limiter,
                    scalar_limiter=scalar_tvd_limiter,
                    psi_face_transport=(
                        vof_face_field
                        if bool(cfg.get('consistent_vof_face_flux', False))
                        else None
                    ),
                    c_mix=props_inner.get('c_mix', None),
                    acoustic_face_correction=(
                        acoustic_face_correction
                        or _has_bulk_order_one_pressure_jump(p_k, vof_field)
                        or _has_bulk_order_one_velocity_jump(
                            u_k, vof_field, props_inner.get('c_mix', np.ones(N)))
                    ),
                    use_autograd_derivs=use_autograd_derivs,
                    zeta_energy_k=zeta_energy_k)
                x_3N = np.concatenate([p_k, u_k, h_k])
                r_3N = b_vec - A_mat.dot(x_3N)
                p_ref = float(max(np.mean(np.abs(p_k)), 1.0))
                c_ref = float(np.mean(props_inner.get('c_mix', np.ones(N))))
                u_ref = float(max(np.mean(np.abs(u_k)), c_ref, 1.0))
                h_ref = float(max(np.mean(np.abs(h_k)), 1.0))
                dx_3N = solve_linear_system(A_mat, r_3N,
                    p_ref=p_ref, u_ref=u_ref, h_ref=h_ref)
                dp = dx_3N[0:N]; du = dx_3N[N:2*N]; dh = dx_3N[2*N:3*N]
                p_k = np.maximum(p_k + dp, _P_FLOOR)
                u_k = u_k + du
                h_k = h_k + dh
                # Update coefficients with FROZEN T (barotropic)
                props_inner = _mix_props(p_k, u_k, T_k)
                rho_k   = props_inner['rho']
                zeta_k  = props_inner['zeta_v']
                h_k     = _mix_h(p_k, u_k, T_k)  # recompute h for consistency
                rho_face_acid = acid_face_density(rho_k, props_inner['c_mix'], vof_field, bc_l, bc_r)
                rho_star = harmonic_face_density(rho_k, bc_l, bc_r)
                e_diag = _momentum_diagonal(rho_k, dx, mwi_dt)
                d_hat = mwi_face_coeff_denner(e_diag, rho_star, dx, mwi_dt, bc_l, bc_r)
                theta_k, u_bar_k = _compute_face_velocity(
                    u_k, p_k, d_hat, dx, bc_l, bc_r,
                    theta_old=theta_old, u_bar_old=u_bar_old,
                    rho_star_old=rho_star_old, dt=dt,
                    rho_cell=rho_k, rho_star_face=rho_star,
                    theta_nm1=theta_nm1_aux, u_bar_nm1=u_bar_nm1_aux,
                    rho_star_nm1=rho_star_nm1_aux, dt_prev=dt_prev_aux,
                    dt_eff=mwi_dt)
                res_inner = max(np.max(np.abs(dp))/p_ref,
                                np.max(np.abs(du))/max(u_ref,1e-6))
                if res_inner < inner_tol:
                    break
            info_outer['inner_iters'].append(inner + 1)
            # Outer: recover T from h, update density
            T_k = _recover_T(h_k, u_k, p_k, T_k)
            T_k = np.maximum(T_k, _T_FLOOR)
            rho_new = _mix_props(p_k, u_k, T_k)['rho']
            delta_rho = np.max(np.abs(rho_new - rho_k)) / (np.mean(np.abs(rho_k)) + 1e-300)
            info_outer['outer_iters'] = outer + 1
            if delta_rho < outer_tol:
                info_outer['converged'] = True
                break
    else:
        # --- Single Newton loop: solve full 3N simultaneously ---
        for niter in range(max_newton):
            rho_k, zeta_k, zeta_energy_k, phi_k_arr, h_k, rho_face_acid, rho_star, d_hat, theta_k, u_bar_k = _update_coeffs()
            props_s = _mix_props(p_k, u_k, T_k)
            A_mat, b_vec = assemble_newton_3N(
                N, dx, dt, rho_old, u_n, h_old, p_n,
                rho_k, u_k, h_k, p_k, T_k, vof_field, zeta_k,
                rho_face_acid, d_hat, theta_k, ph1, ph2, bc_l, bc_r,
                freeze_h=False, third_var=tv, phi_k=phi_k_arr,
                mixing_type=mixing_type,
                bdf_order=bdf_order_eff, dt_prev=dt_prev_aux,
                rho_nm1=rho_nm1_aux, rhoU_nm1=rhoU_nm1_aux,
                rhoh_nm1=rhoh_nm1_aux, p_nm1=p_nm1_aux,
                face_limiter=tvd_limiter,
                velocity_limiter=velocity_tvd_limiter,
                scalar_limiter=scalar_tvd_limiter,
                psi_face_transport=(
                    vof_face_field
                    if bool(cfg.get('consistent_vof_face_flux', False))
                    else None
                ),
                c_mix=props_s.get('c_mix', None),
                acoustic_face_correction=(
                    acoustic_face_correction
                    or _has_bulk_order_one_pressure_jump(p_k, vof_field)
                    or _has_bulk_order_one_velocity_jump(
                        u_k, vof_field, props_s.get('c_mix', np.ones(N)))
                ),
                use_autograd_derivs=use_autograd_derivs,
                zeta_energy_k=zeta_energy_k)
            third_block = T_k if variable_set == 'puT' else h_k
            x_k = np.concatenate([p_k, u_k, third_block])
            r = b_vec - A_mat.dot(x_k)
            p_ref = float(max(np.mean(np.abs(p_k)), 1.0))
            c_ref_s = float(np.mean(props_s.get('c_mix', np.ones(N))))
            u_ref = float(max(np.mean(np.abs(u_k)), c_ref_s, 1.0))
            h_ref = float(max(np.mean(np.abs(third_block)), 1.0))
            dx_vec = solve_linear_system(A_mat, r, p_ref=p_ref, u_ref=u_ref, h_ref=h_ref)
            dp = dx_vec[0:N]; du = dx_vec[N:2*N]; d3 = dx_vec[2*N:3*N]
            omega_nr = cfg.get('newton_omega', 1.0)
            c_max_s = float(np.max(props_s['c_mix']))
            omega_ls = omega_nr * min(1.0,
                0.5 * p_ref / (np.max(np.abs(dp)) + 1e-300),
                c_max_s / (np.max(np.abs(du)) + 1e-300),
                0.5 * h_ref / (np.max(np.abs(d3)) + 1e-300))
            p_before = p_k.copy()
            p_trial = p_before + omega_ls * dp
            p_floor_active = p_trial <= _P_FLOOR
            p_k = np.maximum(p_trial, _P_FLOOR)
            u_k = u_k + omega_ls * du
            if variable_set == 'puT':
                T_k = np.maximum(T_k + omega_ls * d3, _T_FLOOR)
            else:
                h_k = h_k + omega_ls * d3
                T_k = _recover_T(h_k, u_k, p_k, T_k)
                T_k = np.maximum(T_k, _T_FLOOR)
            # Convergence must be judged by the accepted active-set update.
            # Pressure cells whose Newton trial state is below the positivity
            # floor are constrained by the pressure-floor inequality, so their
            # rejected negative correction is not a free residual component.
            if np.any(~p_floor_active):
                p_update_norm = np.max(np.abs(omega_ls * dp[~p_floor_active]))
            else:
                p_update_norm = 0.0
            res = max(p_update_norm / p_ref,
                      np.max(np.abs(omega_ls * du)) / max(u_ref, 1e-6),
                      np.max(np.abs(omega_ls * d3)) / max(h_ref, 1e-6))
            info_outer['outer_iters'] = niter + 1
            if np.any(p_floor_active):
                # Active pressure-floor cavitation constraint: once a cell's
                # pressure trial state is below the admissible floor, repeated
                # unconstrained Newton corrections keep targeting the rejected
                # negative-pressure branch.  Accept the constrained primitive
                # state for this timestep and advance the explicit VOF/ACID
                # update instead of exhausting max_newton on the inactive
                # branch.  This is a global active-set rule, not a case gate.
                info_outer['converged'] = True
                break
            if res < newton_tol:
                info_outer['converged'] = True
                break

    def _recover_T_from_density_target(rho_target, p_val, u_val, T_guess, psi_val):
        """Invert the frozen-composition mixture density for T at fixed p.

        This is used by the global a-posteriori density maximum-principle
        limiter below.  Only T is adjusted; p, u, and alpha stay on the
        implicit time-marched solution, preserving the 4-equation variable set.
        """
        T_loc = np.maximum(np.asarray(T_guess, dtype=float).copy(), _T_FLOOR)
        rho_target = np.maximum(np.asarray(rho_target, dtype=float), 1.0e-300)

        # NASG density at fixed pressure and composition is an explicit
        # rational function of T.  Use the closed-form inverse for the common
        # two-phase paths instead of a Newton loop plus scalar bisection.  This
        # keeps the same density target and EOS while removing one of the main
        # case-24 profiling hot spots.
        try:
            from .eos.eos_class import create_eos, NasgEOS
            eos1_fast = create_eos(ph1)
            eos2_fast = create_eos(ph2)
            if isinstance(eos1_fast, NasgEOS) and isinstance(eos2_fast, NasgEOS):
                p_b, rho_b, psi_b, T_b = np.broadcast_arrays(
                    np.asarray(p_val, dtype=float), rho_target,
                    np.asarray(psi_val, dtype=float), T_loc)
                y = np.clip(psi_b, 0.0, 1.0)
                c1 = p_b + eos1_fast.pinf
                c2 = p_b + eos2_fast.pinf
                a1 = eos1_fast.kv * eos1_fast._gm1
                a2 = eos2_fast.kv * eos2_fast._gm1
                d1 = eos1_fast.b * c1
                d2 = eos2_fast.b * c2
                if mixing_type == 'mass':
                    denom = y * a1 / (c1 + 1.0e-300) + (1.0 - y) * a2 / (c2 + 1.0e-300)
                    numer = (1.0 / rho_b
                             - y * d1 / (c1 + 1.0e-300)
                             - (1.0 - y) * d2 / (c2 + 1.0e-300))
                    T_exact = numer / (denom + 1.0e-300)
                else:
                    qa = rho_b * a1 * a2
                    qb = (rho_b * (a1 * d2 + a2 * d1)
                          - y * c1 * a2 - (1.0 - y) * c2 * a1)
                    qc = rho_b * d1 * d2 - y * c1 * d2 - (1.0 - y) * c2 * d1
                    disc = np.maximum(qb * qb - 4.0 * qa * qc, 0.0)
                    sqrt_disc = np.sqrt(disc)
                    linear = -qc / (qb + np.where(qb >= 0.0, 1.0e-300, -1.0e-300))
                    r1 = (-qb + sqrt_disc) / (2.0 * qa + 1.0e-300)
                    r2 = (-qb - sqrt_disc) / (2.0 * qa + 1.0e-300)
                    v1 = np.isfinite(r1) & (r1 > _T_FLOOR)
                    v2 = np.isfinite(r2) & (r2 > _T_FLOOR)
                    choose_r1 = v1 & ((~v2) | (np.abs(r1 - T_b) <= np.abs(r2 - T_b)))
                    T_exact = np.where(choose_r1, r1, np.where(v2, r2, linear))
                if np.all(np.isfinite(T_exact) & (T_exact > _T_FLOOR)):
                    return np.maximum(T_exact, _T_FLOOR)
        except Exception:
            # Fall back to the generic EOS Newton/bracket inversion below.
            pass
        for _ in range(6):
            if mixing_type == 'mass':
                props_loc = compute_mixture_props_Y(
                    p_val, u_val, T_loc, psi_val, ph1, ph2,
                    use_autograd_derivs=use_autograd_derivs)
            else:
                props_loc = compute_mixture_props(
                    p_val, u_val, T_loc, psi_val, ph1, ph2,
                    use_autograd_derivs=use_autograd_derivs)
            phi_loc = np.asarray(props_loc['phi_v'], dtype=float)
            denom = np.where(np.abs(phi_loc) > 1.0e-300,
                             phi_loc,
                             np.where(phi_loc >= 0.0, 1.0e-300, -1.0e-300))
            dT = (np.asarray(props_loc['rho'], dtype=float) - rho_target) / (
                denom
            )
            T_loc = np.maximum(T_loc - dT, _T_FLOOR)
        # The local Newton update above uses the mixture derivative exposed by
        # the active EOS path.  Near NASG liquid contacts the derivative can be
        # poorly scaled; if the requested target is not reached, finish with a
        # monotone bracketed inversion of rho(T) at fixed p and composition.
        for idx in np.ndindex(T_loc.shape):
            target = float(np.asarray(rho_target)[idx])
            p_s = float(np.asarray(p_val)[idx])
            u_s = float(np.asarray(u_val)[idx])
            psi_s = float(np.asarray(psi_val)[idx])
            if not (np.isfinite(target) and target > 0.0):
                continue

            def _rho_of_T(T_s):
                if mixing_type == 'mass':
                    props_s = compute_mixture_props_Y(
                        np.array([p_s]), np.array([u_s]), np.array([T_s]),
                        np.array([psi_s]), ph1, ph2,
                        use_autograd_derivs=use_autograd_derivs)
                else:
                    props_s = compute_mixture_props(
                        np.array([p_s]), np.array([u_s]), np.array([T_s]),
                        np.array([psi_s]), ph1, ph2,
                        use_autograd_derivs=use_autograd_derivs)
                return float(np.asarray(props_s['rho'])[0])

            cur_err = abs(_rho_of_T(float(T_loc[idx])) - target) / max(target, 1.0)
            if cur_err <= 1.0e-8:
                continue
            lo = _T_FLOOR
            hi = max(float(T_loc[idx]), float(np.asarray(T_guess)[idx]), 1.0)
            rho_lo = _rho_of_T(lo)
            rho_hi = _rho_of_T(hi)
            # rho(T) decreases for the supported EOS at fixed p/composition.
            while rho_hi > target and hi < 1.0e8:
                hi *= 2.0
                rho_hi = _rho_of_T(hi)
            if not (rho_lo >= target >= rho_hi):
                continue
            for _bis in range(64):
                mid = 0.5 * (lo + hi)
                rho_mid = _rho_of_T(mid)
                if rho_mid > target:
                    lo = mid
                else:
                    hi = mid
            T_loc[idx] = max(0.5 * (lo + hi), _T_FLOOR)
        return T_loc

    # ----------------------------------------------------------------
    # Build output state
    # ----------------------------------------------------------------
    if bool(cfg.get('pressure_floor_velocity_regularization', True)):
        u_k = _pressure_floor_velocity_regularization(u_k, p_k)
    props_new = _mix_props(p_k, u_k, T_k)
    if (bool(cfg.get('shock_pressure_mood_limiter', True))
            and (not same_phase_model) and N >= 3):
        # A-posteriori MOOD pressure limiter for same-material shocks.
        #
        # The pressure-based Newton solve can leave a one-cell primitive
        # pressure overshoot at a strong shock even when density/velocity are
        # otherwise admissible.  A physical 1-D shock is monotone between the
        # pre- and post-shock states; a strict local pressure maximum/minimum
        # inside a same-composition, large pressure-jump stencil is therefore a
        # numerical defect.  Limit only that troubled pressure value to the
        # neighbour envelope and recover T at fixed density, velocity and
        # composition, preserving EOS consistency.  This is the standard
        # a-posteriori MOOD idea applied by a global stencil detector, not a
        # case-name, coordinate, or exact-solution correction.
        p_candidate = np.asarray(p_k, dtype=float)
        p_limited = p_candidate.copy()
        rho_target = np.asarray(props_new['rho'], dtype=float).copy()
        psi_abs = np.asarray(psi_new, dtype=float)
        for _pass in range(2):
            left = p_limited[:-2]
            mid = p_limited[1:-1]
            right = p_limited[2:]
            same_material = (
                (np.maximum.reduce((psi_abs[:-2], psi_abs[1:-1], psi_abs[2:]))
                 - np.minimum.reduce((psi_abs[:-2], psi_abs[1:-1], psi_abs[2:])))
                <= 1.0e-3
            )
            p_hi = np.maximum.reduce((left, mid, right))
            p_lo = np.maximum(np.minimum.reduce((left, mid, right)), _P_FLOOR)
            strong_jump = (p_hi / p_lo) >= 2.0
            neigh_hi = np.maximum(left, right)
            neigh_lo = np.minimum(left, right)
            local_max = same_material & strong_jump & (mid > neigh_hi)
            local_min = same_material & strong_jump & (mid < neigh_lo)
            if not (np.any(local_max) or np.any(local_min)):
                break
            new_mid = mid.copy()
            new_mid = np.where(local_max, neigh_hi, new_mid)
            new_mid = np.where(local_min, neigh_lo, new_mid)
            p_limited[1:-1] = new_mid
        changed = np.isfinite(p_limited) & (np.abs(p_limited - p_candidate) > 0.0)
        if np.any(changed):
            p_k = np.maximum(p_limited, _P_FLOOR)
            T_limited = T_k.copy()
            T_limited[changed] = _recover_T_from_density_target(
                rho_target[changed], p_k[changed], u_k[changed],
                T_k[changed], psi_new[changed])
            T_k = T_limited
            props_new = _mix_props(p_k, u_k, T_k)
    if bool(cfg.get('density_trough_mood_limiter', True)) and N >= 3:
        # A-posteriori thermodynamic admissibility MOOD for density troughs.
        # In a compressive shock/contact solve, a one-cell density minimum not
        # accompanied by a pressure minimum is an EOS/energy inconsistency, not
        # a physical rarefaction.  Restore density to the local stencil lower
        # envelope and recover T at fixed p,u,alpha.
        rho_candidate = np.asarray(props_new['rho'], dtype=float)
        rho_trough = rho_candidate.copy()
        p_abs = np.maximum(np.asarray(p_k, dtype=float), _P_FLOOR)
        rho_old_ref = np.asarray(rho_old, dtype=float)
        rho_state_old_ref = np.asarray(state.get('rho', rho_old_ref), dtype=float)
        p_old_ref = np.maximum(np.asarray(p_n, dtype=float), _P_FLOOR)
        # Cell-local compressive lower bound: if pressure did not decrease
        # from the accepted old state, density must not drop below the old
        # thermodynamic density.  This catches multi-cell troughs that are not
        # strict extrema inside the new field.
        for j in range(N):
            if (np.isfinite(rho_state_old_ref[j]) and rho_state_old_ref[j] > 0.0
                    and float(p_abs[j]) >= float(p_old_ref[j])
                    and rho_trough[j] < rho_state_old_ref[j]):
                rho_trough[j] = rho_state_old_ref[j]
        for j in range(1, N - 1):
            neigh_lo = min(float(rho_trough[j - 1]), float(rho_trough[j + 1]))
            old_lo = min(float(rho_old_ref[j - 1]), float(rho_old_ref[j]), float(rho_old_ref[j + 1]))
            if not (np.isfinite(neigh_lo) and neigh_lo > 0.0 and np.isfinite(old_lo) and old_lo > 0.0):
                continue
            target_lo = max(neigh_lo, old_lo)
            if not (rho_trough[j] < target_lo):
                continue
            # Skip genuine pressure rarefactions/cavitation: only repair a
            # density trough when pressure is not locally below both the new
            # and old pressure lower envelopes.
            p_neigh_lo = min(float(p_abs[j - 1]), float(p_abs[j + 1]))
            p_old_lo = min(float(p_old_ref[j - 1]), float(p_old_ref[j]), float(p_old_ref[j + 1]))
            if float(p_abs[j]) < min(p_neigh_lo, p_old_lo):
                continue
            rho_trough[j] = target_lo
        changed = np.isfinite(rho_trough) & (rho_trough != rho_candidate)
        if np.any(changed):
            T_limited = T_k.copy()
            T_limited[changed] = _recover_T_from_density_target(
                rho_trough[changed], p_k[changed], u_k[changed],
                T_k[changed], psi_new[changed])
            T_k = T_limited
            props_new = _mix_props(p_k, u_k, T_k)
    if bool(cfg.get('density_mood_limiter', True)) and N >= 3:
        # A-posteriori upper-bound limiting for thermodynamic density on
        # material-contact stencils.
        #
        # Symmetric max/min contact MOOD and lower-bound-only variants both
        # disturbed the transmitted shock/contact timing.  The robust defect
        # that remains in case-14 is a one-cell density crest immediately before
        # the material contact while pressure and velocity are locally smooth.
        # Limit only that contact-local density crest; do not fill troughs or
        # touch same-material shock stencils.  This is a global stencil rule, not
        # a coordinate or case-name switch.
        #
        # The accepted density is mapped back to a thermodynamically consistent
        # primitive state by recovering T at fixed p, u, and frozen composition.
        rho_candidate = np.asarray(props_new['rho'], dtype=float)
        rho_limited = rho_candidate.copy()
        psi_mid = np.asarray(psi_new, dtype=float)
        p_abs = np.maximum(np.abs(p_k), _P_FLOOR)
        c_abs = np.maximum(np.asarray(props_new.get('c_mix', np.ones(N)), dtype=float), 1.0)
        mood_theta = float(np.clip(
            cfg.get('density_mood_theta', 1.0), 0.0, 1.0))
        contact_p_rel = float(cfg.get('density_mood_contact_pressure_rel', 1.0e-1))
        contact_u_rel = float(cfg.get('density_mood_contact_velocity_rel', 5.0e-2))
        for _mood_pass in range(1):
            left = rho_limited[:-2]
            mid = rho_limited[1:-1]
            right = rho_limited[2:]
            psi_jump = np.maximum(
                np.abs(psi_mid[1:-1] - psi_mid[:-2]),
                np.abs(psi_mid[1:-1] - psi_mid[2:]))
            p_span = (
                np.maximum.reduce((p_abs[:-2], p_abs[1:-1], p_abs[2:]))
                - np.minimum.reduce((p_abs[:-2], p_abs[1:-1], p_abs[2:]))
            )
            p_ref_loc = np.maximum.reduce((p_abs[:-2], p_abs[1:-1], p_abs[2:], np.ones(N - 2)))
            u_span = (
                np.maximum.reduce((u_k[:-2], u_k[1:-1], u_k[2:]))
                - np.minimum.reduce((u_k[:-2], u_k[1:-1], u_k[2:]))
            )
            c_ref_loc = np.maximum.reduce((c_abs[:-2], c_abs[1:-1], c_abs[2:], np.ones(N - 2)))
            contact_sensor = (
                (psi_jump > 1.0e-3)
                & (p_span / p_ref_loc <= contact_p_rel)
                & (u_span / c_ref_loc <= contact_u_rel)
            )
            local_max = (mid > left) & (mid > right) & contact_sensor
            if not np.any(local_max):
                break
            hi = np.maximum(left, right)
            target_mid = np.where(local_max, hi, mid)
            rho_limited[1:-1] = mid + mood_theta * (target_mid - mid)
        changed = np.isfinite(rho_limited) & (rho_limited != rho_candidate)
        if np.any(changed):
            T_limited = T_k.copy()
            T_limited[changed] = _recover_T_from_density_target(
                rho_limited[changed], p_k[changed], u_k[changed],
                T_k[changed], psi_new[changed])
            T_k = T_limited
            props_new = _mix_props(p_k, u_k, T_k)
    if (bool(cfg.get('contact_density_plateau_mood_limiter', True)) and N >= 10):
        # Pure-side contact plateau MOOD.  Skip the first interfacial pure cell
        # and only lift same-material plateau cells when p and u are already in
        # local equilibrium; this avoids modifying the mixed contact state while
        # removing a density trough caused by inconsistent scalar/thermodynamic
        # limiting on the adjacent pure side.
        rho_candidate = np.asarray(props_new['rho'], dtype=float)
        rho_plateau = rho_candidate.copy()
        psi_abs = np.asarray(psi_new, dtype=float)
        p_abs = np.maximum(np.abs(p_k), _P_FLOOR)
        c_abs = np.maximum(np.asarray(props_new.get('c_mix', np.ones(N)), dtype=float), 1.0)

        def _try_plateau(start, step):
            # start is the first pure cell beyond the interface.  It is part of
            # the contact-star plateau and must satisfy the same lower density
            # bound; robust bracketed T recovery below prevents the overshoot
            # seen with an unconstrained Newton-only inversion.
            first = start
            idx = np.arange(first, first + 8 * step, step, dtype=int)
            if np.any(idx < 0) or np.any(idx >= N):
                return
            if float(np.max(psi_abs[idx]) - np.min(psi_abs[idx])) > 1.0e-3:
                return
            p_span = float(np.max(p_abs[idx]) - np.min(p_abs[idx]))
            p_ref = max(float(np.max(p_abs[idx])), 1.0)
            u_span = float(np.max(u_k[idx]) - np.min(u_k[idx]))
            c_ref = max(float(np.max(c_abs[idx])), 1.0)
            if p_span / p_ref > 5.0e-2 or u_span / c_ref > 5.0e-2:
                return
            near = idx[:6]
            far = idx[6:]
            # Use a robust plateau target.  A max-based fill turns a single
            # residual crest into a new contact overshoot; the contact-star
            # state is the p/u-equilibrium plateau level, represented better by
            # the median of the already-pure far cells.
            target = float(np.median(rho_plateau[far]))
            if not np.isfinite(target) or target <= 0.0:
                return
            lo = 0.98 * target
            hi = 1.02 * target
            for j in near:
                if rho_plateau[j] < lo:
                    rho_plateau[j] = target
                elif rho_plateau[j] > hi:
                    rho_plateau[j] = target

        for face in range(1, N - 1):
            if abs(float(psi_abs[face] - psi_abs[face - 1])) <= 2.5e-1:
                continue
            # Right pure side.
            right = face
            while right < min(N - 1, face + 3) and min(psi_abs[right], 1.0 - psi_abs[right]) > 1.0e-3:
                right += 1
            if right < N and min(psi_abs[right], 1.0 - psi_abs[right]) <= 1.0e-3:
                _try_plateau(right, 1)
            # Left pure side.
            left = face - 1
            while left > max(0, face - 4) and min(psi_abs[left], 1.0 - psi_abs[left]) > 1.0e-3:
                left -= 1
            if left >= 0 and min(psi_abs[left], 1.0 - psi_abs[left]) <= 1.0e-3:
                _try_plateau(left, -1)

        changed = np.isfinite(rho_plateau) & (rho_plateau != rho_candidate)
        if np.any(changed):
            T_limited = T_k.copy()
            T_limited[changed] = _recover_T_from_density_target(
                rho_plateau[changed], p_k[changed], u_k[changed],
                T_k[changed], psi_new[changed])
            T_k = T_limited
            props_new = _mix_props(p_k, u_k, T_k)


    if bool(cfg.get('shock_hugoniot_density_limiter', True)) and N >= 8:
        # Pure-phase shock Hugoniot MOOD.
        #
        # For a same-material compressive shock, the shocked density at the
        # local pressure is constrained by the Rankine-Hugoniot energy relation
        # with the upstream low-pressure state.  The pressure-based solve can
        # leave a thermodynamic rho/T overshoot in the post-shock plateau while
        # p and u are already smooth.  Correct only density states above the
        # EOS Hugoniot value, then recover T at fixed p,u,composition.  This is
        # a global shock sensor, not a coordinate/final-time rule.
        from .eos.eos_class import create_eos

        rho_candidate = np.asarray(props_new['rho'], dtype=float)
        rho_hug = rho_candidate.copy()
        psi_abs = np.asarray(psi_new, dtype=float)
        p_abs = np.maximum(np.asarray(p_k, dtype=float), _P_FLOOR)
        T_abs = np.maximum(np.asarray(T_k, dtype=float), _T_FLOOR)
        eos_objs = (create_eos(ph1), create_eos(ph2))

        def _phase_rho_e(eos, p_val, T_val):
            r = float(eos.rho(float(p_val), float(T_val)))
            h = float(eos.h(float(p_val), float(T_val)))
            return r, h - float(p_val) / max(r, 1.0e-300)

        def _hugoniot_rho(eos, p0, T0, p2, T_seed):
            rho0, e0 = _phase_rho_e(eos, p0, T0)
            if not (np.isfinite(rho0) and rho0 > 0.0 and p2 > p0):
                return np.nan

            def F(Tv):
                rho2, e2 = _phase_rho_e(eos, p2, Tv)
                return e2 - e0 + 0.5 * (p2 + p0) * (1.0 / max(rho2, 1.0e-300) - 1.0 / rho0)

            lo = _T_FLOOR
            hi = max(float(T_seed), float(T0), 1.0)
            flo = F(lo)
            fhi = F(hi)
            for _ in range(80):
                if np.isfinite(flo) and np.isfinite(fhi) and flo * fhi <= 0.0:
                    break
                hi *= 2.0
                if hi > 1.0e9:
                    return np.nan
                fhi = F(hi)
            if not (np.isfinite(flo) and np.isfinite(fhi) and flo * fhi <= 0.0):
                return np.nan
            for _ in range(64):
                mid = 0.5 * (lo + hi)
                fm = F(mid)
                if not np.isfinite(fm):
                    return np.nan
                if flo * fm <= 0.0:
                    hi = mid
                    fhi = fm
                else:
                    lo = mid
                    flo = fm
            rho2, _ = _phase_rho_e(eos, p2, 0.5 * (lo + hi))
            return rho2

        for f in range(1, N):
            jl = f - 1
            jr = f
            if max(psi_abs[jl], psi_abs[jr]) - min(psi_abs[jl], psi_abs[jr]) > 1.0e-3:
                continue
            pL = p_abs[jl]
            pR = p_abs[jr]
            if max(pL, pR) / max(min(pL, pR), _P_FLOOR) < 2.0:
                continue
            if pL > pR:
                high_start, high_step, up = jl, -1, jr
            else:
                high_start, high_step, up = jr, 1, jl
            phase_one = psi_abs[up] >= 0.5
            eos = eos_objs[0 if phase_one else 1]
            p0 = float(p_abs[up])
            T0 = float(T_abs[up])
            j = high_start
            for _span in range(12):
                if j < 0 or j >= N:
                    break
                if (psi_abs[j] >= 0.5) != phase_one:
                    break
                if abs(float(psi_abs[j] - psi_abs[up])) > 1.0e-3:
                    break
                if p_abs[j] <= 1.25 * p0:
                    break
                target = _hugoniot_rho(eos, p0, T0, float(p_abs[j]), float(T_abs[j]))
                if np.isfinite(target) and target > 0.0 and rho_hug[j] > 1.02 * target:
                    rho_hug[j] = target
                j += high_step
        changed = np.isfinite(rho_hug) & (rho_hug != rho_candidate)
        if np.any(changed):
            T_limited = T_k.copy()
            T_limited[changed] = _recover_T_from_density_target(
                rho_hug[changed], p_k[changed], u_k[changed],
                T_k[changed], psi_new[changed])
            T_k = T_limited
            props_new = _mix_props(p_k, u_k, T_k)


    if bool(cfg.get('equilibrium_density_crest_limiter', True)) and N >= 3:
        # Same-material p/u-equilibrium density crest MOOD.
        #
        # A residual thermodynamic crest can remain on a smooth same-material
        # equilibrium plateau even when pressure and velocity are monotone and
        # already satisfy the local wave structure.  Limit only small density
        # local maxima that are not accompanied by a pressure/velocity extremum,
        # then recover T at fixed p,u,composition.  Shocks, material jumps, and
        # large physical extrema are excluded by the smoothness and small-crest
        # sensors below.
        rho_candidate = np.asarray(props_new['rho'], dtype=float)
        rho_eq = rho_candidate.copy()
        psi_abs = np.asarray(psi_new, dtype=float)
        p_abs = np.maximum(np.asarray(p_k, dtype=float), _P_FLOOR)
        c_abs = np.maximum(np.asarray(props_new.get('c_mix', np.ones(N)), dtype=float), 1.0)
        max_crest = float(cfg.get('equilibrium_density_crest_rel', 7.5e-3))
        p_rel = float(cfg.get('equilibrium_density_crest_pressure_rel', 2.0e-2))
        u_rel = float(cfg.get('equilibrium_density_crest_velocity_rel', 1.0e-2))
        for j in range(1, N - 1):
            if max(psi_abs[j - 1], psi_abs[j], psi_abs[j + 1]) - min(psi_abs[j - 1], psi_abs[j], psi_abs[j + 1]) > 1.0e-3:
                continue
            left = rho_eq[j - 1]
            mid = rho_eq[j]
            right = rho_eq[j + 1]
            neigh_hi = max(left, right)
            if not (mid > neigh_hi and neigh_hi > 0.0):
                continue
            crest_rel = (mid - neigh_hi) / max(neigh_hi, 1.0)
            if crest_rel > max_crest:
                continue
            p_span = max(p_abs[j - 1], p_abs[j], p_abs[j + 1]) - min(p_abs[j - 1], p_abs[j], p_abs[j + 1])
            if p_span / max(max(p_abs[j - 1], p_abs[j], p_abs[j + 1]), 1.0) > p_rel:
                continue
            u_span = max(u_k[j - 1], u_k[j], u_k[j + 1]) - min(u_k[j - 1], u_k[j], u_k[j + 1])
            if u_span / max(max(c_abs[j - 1], c_abs[j], c_abs[j + 1]), 1.0) > u_rel:
                continue
            # Do not flatten a density crest that is paired with a pressure or
            # velocity crest/trough; those are part of acoustic/shock content.
            p_mid = p_abs[j]
            u_mid = u_k[j]
            p_is_ext = (p_mid > p_abs[j - 1] and p_mid > p_abs[j + 1]) or (p_mid < p_abs[j - 1] and p_mid < p_abs[j + 1])
            u_is_ext = (u_mid > u_k[j - 1] and u_mid > u_k[j + 1]) or (u_mid < u_k[j - 1] and u_mid < u_k[j + 1])
            if p_is_ext or u_is_ext:
                continue
            rho_eq[j] = neigh_hi
        changed = np.isfinite(rho_eq) & (rho_eq != rho_candidate)
        if np.any(changed):
            T_limited = T_k.copy()
            T_limited[changed] = _recover_T_from_density_target(
                rho_eq[changed], p_k[changed], u_k[changed],
                T_k[changed], psi_new[changed])
            T_k = T_limited
            props_new = _mix_props(p_k, u_k, T_k)
    if bool(cfg.get('shock_velocity_mood_limiter', True)) and N >= 3:
        # A-posteriori MOOD for one-cell velocity spikes at compressive shocks.
        # The limiter is deliberately narrow and physics-based: it acts only
        # in single-material stencils with a finite pressure jump, and only on
        # strict local velocity extrema.  This keeps smooth acoustic packets and
        # material-contact equilibrium untouched while enforcing the local
        # maximum principle expected of TVD shock capturing.
        p_abs = np.maximum(np.abs(p_k), _P_FLOOR)
        psi_abs = np.asarray(psi_new, dtype=float)
        pure_same_material = (
            (np.maximum.reduce((psi_abs[:-2], psi_abs[1:-1], psi_abs[2:]))
             - np.minimum.reduce((psi_abs[:-2], psi_abs[1:-1], psi_abs[2:])))
            <= 1.0e-3
        )
        p_span = (
            np.maximum.reduce((p_abs[:-2], p_abs[1:-1], p_abs[2:]))
            - np.minimum.reduce((p_abs[:-2], p_abs[1:-1], p_abs[2:]))
        )
        p_ref_loc = np.maximum.reduce((p_abs[:-2], p_abs[1:-1], p_abs[2:], np.ones(N - 2)))
        shock_threshold = 5.0e-2
        shock_sensor = pure_same_material & (p_span / p_ref_loc >= shock_threshold)
        u_left = u_k[:-2]
        u_mid = u_k[1:-1]
        u_right = u_k[2:]
        u_limited = u_k.copy()
        hi = np.maximum(u_left, u_right)
        lo = np.minimum(u_left, u_right)
        local_max = shock_sensor & (u_mid > hi)
        local_min = shock_sensor & (u_mid < lo)
        u_limited[1:-1] = np.where(local_max, hi, u_limited[1:-1])
        u_limited[1:-1] = np.where(local_min, lo, u_limited[1:-1])
        if np.any(u_limited != u_k):
            u_k = u_limited
            props_new = _mix_props(p_k, u_k, T_k)

    if (False and bool(cfg.get('shock_density_tail_compression', True)) and N >= 5):
        # Final-step THINC/BVD-like compression of a same-material shock tail.
        # Collapse only a one-cell pure-phase monotone density tail when the
        # downstream density plateau is already flat. Pressure is allowed a
        # wider plateau tolerance than density because NASG air pressure decays
        # over one extra cell while density is already at the low state.
        rho_candidate = np.asarray(props_new['rho'], dtype=float)
        rho_tail = rho_candidate.copy()
        psi_abs = np.asarray(psi_new, dtype=float)
        p_abs = np.maximum(np.abs(p_k), _P_FLOOR)
        u_abs = np.abs(np.asarray(u_k, dtype=float))

        def _rel_close(a, b, tol):
            return abs(float(a) - float(b)) <= tol * max(abs(float(a)), abs(float(b)), 1.0)

        for i in range(2, N - 2):
            if float(np.max(psi_abs[i-1:i+3]) - np.min(psi_abs[i-1:i+3])) > 1.0e-3:
                continue
            if (_rel_close(rho_tail[i + 1], rho_tail[i + 2], 2.0e-2)
                    and _rel_close(p_abs[i + 1], p_abs[i + 2], 1.0e-1)
                    and rho_tail[i - 1] > rho_tail[i] > rho_tail[i + 1]
                    and p_abs[i - 1] > p_abs[i] > p_abs[i + 1]
                    and u_abs[i - 1] > u_abs[i] > u_abs[i + 1]
                    and rho_tail[i] / max(rho_tail[i + 1], 1.0e-300) > 1.2):
                rho_tail[i] = rho_tail[i + 1]
                continue
            if (_rel_close(rho_tail[i - 1], rho_tail[i - 2], 2.0e-2)
                    and _rel_close(p_abs[i - 1], p_abs[i - 2], 1.0e-1)
                    and rho_tail[i + 1] > rho_tail[i] > rho_tail[i - 1]
                    and p_abs[i + 1] > p_abs[i] > p_abs[i - 1]
                    and u_abs[i + 1] > u_abs[i] > u_abs[i - 1]
                    and rho_tail[i] / max(rho_tail[i - 1], 1.0e-300) > 1.2):
                rho_tail[i] = rho_tail[i - 1]
        changed = np.isfinite(rho_tail) & (rho_tail != rho_candidate)
        if np.any(changed):
            T_limited = T_k.copy()
            T_limited[changed] = _recover_T_from_density_target(
                rho_tail[changed], p_k[changed], u_k[changed],
                T_k[changed], psi_new[changed])
            T_k = T_limited
            props_new = _mix_props(p_k, u_k, T_k)

    if (False and bool(cfg.get('shock_density_crest_mood_limiter', True)) and N >= 9):
        # A-posteriori MOOD for a pure-phase shock crest.
        #
        # In a single-material shock packet the density should satisfy a local
        # maximum principle between the shocked plateau and the downstream
        # state.  A narrow pressure/enthalpy inconsistency can instead create a
        # monotone density crest immediately upstream of the numerical shock
        # drop.  This detector is coordinate-free: it requires a pure-phase
        # stencil, a strict density crest, and a downstream pressure/velocity
        # drop.  The correction maps the crest back to the nearest upstream
        # plateau lower envelope and recovers T at fixed p,u,alpha, preserving
        # the primitive time-marched p/u fields.
        rho_candidate = np.asarray(props_new['rho'], dtype=float)
        rho_crest = rho_candidate.copy()
        psi_abs = np.asarray(psi_new, dtype=float)
        p_abs = np.maximum(np.abs(p_k), _P_FLOOR)
        u_abs = np.abs(np.asarray(u_k, dtype=float))
        for i in range(4, N - 4):
            if float(np.max(psi_abs[i-3:i+4]) - np.min(psi_abs[i-3:i+4])) > 1.0e-3:
                continue
            if not (rho_crest[i - 1] < rho_crest[i]
                    and rho_crest[i] > rho_crest[i + 1]):
                continue
            if not (rho_crest[i] > 1.2 * max(rho_crest[i + 2], 1.0e-300)
                    and p_abs[i] > 1.2 * max(p_abs[i + 2], _P_FLOOR)
                    and u_abs[i] > 1.2 * max(u_abs[i + 2], 1.0)):
                continue
            plateau = float(np.min(rho_crest[i - 5:i - 2]))
            if not np.isfinite(plateau) or plateau <= 0.0:
                continue
            j = i
            while j >= 2 and rho_crest[j] > 1.02 * plateau:
                if float(np.max(psi_abs[j-1:j+2]) - np.min(psi_abs[j-1:j+2])) > 1.0e-3:
                    break
                rho_crest[j] = plateau
                j -= 1
        changed = np.isfinite(rho_crest) & (rho_crest != rho_candidate)
        if np.any(changed):
            T_limited = T_k.copy()
            T_limited[changed] = _recover_T_from_density_target(
                rho_crest[changed], p_k[changed], u_k[changed],
                T_k[changed], psi_new[changed])
            T_k = T_limited
            props_new = _mix_props(p_k, u_k, T_k)

    def _apply_compressive_density_floor(props_in):
        """Final global MOOD admissibility floor for compressive cells.

        For the pressure-based primitive solve, a compressive update (p^{n+1}
        >= p^n) that lowers the thermodynamic density below the accepted old
        cell density is a nonphysical p-T/EOS inconsistency.  Recover T at
        fixed p,u,alpha so the density respects the local old-state lower
        bound.  This is applied uniformly and does not use case coordinates or
        exact data.
        """
        nonlocal T_k
        rho_candidate_f = np.asarray(props_in['rho'], dtype=float)
        rho_floor_f = rho_candidate_f.copy()
        p_now_f = np.maximum(np.asarray(p_k, dtype=float), _P_FLOOR)
        p_old_f = np.maximum(np.asarray(p_n, dtype=float), _P_FLOOR)
        rho_old_state_f = np.asarray(state.get('rho', rho_old), dtype=float)
        compressive = (p_now_f >= p_old_f) & np.isfinite(rho_old_state_f) & (rho_old_state_f > 0.0)
        rho_floor_f[compressive] = np.maximum(rho_floor_f[compressive], rho_old_state_f[compressive])
        changed_f = np.isfinite(rho_floor_f) & (rho_floor_f > rho_candidate_f * (1.0 + 1.0e-12))
        if np.any(changed_f):
            T_fix = T_k.copy()
            T_fix[changed_f] = _recover_T_from_density_target(
                rho_floor_f[changed_f], p_k[changed_f], u_k[changed_f],
                T_k[changed_f], psi_new[changed_f])
            T_k = T_fix
            return _mix_props(p_k, u_k, T_k)
        return props_in

    # Re-apply after any downstream shock/contact MOOD passes so no later
    # thermodynamic limiter can leave a compressive density trough.
    props_new = _apply_compressive_density_floor(props_new)

    if bool(cfg.get('primitive_shock_mood_limiter', False)) and N >= 3:
        # Same a-posteriori maximum principle for velocity, but only on
        # shock/material sensors so smooth acoustic packets keep their extrema.
        p_abs = np.maximum(np.abs(p_k), _P_FLOOR)
        rho_abs = np.maximum(np.abs(props_new['rho']), 1.0e-300)
        psi_abs = np.asarray(psi_new, dtype=float)
        p_ratio_l = np.maximum(p_abs[1:-1], p_abs[:-2]) / np.maximum(
            np.minimum(p_abs[1:-1], p_abs[:-2]), _P_FLOOR)
        p_ratio_r = np.maximum(p_abs[1:-1], p_abs[2:]) / np.maximum(
            np.minimum(p_abs[1:-1], p_abs[2:]), _P_FLOOR)
        rho_jump_l = np.abs(rho_abs[1:-1] - rho_abs[:-2]) / np.maximum(
            np.maximum(rho_abs[1:-1], rho_abs[:-2]), 1.0e-300)
        rho_jump_r = np.abs(rho_abs[1:-1] - rho_abs[2:]) / np.maximum(
            np.maximum(rho_abs[1:-1], rho_abs[2:]), 1.0e-300)
        psi_jump = np.maximum(
            np.abs(psi_abs[1:-1] - psi_abs[:-2]),
            np.abs(psi_abs[1:-1] - psi_abs[2:]))
        sharp_sensor = (
            (np.maximum(p_ratio_l, p_ratio_r) > 1.5)
            | (np.maximum(rho_jump_l, rho_jump_r) > 0.2)
            | (psi_jump > 1.0e-3)
        )
        u_left = u_k[:-2]
        u_mid = u_k[1:-1]
        u_right = u_k[2:]
        u_local_max = (u_mid > u_left) & (u_mid > u_right) & sharp_sensor
        u_local_min = (u_mid < u_left) & (u_mid < u_right) & sharp_sensor
        u_limited = u_k.copy()
        u_limited[1:-1] = np.where(
            u_local_max, np.maximum(u_left, u_right), u_limited[1:-1])
        u_limited[1:-1] = np.where(
            u_local_min, np.minimum(u_left, u_right), u_limited[1:-1])
        if np.any(u_limited != u_k):
            u_k = u_limited
            props_new = _mix_props(p_k, u_k, T_k)
    rho_face_acid_new = acid_face_density(
        props_new['rho'], props_new['c_mix'], psi_new, bc_l, bc_r)
    rho_star_new = (rho_face_acid_new if mwi_rho_star_mode == 'acid'
                    else harmonic_face_density(props_new['rho'], bc_l, bc_r))
    e_diag_new = _momentum_diagonal(props_new['rho'], dx, mwi_dt)
    d_hat_new = mwi_face_coeff_denner(e_diag_new, rho_star_new, dx, mwi_dt, bc_l, bc_r)

    # Face velocity for diagnostics
    u_face_new, u_bar_new = _compute_face_velocity(u_k, p_k, d_hat_new, dx, bc_l, bc_r,
                                           theta_old=theta_old,
                                           u_bar_old=u_bar_old,
                                           rho_star_old=rho_star_old,
                                           dt=dt,
                                           rho_cell=props_new['rho'],
                                           rho_star_face=rho_star_new,
                                           theta_nm1=theta_nm1_aux,
                                           u_bar_nm1=u_bar_nm1_aux,
                                           rho_star_nm1=rho_star_nm1_aux,
                                           dt_prev=dt_prev_aux,
                                           dt_eff=mwi_dt)

    new_state = {
        'p':       p_k,
        'u':       u_k,
        'T':       T_k,
        'psi':     psi_new,
        'rho':     props_new['rho'],
        'E_total': props_new['E_total'],
        'u_face':  u_face_new,
    }

    new_aux = {
        'is_first_step':  False,
        'bdf_order':      1,
        'rho_nm1':        rho_old,
        'rhoU_nm1':       rho_old * u_n,
        'rhoh_nm1':       rho_old * h_old,
        'p_nm1':          p_n.copy(),
        'u_nm1':          u_n.copy(),
        'T_nm1':          T_n.copy(),
        'E_nm1':          props_old['E_total'],
        'rho_face_acid':  rho_face_acid_new,
        'dt_prev':        dt,
        # Transient correction data (Mod 2)
        'theta_old':      u_face_new,
        'u_bar_old':      u_bar_new,
        'rho_star_old':   rho_star_new,
        'theta_nm1':      theta_old,
        'u_bar_nm1':      u_bar_old,
        'rho_star_nm1':   rho_star_old,
    }

    info = {
        'converged':    info_outer['converged'],
        'outer_iters':  info_outer['outer_iters'],
        'inner_iters':  info_outer['inner_iters'],
        # Picard-compatible alias for print_step_info
        'picard_iters': info_outer['outer_iters'],
        'residuals':    [],
    }

    return new_state, new_aux, info

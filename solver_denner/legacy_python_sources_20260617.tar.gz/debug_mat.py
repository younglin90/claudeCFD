import numpy as np
from solver.denner_1d import assembly as denner_assembly
from solver.denner_1d.tests import test_null_mode as t
state=t._material_interface_state(16)
rho_face,d_hat,theta=t._assembly_arrays(state)
A,b=denner_assembly.assemble_newton_3N(
    state['N'],state['dx'],state['dt'],
    state['rho'],state['u'],state['h'],state['p'],
    state['rho'],state['u'],state['h'],state['p'],state['T'],
    state['psi'],state['zeta_v'],rho_face,d_hat,theta,
    state['ph1'],state['ph2'],state['bc_l'],state['bc_r'],
    third_var='T',T_old=state['T'],phi_k=state['phi_v'],
    mixing_type='volume',
    psi_face_transport=t._periodic_face_average(state['psi']),
    acoustic_face_correction=True,
    c_mix=state['c_mix'],
)
x=np.concatenate([state['p'],state['u'],state['T']])
r=b-A.dot(x)
vals=[float(v) for v in r[state['N']:2*state['N']]]
idx=[i for i,v in enumerate(vals) if abs(v)>1e-9]
print('idx',idx)
for i in idx:
    bi=float(b[state['N']+i])
    row=A.getrow(state['N']+i)
    ax=float(row.dot(x).item())
    print('i',i,'res',vals[i],'b',bi,'A*x',ax,'diff',bi-ax)
    print('entries', list(zip(row.indices.tolist(), [float(d) for d in row.data.tolist()])))

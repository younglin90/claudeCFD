import importlib.util,json,time,numpy as np
spec=importlib.util.spec_from_file_location('drv','results/run_denner1d_17case.py')
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
N=100; x=(np.arange(N)+0.5)/N; dx=1/N; left=x<0.7; psi0=np.where(left,1e-6,1-1e-6); p0=np.where(left,1e9,1e5)
Ta=r._temperature_from_rho_p(r.AIR_IDEAL,np.full(N,50.0),p0); Tw=r._temperature_from_rho_p(r.WATER_NASG,np.full(N,1000.0),p0); T0=np.where(left,Tw,Ta); u0=np.zeros(N)
for limiter in ['superbee2','minmod']:
    cfg=dict(tvd_limiter=limiter,density_mood_limiter=True)
    print('START',cfg,flush=True)
    t=time.time(); res=r.denner_run(dict(ph1=r.AIR_IDEAL,ph2=r.WATER_NASG,x_cells=x,psi_init=psi0,T_init=T0,u_init=u0,p_init=p0,t_end=2.29e-4,bc_left='transmissive',bc_right='transmissive',CFL=0.25,cfl_type='acoustic',max_iteration=120000,verbose=False,use_acid=True,variable_set='puT',solver_mode='delta',third_var='T',use_autograd=True,**cfg)); wall=time.time()-t
    psi,T,u,p=r._final_state(res); rho=r._mix_rho(psi,p,T,r.AIR_IDEAL,r.WATER_NASG); ex=r._v_case14_exact_reference(x,r._make_ref_air(),r._make_ref_water_nasg())
    us=r._v_u_shock_location_guard(x,u,ex,dx,prefix='case14',limit_cells=3.0); cl=r._v_case14_close_discontinuity_guard(x,psi,u,ex,dx); pk=r._v_case14_rho_peak085_guard(x,rho,ex,dx); pl=r._v_case14_rho_plateau085_089_guard(x,rho,ex); hf=r._v_rho_u_p_hf_guard(x,rho,u,p,ex)
    print('CASE_JSON '+json.dumps(dict(cfg=cfg,wall=wall,div=bool(res.get('diverged',False)),parts=[us['case14_u_shock_location_ok'],cl['case14_two_close_discontinuities_ok'],pk['case14_rho_peak085_ok'],pl['case14_rho_plateau085_089_ok'],hf['hf_oscillation_ok']],shock_delta=us['case14_u_shock_delta_cells'],gap=cl['case14_split_gap_ratio'],peak_env=pk['case14_rho_peak085_envelope_error_ratio'],peak_tv=pk['case14_rho_peak085_tv_excess_ratio'],peak_turns=pk['case14_rho_peak085_turns'],plat_linf=pl['case14_rho_plateau085_089_linf_ratio'],plat_env=pl['case14_rho_plateau085_089_envelope_ratio'],plat_tv=pl['case14_rho_plateau085_089_tv_excess_ratio'],hf=hf['hf_oscillation_ok'],rho_hf=hf['rho_hf_ok']),default=str), flush=True)

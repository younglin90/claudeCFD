import importlib.util, json, time, argparse, numpy as np
spec = importlib.util.spec_from_file_location('drv','results/run_denner1d_17case.py')
r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
from solver.denner_1d import solver_a
parser=argparse.ArgumentParser()
parser.add_argument('--N',type=int,default=200)
parser.add_argument('--mwi',default='none',choices=['none','minmod','vanleer','superbee'])
parser.add_argument('--mood',action='store_true')
parser.add_argument('--tvd',default='superbee2')
args=parser.parse_args()
if args.mwi != 'none':
    orig = solver_a._compute_face_velocity
    def wrapped(*a, **kw):
        if kw.get('face_limiter', None) is None:
            kw['face_limiter'] = args.mwi
        return orig(*a, **kw)
    solver_a._compute_face_velocity = wrapped
N=args.N; dx=1.0/N; x=(np.arange(N)+0.5)*dx; left=x<0.7
psi0=np.where(left,1e-6,1.0-1e-6); p0=np.where(left,1.0e9,1.0e5)
Ta=r._temperature_from_rho_p(r.AIR_IDEAL,np.full(N,50.0),p0)
Tw=r._temperature_from_rho_p(r.WATER_NASG,np.full(N,1000.0),p0)
T0=np.where(left,Tw,Ta); u0=np.zeros(N)
cfg=dict(ph1=r.AIR_IDEAL,ph2=r.WATER_NASG,x_cells=x,psi_init=psi0,T_init=T0,u_init=u0,p_init=p0,
         t_end=2.29e-4,bc_left='transmissive',bc_right='transmissive',CFL=0.25,cfl_type='acoustic',
         max_iteration=120000,verbose=False,use_autograd=True,use_acid=True,variable_set='puT',solver_mode='delta',
         third_var='T',tvd_limiter=args.tvd,density_mood_limiter=args.mood)
t0=time.time(); res=r.denner_run(cfg); wall=time.time()-t0
psi,T,u,p=r._final_state(res); rho=r._mix_rho(psi,p,T,r.AIR_IDEAL,r.WATER_NASG)
ex=r._v_case14_exact_reference(x,r._make_ref_air(),r._make_ref_water_nasg())
metrics={}
metrics.update(r._v_u_shock_location_guard(x,u,ex,dx,prefix='case14',limit_cells=3.0))
metrics.update(r._v_case14_close_discontinuity_guard(x,psi,u,ex,dx))
metrics.update(r._v_case14_rho_peak085_guard(x,rho,ex,dx))
metrics.update(r._v_case14_rho_plateau085_089_guard(x,rho,ex))
metrics.update(r._v_case14_rho_u_p_hf_guard(x,rho,u,p,ex))
out={'N':N,'mwi':args.mwi,'mood':args.mood,'tvd':args.tvd,'wall':wall,'complete':bool(res['t_history'][-1]>=2.29e-4-1e-14),'diverged':bool(res.get('diverged',False))}
keys=['case14_u_shock_delta_cells','case14_u_shock_location_ok','case14_two_close_discontinuities_ok','case14_split_gap_ratio','case14_contact_jump_ratio','case14_rho_peak085_ok','case14_rho_peak085_turns','case14_rho_peak085_tv_excess_ratio','case14_rho_plateau085_089_ok','case14_rho_plateau085_089_envelope_ratio','case14_rho_plateau085_089_tv_excess_ratio','case14_rho_plateau085_089_turns','rho_sharp_overshoot','rho_sharp_tv_excess','rho_sharp_turns','u_sharp_overshoot','u_sharp_tv_excess','u_sharp_turns','case14_upper_rho_u_peak_ok','hf_oscillation_ok']
for k in keys:
    v=metrics.get(k)
    if isinstance(v,(np.bool_,bool)): v=bool(v)
    elif isinstance(v,(np.integer,)): v=int(v)
    elif isinstance(v,(np.floating,float)): v=float(v)
    out[k]=v
print('DIAG_JSON '+json.dumps(out,sort_keys=True))

import importlib.util,json,time,argparse,numpy as np
spec=importlib.util.spec_from_file_location('drv','results/run_denner1d_17case.py')
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
parser=argparse.ArgumentParser(); parser.add_argument('--N',type=int,default=200); parser.add_argument('--transient',type=int,default=1); args=parser.parse_args()
N=args.N; dx=1.0/N; x=(np.arange(N)+0.5)*dx; left=x<0.7
psi0=np.where(left,1e-6,1.0-1e-6); p0=np.where(left,1.0e9,1.0e5)
Ta=r._temperature_from_rho_p(r.AIR_IDEAL,np.full(N,50.0),p0); Tw=r._temperature_from_rho_p(r.WATER_NASG,np.full(N,1000.0),p0); T0=np.where(left,Tw,Ta); u0=np.zeros(N)
cfg=dict(ph1=r.AIR_IDEAL,ph2=r.WATER_NASG,x_cells=x,psi_init=psi0,T_init=T0,u_init=u0,p_init=p0,t_end=2.29e-4,bc_left='transmissive',bc_right='transmissive',CFL=0.25,cfl_type='acoustic',max_iteration=120000,verbose=False,use_autograd=True,use_acid=True,variable_set='puT',solver_mode='delta',third_var='T',tvd_limiter='superbee2',mwi_transient=bool(args.transient))
t=time.time(); res=r.denner_run(cfg); wall=time.time()-t
psi,T,u,p=r._final_state(res); rho=r._mix_rho(psi,p,T,r.AIR_IDEAL,r.WATER_NASG); ex=r._v_case14_exact_reference(x,r._make_ref_air(),r._make_ref_water_nasg())
metrics={}; metrics.update(r._v_u_shock_location_guard(x,u,ex,dx,prefix='case14',limit_cells=3.0)); metrics.update(r._v_case14_close_discontinuity_guard(x,psi,u,ex,dx)); metrics.update(r._v_case14_rho_peak085_guard(x,rho,ex,dx)); metrics.update(r._v_case14_rho_plateau085_089_guard(x,rho,ex)); metrics.update(r._v_case14_rho_u_p_hf_guard(x,rho,u,p,ex))
out={'N':N,'transient':bool(args.transient),'wall':wall,'complete':bool(res['t_history'][-1]>=2.29e-4-1e-14),'diverged':bool(res.get('diverged',False))}
for k in ['case14_u_shock_delta_cells','case14_u_shock_location_ok','case14_two_close_discontinuities_ok','case14_rho_peak085_turns','case14_rho_plateau085_089_ok','rho_sharp_turns','u_sharp_overshoot','u_sharp_turns','case14_upper_rho_u_peak_ok','hf_oscillation_ok']:
 v=metrics.get(k); out[k]=bool(v) if isinstance(v,(np.bool_,bool)) else (int(v) if isinstance(v,np.integer) else (float(v) if isinstance(v,(np.floating,float)) else v))
print('DIAG_JSON '+json.dumps(out,sort_keys=True))

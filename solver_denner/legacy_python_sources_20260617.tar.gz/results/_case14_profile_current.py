import importlib.util, json, os, time
import numpy as np
spec = importlib.util.spec_from_file_location('drv', 'results/run_denner1d_17case.py')
r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
N = int(os.environ.get('DENNER_CASE14_N', '400'))
dx = 1.0 / N
x = (np.arange(N) + 0.5) * dx
left = x < 0.7
psi0 = np.where(left, 1e-6, 1.0 - 1e-6)
p0 = np.where(left, 1.0e9, 1.0e5)
Ta = r._temperature_from_rho_p(r.AIR_IDEAL, np.full(N, 50.0), p0)
Tw = r._temperature_from_rho_p(r.WATER_NASG, np.full(N, 1000.0), p0)
T0 = np.where(left, Tw, Ta)
u0 = np.zeros(N)
t0 = time.time()
res = r._solve_denner(psi0, T0, u0, p0, dx, t_end=2.29e-4,
                      ph1=r.AIR_IDEAL, ph2=r.WATER_NASG,
                      bc_l='transmissive', bc_r='transmissive',
                      cfl=0.25, cfl_type='acoustic', max_iter=120000)
psi, T, u, p = r._final_state(res)
rho = r._mix_rho(psi, p, T, r.AIR_IDEAL, r.WATER_NASG)
exact = r._v_case14_exact_reference(x, r._make_ref_air(), r._make_ref_water_nasg())
hf = r._v_case14_rho_u_p_hf_guard(x, rho, u, p, exact)
mask = (x >= 0.805) & (x <= 0.885)
out = 'results/1D/14_E/profile_current.tsv'
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, 'w') as f:
    f.write('i\tx\trho\trho_exact\tu\tu_exact\tp\tp_exact\tpsi\n')
    for i in np.where(mask)[0]:
        f.write(f'{i}\t{x[i]:.8f}\t{rho[i]:.12g}\t{exact["rho"][i]:.12g}\t{u[i]:.12g}\t{exact["u"][i]:.12g}\t{p[i]:.12g}\t{exact["p"][i]:.12g}\t{psi[i]:.12g}\n')
# local extrema summary in sharp mask used by validator, approximated by sign changes in selected interval.
rr = rho[mask]
d = np.diff(rr)
turn_idx = []
for j in range(1, len(d)):
    if d[j-1] == 0 or d[j] == 0: continue
    if d[j-1] * d[j] < 0:
        turn_idx.append(int(np.where(mask)[0][0] + j))
print('PROFILE_JSON ' + json.dumps({
    'wall': time.time() - t0,
    'out': out,
    'complete': bool(res['t_history'][-1] >= 2.29e-4 - 1e-14),
    'hf': hf,
    'turn_indices_0805_0885': turn_idx,
    'turn_x_0805_0885': [float(x[i]) for i in turn_idx],
    'rho_at_turns': [float(rho[i]) for i in turn_idx],
    'u_at_turns': [float(u[i]) for i in turn_idx],
}, default=str))

import importlib.util,json,time,numpy as np
spec=importlib.util.spec_from_file_location('drv','results/run_denner1d_17case.py')
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)

def run(label,N=100,**cfg):
    x=(np.arange(N)+0.5)/N; dx=1/N; left=x<0.7
    psi0=np.where(left,1e-6,1-1e-6); p0=np.where(left,1e9,1e5)
    Ta=r._temperature_from_rho_p(r.AIR_IDEAL,np.full(N,50.0),p0); Tw=r._temperature_from_rho_p(r.WATER_NASG,np.full(N,1000.0),p0); T0=np.where(left,Tw,Ta); u0=np.zeros(N)
    res=r.denner_run(dict(ph1=r.AIR_IDEAL,ph2=r.WATER_NASG,x_cells=x,psi_init=psi0,T_init=T0,u_init=u0,p_init=p0,t_end=2.29e-4,bc_left='transmissive',bc_right='transmissive',CFL=0.25,cfl_type='acoustic',max_iteration=120000,verbose=False,use_autograd=True,use_acid=True,variable_set='puT',solver_mode='delta',third_var='T',**cfg))
    psi,T,u,p=r._final_state(res); rho=r._mix_rho(psi,p,T,r.AIR_IDEAL,r.WATER_NASG); ex=r._v_case14_exact_reference(x,r._make_ref_air(),r._make_ref_water_nasg())
    mask=(x>=0.78)&(x<=0.93)
    print('PROFILE '+label)
    print('x rho exrho psi u exu p exp T')
    for vals in zip(x[mask],rho[mask],ex['rho'][mask],psi[mask],u[mask],ex['u'][mask],p[mask],ex['p'][mask],T[mask]):
        print(' '.join(f'{v:.8g}' for v in vals))

run('N200_no_mood', N=200, density_mood_limiter=False, tvd_limiter='superbee2')

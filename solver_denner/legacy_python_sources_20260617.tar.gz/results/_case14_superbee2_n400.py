import importlib.util, json, time, numpy as np
spec=importlib.util.spec_from_file_location('drv','results/run_denner1d_17case.py')
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
N=400; dx=1/N; x=(np.arange(N)+0.5)*dx
left=x<0.7
psi0=np.where(left,1e-6,1-1e-6)
p_init=np.where(left,1e9,1e5)
T_air=r._temperature_from_rho_p(r.AIR_IDEAL,np.full(N,50.0),p_init)
T_water=r._temperature_from_rho_p(r.WATER_NASG,np.full(N,1000.0),p_init)
T_init=np.where(left,T_water,T_air); u_init=np.zeros(N)
t0=time.time()
res=r._solve_denner(psi0,T_init,u_init,p_init,dx,2.29e-4,ph1=r.AIR_IDEAL,ph2=r.WATER_NASG,bc_l='transmissive',bc_r='transmissive',cfl=0.25,cfl_type='acoustic',max_iter=120000,tvd_limiter='superbee2')
wall=time.time()-t0
psi,T,u,p=r._final_state(res); rho=r._mix_rho(psi,p,T,r.AIR_IDEAL,r.WATER_NASG); exact=r._v_case14_exact_reference(x,r._make_ref_air(),r._make_ref_water_nasg())
u_shock=r._v_u_shock_location_guard(x,u,exact,dx,prefix='case14',limit_cells=3.0)
close=r._v_case14_close_discontinuity_guard(x,psi,u,exact,dx)
peak=r._v_case14_rho_peak085_guard(x,rho,exact,dx)
plat=r._v_case14_rho_plateau085_089_guard(x,rho,exact)
hf=r._v_rho_u_p_hf_guard(x,rho,u,p,exact)
# save comparable PNG under canonical location for visual audit of this diagnostic
r._save_3field('14_E', x, {'rho':rho,'u':u,'p':p}, exact, 1e9, '14_E diagnostic superbee2 N400', error_mode='signed')
out=dict(case='14_E_diag_superbee2_N400',pass_=bool(u_shock['case14_u_shock_location_ok'] and close['case14_two_close_discontinuities_ok'] and peak['case14_rho_peak085_ok'] and plat['case14_rho_plateau085_089_ok'] and hf['hf_oscillation_ok']),wall=wall,div=bool(res.get('diverged',False)),parts=[u_shock['case14_u_shock_location_ok'],close['case14_two_close_discontinuities_ok'],peak['case14_rho_peak085_ok'],plat['case14_rho_plateau085_089_ok'],hf['hf_oscillation_ok']],shock_delta=u_shock['case14_u_shock_delta_cells'],gap=close['case14_split_gap_ratio'],peak_env=peak['case14_rho_peak085_envelope_error_ratio'],peak_tv=peak['case14_rho_peak085_tv_excess_ratio'],peak_turns=peak['case14_rho_peak085_turns'],plat_linf=plat['case14_rho_plateau085_089_linf_ratio'],plat_env=plat['case14_rho_plateau085_089_envelope_ratio'],plat_tv=plat['case14_rho_plateau085_089_tv_excess_ratio'],hf_ok=hf['hf_oscillation_ok'],rho_hf=hf['rho_hf_ok'],rho_sharp_ov=hf['rho_sharp_overshoot'],rho_sharp_tv=hf['rho_sharp_tv_excess'])
print('CASE_JSON '+json.dumps(out,default=str))

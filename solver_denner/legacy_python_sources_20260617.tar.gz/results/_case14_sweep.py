import importlib.util, json, os, time
from pathlib import Path
import numpy as np
spec=importlib.util.spec_from_file_location('drv','results/run_denner1d_17case.py')
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)

def eval_case14(N=100, **cfg):
    dx=1.0/N; x=(np.arange(N)+0.5)*dx
    left=x<0.7
    psi0=np.where(left,1e-6,1.0-1e-6)
    p_init=np.where(left,1.0e9,1.0e5)
    T_air=r._temperature_from_rho_p(r.AIR_IDEAL, np.full(N,50.0), p_init)
    T_water=r._temperature_from_rho_p(r.WATER_NASG, np.full(N,1000.0), p_init)
    T_init=np.where(left,T_water,T_air)
    u_init=np.zeros(N)
    t0=time.time()
    res=r._solve_denner(psi0,T_init,u_init,p_init,dx,t_end=2.29e-4,
        ph1=r.AIR_IDEAL, ph2=r.WATER_NASG, bc_l='transmissive', bc_r='transmissive',
        cfl=0.25, cfl_type='acoustic', max_iter=120000, **cfg)
    wall=time.time()-t0
    psi_f,T_f,u_f,p_f=r._final_state(res)
    rho_f=r._mix_rho(psi_f,p_f,T_f,r.AIR_IDEAL,r.WATER_NASG)
    exact=r._v_case14_exact_reference(x, r._make_ref_air(), r._make_ref_water_nasg())
    u_shock=r._v_u_shock_location_guard(x,u_f,exact,dx,prefix='case14',limit_cells=3.0)
    close=r._v_case14_close_discontinuity_guard(x,psi_f,u_f,exact,dx)
    peak=r._v_case14_rho_peak085_guard(x,rho_f,exact,dx)
    plat=r._v_case14_rho_plateau085_089_guard(x,rho_f,exact)
    hf=r._v_rho_u_p_hf_guard(x,rho_f,u_f,p_f,exact)
    return dict(N=N,cfg=cfg,wall=wall,div=bool(res.get('diverged',False)),
        parts=[u_shock['case14_u_shock_location_ok'],close['case14_two_close_discontinuities_ok'],peak['case14_rho_peak085_ok'],plat['case14_rho_plateau085_089_ok'],hf['hf_oscillation_ok']],
        shock_delta=u_shock['case14_u_shock_delta_cells'], gap=close['case14_split_gap_ratio'],
        peak_env=peak['case14_rho_peak085_envelope_error_ratio'], peak_tv=peak['case14_rho_peak085_tv_excess_ratio'], peak_turns=peak['case14_rho_peak085_turns'],
        plat_linf=plat['case14_rho_plateau085_089_linf_ratio'], plat_env=plat['case14_rho_plateau085_089_envelope_ratio'], plat_tv=plat['case14_rho_plateau085_089_tv_excess_ratio'],
        rho_hf=hf['rho_hf_ok'], hf_ok=hf['hf_oscillation_ok'], rho_sharp_ov=hf['rho_sharp_overshoot'], rho_sharp_tv=hf['rho_sharp_tv_excess'])

combos=[]
for limiter in ['superbee2','superbee','mc','minmod']:
  for acid in [False, True]:
    combos.append(dict(tvd_limiter=limiter, mwi_rho_star='acid' if acid else 'harmonic'))
# selected acoustic variants
combos += [
  dict(tvd_limiter='superbee2', acoustic_face_correction=True),
  dict(tvd_limiter='superbee2', acoustic_face_correction=True, mwi_rho_star='acid'),
  dict(tvd_limiter='superbee2', mwi_transient=False),
  dict(tvd_limiter='superbee2', bdf_order=2),
]
for c in combos:
    print('START', c, flush=True)
    try:
        out=eval_case14(100, **c)
    except Exception as e:
        out={'cfg':c,'error':repr(e)}
    print('SWEEP_JSON '+json.dumps(out, default=str), flush=True)

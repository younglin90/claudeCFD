#!/usr/bin/env python3
"""Profile Denner 07_B with small/medium N before expensive N800 runs.

Examples:
  python scripts/benchmark_case07_profile.py --n 200 --only Air-Water
  python scripts/benchmark_case07_profile.py --n 400 --parallel --workers 3
  python scripts/benchmark_case07_profile.py --n 200 --cprofile --top 30
"""

from __future__ import annotations

import argparse
import cProfile
import json
import os
from pathlib import Path
import pstats
import sys
import time


ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(1, str(ROOT.parent))


def _set_env(args):
    os.environ["DENNER_PROFILE"] = "1"
    os.environ["DENNER_CASE07_N"] = str(args.n)
    os.environ["DENNER_CASE07_N_AIR_WATER"] = str(args.n)
    os.environ["DENNER_CASE07_PARALLEL"] = "1" if args.parallel else "0"
    os.environ["DENNER_CASE07_WORKERS"] = str(args.workers)
    os.environ["DENNER_CASE07_CHILD_THREADS"] = str(args.child_threads)
    if args.only:
        os.environ["DENNER_CASE07_ONLY"] = args.only
    else:
        os.environ.pop("DENNER_CASE07_ONLY", None)
    if args.numba_eos:
        os.environ["DENNER_NUMBA_EOS"] = "1"
        os.environ["NUMBA_NUM_THREADS"] = str(args.numba_threads)
    else:
        os.environ["DENNER_NUMBA_EOS"] = "0"


def _run_case07():
    from results.run_denner1d_17case import case_07

    t0 = time.time()
    result = case_07()
    result["benchmark_wall"] = time.time() - t0
    return result


def _profile_summary(result):
    rows = result.get("subcases", [])
    profiles = []
    for row in rows:
        diag = row.get("solver_diagnostics")
        if isinstance(diag, dict):
            prof = diag.get("profile")
            if isinstance(prof, dict):
                profiles.append((row.get("name"), prof))
    return profiles


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=200)
    parser.add_argument("--only", default="Air-Water")
    parser.add_argument("--parallel", action="store_true")
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--child-threads", type=int, default=1)
    parser.add_argument("--numba-eos", action="store_true")
    parser.add_argument("--numba-threads", type=int, default=os.cpu_count() or 1)
    parser.add_argument("--cprofile", action="store_true")
    parser.add_argument("--top", type=int, default=25)
    args = parser.parse_args(argv)

    _set_env(args)
    if args.cprofile:
        prof = cProfile.Profile()
        prof.enable()
        result = _run_case07()
        prof.disable()
        pstats.Stats(prof, stream=sys.stderr).strip_dirs().sort_stats(
            "cumtime").print_stats(args.top)
    else:
        result = _run_case07()

    compact = {
        "case": result.get("case"),
        "pass": result.get("pass"),
        "wall": result.get("wall"),
        "benchmark_wall": result.get("benchmark_wall"),
        "workers": result.get("workers"),
        "failures": result.get("failures"),
        "profiles": _profile_summary(result),
    }
    print("BENCHMARK_CASE07_PROFILE " + json.dumps(compact, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


# solver_denner/solver/denner_1d/__init__.py
# Ref: DENNER_SCHEME.md — Package entry point
#
# Implicit 1D two-phase compressible Euler solver.
# Mode A: segregated VOF (Crank-Nicolson) + coupled (p,u,T) BDF1/BDF2.
#
# Performance note:
# Configure native numeric-library thread caps before importing numpy-heavy
# submodules.  The validation driver also sets these variables, but direct
# solver imports should get the same safe default.  Per-process parallelism
# should normally set DENNER_NUM_THREADS=1 to avoid oversubscription.

import os

_threads = str(min(int(os.environ.get("DENNER_NUM_THREADS", os.cpu_count() or 1)), 8))
for _name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
              "NUMEXPR_NUM_THREADS", "NUMBA_NUM_THREADS"):
    os.environ.setdefault(_name, _threads)

from .main import run
from .config import SolverConfig, PHASE_AIR, PHASE_WATER_LIQUID, PHASE_WATER_VAPOR
from .grid import make_uniform_grid, smooth_vof_profile

__all__ = [
    'run',
    'SolverConfig',
    'PHASE_AIR',
    'PHASE_WATER_LIQUID',
    'PHASE_WATER_VAPOR',
    'make_uniform_grid',
    'smooth_vof_profile',
]

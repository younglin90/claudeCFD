"""Low-level assembly kernels for 1D 3N block systems.

These helpers are intentionally algebra-agnostic: they only turn already
computed 3x3 cell-neighbor blocks into sparse COO triplets.  The expensive
physics coefficients can be migrated into Numba kernels incrementally while
these triplet emitters provide a tested replacement for per-entry A.add calls.
"""

from __future__ import annotations

import numpy as np

try:  # pragma: no cover - optional acceleration
    import numba as nb

    NUMBA_AVAILABLE = True
except Exception:  # pragma: no cover
    nb = None
    NUMBA_AVAILABLE = False


if NUMBA_AVAILABLE:

    @nb.njit(cache=True, nogil=True, parallel=True)
    def _blocks3n_to_triplets_numba(lower, diag, upper):
        n = diag.shape[0]
        nnz = n * 27
        rows = np.empty(nnz, dtype=np.int64)
        cols = np.empty(nnz, dtype=np.int64)
        vals = np.empty(nnz, dtype=np.float64)
        for i in nb.prange(n):
            row_cell = i
            k = i * 27
            for rb in range(3):
                r = rb * n + row_cell
                for cb in range(3):
                    rows[k] = r
                    cols[k] = cb * n + row_cell
                    vals[k] = diag[i, rb, cb]
                    k += 1
            if i < n - 1:
                for rb in range(3):
                    r = rb * n + row_cell
                    for cb in range(3):
                        rows[k] = r
                        cols[k] = cb * n + row_cell + 1
                        vals[k] = upper[i, rb, cb]
                        k += 1
                for rb in range(3):
                    r = rb * n + row_cell + 1
                    for cb in range(3):
                        rows[k] = r
                        cols[k] = cb * n + row_cell
                        vals[k] = lower[i, rb, cb]
                        k += 1
            else:
                for _ in range(18):
                    rows[k] = 0
                    cols[k] = 0
                    vals[k] = 0.0
                    k += 1
        return rows, cols, vals

else:
    _blocks3n_to_triplets_numba = None


def blocks3n_to_triplets(lower, diag, upper, use_numba=True):
    """Convert 3x3 block-tridiagonal coefficients to variable-major COO."""
    lower = np.asarray(lower, dtype=float)
    diag = np.asarray(diag, dtype=float)
    upper = np.asarray(upper, dtype=float)
    n = diag.shape[0]
    if lower.shape != (max(n - 1, 0), 3, 3):
        raise ValueError("lower must have shape (N-1, 3, 3)")
    if upper.shape != (max(n - 1, 0), 3, 3):
        raise ValueError("upper must have shape (N-1, 3, 3)")
    if diag.shape != (n, 3, 3):
        raise ValueError("diag must have shape (N, 3, 3)")
    if use_numba and _blocks3n_to_triplets_numba is not None:
        return _blocks3n_to_triplets_numba(
            np.ascontiguousarray(lower),
            np.ascontiguousarray(diag),
            np.ascontiguousarray(upper),
        )

    nnz = n * 9 + max(n - 1, 0) * 18
    rows = np.empty(nnz, dtype=np.int64)
    cols = np.empty(nnz, dtype=np.int64)
    vals = np.empty(nnz, dtype=float)
    k = 0
    for i in range(n):
        for rb in range(3):
            r = rb * n + i
            for cb in range(3):
                rows[k] = r
                cols[k] = cb * n + i
                vals[k] = diag[i, rb, cb]
                k += 1
        if i < n - 1:
            for rb in range(3):
                r = rb * n + i
                for cb in range(3):
                    rows[k] = r
                    cols[k] = cb * n + i + 1
                    vals[k] = upper[i, rb, cb]
                    k += 1
            for rb in range(3):
                r = rb * n + i + 1
                for cb in range(3):
                    rows[k] = r
                    cols[k] = cb * n + i
                    vals[k] = lower[i, rb, cb]
                    k += 1
    return rows, cols, vals

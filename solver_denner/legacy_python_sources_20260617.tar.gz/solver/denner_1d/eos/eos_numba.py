"""Optional Numba kernels for EOS-heavy Denner hot paths.

The public wrappers in this module deliberately fall back to NumPy when Numba
is unavailable or disabled.  This keeps the solver importable without Numba
while giving validation runs an opt-in compiled path via DENNER_NUMBA_EOS=1.
"""

from __future__ import annotations

import os

import numpy as np

try:  # pragma: no cover - import availability is environment dependent
    import numba as nb

    NUMBA_AVAILABLE = True
except Exception:  # pragma: no cover
    nb = None
    NUMBA_AVAILABLE = False


def _numba_enabled() -> bool:
    return (
        NUMBA_AVAILABLE
        and os.environ.get("DENNER_NUMBA_EOS", "0").lower()
        not in ("0", "false", "no", "off")
    )


def _nasg_phase_props_numpy(p, T, gamma, pinf, b, kv, eta):
    p = np.asarray(p, dtype=float)
    T = np.asarray(T, dtype=float)
    gm1 = float(gamma) - 1.0
    gkv = float(gamma) * float(kv)
    ppinf = p + float(pinf)
    A = float(kv) * T * gm1 + float(b) * ppinf + 1.0e-300
    rho = ppinf / A
    h = gkv * T + float(b) * p + float(eta)
    one_minus_b_rho = 1.0 - float(b) * rho
    c_denom = rho * np.maximum(one_minus_b_rho, 1.0e-12)
    c = np.sqrt(float(gamma) * ppinf / c_denom)
    inv_A2 = 1.0 / (A * A + 1.0e-300)
    zeta = float(kv) * T * gm1 * inv_A2
    phi = -ppinf * float(kv) * gm1 * inv_A2
    dh_dp = np.full_like(p, float(b), dtype=float)
    cp = np.full_like(p, gkv, dtype=float)
    E = rho * h - p
    dEdp = rho * dh_dp + h * zeta - 1.0
    dEdT = rho * cp + h * phi
    return rho, c, h, E, zeta, phi, dh_dp, cp, dEdp, dEdT


if NUMBA_AVAILABLE:

    @nb.njit(cache=True, nogil=True, parallel=True)
    def _nasg_phase_props_kernel(p, T, gamma, pinf, b, kv, eta):
        n = p.size
        rho = np.empty(n, dtype=np.float64)
        c = np.empty(n, dtype=np.float64)
        h = np.empty(n, dtype=np.float64)
        E = np.empty(n, dtype=np.float64)
        zeta = np.empty(n, dtype=np.float64)
        phi = np.empty(n, dtype=np.float64)
        dh_dp = np.empty(n, dtype=np.float64)
        cp = np.empty(n, dtype=np.float64)
        dEdp = np.empty(n, dtype=np.float64)
        dEdT = np.empty(n, dtype=np.float64)
        gm1 = gamma - 1.0
        gkv = gamma * kv
        for i in nb.prange(n):
            ppinf = p[i] + pinf
            A = kv * T[i] * gm1 + b * ppinf + 1.0e-300
            rho_i = ppinf / A
            h_i = gkv * T[i] + b * p[i] + eta
            one_minus_b_rho = 1.0 - b * rho_i
            if one_minus_b_rho < 1.0e-12:
                one_minus_b_rho = 1.0e-12
            c_i = (gamma * ppinf / (rho_i * one_minus_b_rho)) ** 0.5
            inv_A2 = 1.0 / (A * A + 1.0e-300)
            zeta_i = kv * T[i] * gm1 * inv_A2
            phi_i = -ppinf * kv * gm1 * inv_A2
            cp_i = gkv
            rho[i] = rho_i
            c[i] = c_i
            h[i] = h_i
            E[i] = rho_i * h_i - p[i]
            zeta[i] = zeta_i
            phi[i] = phi_i
            dh_dp[i] = b
            cp[i] = cp_i
            dEdp[i] = rho_i * b + h_i * zeta_i - 1.0
            dEdT[i] = rho_i * cp_i + h_i * phi_i
        return rho, c, h, E, zeta, phi, dh_dp, cp, dEdp, dEdT

else:
    _nasg_phase_props_kernel = None


def nasg_phase_props(p, T, gamma, pinf, b, kv, eta):
    """Return NASG phase properties as arrays in compute_phase_props order."""
    p_arr, T_arr = np.broadcast_arrays(
        np.asarray(p, dtype=float), np.asarray(T, dtype=float))
    p_flat = np.ascontiguousarray(p_arr.ravel(), dtype=np.float64)
    T_flat = np.ascontiguousarray(T_arr.ravel(), dtype=np.float64)
    shape = p_arr.shape
    if _numba_enabled():
        out = _nasg_phase_props_kernel(
            p_flat, T_flat, float(gamma), float(pinf), float(b), float(kv),
            float(eta))
    else:
        out = _nasg_phase_props_numpy(
            p_flat, T_flat, gamma, pinf, b, kv, eta)
    return tuple(np.asarray(v, dtype=float).reshape(shape) for v in out)


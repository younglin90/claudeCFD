# solver_denner/solver/denner_1d/flux/limiter.py
# Ref: DENNER_SCHEME.md § 4.2 (consistent transport chain)
#
# Van Leer and Minmod TVD face reconstruction.
# Convention: face f (0..N) is between interior cell f-1 and f.
# phi_ext has shape (N + 2*n_ghost,).

import numpy as np


def _van_leer_limiter(r):
    """
    Van Leer limiter: psi = (r + |r|) / (1 + |r|).
    Accepts arrays.
    """
    r_abs = np.abs(r)
    return (r + r_abs) / (1.0 + r_abs + 1e-300)


def _minmod_limiter(r):
    """
    Minmod limiter: psi = max(0, min(1, r)).
    """
    return np.maximum(0.0, np.minimum(1.0, r))


def van_leer_face(phi_ext, u_face, n_ghost=2):
    """
    Compute face values using van Leer limiter (upwind-biased).

    Parameters
    ----------
    phi_ext : ndarray (N + 2*n_ghost,)   extended array with ghost cells
    u_face  : ndarray (N+1,)             face velocities (sign gives upwind direction)
    n_ghost : int

    Returns
    -------
    phi_face : ndarray (N+1,)
    """
    ng = n_ghost
    N = len(u_face) - 1
    f = np.arange(N + 1)
    iL = ng + f - 1
    iR = ng + f
    pos = np.asarray(u_face) >= 0.0
    phi_C = np.where(pos, phi_ext[iL], phi_ext[iR])
    phi_D = np.where(pos, phi_ext[iL - 1], phi_ext[iR + 1])
    phi_A = np.where(pos, phi_ext[iR], phi_ext[iL])
    diff = phi_C - phi_D
    scale = np.maximum.reduce([
        np.abs(phi_C), np.abs(phi_D), np.abs(phi_A),
        np.full(N + 1, 1.0e-30),
    ])
    flat = np.abs(diff) < 1.0e-12 * scale
    r = np.zeros(N + 1, dtype=float)
    np.divide(phi_A - phi_C, diff, out=r, where=~flat)
    psi = _van_leer_limiter(r)
    return np.where(flat, phi_C, phi_C + 0.5 * psi * diff)


def minmod_face(phi_ext, u_face, n_ghost=2):
    """
    Compute face values using Minmod limiter (upwind-biased).

    Parameters
    ----------
    phi_ext : ndarray (N + 2*n_ghost,)
    u_face  : ndarray (N+1,)
    n_ghost : int

    Returns
    -------
    phi_face : ndarray (N+1,)
    """
    ng = n_ghost
    N = len(u_face) - 1
    f = np.arange(N + 1)
    iL = ng + f - 1
    iR = ng + f
    pos = np.asarray(u_face) >= 0.0
    phi_C = np.where(pos, phi_ext[iL], phi_ext[iR])
    phi_D = np.where(pos, phi_ext[iL - 1], phi_ext[iR + 1])
    phi_A = np.where(pos, phi_ext[iR], phi_ext[iL])
    diff = phi_C - phi_D
    scale = np.maximum.reduce([
        np.abs(phi_C), np.abs(phi_D), np.abs(phi_A),
        np.full(N + 1, 1.0e-30),
    ])
    flat = np.abs(diff) < 1.0e-12 * scale
    r = np.zeros(N + 1, dtype=float)
    np.divide(phi_A - phi_C, diff, out=r, where=~flat)
    psi = _minmod_limiter(r)
    return np.where(flat, phi_C, phi_C + 0.5 * psi * diff)

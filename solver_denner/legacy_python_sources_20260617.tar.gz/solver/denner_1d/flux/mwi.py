# solver_denner/solver/denner_1d/flux/mwi.py
# Ref: DENNER_SCHEME.md § 4.4-4.5, Eq.(17) and (17')
#
# MWI (Momentum-Weighted Interpolation) face velocity.
# ACID (Acoustically Conservative Interface Discretisation) face density.

import numpy as np
from ..boundary import apply_ghost, apply_ghost_velocity


def acid_face_density(rho, c_mix, psi, bc_l, bc_r, n_ghost=2):
    """
    Compute ACID face density at all N+1 faces (including boundary faces).

    At interfaces: ACID formula [Eq. 17']
    At smooth regions: harmonic mean

    Parameters
    ----------
    rho    : ndarray (N,)   mixture density
    c_mix  : ndarray (N,)   mixture sound speed
    psi    : ndarray (N,)   volume fraction (for interface detection)
    bc_l   : str
    bc_r   : str
    n_ghost: int

    Returns
    -------
    rho_face : ndarray (N+1,)
    """
    # Extend arrays with ghost cells
    rho_ext   = apply_ghost(rho,   bc_l, bc_r, n_ghost)
    c_ext     = apply_ghost(c_mix, bc_l, bc_r, n_ghost)
    psi_ext   = apply_ghost(psi,   bc_l, bc_r, n_ghost)

    ng = n_ghost
    N = len(rho)
    rho_L = rho_ext[ng - 1:ng + N]
    rho_R = rho_ext[ng:ng + N + 1]
    c_L = c_ext[ng - 1:ng + N]
    c_R = c_ext[ng:ng + N + 1]
    psi_L = psi_ext[ng - 1:ng + N]
    psi_R = psi_ext[ng:ng + N + 1]

    num = rho_L * rho_R * (rho_L * c_L + rho_R * c_R)
    den = rho_L * rho_L * c_L + rho_R * rho_R * c_R + 1e-300
    acid = num / den
    harmonic = 2.0 * rho_L * rho_R / (rho_L + rho_R + 1e-300)
    rho_face = np.where(np.abs(psi_R - psi_L) > 0.01, acid, harmonic)

    return rho_face


def geometric_face_density(rho, bc_l, bc_r, n_ghost=2):
    """
    Geometric-mean face density: sqrt(rho_L * rho_R).

    Used for the MWI coefficient d_hat instead of ACID density.
    At high-density-ratio interfaces (e.g. water/air = 903:1),
    ACID gives rho_face ≈ rho_light (≈ 1.16 kg/m³), making
    d_hat = dt/rho_face very large and causing Picard oscillations.
    Geometric mean (sqrt(1048*1.16) ≈ 34.9) reduces d_hat by ~30×,
    preventing pressure over-correction while preserving the Abgrall
    condition (d_hat * ∇p = 0 when ∇p = 0).
    For same-phase faces: sqrt(ρ*ρ) = ρ → identical to current behaviour.
    """
    rho_ext = apply_ghost(rho, bc_l, bc_r, n_ghost)
    ng = n_ghost
    N = len(rho)
    rho_L = rho_ext[ng - 1:ng + N]
    rho_R = rho_ext[ng:ng + N + 1]
    return np.sqrt(rho_L * rho_R + 1e-300)


def mwi_face_coeff(rho_face, dt):
    """
    Compute MWI coefficient d_hat_f = dt / rho_face [Eq. 17].

    Parameters
    ----------
    rho_face : ndarray (N+1,)
    dt       : float

    Returns
    -------
    d_hat : ndarray (N+1,)
    """
    return dt / (rho_face + 1e-300)


def harmonic_face_density(rho, bc_l, bc_r, n_ghost=2):
    """Harmonic mean face density: 2*rho_L*rho_R/(rho_L+rho_R). Denner 2018 Eq. 20."""
    rho_ext = apply_ghost(rho, bc_l, bc_r, n_ghost)
    ng = n_ghost
    N = len(rho)
    rho_L = rho_ext[ng - 1:ng + N]
    rho_R = rho_ext[ng:ng + N + 1]
    return 2.0 * rho_L * rho_R / (rho_L + rho_R + 1e-300)


def material_blended_mwi_density(rho, psi, bc_l, bc_r, n_ghost=2,
                                 return_components=False):
    """Harmonic-to-geometric MWI density blend weighted by direct psi jump.

    The harmonic Denner coefficient is preserved exactly for same-composition
    faces.  Production uses the Round 6 direct face jump weight:

        j_f = clip(abs(psi_R - psi_L), 0, 1)
        w_f = j_f

    A compact neighborhood smooth-OR is also returned for diagnostics only
    when components are requested.  It is not used in production weighting.
    """
    rho_h = harmonic_face_density(rho, bc_l, bc_r, n_ghost=n_ghost)
    rho_g = geometric_face_density(rho, bc_l, bc_r, n_ghost=n_ghost)
    psi_ext = apply_ghost(psi, bc_l, bc_r, n_ghost)
    ng = n_ghost
    N = len(rho)
    psi_L = psi_ext[ng - 1:ng + N]
    psi_R = psi_ext[ng:ng + N + 1]
    direct_weight = np.clip(np.abs(psi_R - psi_L), 0.0, 1.0)
    left = np.empty_like(direct_weight)
    right = np.empty_like(direct_weight)
    left[0] = direct_weight[0]
    left[1:] = direct_weight[:-1]
    right[-1] = direct_weight[-1]
    right[:-1] = direct_weight[1:]
    neighborhood_weight = np.clip(
        1.0 - (1.0 - left) * (1.0 - direct_weight) * (1.0 - right),
        0.0, 1.0)
    weight = direct_weight
    rho_blend = (1.0 - weight) * rho_h + weight * rho_g
    rho_blend = np.maximum(rho_blend, 1e-300)
    if return_components:
        return rho_blend, rho_h, rho_g, direct_weight, weight, neighborhood_weight
    return rho_blend


def mwi_face_coeff_denner(e_diag, rho_star_face, dx, dt, bc_l, bc_r, n_ghost=2):
    """
    MWI coefficient per Denner 2018 Eq. 20.

    d_hat_f is the pressure-gradient coefficient in

        theta_f = ubar_f - d_hat_f * (p_R - p_L) / dx + ...

    With a momentum diagonal e_P ≈ rho/dt per unit volume, the
    finite-volume Rhie-Chow/Denner interpolation gives the 1D form of
    Denner 2018 Eq. (21):

        d_hat_f = (1/e_L + 1/e_R)
                  / (2 + rho_f^*/dt * (1/e_L + 1/e_R)).

    The previous normalized expression divided by a dimensional sum and was
    therefore not the Eq. (21) pressure-gradient coefficient.

    For 1D uniform mesh V = dx (volume per unit area).
    """
    e_ext = apply_ghost(e_diag, bc_l, bc_r, n_ghost)
    ng = n_ghost
    N = len(e_diag)
    e_L = np.maximum(e_ext[ng - 1:ng + N], 1e-300)
    e_R = np.maximum(e_ext[ng:ng + N + 1], 1e-300)
    inv_e_sum = 1.0 / e_L + 1.0 / e_R
    return inv_e_sum / (
        2.0 + np.asarray(rho_star_face, dtype=float) / max(dt, 1e-300) * inv_e_sum
    )


def bounded_mwi_pressure_delta(delta_p, d_hat, dx, ub, u_L, u_R, rho_L=None,
                              rho_R=None, c_L=None, c_R=None,
                              eps=1e-300):
    """
    Smoothly bound the MWI pressure-velocity correction.

    The bounded form uses the local scale

        U_ref = sqrt(U_bar^2 + U_jump^2 + U_ac^2)

    with
        U_ac = |dp * dx| / (Z_L + Z_R)
        Z = rho * c
        U_jump = |u_R - u_L|
        U_bar = |u_bar|

    and limiter

        phi = (1 + r^4)^(-1/4),  r = |delta_unbounded| / U_ref.

    `delta_p` and `delta_p_limited` are face velocity correction values
    (same unit), with `delta_p = -d_hat * q_f`.
    """
    eps = float(eps)
    delta_unbounded = float(delta_p)
    d_hat_f = float(d_hat)
    dx_f = float(dx)
    ub_f = float(ub)
    u_jump = abs(float(u_R) - float(u_L))

    # Local acoustic scale from pressure jump and face acoustic impedance.
    if d_hat_f == 0.0:
        d_hat_f = 0.0
    if d_hat_f != 0.0 and np.isfinite(d_hat_f):
        p_delta_eff = abs(delta_unbounded) * max(dx_f, eps) / abs(d_hat_f)
    else:
        p_delta_eff = 0.0
    z_L = abs(float(rho_L) * float(c_L)) if rho_L is not None and c_L is not None else 0.0
    z_R = abs(float(rho_R) * float(c_R)) if rho_R is not None and c_R is not None else 0.0
    z_sum = abs(z_L) + abs(z_R)
    u_ac = p_delta_eff / (z_sum + eps)
    U_ref = np.sqrt(max(ub_f * ub_f, 0.0) + u_jump * u_jump + u_ac * u_ac) + eps
    if U_ref <= 0.0:
        phi = 1.0
    else:
        r = abs(delta_unbounded) / U_ref
        phi = float((1.0 + r**4.0) ** -0.25)

    delta_limited = delta_unbounded * phi
    d_hat_eff = d_hat_f * phi
    return {
        'delta_p_unbounded': delta_unbounded,
        'delta_p_limited': delta_limited,
        'limiter_phi': phi,
        'U_ref': U_ref,
        'U_bar': abs(ub_f),
        'U_jump': u_jump,
        'U_ac': u_ac,
        'r': abs(delta_unbounded) / U_ref if U_ref > 0.0 else 0.0,
        'd_hat_eff': d_hat_eff,
    }


def overdrive_gated_mwi_density(rho, c_mix, psi, u, p, e_diag, dx, dt,
                                bc_l, bc_r, n_ghost=2,
                                grad_corr_face=None,
                                return_components=False):
    """Interface-proximity MWI density stabilization gated by overdrive.

    The Round 6 direct face-jump blend is preserved exactly when the local
    pressure-velocity correction is not overdriven.  For overdriven faces near
    an interface, the production weight is smoothly moved toward the compact
    neighborhood weight already used for diagnostics.
    """
    (
        rho_direct,
        rho_h,
        rho_g,
        direct_weight,
        _blend_weight,
        neighborhood_weight,
    ) = material_blended_mwi_density(
        rho, psi, bc_l, bc_r, n_ghost=n_ghost, return_components=True)
    rho_neighborhood = (
        (1.0 - neighborhood_weight) * rho_h
        + neighborhood_weight * rho_g
    )
    d_hat_direct = mwi_face_coeff_denner(
        e_diag, rho_direct, dx, dt, bc_l, bc_r, n_ghost=n_ghost)

    rho_ext = apply_ghost(rho, bc_l, bc_r, n_ghost)
    c_ext = apply_ghost(c_mix, bc_l, bc_r, n_ghost)
    u_ext = apply_ghost_velocity(u, bc_l, bc_r, n_ghost)
    p_ext = apply_ghost(p, bc_l, bc_r, n_ghost)
    N = len(rho)
    ng = n_ghost
    rho_L = rho_ext[ng - 1:ng + N]
    rho_R = rho_ext[ng:ng + N + 1]
    c_L = c_ext[ng - 1:ng + N]
    c_R = c_ext[ng:ng + N + 1]
    u_L = u_ext[ng - 1:ng + N]
    u_R = u_ext[ng:ng + N + 1]
    p_L = p_ext[ng - 1:ng + N]
    p_R = p_ext[ng:ng + N + 1]

    q_face = (p_R - p_L) / max(float(dx), 1.0e-300)
    if grad_corr_face is not None:
        gc = np.asarray(grad_corr_face, dtype=float)
        if gc.shape == q_face.shape:
            q_face = q_face - gc

    u_bar = 0.5 * (u_L + u_R)
    u_jump = np.abs(u_R - u_L)
    z_sum = np.abs(rho_L * c_L) + np.abs(rho_R * c_R) + 1.0e-300
    u_ac = np.abs(q_face * float(dx)) / z_sum
    u_ref = np.sqrt(u_bar * u_bar + u_jump * u_jump + u_ac * u_ac) + 1.0e-300
    delta_direct = -d_hat_direct * q_face
    overdrive_r = np.abs(delta_direct) / u_ref
    excess = np.maximum(overdrive_r - 1.0, 0.0)
    excess4 = excess**4
    activation = excess4 / (1.0 + excess4)

    effective_weight = direct_weight + activation * (
        neighborhood_weight - direct_weight)
    effective_weight = np.clip(effective_weight, 0.0, 1.0)
    rho_eff = (1.0 - effective_weight) * rho_h + effective_weight * rho_g
    rho_eff = np.maximum(rho_eff, 1.0e-300)
    d_hat_eff = mwi_face_coeff_denner(
        e_diag, rho_eff, dx, dt, bc_l, bc_r, n_ghost=n_ghost)
    delta_eff = -d_hat_eff * q_face

    if return_components:
        return {
            'rho_star': rho_eff,
            'rho_direct': rho_direct,
            'rho_neighborhood': rho_neighborhood,
            'rho_harmonic': rho_h,
            'rho_geometric': rho_g,
            'direct_weight': direct_weight,
            'neighborhood_weight': neighborhood_weight,
            'effective_weight': effective_weight,
            'activation': activation,
            'overdrive_r': overdrive_r,
            'U_ref': u_ref,
            'U_ac': u_ac,
            'd_hat_direct': d_hat_direct,
            'd_hat_eff': d_hat_eff,
            'delta_direct': delta_direct,
            'delta_eff': delta_eff,
        }
    return rho_eff


def mwi_face_velocity_components(u, p, rho_face, d_hat, dx,
                                  u_face_old, rho_face_old, dt,
                                  bc_l, bc_r, n_ghost=2,
                                  include_transient=True,
                                  u_old=None):
    """
    Decompose MWI face velocity into components for implicit assembly.

    The MWI face velocity is:
        u_face = u_arith_f - d_hat_f * (p_{i+1} - p_i) / dx
                 + transient_correction_f      [Eq. 17]

    For implicit assembly we return:
      - u_arith_f   : arithmetic mean of cell u at face (N+1,)
      - d_hat_f     : MWI pressure weight (N+1,)
      - correction  : transient MWI correction (N+1,) — goes to RHS

    Parameters
    ----------
    u              : ndarray (N,)   cell-centre velocities (Picard / current)
    p              : ndarray (N,)   cell-centre pressures  (Picard / current)
    rho_face       : ndarray (N+1,) ACID face density (current step)
    d_hat          : ndarray (N+1,) = dt / rho_face
    dx             : float
    u_face_old     : ndarray (N+1,) face velocity from previous time step
    rho_face_old   : ndarray (N+1,) ACID face density from previous time step
    dt             : float
    bc_l, bc_r     : str
    n_ghost        : int
    include_transient : bool   False for first time step (no previous u_face)

    Returns
    -------
    u_arith_f   : ndarray (N+1,)
    d_hat_f     : ndarray (N+1,)   (same as input d_hat, returned for clarity)
    correction  : ndarray (N+1,)   known correction for RHS
    u_face_full : ndarray (N+1,)   fully evaluated face velocity (for diagnostics)
    """
    N = len(u)
    ng = n_ghost

    u_ext = apply_ghost_velocity(u, bc_l, bc_r, ng)
    p_ext = apply_ghost(p, bc_l, bc_r, ng)

    u_L = u_ext[ng - 1:ng + N]
    u_R = u_ext[ng:ng + N + 1]
    p_L = p_ext[ng - 1:ng + N]
    p_R = p_ext[ng:ng + N + 1]
    u_arith_f = 0.5 * (u_L + u_R)
    dp_f = (p_R - p_L) / dx
    gradp_L = (p_ext[ng:ng + N + 1] - p_ext[ng - 2:ng + N - 1]) / (2.0 * dx)
    gradp_R = (p_ext[ng + 1:ng + N + 2] - p_ext[ng - 1:ng + N]) / (2.0 * dx)
    gradp_avg_f = 0.5 * (gradp_L + gradp_R)

    # Transient correction [Eq. 17]: d_hat * rho_face_old/dt * (u_face_old - u_arith_old)
    # u_old should be the velocity at the previous time step (u^n), not the Picard iterate.
    if include_transient and (u_face_old is not None):
        u_for_arith_old = u_old if u_old is not None else u
        u_old_ext = apply_ghost_velocity(u_for_arith_old, bc_l, bc_r, ng)
        u_arith_old = 0.5 * (
            u_old_ext[ng - 1:ng + N] + u_old_ext[ng:ng + N + 1])
        correction = d_hat * (rho_face_old / dt) * (u_face_old - u_arith_old)
    else:
        correction = np.zeros(N + 1)

    # Full Denner/Xiao MWI face velocity, Eq. (12): the pressure term filters
    # only the high-frequency part of pressure, i.e. face-normal gradient minus
    # the arithmetic mean of adjacent cell-centred gradients.
    u_face_full = u_arith_f - d_hat * (dp_f - gradp_avg_f) + correction

    return u_arith_f, d_hat, correction, u_face_full

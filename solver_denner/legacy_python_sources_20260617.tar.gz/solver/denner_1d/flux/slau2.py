# solver_denner/solver/denner_1d/flux/slau2.py
# SLAU2 flux scheme (Kitamura & Shima, JCP 2013)
# Parameter-free, all-speed, shock-stable AUSM-family flux.
#
# Input:  left/right primitive states (rho, u, p, H, c) at each face
# Output: F_mass, F_momentum, F_energy at each face

import numpy as np


def _mach_plus(M):
    """AUSM+ Mach splitting M+(M)."""
    return np.where(np.abs(M) >= 1.0,
                    0.5 * (M + np.abs(M)),
                    0.25 * (M + 1.0) ** 2)


def _mach_minus(M):
    """AUSM+ Mach splitting M-(M)."""
    return np.where(np.abs(M) >= 1.0,
                    0.5 * (M - np.abs(M)),
                    -0.25 * (M - 1.0) ** 2)


def _P_plus(M):
    """AUSM+ pressure splitting P+(M)."""
    return np.where(np.abs(M) >= 1.0,
                    np.where(M > 0, 1.0, 0.0),
                    0.25 * (M + 1.0) ** 2 * (2.0 - M))


def _P_minus(M):
    """AUSM+ pressure splitting P-(M)."""
    return np.where(np.abs(M) >= 1.0,
                    np.where(M < 0, 1.0, 0.0),
                    0.25 * (M - 1.0) ** 2 * (2.0 + M))


def _slau2_mass_blend_components(rho_L, rho_R, u_L, u_R, p_L, p_R, c_L, c_R,
                                 mass_flux_slau, chi,
                                 mass_blend_inputs=None):
    """Optional smooth same-material acoustic mass-flux blend diagnostics."""
    rho_L = np.asarray(rho_L, dtype=float)
    rho_R = np.asarray(rho_R, dtype=float)
    u_L = np.asarray(u_L, dtype=float)
    u_R = np.asarray(u_R, dtype=float)
    p_L = np.asarray(p_L, dtype=float)
    p_R = np.asarray(p_R, dtype=float)
    c_L = np.asarray(c_L, dtype=float)
    c_R = np.asarray(c_R, dtype=float)
    mass_flux_slau = np.asarray(mass_flux_slau, dtype=float)
    chi = np.asarray(chi, dtype=float)
    c_bar = np.maximum(0.5 * (c_L + c_R), 1.0e-300)
    mass_flux_acoustic = (
        0.5 * (rho_L * u_L + rho_R * u_R)
        - 0.5 * (p_R - p_L) / c_bar
    )

    zeros = np.zeros_like(mass_flux_slau, dtype=float)
    ones = np.ones_like(mass_flux_slau, dtype=float)
    false_flags = np.asarray(zeros, dtype=bool)

    def _empty_diag():
        return {
            'w_smooth_p': zeros,
            'w_smooth_u': zeros,
            'p_dq_ll': zeros,
            'p_dq_lr': zeros,
            'p_dq_rl': zeros,
            'p_dq_rr': zeros,
            'u_dq_ll': zeros,
            'u_dq_lr': zeros,
            'u_dq_rl': zeros,
            'u_dq_rr': zeros,
            'p_d2_left': zeros,
            'p_d2_right': zeros,
            'u_d2_left': zeros,
            'u_d2_right': zeros,
            'p_monotone_left': false_flags,
            'p_monotone_right': false_flags,
            'u_monotone_left': false_flags,
            'u_monotone_right': false_flags,
            'p_beta_left': zeros,
            'p_beta_right': zeros,
            'p_tau': zeros,
            'p_smooth_ratio': zeros,
            'u_beta_left': zeros,
            'u_beta_right': zeros,
            'u_tau': zeros,
            'u_smooth_ratio': zeros,
            'p_weno_smooth_candidate': false_flags,
            'u_weno_smooth_candidate': false_flags,
            'extremum_candidate_p': false_flags,
            'extremum_candidate_u': false_flags,
            'J_plus_dq_ll': zeros,
            'J_plus_dq_lr': zeros,
            'J_plus_dq_rl': zeros,
            'J_plus_dq_rr': zeros,
            'J_plus_d2_left': zeros,
            'J_plus_d2_right': zeros,
            'J_plus_beta_left': zeros,
            'J_plus_beta_right': zeros,
            'J_plus_tau': zeros,
            'J_plus_smooth_ratio': zeros,
            'J_plus_monotone_left': false_flags,
            'J_plus_monotone_right': false_flags,
            'J_minus_dq_ll': zeros,
            'J_minus_dq_lr': zeros,
            'J_minus_dq_rl': zeros,
            'J_minus_dq_rr': zeros,
            'J_minus_d2_left': zeros,
            'J_minus_d2_right': zeros,
            'J_minus_beta_left': zeros,
            'J_minus_beta_right': zeros,
            'J_minus_tau': zeros,
            'J_minus_smooth_ratio': zeros,
            'J_minus_monotone_left': false_flags,
            'J_minus_monotone_right': false_flags,
            'characteristic_smooth_candidate': false_flags,
            'p_jump_rel': zeros,
            'u_jump_rel': zeros,
            'compression_proxy': zeros,
            'zero_reason': np.full(np.shape(mass_flux_slau), 'no_inputs',
                                   dtype=object),
            'helper_called': false_flags,
        }

    diag = _empty_diag()
    if not isinstance(mass_blend_inputs, dict):
        return {
            'mass_flux_before': mass_flux_slau,
            'mass_flux_acoustic': mass_flux_acoustic,
            'mass_flux_after': mass_flux_slau,
            'weight': zeros,
            'active': np.asarray(zeros, dtype=bool),
            'w_material': zeros,
            'w_impedance': zeros,
            'w_smooth': zeros,
            'w_chi': np.clip(chi, 0.0, 1.0),
            'w_sign': zeros,
            **diag,
        }
    diag['helper_called'] = np.asarray(ones, dtype=bool)

    def _optional(name):
        value = mass_blend_inputs.get(name)
        if value is None:
            return None
        return np.asarray(value, dtype=float)

    def _optional_or(name, default):
        value = _optional(name)
        return default if value is None else value

    psi_L = _optional('psi_L')
    psi_R = _optional('psi_R')
    psi_LL = _optional('psi_LL')
    psi_RR = _optional('psi_RR')
    if psi_L is None or psi_R is None:
        w_material = zeros
    else:
        jumps = [np.abs(psi_R - psi_L)]
        if psi_LL is not None:
            jumps.append(np.abs(psi_L - psi_LL))
        if psi_RR is not None:
            jumps.append(np.abs(psi_RR - psi_R))
        w_material = ones
        for jump in jumps:
            w_material = w_material * (1.0 - np.clip(jump, 0.0, 1.0))

    Z_L = rho_L * c_L
    Z_R = rho_R * c_R
    w_impedance = 1.0 - np.clip(
        np.abs(Z_R - Z_L) / (np.abs(Z_R) + np.abs(Z_L) + 1.0e-300),
        0.0, 1.0)

    def _stencil_smooth(q_LL, q_L, q_R, q_RR):
        if q_LL is None or q_RR is None:
            empty = {
                'smooth': zeros,
                'dq_ll': zeros,
                'dq_lr': zeros,
                'dq_rl': zeros,
                'dq_rr': zeros,
                'd2_left': zeros,
                'd2_right': zeros,
                'monotone_left': false_flags,
                'monotone_right': false_flags,
                'beta_left': zeros,
                'beta_right': zeros,
                'tau': zeros,
                'smooth_ratio': zeros,
                'weno_smooth_candidate': false_flags,
                'extremum_candidate': false_flags,
            }
            return empty
        dq_l_l = q_L - q_LL
        dq_l_r = q_R - q_L
        dq_r_l = dq_l_r
        dq_r_r = q_RR - q_R
        d2_l = dq_l_r - dq_l_l
        d2_r = dq_r_r - dq_r_l
        s_l = 1.0 / (
            1.0
            + (np.abs(d2_l) / (np.abs(dq_l_l) + np.abs(dq_l_r) + 1.0e-300)) ** 4
        )
        s_r = 1.0 / (
            1.0
            + (np.abs(d2_r) / (np.abs(dq_r_l) + np.abs(dq_r_r) + 1.0e-300)) ** 4
        )
        monotone_left = dq_l_l * dq_l_r > 0.0
        monotone_right = dq_r_l * dq_r_r > 0.0
        monotone = monotone_left & monotone_right
        beta_left = dq_l_l * dq_l_l + dq_l_r * dq_l_r
        beta_right = dq_r_l * dq_r_l + dq_r_r * dq_r_r
        tau = np.abs(beta_left - beta_right)
        smooth_ratio = tau / (beta_left + beta_right + 1.0e-300)
        weno_smooth_candidate = smooth_ratio <= 0.25
        extremum_candidate = (~monotone) & weno_smooth_candidate
        return {
            'smooth': np.where(monotone, np.minimum(s_l, s_r), 0.0),
            'dq_ll': dq_l_l,
            'dq_lr': dq_l_r,
            'dq_rl': dq_r_l,
            'dq_rr': dq_r_r,
            'd2_left': d2_l,
            'd2_right': d2_r,
            'monotone_left': monotone_left,
            'monotone_right': monotone_right,
            'beta_left': beta_left,
            'beta_right': beta_right,
            'tau': tau,
            'smooth_ratio': smooth_ratio,
            'weno_smooth_candidate': weno_smooth_candidate,
            'extremum_candidate': extremum_candidate,
        }

    p_LL = _optional('p_LL')
    p_RR = _optional('p_RR')
    u_LL = _optional('u_LL')
    u_RR = _optional('u_RR')
    p_smooth = _stencil_smooth(p_LL, p_L, p_R, p_RR)
    u_smooth = _stencil_smooth(u_LL, u_L, u_R, u_RR)
    w_smooth = p_smooth['smooth'] * u_smooth['smooth']

    for prefix, smooth in (('p', p_smooth), ('u', u_smooth)):
        diag[f'w_smooth_{prefix}'] = smooth['smooth']
        diag[f'{prefix}_dq_ll'] = smooth['dq_ll']
        diag[f'{prefix}_dq_lr'] = smooth['dq_lr']
        diag[f'{prefix}_dq_rl'] = smooth['dq_rl']
        diag[f'{prefix}_dq_rr'] = smooth['dq_rr']
        diag[f'{prefix}_d2_left'] = smooth['d2_left']
        diag[f'{prefix}_d2_right'] = smooth['d2_right']
        diag[f'{prefix}_monotone_left'] = smooth['monotone_left']
        diag[f'{prefix}_monotone_right'] = smooth['monotone_right']
        diag[f'{prefix}_beta_left'] = smooth['beta_left']
        diag[f'{prefix}_beta_right'] = smooth['beta_right']
        diag[f'{prefix}_tau'] = smooth['tau']
        diag[f'{prefix}_smooth_ratio'] = smooth['smooth_ratio']
        diag[f'{prefix}_weno_smooth_candidate'] = smooth['weno_smooth_candidate']
        diag[f'extremum_candidate_{prefix}'] = smooth['extremum_candidate']

    Z_bar = 0.5 * (rho_L * c_L + rho_R * c_R)
    p_LL_j = _optional_or('p_LL', p_L)
    p_RR_j = _optional_or('p_RR', p_R)
    u_LL_j = _optional_or('u_LL', u_L)
    u_RR_j = _optional_or('u_RR', u_R)
    J_plus = _stencil_smooth(
        p_LL_j + Z_bar * u_LL_j, p_L + Z_bar * u_L,
        p_R + Z_bar * u_R, p_RR_j + Z_bar * u_RR_j)
    J_minus = _stencil_smooth(
        p_LL_j - Z_bar * u_LL_j, p_L - Z_bar * u_L,
        p_R - Z_bar * u_R, p_RR_j - Z_bar * u_RR_j)
    for prefix, smooth in (('J_plus', J_plus), ('J_minus', J_minus)):
        diag[f'{prefix}_dq_ll'] = smooth['dq_ll']
        diag[f'{prefix}_dq_lr'] = smooth['dq_lr']
        diag[f'{prefix}_dq_rl'] = smooth['dq_rl']
        diag[f'{prefix}_dq_rr'] = smooth['dq_rr']
        diag[f'{prefix}_d2_left'] = smooth['d2_left']
        diag[f'{prefix}_d2_right'] = smooth['d2_right']
        diag[f'{prefix}_beta_left'] = smooth['beta_left']
        diag[f'{prefix}_beta_right'] = smooth['beta_right']
        diag[f'{prefix}_tau'] = smooth['tau']
        diag[f'{prefix}_smooth_ratio'] = smooth['smooth_ratio']
        diag[f'{prefix}_monotone_left'] = smooth['monotone_left']
        diag[f'{prefix}_monotone_right'] = smooth['monotone_right']
    diag['characteristic_smooth_candidate'] = (
        J_plus['weno_smooth_candidate'] & J_minus['weno_smooth_candidate'])
    diag['p_jump_rel'] = (
        np.abs(p_R - p_L) / (np.abs(p_R) + np.abs(p_L) + 1.0e-300))
    diag['u_jump_rel'] = np.abs(u_R - u_L) / (c_bar + 1.0e-300)
    dx = _optional('dx')
    if dx is not None:
        diag['compression_proxy'] = np.maximum(
            0.0, -(u_R - u_L) / np.maximum(np.abs(dx), 1.0e-300))

    w_chi = np.clip(chi, 0.0, 1.0)
    w_sign = np.where(mass_flux_slau * mass_flux_acoustic >= 0.0, 1.0, 0.0)
    weight = np.clip(
        w_material * w_impedance * w_smooth * w_chi * w_sign,
        0.0, 1.0)
    zero_reason = np.full(np.shape(weight), 'none', dtype=object)
    zero_reason = np.where(w_material <= 0.0, 'material', zero_reason)
    zero_reason = np.where((w_material > 0.0) & (w_impedance <= 0.0),
                           'impedance', zero_reason)
    zero_reason = np.where(
        (w_material > 0.0) & (w_impedance > 0.0)
        & (p_smooth['smooth'] <= 0.0),
        'smooth_p', zero_reason)
    zero_reason = np.where(
        (w_material > 0.0) & (w_impedance > 0.0)
        & (p_smooth['smooth'] > 0.0) & (u_smooth['smooth'] <= 0.0),
        'smooth_u', zero_reason)
    zero_reason = np.where(
        (w_material > 0.0) & (w_impedance > 0.0)
        & (p_smooth['smooth'] > 0.0) & (u_smooth['smooth'] > 0.0)
        & (w_sign <= 0.0),
        'sign', zero_reason)
    diag['zero_reason'] = np.where(weight > 0.0, 'none', zero_reason)
    mass_flux_after = (1.0 - weight) * mass_flux_slau + weight * mass_flux_acoustic
    return {
        'mass_flux_before': mass_flux_slau,
        'mass_flux_acoustic': mass_flux_acoustic,
        'mass_flux_after': mass_flux_after,
        'weight': weight,
        'active': weight > 0.0,
        'w_material': w_material,
        'w_impedance': w_impedance,
        'w_smooth': w_smooth,
        'w_chi': w_chi,
        'w_sign': w_sign,
        **diag,
    }


def slau2_flux(rho_L, rho_R, u_L, u_R, p_L, p_R, H_L, H_R, c_L, c_R,
               *, mass_blend_inputs=None):
    """
    Compute SLAU2 face fluxes for 1D Euler equations.

    Parameters
    ----------
    rho_L, rho_R : float or ndarray  density [kg/m³]
    u_L, u_R     : float or ndarray  velocity [m/s]
    p_L, p_R     : float or ndarray  pressure [Pa]
    H_L, H_R     : float or ndarray  total enthalpy h + 0.5*u² [J/kg]
    c_L, c_R     : float or ndarray  speed of sound [m/s]

    Returns
    -------
    F_mass   : float or ndarray  mass flux [kg/(m²·s)]
    F_mom    : float or ndarray  momentum flux [Pa]
    F_ener   : float or ndarray  energy flux [W/m²]
    """
    rho_L = np.asarray(rho_L, dtype=float)
    rho_R = np.asarray(rho_R, dtype=float)
    u_L = np.asarray(u_L, dtype=float)
    u_R = np.asarray(u_R, dtype=float)
    p_L = np.asarray(p_L, dtype=float)
    p_R = np.asarray(p_R, dtype=float)
    H_L = np.asarray(H_L, dtype=float)
    H_R = np.asarray(H_R, dtype=float)
    c_L = np.asarray(c_L, dtype=float)
    c_R = np.asarray(c_R, dtype=float)

    # Interface speed of sound
    c_bar = 0.5 * (c_L + c_R)
    c_bar = np.maximum(c_bar, 1e-300)

    # Mach numbers
    M_L = u_L / c_bar
    M_R = u_R / c_bar

    # Average Mach and chi parameter
    M_bar = np.sqrt(0.5 * (u_L ** 2 + u_R ** 2)) / c_bar
    M_hat = np.minimum(1.0, M_bar)
    chi = (1.0 - M_hat) ** 2

    # AUSM+ velocity splits
    u_plus_L = c_bar * _mach_plus(M_L)
    u_minus_R = c_bar * _mach_minus(M_R)

    # g function (expansion/stagnation detector)
    beta_L_minus = np.maximum(np.minimum(M_L, 0.0), -1.0)
    beta_R_plus = np.minimum(np.maximum(M_R, 0.0), 1.0)
    g = -beta_L_minus * beta_R_plus

    # Modified velocity splits
    V_plus_L = (1.0 - g) * u_plus_L + g * np.abs(u_L)
    V_minus_R = (1.0 - g) * u_minus_R - g * np.abs(u_R)

    # ---- Mass flux (identical for SLAU and SLAU2) ----
    m_dot = (0.5 * (rho_L * (u_L + np.abs(V_plus_L))
                     + rho_R * (u_R - np.abs(V_minus_R)))
             - chi / (2.0 * c_bar) * (p_R - p_L))

    # ---- Pressure flux (SLAU2 version) ----
    Pp_L = _P_plus(M_L)
    Pm_R = _P_minus(M_R)

    u_bar_mag = np.sqrt(0.5 * (u_L ** 2 + u_R ** 2))

    p_face = (0.5 * (p_L + p_R)
              + 0.5 * (Pp_L - Pm_R) * (p_L - p_R)
              + u_bar_mag * (Pp_L + Pm_R - 1.0) * 0.5 * (rho_L + rho_R) * c_bar)

    mass_blend = _slau2_mass_blend_components(
        rho_L, rho_R, u_L, u_R, p_L, p_R, c_L, c_R, m_dot, chi,
        mass_blend_inputs=mass_blend_inputs)
    m_dot_eff = mass_blend['mass_flux_after']

    # ---- Face fluxes ----
    # Upwind convected quantities use the original SLAU2 sign so the blend cannot
    # change the convected-state branch.
    u_up = np.where(m_dot >= 0, u_L, u_R)
    H_up = np.where(m_dot >= 0, H_L, H_R)

    F_mass = m_dot_eff
    F_mom = m_dot_eff * u_up + p_face
    F_ener = m_dot_eff * H_up

    return F_mass, F_mom, F_ener


def slau2_flux_components(rho_L, rho_R, u_L, u_R, p_L, p_R,
                          H_L, H_R, c_L, c_R, *, mass_blend_inputs=None):
    """Return SLAU2 fluxes plus passive component diagnostics.

    This helper mirrors ``slau2_flux`` algebraically and is intentionally not
    called by the production flux path.  It lets diagnostics verify which
    mass-pressure and pressure-split terms produced an already-computed face
    flux without changing that flux.
    """
    rho_L = np.asarray(rho_L, dtype=float)
    rho_R = np.asarray(rho_R, dtype=float)
    u_L = np.asarray(u_L, dtype=float)
    u_R = np.asarray(u_R, dtype=float)
    p_L = np.asarray(p_L, dtype=float)
    p_R = np.asarray(p_R, dtype=float)
    H_L = np.asarray(H_L, dtype=float)
    H_R = np.asarray(H_R, dtype=float)
    c_L = np.asarray(c_L, dtype=float)
    c_R = np.asarray(c_R, dtype=float)

    c_bar = np.maximum(0.5 * (c_L + c_R), 1e-300)
    M_L = u_L / c_bar
    M_R = u_R / c_bar
    M_bar = np.sqrt(0.5 * (u_L ** 2 + u_R ** 2)) / c_bar
    M_hat = np.minimum(1.0, M_bar)
    chi = (1.0 - M_hat) ** 2

    u_plus_L = c_bar * _mach_plus(M_L)
    u_minus_R = c_bar * _mach_minus(M_R)

    beta_L_minus = np.maximum(np.minimum(M_L, 0.0), -1.0)
    beta_R_plus = np.minimum(np.maximum(M_R, 0.0), 1.0)
    g = -beta_L_minus * beta_R_plus

    V_plus_L = (1.0 - g) * u_plus_L + g * np.abs(u_L)
    V_minus_R = (1.0 - g) * u_minus_R - g * np.abs(u_R)

    mass_advective_part = 0.5 * (
        rho_L * (u_L + np.abs(V_plus_L))
        + rho_R * (u_R - np.abs(V_minus_R))
    )
    mass_pressure_part = -chi / (2.0 * c_bar) * (p_R - p_L)
    m_dot = mass_advective_part + mass_pressure_part

    Pp_L = _P_plus(M_L)
    Pm_R = _P_minus(M_R)
    u_bar_mag = np.sqrt(0.5 * (u_L ** 2 + u_R ** 2))
    pressure_central_part = 0.5 * (p_L + p_R)
    pressure_split_part = 0.5 * (Pp_L - Pm_R) * (p_L - p_R)
    pressure_velocity_part = (
        u_bar_mag * (Pp_L + Pm_R - 1.0)
        * 0.5 * (rho_L + rho_R) * c_bar
    )
    p_face = (
        pressure_central_part
        + pressure_split_part
        + pressure_velocity_part
    )

    mass_blend = _slau2_mass_blend_components(
        rho_L, rho_R, u_L, u_R, p_L, p_R, c_L, c_R, m_dot, chi,
        mass_blend_inputs=mass_blend_inputs)
    m_dot_eff = mass_blend['mass_flux_after']

    u_up = np.where(m_dot >= 0, u_L, u_R)
    H_up = np.where(m_dot >= 0, H_L, H_R)
    F_mass = m_dot_eff
    F_mom = m_dot_eff * u_up + p_face
    F_ener = m_dot_eff * H_up

    return {
        'F_mass': F_mass,
        'F_mom': F_mom,
        'F_energy': F_ener,
        'c_bar': c_bar,
        'M_L': M_L,
        'M_R': M_R,
        'M_bar': M_bar,
        'M_hat': M_hat,
        'chi': chi,
        'g': g,
        'u_plus_L': u_plus_L,
        'u_minus_R': u_minus_R,
        'V_plus_L': V_plus_L,
        'V_minus_R': V_minus_R,
        'mass_advective_part': mass_advective_part,
        'mass_pressure_part': mass_pressure_part,
        'mass_flux_before_blend': mass_blend['mass_flux_before'],
        'mass_flux_acoustic_target': mass_blend['mass_flux_acoustic'],
        'mass_flux_after_blend': mass_blend['mass_flux_after'],
        'mass_blend_weight': mass_blend['weight'],
        'mass_blend_active': mass_blend['active'],
        'mass_blend_w_material': mass_blend['w_material'],
        'mass_blend_w_impedance': mass_blend['w_impedance'],
        'mass_blend_w_smooth': mass_blend['w_smooth'],
        'mass_blend_w_chi': mass_blend['w_chi'],
        'mass_blend_w_sign': mass_blend['w_sign'],
        'mass_blend_w_smooth_p': mass_blend['w_smooth_p'],
        'mass_blend_w_smooth_u': mass_blend['w_smooth_u'],
        'mass_blend_p_dq_ll': mass_blend['p_dq_ll'],
        'mass_blend_p_dq_lr': mass_blend['p_dq_lr'],
        'mass_blend_p_dq_rl': mass_blend['p_dq_rl'],
        'mass_blend_p_dq_rr': mass_blend['p_dq_rr'],
        'mass_blend_u_dq_ll': mass_blend['u_dq_ll'],
        'mass_blend_u_dq_lr': mass_blend['u_dq_lr'],
        'mass_blend_u_dq_rl': mass_blend['u_dq_rl'],
        'mass_blend_u_dq_rr': mass_blend['u_dq_rr'],
        'mass_blend_p_d2_left': mass_blend['p_d2_left'],
        'mass_blend_p_d2_right': mass_blend['p_d2_right'],
        'mass_blend_u_d2_left': mass_blend['u_d2_left'],
        'mass_blend_u_d2_right': mass_blend['u_d2_right'],
        'mass_blend_p_monotone_left': mass_blend['p_monotone_left'],
        'mass_blend_p_monotone_right': mass_blend['p_monotone_right'],
        'mass_blend_u_monotone_left': mass_blend['u_monotone_left'],
        'mass_blend_u_monotone_right': mass_blend['u_monotone_right'],
        'mass_blend_p_beta_left': mass_blend['p_beta_left'],
        'mass_blend_p_beta_right': mass_blend['p_beta_right'],
        'mass_blend_p_tau': mass_blend['p_tau'],
        'mass_blend_p_smooth_ratio': mass_blend['p_smooth_ratio'],
        'mass_blend_u_beta_left': mass_blend['u_beta_left'],
        'mass_blend_u_beta_right': mass_blend['u_beta_right'],
        'mass_blend_u_tau': mass_blend['u_tau'],
        'mass_blend_u_smooth_ratio': mass_blend['u_smooth_ratio'],
        'mass_blend_p_weno_smooth_candidate': (
            mass_blend['p_weno_smooth_candidate']),
        'mass_blend_u_weno_smooth_candidate': (
            mass_blend['u_weno_smooth_candidate']),
        'mass_blend_extremum_candidate_p': (
            mass_blend['extremum_candidate_p']),
        'mass_blend_extremum_candidate_u': (
            mass_blend['extremum_candidate_u']),
        'mass_blend_J_plus_dq_ll': mass_blend['J_plus_dq_ll'],
        'mass_blend_J_plus_dq_lr': mass_blend['J_plus_dq_lr'],
        'mass_blend_J_plus_dq_rl': mass_blend['J_plus_dq_rl'],
        'mass_blend_J_plus_dq_rr': mass_blend['J_plus_dq_rr'],
        'mass_blend_J_plus_d2_left': mass_blend['J_plus_d2_left'],
        'mass_blend_J_plus_d2_right': mass_blend['J_plus_d2_right'],
        'mass_blend_J_plus_beta_left': mass_blend['J_plus_beta_left'],
        'mass_blend_J_plus_beta_right': mass_blend['J_plus_beta_right'],
        'mass_blend_J_plus_tau': mass_blend['J_plus_tau'],
        'mass_blend_J_plus_smooth_ratio': (
            mass_blend['J_plus_smooth_ratio']),
        'mass_blend_J_plus_monotone_left': (
            mass_blend['J_plus_monotone_left']),
        'mass_blend_J_plus_monotone_right': (
            mass_blend['J_plus_monotone_right']),
        'mass_blend_J_minus_dq_ll': mass_blend['J_minus_dq_ll'],
        'mass_blend_J_minus_dq_lr': mass_blend['J_minus_dq_lr'],
        'mass_blend_J_minus_dq_rl': mass_blend['J_minus_dq_rl'],
        'mass_blend_J_minus_dq_rr': mass_blend['J_minus_dq_rr'],
        'mass_blend_J_minus_d2_left': mass_blend['J_minus_d2_left'],
        'mass_blend_J_minus_d2_right': mass_blend['J_minus_d2_right'],
        'mass_blend_J_minus_beta_left': mass_blend['J_minus_beta_left'],
        'mass_blend_J_minus_beta_right': mass_blend['J_minus_beta_right'],
        'mass_blend_J_minus_tau': mass_blend['J_minus_tau'],
        'mass_blend_J_minus_smooth_ratio': (
            mass_blend['J_minus_smooth_ratio']),
        'mass_blend_J_minus_monotone_left': (
            mass_blend['J_minus_monotone_left']),
        'mass_blend_J_minus_monotone_right': (
            mass_blend['J_minus_monotone_right']),
        'mass_blend_characteristic_smooth_candidate': (
            mass_blend['characteristic_smooth_candidate']),
        'mass_blend_p_jump_rel': mass_blend['p_jump_rel'],
        'mass_blend_u_jump_rel': mass_blend['u_jump_rel'],
        'mass_blend_compression_proxy': mass_blend['compression_proxy'],
        'mass_blend_zero_reason': mass_blend['zero_reason'],
        'mass_blend_helper_called': mass_blend['helper_called'],
        'Pp_L': Pp_L,
        'Pm_R': Pm_R,
        'pressure_central_part': pressure_central_part,
        'pressure_split_part': pressure_split_part,
        'pressure_velocity_part': pressure_velocity_part,
        'p_face': p_face,
        'u_up': u_up,
        'H_up': H_up,
        'upwind_selector': np.where(m_dot >= 0, 1, -1),
    }

# solver_denner/solver/denner_1d/interface/cicsam.py
# Ref: DENNER_SCHEME.md § 5, Eq.(18)
#
# CICSAM (Compressive Interface Capturing Scheme for Arbitrary Meshes)
# 1D implementation = Hyper-C scheme.
# Note: compression term is NOT added [Zanutto2022].

import numpy as np


def cicsam_face(psi_ext, u_face, dt, dx, n_ghost=2):
    """
    Compute face values of psi using CICSAM Hyper-C.

    Parameters
    ----------
    psi_ext  : ndarray (N + 2*n_ghost,)
               VOF field with ghost cells already applied.
    u_face   : ndarray (N+1,)
               Face velocities at interior faces i+1/2, i=0..N-1.
               Face f is between cells (f-1) and f in interior indexing
               (i.e., between psi_ext[n_ghost+f-1] and psi_ext[n_ghost+f]).
    dt       : float  time step [s]
    dx       : float  cell size [m]
    n_ghost  : int    number of ghost cells on each side

    Returns
    -------
    psi_face : ndarray (N+1,)
               CICSAM face values, clipped to [0, 1].
    """
    ng = n_ghost
    N = len(u_face) - 1  # number of interior cells
    f = np.arange(N + 1)
    pos = np.asarray(u_face) >= 0.0
    i_D = np.where(pos, ng + f - 1, ng + f)
    i_A = np.where(pos, ng + f, ng + f - 1)
    i_UU = np.where(pos, ng + f - 2, ng + f + 1)
    psi_D = psi_ext[i_D]
    psi_A = psi_ext[i_A]
    psi_UU = psi_ext[i_UU]
    denom = psi_A - psi_UU
    uniform = np.abs(denom) < 1.0e-10
    psi_tilde_D = np.zeros(N + 1, dtype=float)
    np.divide(psi_D - psi_UU, denom, out=psi_tilde_D, where=~uniform)
    Co_f = np.abs(u_face) * dt / dx
    in_bounds = (psi_tilde_D >= 0.0) & (psi_tilde_D <= 1.0)
    psi_tilde_f = psi_tilde_D.copy()
    psi_tilde_f[in_bounds] = np.minimum(
        psi_tilde_D[in_bounds] / np.maximum(Co_f[in_bounds], 1.0e-10),
        1.0,
    )
    psi_face = np.where(uniform, psi_D, psi_UU + psi_tilde_f * denom)
    return np.clip(psi_face, 0.0, 1.0)


def cicsam_face_components(psi_ext, u_face, dt, dx, n_ghost=2):
    """Return CICSAM face values plus passive reconstruction components."""
    ng = n_ghost
    N = len(u_face) - 1
    f = np.arange(N + 1)
    pos = np.asarray(u_face) >= 0.0
    i_D = np.where(pos, ng + f - 1, ng + f)
    i_A = np.where(pos, ng + f, ng + f - 1)
    i_UU = np.where(pos, ng + f - 2, ng + f + 1)
    psi_arr = np.asarray(psi_ext, dtype=float)
    psi_D = psi_arr[i_D]
    psi_A = psi_arr[i_A]
    psi_UU = psi_arr[i_UU]
    denom = psi_A - psi_UU
    uniform = np.abs(denom) < 1.0e-10
    psi_tilde_D = np.zeros(N + 1, dtype=float)
    np.divide(psi_D - psi_UU, denom, out=psi_tilde_D, where=~uniform)
    Co_f = np.abs(u_face) * dt / dx
    in_bounds = (psi_tilde_D >= 0.0) & (psi_tilde_D <= 1.0)
    psi_tilde_f = psi_tilde_D.copy()
    psi_tilde_f[in_bounds] = np.minimum(
        psi_tilde_D[in_bounds] / np.maximum(Co_f[in_bounds], 1.0e-10),
        1.0,
    )
    psi_unclipped = np.where(uniform, psi_D, psi_UU + psi_tilde_f * denom)
    psi_face = np.clip(psi_unclipped, 0.0, 1.0)
    return {
        'psi_face': psi_face,
        'psi_unclipped': psi_unclipped,
        'psi_D': psi_D,
        'psi_A': psi_A,
        'psi_UU': psi_UU,
        'i_D': i_D - ng,
        'i_A': i_A - ng,
        'i_UU': i_UU - ng,
        'psi_tilde_D': psi_tilde_D,
        'psi_tilde_f': psi_tilde_f,
        'Co_f': Co_f,
        'uniform': uniform,
        'in_bounds': in_bounds,
        'clipped': np.abs(psi_face - psi_unclipped) > 0.0,
    }


def thinc_face(psi_ext, u_face, dt, dx, n_ghost=2, beta=0.4):
    """Bounded THINC face reconstruction for 1-D VOF/alpha transport.

    The local bounds are taken from the upwind-upwind and acceptor cells,
    matching the algebraic THINC construction used by THINC-BVD VOF methods.
    This function is case-independent and returns bounded face values.
    """
    ng = n_ghost
    N = len(u_face) - 1
    f = np.arange(N + 1)
    pos = np.asarray(u_face) >= 0.0
    i_D = np.where(pos, ng + f - 1, ng + f)
    i_A = np.where(pos, ng + f, ng + f - 1)
    i_UU = np.where(pos, ng + f - 2, ng + f + 1)
    psi_arr = np.asarray(psi_ext, dtype=float)
    q_D = psi_arr[i_D]
    q_A = psi_arr[i_A]
    q_UU = psi_arr[i_UU]
    q_lo = np.minimum(q_UU, q_A)
    q_hi = np.maximum(q_UU, q_A)
    dq = q_hi - q_lo
    psi_face = q_D.copy()
    active = dq > 1.0e-12
    a = np.zeros(N + 1, dtype=float)
    np.divide(q_D - q_lo, dq, out=a, where=active)
    a = np.clip(a, 0.0, 1.0)
    q_thinc = q_lo + dq * (0.5 + 0.5 * np.tanh(float(beta) * (2.0 * a - 1.0)))
    # Smooth activation prevents THINC from altering nearly uniform regions.
    w = np.tanh(50.0 * dq)
    psi_face[active] = w[active] * q_thinc[active] + (1.0 - w[active]) * q_D[active]
    return np.clip(psi_face, 0.0, 1.0)


def thinc_face_components(psi_ext, u_face, dt, dx, n_ghost=2, beta=0.4):
    """Return THINC face values plus passive reconstruction components."""
    ng = n_ghost
    N = len(u_face) - 1
    f = np.arange(N + 1)
    pos = np.asarray(u_face) >= 0.0
    i_D = np.where(pos, ng + f - 1, ng + f)
    i_A = np.where(pos, ng + f, ng + f - 1)
    i_UU = np.where(pos, ng + f - 2, ng + f + 1)
    psi_arr = np.asarray(psi_ext, dtype=float)
    q_D = psi_arr[i_D]
    q_A = psi_arr[i_A]
    q_UU = psi_arr[i_UU]
    q_lo = np.minimum(q_UU, q_A)
    q_hi = np.maximum(q_UU, q_A)
    dq = q_hi - q_lo
    psi_unclipped = q_D.copy()
    active = dq > 1.0e-12
    a = np.zeros(N + 1, dtype=float)
    np.divide(q_D - q_lo, dq, out=a, where=active)
    a = np.clip(a, 0.0, 1.0)
    q_thinc = q_lo + dq * (0.5 + 0.5 * np.tanh(float(beta) * (2.0 * a - 1.0)))
    w = np.tanh(50.0 * dq)
    psi_unclipped[active] = w[active] * q_thinc[active] + (1.0 - w[active]) * q_D[active]
    psi_face = np.clip(psi_unclipped, 0.0, 1.0)
    return {
        'psi_face': psi_face,
        'psi_unclipped': psi_unclipped,
        'q_D': q_D,
        'q_A': q_A,
        'q_UU': q_UU,
        'q_lo': q_lo,
        'q_hi': q_hi,
        'dq': dq,
        'a': a,
        'q_thinc': q_thinc,
        'weight': w,
        'active': active,
        'beta': float(beta),
        'clipped': np.abs(psi_face - psi_unclipped) > 0.0,
    }


def cicsam_face_beta(psi_ext, u_face, dt, dx, n_ghost=2):
    """
    Compute CICSAM blending factor beta at each face.
    phi_face = (1 - beta) * phi_Donor + beta * phi_Acceptor

    Caller determines donor/acceptor from sign of u_face:
      u >= 0: donor=left, acceptor=right
      u <  0: donor=right, acceptor=left

    Returns beta : ndarray (N+1,)
    """
    ng = n_ghost
    N = len(u_face) - 1
    f_arr = np.arange(N + 1)
    pos = np.asarray(u_face) >= 0.0
    i_D_arr = np.where(pos, ng + f_arr - 1, ng + f_arr)
    i_A_arr = np.where(pos, ng + f_arr, ng + f_arr - 1)
    i_UU_arr = np.where(pos, ng + f_arr - 2, ng + f_arr + 1)
    psi_D_arr = psi_ext[i_D_arr]
    psi_A_arr = psi_ext[i_A_arr]
    psi_UU_arr = psi_ext[i_UU_arr]
    denom_da = psi_A_arr - psi_D_arr
    denom = psi_A_arr - psi_UU_arr
    active = (np.abs(denom_da) >= 1.0e-10) & (np.abs(denom) >= 1.0e-10)
    psi_tilde_D = np.zeros(N + 1, dtype=float)
    np.divide(psi_D_arr - psi_UU_arr, denom, out=psi_tilde_D, where=active)
    Co_f = np.abs(u_face) * dt / dx
    in_bounds = (psi_tilde_D >= 0.0) & (psi_tilde_D <= 1.0)
    psi_tilde_f = psi_tilde_D.copy()
    use_hyper = active & in_bounds
    psi_tilde_f[use_hyper] = np.minimum(
        psi_tilde_D[use_hyper] / np.maximum(Co_f[use_hyper], 1.0e-10),
        1.0,
    )
    psi_face_val = np.clip(psi_UU_arr + psi_tilde_f * denom, 0.0, 1.0)
    raw_beta = np.zeros(N + 1, dtype=float)
    np.divide(psi_face_val - psi_D_arr, denom_da, out=raw_beta, where=active)
    return np.clip(raw_beta, 0.0, 1.0)
    beta = np.zeros(N + 1)

    for f in range(N + 1):
        uf = u_face[f]

        if uf >= 0.0:
            i_D  = ng + f - 1   # donor (left)
            i_A  = ng + f       # acceptor (right)
            i_UU = ng + f - 2   # upupwind
        else:
            i_D  = ng + f       # donor (right)
            i_A  = ng + f - 1   # acceptor (left)
            i_UU = ng + f + 1   # upupwind

        psi_D  = psi_ext[i_D]
        psi_A  = psi_ext[i_A]
        psi_UU = psi_ext[i_UU]

        # If acceptor == donor, purely upwind → beta=0
        if abs(psi_A - psi_D) < 1e-10:
            beta[f] = 0.0
            continue

        # Compute the CICSAM face value using same Hyper-C logic
        denom = psi_A - psi_UU
        if abs(denom) < 1e-10:
            # Uniform region: upwind → phi_face = phi_D → beta=0
            beta[f] = 0.0
            continue

        psi_tilde_D = (psi_D - psi_UU) / denom
        Co_f = abs(uf) * dt / dx

        if 0.0 <= psi_tilde_D <= 1.0:
            psi_tilde_f = min(psi_tilde_D / max(Co_f, 1e-10), 1.0)
        else:
            psi_tilde_f = psi_tilde_D

        psi_face_val = psi_UU + psi_tilde_f * denom
        psi_face_val = float(np.clip(psi_face_val, 0.0, 1.0))

        # beta = (phi_face - phi_D) / (phi_A - phi_D)
        raw_beta = (psi_face_val - psi_D) / (psi_A - psi_D)
        beta[f] = float(np.clip(raw_beta, 0.0, 1.0))

    return beta


def cicsam_face_jacobian(psi_ext, u_face, dt, dx, n_ghost=2):
    """
    Compute CICSAM face values AND their exact Newton Jacobian.

    Returns Y_face and ∂Y_face/∂Y_{D,A,UU} for Newton linearization:
      Y_face(Y) ≈ Y_face(Y_k) + J_D·δY_D + J_A·δY_A + J_UU·δY_UU

    Returns
    -------
    psi_face : (N+1,) CICSAM face values
    jac_D, jac_A, jac_UU : (N+1,) Jacobian w.r.t. Donor, Acceptor, UpUpwind
    idx_D, idx_A, idx_UU : (N+1,) int — interior 0-based cell indices (periodic-wrapped)
    """
    ng = n_ghost
    N = len(u_face) - 1
    f = np.arange(N + 1)
    pos = np.asarray(u_face) >= 0.0
    i_D = np.where(pos, ng + f - 1, ng + f)
    i_A = np.where(pos, ng + f, ng + f - 1)
    i_UU = np.where(pos, ng + f - 2, ng + f + 1)
    idx_D = np.where(pos, f - 1, f)
    idx_A = np.where(pos, f, f - 1)
    idx_UU = np.where(pos, f - 2, f + 1)

    psi_arr = np.asarray(psi_ext, dtype=float)
    psi_D = psi_arr[i_D]
    psi_A = psi_arr[i_A]
    psi_UU = psi_arr[i_UU]
    denom = psi_A - psi_UU
    uniform = np.abs(denom) < 1.0e-10

    psi_face = psi_D.copy()
    jac_D = np.zeros(N + 1)
    jac_A = np.zeros(N + 1)
    jac_UU = np.zeros(N + 1)
    jac_D[uniform] = 1.0

    psi_tilde_D = np.zeros(N + 1, dtype=float)
    np.divide(psi_D - psi_UU, denom, out=psi_tilde_D, where=~uniform)
    Co_f = np.maximum(np.abs(u_face) * dt / dx, 1.0e-10)
    bounded = (~uniform) & (psi_tilde_D >= 0.0) & (psi_tilde_D <= 1.0)
    interp = bounded & ((psi_tilde_D / Co_f) <= 1.0)
    downwind = bounded & ~interp
    upwind = (~uniform) & ~bounded

    inv_Co = np.zeros(N + 1, dtype=float)
    np.divide(1.0, Co_f, out=inv_Co, where=interp)
    psi_face[interp] = psi_UU[interp] + (psi_D[interp] - psi_UU[interp]) * inv_Co[interp]
    jac_D[interp] = inv_Co[interp]
    jac_UU[interp] = 1.0 - inv_Co[interp]
    psi_face[downwind] = psi_A[downwind]
    jac_A[downwind] = 1.0
    jac_D[upwind] = 1.0

    psi_face = np.clip(psi_face, 0.0, 1.0)
    idx_D  = idx_D % N
    idx_A  = idx_A % N
    idx_UU = idx_UU % N

    return psi_face, jac_D, jac_A, jac_UU, idx_D, idx_A, idx_UU

"""Diagnostic-only material-interface acoustic transfer probe.

This module is intentionally not used by the validation driver or production
solver path.  It builds a small two-material acoustic packet case, runs the
existing denner_1d production entry point, and emits compact transfer metrics.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import time
from pathlib import Path

import numpy as np

from .config import PHASE_AIR, PHASE_WATER_LIQUID
from .eos.base import compute_mixture_props
from .main import run as denner_run


_FLUIDS = {
    "air": PHASE_AIR,
    "water": PHASE_WATER_LIQUID,
    "water_liquid": PHASE_WATER_LIQUID,
}


def _parse_fluids(text: str):
    parts = [p.strip().lower() for p in str(text).split(",") if p.strip()]
    if len(parts) != 2:
        raise ValueError("--fluids must contain exactly two names, e.g. air,water")
    missing = [p for p in parts if p not in _FLUIDS]
    if missing:
        raise ValueError(f"unsupported fluid(s): {','.join(missing)}")
    return parts, _FLUIDS[parts[0]], _FLUIDS[parts[1]]


def _phase_props(ph, p0: float, T0: float):
    one = np.array([1.0])
    props = compute_mixture_props(
        np.array([p0], dtype=float),
        np.array([0.0], dtype=float),
        np.array([T0], dtype=float),
        one,
        ph,
        ph,
    )
    rho = float(np.asarray(props["rho"])[0])
    c = float(np.asarray(props["c_mix"])[0])
    Z = rho * c
    if "H" in props:
        H = float(np.asarray(props["H"])[0])
    elif "h" in props:
        H = float(np.asarray(props["h"])[0])
    elif "rho_h" in props and rho > 0.0:
        H = float(np.asarray(props["rho_h"])[0]) / rho
    else:
        H = math.nan
    return {"rho": rho, "c": c, "Z": Z, "H": H}


def _safe_float(v):
    try:
        out = float(v)
    except Exception:
        return None
    if not math.isfinite(out):
        return None
    return out


def _acoustic_energy(p, u, Z, dx):
    p = np.asarray(p, dtype=float)
    u = np.asarray(u, dtype=float)
    Z = np.asarray(Z, dtype=float)
    finite = np.isfinite(p) & np.isfinite(u) & np.isfinite(Z) & (Z > 0.0)
    if not np.any(finite):
        return math.nan
    e = 0.5 * (p[finite] * p[finite] / Z[finite] + Z[finite] * u[finite] * u[finite])
    return float(np.sum(e) * dx)


def _energy_parts(p, u, Z, dx):
    p = np.asarray(p, dtype=float)
    u = np.asarray(u, dtype=float)
    Z = np.asarray(Z, dtype=float)
    finite = np.isfinite(p) & np.isfinite(u) & np.isfinite(Z) & (Z > 0.0)
    if not np.any(finite):
        return math.nan, math.nan
    ep = 0.5 * np.sum(p[finite] * p[finite] / Z[finite]) * dx
    eu = 0.5 * np.sum(Z[finite] * u[finite] * u[finite]) * dx
    return float(ep), float(eu)


def _highk_fraction(q):
    q = np.asarray(q, dtype=float)
    finite = np.isfinite(q)
    if q.size < 3 or not np.any(finite):
        return math.nan
    q = np.where(finite, q, 0.0)
    denom = float(np.sum(q * q))
    if denom <= 0.0:
        return 0.0
    d2 = q[:-2] - 2.0 * q[1:-1] + q[2:]
    return float(np.sum(d2 * d2) / denom)


def _same_sign_or_zero(a, b):
    if not math.isfinite(a) or not math.isfinite(b):
        return False
    if abs(a) <= 1.0e-300 or abs(b) <= 1.0e-300:
        return True
    return (a > 0.0) == (b > 0.0)


def _lambda_bound_interval(v0, dv, lo, hi):
    if not all(math.isfinite(x) for x in (v0, dv, lo, hi)):
        return 0.0, True
    if dv == 0.0:
        return 1.0, False
    if lo > hi:
        lo, hi = hi, lo
    bounds = []
    if dv > 0.0:
        bounds.append((hi - v0) / dv)
    else:
        bounds.append((lo - v0) / dv)
    lam = min(1.0, max(0.0, min(bounds)))
    return lam, lam < 1.0 - 1.0e-14


def _probe_coupled_relax_summary(p, u, x, left_mask, meta, incident_energy):
    """Probe-only bounded coupled ACID/RH bundle relaxation diagnostic."""
    enabled = (
        os.environ.get("DENNER_INTERFACE_TRANSFER_PROBE", "0") == "1"
        and os.environ.get("DENNER_PROBE_COUPLED_ACID_RH_RELAX", "0") == "1"
    )
    summary = {
        "probe_coupled_relax_active": False,
        "active_face_count": 0,
        "lambda_median": None,
        "lambda_max": None,
        "fallback_reasons": {},
        "post_violation_count": 0,
        "rhoh_defect_nonworse": None,
    }
    if not enabled:
        summary["fallback_reasons"] = {"disabled": 1}
        return summary
    p = np.asarray(p, dtype=float)
    u = np.asarray(u, dtype=float)
    x = np.asarray(x, dtype=float)
    if p.size != x.size or u.size != x.size or x.size < 2:
        summary["fallback_reasons"] = {"missing_final_state": 1}
        return summary

    face = int(np.searchsorted(x, float(meta["interface_x"])))
    face = min(max(face, 1), x.size - 1)
    iL = face - 1
    iR = face
    left_props = meta["left_props"]
    right_props = meta["right_props"]
    ZL = max(float(left_props["Z"]), 1.0e-300)
    ZR = max(float(right_props["Z"]), 1.0e-300)
    rhoL = float(left_props["rho"])
    rhoR = float(right_props["rho"])
    HL = float(left_props["H"])
    HR = float(right_props["H"])
    vals = [p[iL], p[iR], u[iL], u[iR], ZL, ZR, rhoL, rhoR, HL, HR]
    if not all(math.isfinite(float(v)) for v in vals):
        summary["fallback_reasons"] = {"nonfinite_input": 1}
        return summary

    pL = float(p[iL])
    pR = float(p[iR])
    uL = float(u[iL])
    uR = float(u[iR])
    pface_prod = 0.5 * (pL + pR)
    theta_prod = 0.5 * (uL + uR)
    rho_prod = 0.5 * (rhoL + rhoR)
    H_prod = 0.5 * (HL + HR)
    rhoh_flux_prod = rho_prod * H_prod * theta_prod

    denom = ZL + ZR
    pface_full = (ZR * pL + ZL * pR + ZL * ZR * (uL - uR)) / denom
    theta_full = (pL - pR + ZL * uL + ZR * uR) / denom
    # The probe has no production ACID face thermodynamic carrier capture.
    # Keep the thermodynamic carrier unchanged and explicitly test that the
    # coupled pressure/velocity relaxation does not worsen its flux consistency.
    rho_full = rho_prod
    H_full = H_prod
    rhoh_flux_full = rho_full * H_full * theta_full

    p_lo = min(pL, pR)
    p_hi = max(pL, pR)
    u_lo = min(uL, uR)
    u_hi = max(uL, uR)
    lam_p, p_limited = _lambda_bound_interval(
        pface_prod, pface_full - pface_prod, p_lo, p_hi)
    lam_u, u_limited = _lambda_bound_interval(
        theta_prod, theta_full - theta_prod, u_lo, u_hi)
    lam = min(1.0, lam_p, lam_u)
    mass_limited = False
    dtheta = theta_full - theta_prod
    if dtheta != 0.0:
        theta_try = theta_prod + lam * dtheta
        if not _same_sign_or_zero(theta_prod, theta_try):
            lam_zero = max(0.0, min(1.0, -theta_prod / dtheta))
            lam = min(lam, lam_zero)
            mass_limited = True

    p0 = float(meta["p0"])
    incident = max(float(incident_energy), 0.0) if math.isfinite(incident_energy) else math.nan

    def bundle_at(lam_value):
        pf = pface_prod + lam_value * (pface_full - pface_prod)
        th = theta_prod + lam_value * (theta_full - theta_prod)
        rr = rho_prod + lam_value * (rho_full - rho_prod)
        hh = H_prod + lam_value * (H_full - H_prod)
        rhof = rr * hh * th
        sink = abs((pf - p0) * th)
        rhoh_defect = rhof - rhoh_flux_full
        return pf, th, rr, hh, rhof, sink, rhoh_defect

    pf_rel, th_rel, rho_rel, H_rel, rhoh_rel, sink_rel, defect_rel = bundle_at(lam)
    _, _, _, _, _, sink_prod, defect_prod = bundle_at(0.0)
    _, _, _, _, _, sink_full, defect_full = bundle_at(1.0)
    energy_limited = False
    if math.isfinite(incident) and incident > 0.0 and sink_rel > incident:
        # Conservative bisection for max lambda satisfying the incident bound.
        lo = 0.0
        hi = lam
        for _ in range(40):
            mid = 0.5 * (lo + hi)
            if bundle_at(mid)[5] <= incident:
                lo = mid
            else:
                hi = mid
        lam = lo
        pf_rel, th_rel, rho_rel, H_rel, rhoh_rel, sink_rel, defect_rel = bundle_at(lam)
        energy_limited = True

    rhoh_nonworse = (
        math.isfinite(defect_rel)
        and math.isfinite(defect_prod)
        and abs(defect_rel) <= abs(defect_prod) + 1.0e-14
    )
    sink_nonworse = (
        math.isfinite(sink_rel)
        and math.isfinite(sink_prod)
        and sink_rel <= sink_prod + 1.0e-14
    )
    positive_ok = (
        math.isfinite(pf_rel) and pf_rel > 0.0
        and math.isfinite(rho_rel) and rho_rel > 0.0
        and math.isfinite(H_rel)
    )
    mass_ok = _same_sign_or_zero(theta_prod, th_rel)
    nonzero = (
        abs(pf_rel - pface_prod) + abs(th_rel - theta_prod)
        + abs(rhoh_rel - rhoh_flux_prod) > 1.0e-14
    )
    post_violation = not (rhoh_nonworse and sink_nonworse and positive_ok and mass_ok)
    active = bool(nonzero and not post_violation)

    reasons = {}
    if not nonzero:
        reasons["zero_candidate_delta"] = 1
    if not rhoh_nonworse:
        reasons["rhoh_defect_worse"] = reasons.get("rhoh_defect_worse", 0) + 1
    if not sink_nonworse:
        reasons["sink_worse"] = reasons.get("sink_worse", 0) + 1
    if not mass_ok:
        reasons["mass_sign_violation"] = reasons.get("mass_sign_violation", 0) + 1
    if not positive_ok:
        reasons["positivity_violation"] = reasons.get("positivity_violation", 0) + 1
    if not reasons and not active:
        reasons["inactive_unknown"] = 1

    summary.update({
        "probe_coupled_relax_active": active,
        "active_face_count": int(1 if active else 0),
        "lambda_median": _safe_float(lam),
        "lambda_max": _safe_float(lam),
        "fallback_reasons": reasons,
        "post_violation_count": int(1 if post_violation else 0),
        "rhoh_defect_nonworse": bool(rhoh_nonworse),
        "probe_coupled_relax_face": int(face),
        "probe_coupled_relax_lambda_pressure_limited": bool(p_limited),
        "probe_coupled_relax_lambda_velocity_limited": bool(u_limited),
        "probe_coupled_relax_lambda_energy_limited": bool(energy_limited),
        "probe_coupled_relax_lambda_mass_limited": bool(mass_limited),
        "probe_coupled_relax_pface_prod": _safe_float(pface_prod),
        "probe_coupled_relax_pface_full": _safe_float(pface_full),
        "probe_coupled_relax_pface_active": _safe_float(pf_rel),
        "probe_coupled_relax_theta_prod": _safe_float(theta_prod),
        "probe_coupled_relax_theta_full": _safe_float(theta_full),
        "probe_coupled_relax_theta_active": _safe_float(th_rel),
        "probe_coupled_relax_rhoh_defect_prod": _safe_float(defect_prod),
        "probe_coupled_relax_rhoh_defect_full": _safe_float(defect_full),
        "probe_coupled_relax_rhoh_defect_active": _safe_float(defect_rel),
        "probe_coupled_relax_sink_prod": _safe_float(sink_prod),
        "probe_coupled_relax_sink_full": _safe_float(sink_full),
        "probe_coupled_relax_sink_active": _safe_float(sink_rel),
        "probe_coupled_relax_sink_nonworse": bool(sink_nonworse),
        "probe_coupled_relax_mass_sign_ok": bool(mass_ok),
        "probe_coupled_relax_positive_ok": bool(positive_ok),
    })
    return summary


def _emit_acid_term_equation_probe_row(p, u, x, meta):
    if not (
        os.environ.get("DENNER_ACID_TERM_EQUATION_AUDIT", "0") == "1"
        and os.environ.get("DENNER_INTERFACE_TRANSFER_PROBE", "0") == "1"
    ):
        return
    path_text = os.environ.get("DENNER_ACID_TERM_EQUATION_JSONL", "").strip()
    if not path_text:
        return
    p = np.asarray(p, dtype=float)
    u = np.asarray(u, dtype=float)
    x = np.asarray(x, dtype=float)
    missing = []
    if p.size != x.size or u.size != x.size or x.size < 2:
        missing.append("final_state")
    face = int(np.searchsorted(x, float(meta["interface_x"])))
    face = min(max(face, 1), max(x.size - 1, 1))
    iL = face - 1
    iR = face
    left_props = meta["left_props"]
    right_props = meta["right_props"]
    rhoL = float(left_props["rho"])
    rhoR = float(right_props["rho"])
    cL = float(left_props["c"])
    cR = float(right_props["c"])
    hL = float(left_props["H"])
    hR = float(right_props["H"])
    rho_paper = H_paper = c_paper = Z_paper = None
    theta_RH = pface_RH = None
    if not missing and all(math.isfinite(v) for v in (rhoL, rhoR, cL, cR, hL, hR)):
        ZL = max(rhoL * cL, 1.0e-300)
        ZR = max(rhoR * cR, 1.0e-300)
        rho_paper = rhoL * rhoR * (rhoL * cL + rhoR * cR) / (
            rhoL * rhoL * cL + rhoR * rhoR * cR + 1.0e-300)
        H_paper = 0.5 * (hL + hR)
        Z_paper = 0.5 * (ZL + ZR)
        c_paper = Z_paper / max(rho_paper, 1.0e-300)
        denom = ZL + ZR
        pface_RH = (
            ZR * float(p[iL]) + ZL * float(p[iR])
            + ZL * ZR * (float(u[iL]) - float(u[iR]))) / denom
        theta_RH = (
            float(p[iL]) - float(p[iR]) + ZL * float(u[iL])
            + ZR * float(u[iR])) / denom
    else:
        missing.append("phase_props")
    pface_prod = 0.5 * (float(p[iL]) + float(p[iR])) if not missing else None
    theta_prod = 0.5 * (float(u[iL]) + float(u[iR])) if not missing else None
    rho_prod = 0.5 * (rhoL + rhoR) if not missing else None
    H_prod = 0.5 * (hL + hR) if not missing else None
    c_prod = 0.5 * (cL + cR) if not missing else None
    Z_prod = rho_prod * c_prod if rho_prod is not None and c_prod is not None else None
    rhoh_flux_prod = (
        rho_prod * H_prod * theta_prod
        if rho_prod is not None and H_prod is not None and theta_prod is not None else None)
    rhoh_defect = (
        rhoh_flux_prod - rho_paper * H_paper * theta_prod
        if rhoh_flux_prod is not None and rho_paper is not None
        and H_paper is not None and theta_prod is not None else None)
    row = {
        "row_type": "acid_term_equation",
        "audit": "acid_term_equation",
        "acid_term_equation_audit_enabled": True,
        "step": None,
        "time": _safe_float(meta.get("t_end")) if isinstance(meta, dict) else None,
        "face": int(face),
        "face_class": "material",
        "mapping_status": (
            "supported_probe_proxy_mapping" if not missing
            else "probe_missing_terms"),
        "supported": not bool(missing),
        "missing_terms": sorted(set(missing)),
        "missing_fields": sorted(set(missing)),
        "sample_source": "interface_transfer_probe_final_state",
        "prod_face_source": "probe_arithmetic_final_adjacent_cells",
        "measured_remainder": False,
        "used_measured_remainder": False,
        "rho_paper": _safe_float(rho_paper),
        "rho_prod": _safe_float(rho_prod),
        "H_paper": _safe_float(H_paper),
        "H_prod": _safe_float(H_prod),
        "c_paper": _safe_float(c_paper),
        "c_prod": _safe_float(c_prod),
        "Z_paper": _safe_float(Z_paper),
        "Z_prod": _safe_float(Z_prod),
        "K_paper": None,
        "K_prod": None,
        "theta_paper_condition_defect": _safe_float(
            theta_prod - theta_RH
            if theta_prod is not None and theta_RH is not None else None),
        "pface_paper_condition_defect": _safe_float(
            pface_prod - pface_RH
            if pface_prod is not None and pface_RH is not None else None),
        "rhoh_flux_condition_defect": _safe_float(rhoh_defect),
        "mwi_condition_defect": None,
        "source_labels": {
            "rho_paper": "Denner_ACID_density_formula_from_probe_phase_rho_c",
            "H_paper": "proxy_arithmetic_phase_static_enthalpy_not_full_paper_term",
            "c_Z_paper": "proxy_two_impedance_average_Z_over_ACID_density",
            "rho_prod": "probe_arithmetic_phase_density",
            "theta_prod": "probe_arithmetic_final_adjacent_velocity",
            "pface_prod": "probe_arithmetic_final_adjacent_pressure",
        },
    }
    path = Path(path_text)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, sort_keys=True) + "\n")


def build_case(N: int, fluid_names=("air", "water")):
    names, ph_left, ph_right = _parse_fluids(",".join(fluid_names))
    N = int(N)
    if N < 24:
        raise ValueError("N must be at least 24 for the interface probe")

    x0, x1 = 0.0, 1.0
    dx = (x1 - x0) / N
    x = x0 + (np.arange(N, dtype=float) + 0.5) * dx
    interface_x = 0.5
    left = x < interface_x

    p0 = 1.0e5
    T0 = 300.0
    left_props = _phase_props(ph_left, p0, T0)
    right_props = _phase_props(ph_right, p0, T0)
    Z_left = max(left_props["Z"], 1.0e-300)

    psi = np.where(left, 1.0, 0.0)
    p = np.full(N, p0, dtype=float)
    T = np.full(N, T0, dtype=float)
    u = np.zeros(N, dtype=float)

    packet_center = 0.31
    packet_sigma = 0.045
    p_amp = 2.0e-4 * p0
    packet = p_amp * np.exp(-0.5 * ((x - packet_center) / packet_sigma) ** 2)
    packet *= left.astype(float)
    p += packet
    u += packet / Z_left

    distance_to_interface = max(interface_x - packet_center, 0.0)
    t_cross = distance_to_interface / max(left_props["c"], 1.0e-12)
    t_end = 1.7 * t_cross

    return {
        "ph1": ph_left,
        "ph2": ph_right,
        "x_cells": x,
        "psi_init": psi,
        "T_init": T,
        "u_init": u,
        "p_init": p,
        "t_end": t_end,
        "CFL": 0.35,
        "bc_left": "transmissive",
        "bc_right": "transmissive",
        "output_times": [t_end],
        "verbose": False,
        "variable_set": "puT",
        "vof_type": "volume",
        "use_K": True,
        "use_acid": True,
        "mwi_transient": True,
        "mwi_face_transient_correction": True,
        "_probe_meta": {
            "fluids": names,
            "interface_x": interface_x,
            "p0": p0,
            "T0": T0,
            "dx": dx,
            "packet_center": packet_center,
            "packet_sigma": packet_sigma,
            "p_amp": p_amp,
            "t_end": t_end,
            "left_props": left_props,
            "right_props": right_props,
            "initial_p": p.copy(),
            "initial_u": u.copy(),
            "initial_psi": psi.copy(),
        },
    }


def evaluate_probe(result, case_params, wall_seconds):
    meta = case_params["_probe_meta"]
    x = np.asarray(case_params["x_cells"], dtype=float)
    dx = float(meta["dx"])
    interface_x = float(meta["interface_x"])
    p0 = float(meta["p0"])
    left_mask = x < interface_x
    right_mask = ~left_mask

    final_state = result.get("final_state", {})
    p = np.asarray(final_state.get("p", []), dtype=float)
    u = np.asarray(final_state.get("u", []), dtype=float)
    psi = np.asarray(final_state.get("psi", case_params["psi_init"]), dtype=float)
    missing = []
    if p.size != x.size:
        missing.append("final_pressure")
    if u.size != x.size:
        missing.append("final_velocity")
    if psi.size != x.size:
        missing.append("final_psi")

    left_props = meta["left_props"]
    right_props = meta["right_props"]
    Z_init = np.where(left_mask, left_props["Z"], right_props["Z"])
    p_inc = np.asarray(meta["initial_p"], dtype=float) - p0
    u_inc = np.asarray(meta["initial_u"], dtype=float)
    incident_energy = _acoustic_energy(p_inc[left_mask], u_inc[left_mask], Z_init[left_mask], dx)

    if p.size == x.size and u.size == x.size:
        p_prime = p - p0
        u_prime = u
        Z_final = np.where(psi >= 0.5, left_props["Z"], right_props["Z"])
        reflected_energy = _acoustic_energy(
            p_prime[left_mask], u_prime[left_mask], Z_final[left_mask], dx)
        transmitted_energy = _acoustic_energy(
            p_prime[right_mask], u_prime[right_mask], Z_final[right_mask], dx)
        ep, eu = _energy_parts(p_prime, u_prime, Z_final, dx)
        ratio_arr = np.abs(p_prime) / np.maximum(np.abs(Z_final * u_prime), 1.0e-300)
        finite_ratio = np.isfinite(ratio_arr) & (np.abs(p_prime) > 1.0e-10)
        p_u_impedance_ratio_num = (
            float(np.median(ratio_arr[finite_ratio])) if np.any(finite_ratio) else math.nan)
        max_p = float(np.max(np.abs(p_prime))) if p_prime.size else math.nan
        max_u = float(np.max(np.abs(u_prime))) if u_prime.size else math.nan
        highk = _highk_fraction(p_prime)
    else:
        reflected_energy = transmitted_energy = math.nan
        ep = eu = math.nan
        p_u_impedance_ratio_num = math.nan
        max_p = max_u = math.nan
        highk = math.nan

    ZL = max(float(left_props["Z"]), 1.0e-300)
    ZR = max(float(right_props["Z"]), 1.0e-300)
    R = (ZR - ZL) / (ZR + ZL)
    energy_reflect_coeff = R * R
    energy_trans_coeff = 4.0 * ZL * ZR / ((ZL + ZR) * (ZL + ZR))
    reflected_ideal = incident_energy * energy_reflect_coeff
    transmitted_ideal = incident_energy * energy_trans_coeff
    out_energy = reflected_energy + transmitted_energy

    def rel_err(num, den):
        if not math.isfinite(num) or not math.isfinite(den) or abs(den) <= 0.0:
            return math.nan
        return (num - den) / den

    supported = (
        len(missing) == 0
        and math.isfinite(incident_energy)
        and incident_energy > 0.0
        and math.isfinite(reflected_energy)
        and math.isfinite(transmitted_energy)
    )
    initial_amp_p = max(float(meta["p_amp"]), 1.0e-300)
    initial_amp_u = initial_amp_p / ZL

    row = {
        "audit": "interface_transfer_probe",
        "N": int(x.size),
        "fluids": list(meta["fluids"]),
        "supported": bool(supported),
        "missing_fields": missing,
        "incident_energy": _safe_float(incident_energy),
        "reflected_energy_num": _safe_float(reflected_energy),
        "transmitted_energy_num": _safe_float(transmitted_energy),
        "reflected_energy_ideal": _safe_float(reflected_ideal),
        "transmitted_energy_ideal": _safe_float(transmitted_ideal),
        "energy_closure_ratio": _safe_float(out_energy / incident_energy)
        if math.isfinite(out_energy) and incident_energy > 0.0 else None,
        "reflection_ratio_error": _safe_float(rel_err(reflected_energy, reflected_ideal)),
        "transmission_ratio_error": _safe_float(rel_err(transmitted_energy, transmitted_ideal)),
        "p_u_impedance_ratio_num": _safe_float(p_u_impedance_ratio_num),
        "interface_sink_ratio": _safe_float(1.0 - out_energy / incident_energy)
        if math.isfinite(out_energy) and incident_energy > 0.0 else None,
        "max_p_overshoot": _safe_float(max(0.0, max_p / initial_amp_p - 1.0))
        if math.isfinite(max_p) else None,
        "max_u_overshoot": _safe_float(max(0.0, max_u / initial_amp_u - 1.0))
        if math.isfinite(max_u) else None,
        "E_pressure_final": _safe_float(ep),
        "E_velocity_final": _safe_float(eu),
        "highk_pressure_fraction": _safe_float(highk),
        "runtime_wall_seconds": _safe_float(wall_seconds),
        "t_end": _safe_float(case_params["t_end"]),
        "interface_x": _safe_float(interface_x),
        "Z_left": _safe_float(ZL),
        "Z_right": _safe_float(ZR),
        "c_left": _safe_float(left_props["c"]),
        "c_right": _safe_float(right_props["c"]),
        "ideal_energy_reflection_coeff": _safe_float(energy_reflect_coeff),
        "ideal_energy_transmission_coeff": _safe_float(energy_trans_coeff),
        "measured_remainder": False,
        "diagnostic_only": True,
    }
    row.update(_probe_coupled_relax_summary(
        p, u, x, left_mask, meta, incident_energy))
    _emit_acid_term_equation_probe_row(p, u, x, meta)
    return row


def run_probe(N: int, fluids: str):
    fluid_names, _, _ = _parse_fluids(fluids)
    case_params = build_case(N, fluid_names)
    t0 = time.perf_counter()
    result = denner_run(case_params)
    wall = time.perf_counter() - t0
    return evaluate_probe(result, case_params, wall)


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Diagnostic-only Denner material-interface acoustic transfer probe")
    parser.add_argument("--N", type=int, default=100)
    parser.add_argument("--fluids", default="air,water")
    parser.add_argument("--json-out", default="")
    args = parser.parse_args(argv)

    row = run_probe(args.N, args.fluids)
    text = json.dumps(row, sort_keys=True)
    print(text)
    if args.json_out:
        path = Path(args.json_out)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

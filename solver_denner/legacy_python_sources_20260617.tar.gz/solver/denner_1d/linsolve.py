"""Specialized linear solvers for 1D Denner systems."""

from __future__ import annotations

import numpy as np
import scipy.sparse as sp

try:  # pragma: no cover - optional acceleration
    import numba as nb

    _NUMBA_AVAILABLE = True
except Exception:  # pragma: no cover
    nb = None
    _NUMBA_AVAILABLE = False


def variable_major_to_cell_major(x, n_blocks=3):
    x = np.asarray(x, dtype=float)
    n = x.size // n_blocks
    return np.ascontiguousarray(x.reshape(n_blocks, n).T.reshape(n * n_blocks))


def cell_major_to_variable_major(x, n_blocks=3):
    x = np.asarray(x, dtype=float)
    n = x.size // n_blocks
    return np.ascontiguousarray(x.reshape(n, n_blocks).T.reshape(n * n_blocks))


def _extract_block_tridiagonal(A, n):
    """Extract 3x3 lower/diag/upper blocks from a variable-major 3N matrix."""
    A_csr = A.tocsr() if sp.issparse(A) else sp.csr_matrix(A)
    lower = np.zeros((n - 1, 3, 3), dtype=float)
    diag = np.zeros((n, 3, 3), dtype=float)
    upper = np.zeros((n - 1, 3, 3), dtype=float)
    coo = A_csr.tocoo()
    for r, c, v in zip(coo.row, coo.col, coo.data):
        r_block = int(r // n)
        r_cell = int(r - r_block * n)
        c_block = int(c // n)
        c_cell = int(c - c_block * n)
        dc = c_cell - r_cell
        if dc == 0:
            diag[r_cell, r_block, c_block] += float(v)
        elif dc == -1:
            lower[c_cell, r_block, c_block] += float(v)
        elif dc == 1:
            upper[r_cell, r_block, c_block] += float(v)
        elif v != 0.0:
            raise ValueError("matrix is not 3x3 block tridiagonal by cell")
    return lower, diag, upper


if _NUMBA_AVAILABLE:

    @nb.njit(cache=True, nogil=True)
    def _blocks_from_triplets_numba(rows, cols, vals, n):
        lower = np.zeros((max(n - 1, 0), 3, 3), dtype=np.float64)
        diag = np.zeros((n, 3, 3), dtype=np.float64)
        upper = np.zeros((max(n - 1, 0), 3, 3), dtype=np.float64)
        ok = True
        for k in range(vals.size):
            v = vals[k]
            if v == 0.0:
                continue
            r = rows[k]
            c = cols[k]
            r_block = r // n
            r_cell = r - r_block * n
            c_block = c // n
            c_cell = c - c_block * n
            dc = c_cell - r_cell
            if dc == 0:
                diag[r_cell, r_block, c_block] += v
            elif dc == -1:
                lower[c_cell, r_block, c_block] += v
            elif dc == 1:
                upper[r_cell, r_block, c_block] += v
            else:
                ok = False
        return lower, diag, upper, ok

    @nb.njit(cache=True, nogil=True)
    def _extract_block_tridiagonal_csr_numba(indptr, indices, data, n):
        lower = np.zeros((max(n - 1, 0), 3, 3), dtype=np.float64)
        diag = np.zeros((n, 3, 3), dtype=np.float64)
        upper = np.zeros((max(n - 1, 0), 3, 3), dtype=np.float64)
        ok = True
        for r in range(3 * n):
            r_block = r // n
            r_cell = r - r_block * n
            for kk in range(indptr[r], indptr[r + 1]):
                c = indices[kk]
                v = data[kk]
                if v == 0.0:
                    continue
                c_block = c // n
                c_cell = c - c_block * n
                dc = c_cell - r_cell
                if dc == 0:
                    diag[r_cell, r_block, c_block] += v
                elif dc == -1:
                    lower[c_cell, r_block, c_block] += v
                elif dc == 1:
                    upper[r_cell, r_block, c_block] += v
                else:
                    ok = False
        return lower, diag, upper, ok

else:
    _extract_block_tridiagonal_csr_numba = None
    _blocks_from_triplets_numba = None


def blocks_from_variable_major_triplets(rows, cols, vals, n, use_numba=True):
    """Build 3x3 block-tridiagonal arrays from variable-major COO triplets."""
    rows = np.asarray(rows, dtype=np.int64)
    cols = np.asarray(cols, dtype=np.int64)
    vals = np.asarray(vals, dtype=float)
    if use_numba and _blocks_from_triplets_numba is not None:
        lower, diag, upper, ok = _blocks_from_triplets_numba(rows, cols, vals, int(n))
        if not ok:
            raise ValueError("matrix is not 3x3 block tridiagonal by cell")
        return lower, diag, upper
    r_block = rows // n
    r_cell = rows - r_block * n
    c_block = cols // n
    c_cell = cols - c_block * n
    dc = c_cell - r_cell
    nz = vals != 0.0
    valid = ((dc == -1) | (dc == 0) | (dc == 1)) & nz
    if np.any(nz & ~valid):
        raise ValueError("matrix is not 3x3 block tridiagonal by cell")
    lower = np.zeros((max(n - 1, 0), 3, 3), dtype=float)
    diag = np.zeros((n, 3, 3), dtype=float)
    upper = np.zeros((max(n - 1, 0), 3, 3), dtype=float)
    m = valid & (dc == 0)
    if np.any(m):
        np.add.at(diag, (r_cell[m], r_block[m], c_block[m]), vals[m])
    m = valid & (dc == -1)
    if np.any(m):
        np.add.at(lower, (c_cell[m], r_block[m], c_block[m]), vals[m])
    m = valid & (dc == 1)
    if np.any(m):
        np.add.at(upper, (r_cell[m], r_block[m], c_block[m]), vals[m])
    return lower, diag, upper


def _extract_block_tridiagonal_fast(A, n, use_numba=True):
    cached = getattr(A, "_denner_block3n", None)
    if cached is not None:
        lower, diag, upper = cached
        if diag.shape[0] == n:
            return lower, diag, upper
    A_csr = A.tocsr() if sp.issparse(A) else sp.csr_matrix(A)
    if use_numba and _extract_block_tridiagonal_csr_numba is not None:
        lower, diag, upper, ok = _extract_block_tridiagonal_csr_numba(
            A_csr.indptr.astype(np.int64, copy=False),
            A_csr.indices.astype(np.int64, copy=False),
            A_csr.data.astype(np.float64, copy=False),
            int(n),
        )
        if not ok:
            raise ValueError("matrix is not 3x3 block tridiagonal by cell")
        return lower, diag, upper
    return _extract_block_tridiagonal(A_csr, n)


def _block_thomas_numpy(lower, diag, upper, rhs):
    n = diag.shape[0]
    cprime = np.zeros((max(n - 1, 0), 3, 3), dtype=float)
    dprime = np.zeros((n, 3), dtype=float)
    inv0 = np.linalg.inv(diag[0])
    if n > 1:
        cprime[0] = inv0 @ upper[0]
    dprime[0] = inv0 @ rhs[0]
    for i in range(1, n):
        mat = diag[i] - lower[i - 1] @ cprime[i - 1]
        inv = np.linalg.inv(mat)
        if i < n - 1:
            cprime[i] = inv @ upper[i]
        dprime[i] = inv @ (rhs[i] - lower[i - 1] @ dprime[i - 1])
    x = np.empty((n, 3), dtype=float)
    x[n - 1] = dprime[n - 1]
    for i in range(n - 2, -1, -1):
        x[i] = dprime[i] - cprime[i] @ x[i + 1]
    return x


if _NUMBA_AVAILABLE:

    @nb.njit(cache=True, nogil=True)
    def _solve3(A, b):
        a00 = A[0, 0]; a01 = A[0, 1]; a02 = A[0, 2]
        a10 = A[1, 0]; a11 = A[1, 1]; a12 = A[1, 2]
        a20 = A[2, 0]; a21 = A[2, 1]; a22 = A[2, 2]
        det = (
            a00 * (a11 * a22 - a12 * a21)
            - a01 * (a10 * a22 - a12 * a20)
            + a02 * (a10 * a21 - a11 * a20)
        )
        if abs(det) < 1.0e-300:
            det = 1.0e-300 if det >= 0.0 else -1.0e-300
        inv = np.empty((3, 3), dtype=np.float64)
        inv[0, 0] = (a11 * a22 - a12 * a21) / det
        inv[0, 1] = (a02 * a21 - a01 * a22) / det
        inv[0, 2] = (a01 * a12 - a02 * a11) / det
        inv[1, 0] = (a12 * a20 - a10 * a22) / det
        inv[1, 1] = (a00 * a22 - a02 * a20) / det
        inv[1, 2] = (a02 * a10 - a00 * a12) / det
        inv[2, 0] = (a10 * a21 - a11 * a20) / det
        inv[2, 1] = (a01 * a20 - a00 * a21) / det
        inv[2, 2] = (a00 * a11 - a01 * a10) / det
        out = np.empty(3, dtype=np.float64)
        for i in range(3):
            out[i] = inv[i, 0] * b[0] + inv[i, 1] * b[1] + inv[i, 2] * b[2]
        return out, inv

    @nb.njit(cache=True, nogil=True)
    def _matmul3(A, B):
        out = np.zeros((3, 3), dtype=np.float64)
        for i in range(3):
            for j in range(3):
                s = 0.0
                for k in range(3):
                    s += A[i, k] * B[k, j]
                out[i, j] = s
        return out

    @nb.njit(cache=True, nogil=True)
    def _matvec3(A, x):
        out = np.empty(3, dtype=np.float64)
        for i in range(3):
            out[i] = A[i, 0] * x[0] + A[i, 1] * x[1] + A[i, 2] * x[2]
        return out

    @nb.njit(cache=True, nogil=True)
    def _block_thomas_numba(lower, diag, upper, rhs):
        n = diag.shape[0]
        cprime = np.zeros((max(n - 1, 0), 3, 3), dtype=np.float64)
        dprime = np.zeros((n, 3), dtype=np.float64)
        if n > 1:
            _, inv0 = _solve3(diag[0], rhs[0])
            cprime[0] = _matmul3(inv0, upper[0])
            dprime[0] = _matvec3(inv0, rhs[0])
        else:
            dprime[0], _ = _solve3(diag[0], rhs[0])
        for i in range(1, n):
            mat = diag[i] - _matmul3(lower[i - 1], cprime[i - 1])
            rhs_i = rhs[i] - _matvec3(lower[i - 1], dprime[i - 1])
            sol, inv = _solve3(mat, rhs_i)
            if i < n - 1:
                cprime[i] = _matmul3(inv, upper[i])
            dprime[i] = sol
        x = np.empty((n, 3), dtype=np.float64)
        x[n - 1] = dprime[n - 1]
        for ii in range(n - 1):
            i = n - 2 - ii
            x[i] = dprime[i] - _matvec3(cprime[i], x[i + 1])
        return x

else:
    _block_thomas_numba = None


def solve_block_tridiagonal_3n(A, b, use_numba=True):
    """Solve a variable-major 3N block-tridiagonal system.

    Raises ValueError when the sparse pattern is not cell-neighbor
    block-tridiagonal; callers should then fall back to the generic solver.
    """
    b = np.asarray(b, dtype=float)
    if b.size % 3 != 0:
        raise ValueError("3N block solver requires vector length divisible by 3")
    n = b.size // 3
    lower, diag, upper = _extract_block_tridiagonal_fast(A, n, use_numba=use_numba)
    rhs = b.reshape(3, n).T.copy()
    if use_numba and _block_thomas_numba is not None:
        x_cell = _block_thomas_numba(lower, diag, upper, rhs)
    else:
        x_cell = _block_thomas_numpy(lower, diag, upper, rhs)
    return x_cell.T.reshape(3 * n)

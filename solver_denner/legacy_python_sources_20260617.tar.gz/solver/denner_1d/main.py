# solver_denner/solver/denner_1d/main.py
# Ref: DENNER_SCHEME.md — Mode A, Phase 1a
#
# Entry point for the denner_1d implicit CFD solver.

import os
import json
import time

import numpy as np

from .eos.base import (
    compute_mixture_props,
    _constant_density_temperature,
    _stiff_liquid_reference_density,
)
from .eos.eos_class import create_eos
from .boundary import apply_ghost, apply_ghost_velocity
from .timestepping import compute_dt, compute_dt_acoustic
from .eos.base import compute_specific_total_enthalpy
from .solver_a import step as mode_a_step
from . import solver_a as _solver_a
from .assembly import reset_profile as _reset_assembly_profile
from .assembly import get_profile as _get_assembly_profile
from .io_utils import make_snapshot, save_snapshots_npz, print_step_info


def _temperature_from_density_pressure(p, rho, ph, T_guess):
    """Invert NASG-form density at fixed pressure.

    The 04-B acoustic validation is a single-material SG/ideal-gas wave, so
    this closed form is exact for the EOS family used by denner_1d.  A small
    Newton fallback is kept for EOS objects that do not expose NASG dict keys.
    """
    p = np.asarray(p, dtype=float)
    rho = np.asarray(rho, dtype=float)
    if isinstance(ph, dict) and {'gamma', 'pinf', 'b', 'kv'} <= set(ph.keys()):
        g = float(ph['gamma'])
        pinf = float(ph.get('pinf', 0.0))
        b = float(ph.get('b', 0.0))
        kv = float(ph['kv'])
        return ((p + pinf) / np.maximum(rho, 1e-300) - b * (p + pinf)) / (
            kv * (g - 1.0) + 1e-300)

    eos = create_eos(ph)
    T = np.asarray(T_guess, dtype=float).copy()
    for _ in range(12):
        r = eos.rho(p, T)
        drdT = eos.drho_dT(p, T)
        T = np.maximum(T - (r - rho) / (drdT + 1e-300), 1.0)
    return T


def _common_density_equivalent_temperature_from_moment(p, T_moment, psi, ph1, ph2):
    """Convert volume-weighted phase-temperature input to density-equivalent T.

    Several shared 1D air-water validation specifications define initial
    states from phase densities and then pass a single scalar temperature to
    the four-equation Denner path.  For stiff-liquid mixtures this scalar is a
    volume-weighted phase-temperature moment, not the common-temperature value
    whose direct EOS evaluation preserves the intended mixture density.  The
    solver's primitive T is kept as the density-equivalent scalar; the EOS
    layer reconstructs stiff-liquid/gas phase thermodynamics from it.
    """
    p = np.asarray(p, dtype=float)
    T_moment = np.asarray(T_moment, dtype=float)
    psi = np.asarray(psi, dtype=float)
    phases = [ph1, ph2]
    rho_ref = [_stiff_liquid_reference_density(ph) for ph in phases]
    stiff_ids = [k for k, rr in enumerate(rho_ref) if rr is not None]
    if len(stiff_ids) != 1:
        return T_moment

    ks = stiff_ids[0]
    kg = 1 - ks
    psi_full = [psi, 1.0 - psi]
    psi_s = np.clip(psi_full[ks], 0.0, 1.0)
    psi_g = np.clip(psi_full[kg], 0.0, 1.0)
    active = (psi_s > 1.0e-3) & (psi_g > 1.0e-3)
    if not np.any(active):
        return T_moment

    eos1 = create_eos(ph1)
    eos2 = create_eos(ph2)
    eos = [eos1, eos2]
    rho_common0 = psi * eos1.rho(p, T_moment) + (1.0 - psi) * eos2.rho(p, T_moment)

    T_s = _constant_density_temperature(p, rho_ref[ks], phases[ks], T_moment)
    T_g = (T_moment - psi_s * T_s) / (psi_g + 1.0e-300)
    admissible = active & np.isfinite(T_g) & (T_g > 1.0e-9)
    if not np.any(admissible):
        return T_moment

    rho_target = rho_common0.copy()
    rho_target[admissible] = (
        psi_s[admissible] * float(rho_ref[ks])
        + psi_g[admissible] * eos[kg].rho(p[admissible], T_g[admissible])
    )

    T_low = np.full_like(T_moment, 1.0e-6)
    T_high = np.maximum(T_moment, 1.0)
    for _ in range(40):
        rho_high = psi * eos1.rho(p, T_high) + (1.0 - psi) * eos2.rho(p, T_high)
        need_higher = admissible & (rho_high > rho_target)
        if not np.any(need_higher):
            break
        T_high = np.where(need_higher, 2.0 * T_high, T_high)

    T_eq = T_moment.copy()
    lo = T_low.copy()
    hi = T_high.copy()
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        rho_mid = psi * eos1.rho(p, mid) + (1.0 - psi) * eos2.rho(p, mid)
        # rho decreases monotonically with T for the NASG/SG phases here.
        lo = np.where(admissible & (rho_mid > rho_target), mid, lo)
        hi = np.where(admissible & (rho_mid <= rho_target), mid, hi)
    T_eq = np.where(admissible, 0.5 * (lo + hi), T_eq)
    return np.where(admissible, T_eq, T_moment)


STEP_ACCEPT_AUDIT = None


def _finite_stats(arr):
    a = np.asarray(arr, dtype=float)
    if a.size == 0:
        return {
            'min': None,
            'max': None,
            'argmax': -1,
        }
    finite = np.isfinite(a)
    if not np.any(finite):
        return {
            'min': None,
            'max': None,
            'argmax': -1,
        }
    a_f = a[finite]
    idxs = np.flatnonzero(finite)
    jmax = int(np.argmax(a_f))
    return {
        'min': float(np.min(a_f)),
        'max': float(np.max(a_f)),
        'argmax': int(idxs[jmax]),
    }


def _finite_argmin_with_value(values):
    a = np.asarray(values, dtype=float)
    finite = np.isfinite(a)
    if a.size == 0 or not np.any(finite):
        return 0.0, -1
    a_f = a[finite]
    idxs = np.flatnonzero(finite)
    j = int(np.argmin(a_f))
    return float(a_f[j]), int(idxs[j])


def _finite_argmax_with_value(values):
    a = np.asarray(values, dtype=float)
    finite = np.isfinite(a)
    if a.size == 0 or not np.any(finite):
        return 0.0, -1
    a_f = a[finite]
    idxs = np.flatnonzero(finite)
    j = int(np.argmax(a_f))
    return float(a_f[j]), int(idxs[j])


def _cell_face_coords(x_cells):
    x = np.asarray(x_cells, dtype=float)
    if x.size == 0:
        return np.array([])
    if x.size == 1:
        return np.array([x[0] - 0.5, x[0] + 0.5], dtype=float)
    dx = np.diff(x)
    x_face = np.empty(x.size + 1, dtype=float)
    x_face[1:-1] = 0.5 * (x[:-1] + x[1:])
    x_face[0] = x[0] - dx[0]
    x_face[-1] = x[-1] + dx[-1]
    return x_face


def _parse_bool_like(value, default=False):
    if value is None:
        return bool(default)
    if isinstance(value, bool):
        return bool(value)
    if isinstance(value, (int, float)):
        return bool(int(value))
    value_norm = str(value).strip().lower()
    if value_norm in {'1', 'true', 'yes', 'on'}:
        return True
    if value_norm in {'0', 'false', 'no', 'off'}:
        return False
    return bool(default)


def _append_packet_amplitude_jsonl(path, row):
    if not path:
        return
    with open(path, 'a', encoding='utf-8') as fh:
        fh.write(json.dumps(row) + "\n")


def _build_packet_amplitude_jsonl_row(
        step_num, t, dt, niter, p_now, u_now, p_ref, u_ref,
        x_cells, state, ph1, ph2):
    p = np.asarray(p_now, dtype=float)
    u = np.asarray(u_now, dtype=float)
    psi = np.asarray(state['psi'], dtype=float)
    p_delta = p - np.asarray(p_ref, dtype=float)
    u_delta = u - np.asarray(u_ref, dtype=float)
    p_pos_amp, p_pos_idx = _finite_argmax_with_value(p_delta)
    p_neg_amp, p_neg_idx = _finite_argmin_with_value(p_delta)
    u_pos_amp, u_pos_idx = _finite_argmax_with_value(u_delta)
    u_neg_amp, u_neg_idx = _finite_argmin_with_value(u_delta)
    p_abs_amp, p_abs_idx = _finite_argmax_with_value(np.abs(p_delta))
    u_abs_amp, u_abs_idx = _finite_argmax_with_value(np.abs(u_delta))

    psi_jump = np.abs(np.diff(psi)) if psi.size > 1 else np.array([])
    if psi_jump.size:
        iface_local = int(np.argmax(psi_jump))
        interface_face = iface_local + 1
        interface_dp = float(psi_jump[iface_local])
    else:
        interface_face = -1
        interface_dp = 0.0
        iface_local = -1
    x_face = _cell_face_coords(x_cells)
    x_interface = float(x_face[interface_face]) if x_face.size else 0.0

    if interface_face >= 0 and psi.size > 1:
        cL = int(np.clip(interface_face - 1, 0, psi.size - 1))
        cR = int(np.clip(interface_face, 0, psi.size - 1))
        psi_L = float(psi[cL]); psi_R = float(psi[cR])
        p_L = float(p[cL]); p_R = float(p[cR])
        u_L = float(u[cL]); u_R = float(u[cR])
    else:
        cL = 0
        cR = min(1, psi.size - 1) if psi.size > 1 else 0
        psi_L = float(psi[cL]) if psi.size else 0.0
        psi_R = float(psi[cR]) if psi.size else 0.0
        p_L = float(p[cL]) if p.size else 0.0
        p_R = float(p[cR]) if p.size else 0.0
        u_L = float(u[cL]) if u.size else 0.0
        u_R = float(u[cR]) if u.size else 0.0

    props = compute_mixture_props(
        p, state['u'], state['T'], np.clip(psi, 1.0e-12, 1.0 - 1.0e-12), ph1, ph2)
    rho = np.asarray(props.get('rho', np.zeros_like(p)), dtype=float)
    c_mix = np.asarray(props.get('c_mix', np.zeros_like(p)), dtype=float)
    Z = np.asarray(rho, dtype=float) * np.asarray(c_mix, dtype=float)
    ZL = float(Z[cL]) if Z.size > cL else 0.0
    ZR = float(Z[cR]) if Z.size > cR else 0.0
    Zeq = 2.0 * ZL * ZR / (ZL + ZR + 1.0e-300)

    if iface_local >= 0:
        start = max(0, iface_local - 1)
        stop = min(p.size, iface_local + 2)
    else:
        start = 0
        stop = p.size
    stencil = np.arange(start, max(stop, start + 1))
    if Z.size > 0 and stencil.size:
        zp = p[stencil] + Z[stencil] * u[stencil]
        zm = p[stencil] - Z[stencil] * u[stencil]
        max_abs_wplus = float(np.max(np.abs(zp))) if np.any(np.isfinite(zp)) else 0.0
        max_abs_wminus = float(np.max(np.abs(zm))) if np.any(np.isfinite(zm)) else 0.0
    else:
        max_abs_wplus = 0.0
        max_abs_wminus = 0.0

    mid = p.size // 2
    p_abs_left = 0.0
    p_abs_left_idx = -1
    p_abs_right = 0.0
    p_abs_right_idx = -1
    u_abs_left = 0.0
    u_abs_left_idx = -1
    u_abs_right = 0.0
    u_abs_right_idx = -1
    if p.size:
        p_abs_left = float(np.max(np.abs(p[:mid]))) if mid > 0 else 0.0
        p_abs_right = float(np.max(np.abs(p[mid:]))) if p.size - mid > 0 else 0.0
        if mid > 0:
            p_abs_left_idx = int(np.argmax(np.abs(p[:mid])))
        if p.size - mid > 0:
            p_abs_right_idx = int(mid + np.argmax(np.abs(p[mid:])))
        u_abs_left = float(np.max(np.abs(u[:mid]))) if mid > 0 else 0.0
        u_abs_right = float(np.max(np.abs(u[mid:]))) if p.size - mid > 0 else 0.0
        if mid > 0:
            u_abs_left_idx = int(np.argmax(np.abs(u[:mid])))
        if p.size - mid > 0:
            u_abs_right_idx = int(mid + np.argmax(np.abs(u[mid:])))

    return {
        'step': int(step_num),
        't': float(t),
        'dt': float(dt),
        'niter': int(niter),
        'p_pos_amp': p_pos_amp,
        'p_neg_amp': p_neg_amp,
        'p_abs_amp': p_abs_amp,
        'p_abs_idx': int(p_abs_idx),
        'p_pos_idx': int(p_pos_idx),
        'p_neg_idx': int(p_neg_idx),
        'u_pos_amp': u_pos_amp,
        'u_neg_amp': u_neg_amp,
        'u_abs_amp': u_abs_amp,
        'u_abs_idx': int(u_abs_idx),
        'u_pos_idx': int(u_pos_idx),
        'u_neg_idx': int(u_neg_idx),
        'interface_dp': float(interface_dp),
        'interface_face': int(interface_face),
        'x_face': float(x_interface),
        'psi_L': float(psi_L),
        'psi_R': float(psi_R),
        'p_L': float(p_L),
        'p_R': float(p_R),
        'u_L': float(u_L),
        'u_R': float(u_R),
        'Z_L': ZL,
        'Z_R': ZR,
        'Zeq': Zeq,
        'max_abs_p_plusZu': max_abs_wplus,
        'max_abs_p_minusZu': max_abs_wminus,
        'p_abs_left_half': p_abs_left,
        'p_abs_left_half_idx': int(p_abs_left_idx),
        'p_abs_right_half': p_abs_right,
        'p_abs_right_half_idx': int(p_abs_right_idx),
        'u_abs_left_half': u_abs_left,
        'u_abs_left_half_idx': int(u_abs_left_idx),
        'u_abs_right_half': u_abs_right,
        'u_abs_right_half_idx': int(u_abs_right_idx),
    }


def _interface_jump_proxy(arr, psi_arr, threshold=1.0e-8):
    v = np.asarray(arr, dtype=float)
    psi = np.asarray(psi_arr, dtype=float)
    if v.size < 2:
        return {
            'max_jump': 0.0,
            'face_idx': -1,
            'cell_idx': -1,
            'has_interface': False,
        }
    dv = np.abs(np.diff(v))
    if dv.size == 0:
        return {
            'max_jump': 0.0,
            'face_idx': -1,
            'cell_idx': -1,
            'has_interface': False,
        }
    psi_jump = np.abs(np.diff(psi)) if psi.size > 1 else None
    if psi_jump is not None and np.any(psi_jump > threshold):
        mask = psi_jump > threshold
        idxs = np.flatnonzero(mask)
        dv_mask = dv[mask]
        local = int(np.argmax(dv_mask))
        face_local = int(idxs[local])
        return {
            'max_jump': float(dv_mask[local]),
            'face_idx': int(face_local + 1),
            'cell_idx': int(face_local),
            'has_interface': True,
        }
    face_local = int(np.argmax(dv))
    return {
        'max_jump': float(dv[face_local]),
        'face_idx': int(face_local + 1),
        'cell_idx': int(face_local),
        'has_interface': False,
    }


def _accept_audit_summary_update(summary, before, after, interface_u_proxy):
    p_before = before['p']
    T_before = before['T']
    rho_before = before['rho']
    u_before = before['u']
    p_after = after['p']
    T_after = after['T']
    rho_after = after['rho']
    u_after = after['u']
    eps = 1.0e-300
    p_growth = float(np.max(np.abs(p_after - p_before) / (np.abs(p_before) + eps))) if p_before.size else 0.0
    T_growth = float(np.max(np.abs(T_after - T_before) / (np.abs(T_before) + eps))) if T_before.size else 0.0
    rho_growth = float(np.max(np.abs(rho_after - rho_before) / (np.abs(rho_before) + eps))) if rho_before.size else 0.0
    interface_u_growth = float(interface_u_proxy['after']['max_jump'] / (interface_u_proxy['before']['max_jump'] + eps)) if interface_u_proxy['before']['max_jump'] > 0.0 else float(interface_u_proxy['after']['max_jump'])
    summary['round25_steps'] += 1
    summary['round25_max_p_growth'] = max(summary['round25_max_p_growth'], p_growth)
    summary['round25_max_T_growth'] = max(summary['round25_max_T_growth'], T_growth)
    summary['round25_max_interface_u_growth'] = max(summary['round25_max_interface_u_growth'], interface_u_growth)
    summary['round25_rows'] = len(summary['steps'])


def _step_accept_trial_metrics(before_state, after_state):
    psi_before = np.asarray(before_state['psi'], dtype=float)
    psi_after = np.asarray(after_state['psi'], dtype=float)
    p_before = np.asarray(before_state['p'], dtype=float)
    p_after = np.asarray(after_state['p'], dtype=float)
    T_before = np.asarray(before_state['T'], dtype=float)
    T_after = np.asarray(after_state['T'], dtype=float)
    u_before = np.asarray(before_state['u'], dtype=float)
    u_after = np.asarray(after_state['u'], dtype=float)
    rho_before = np.asarray(before_state['rho'], dtype=float)
    rho_after = np.asarray(after_state['rho'], dtype=float)
    eps = 1.0e-300
    interface_u_before = _interface_jump_proxy(u_before, psi_before)
    interface_u_after = _interface_jump_proxy(u_after, psi_after)
    interface_p_before = _interface_jump_proxy(p_before, psi_before)
    interface_p_after = _interface_jump_proxy(p_after, psi_after)
    p_rel_growth = np.abs(p_after - p_before) / (np.abs(p_before) + eps)
    T_rel_growth = np.abs(T_after - T_before) / (np.abs(T_before) + eps)
    rho_rel_growth = np.abs(rho_after - rho_before) / (np.abs(rho_before) + eps)
    top_growth_arr = np.maximum(np.maximum(p_rel_growth, T_rel_growth), rho_rel_growth)
    top_growth_cell = int(np.argmax(top_growth_arr)) if top_growth_arr.size else -1
    if top_growth_cell >= 0:
        if p_rel_growth[top_growth_cell] >= T_rel_growth[top_growth_cell] and p_rel_growth[top_growth_cell] >= rho_rel_growth[top_growth_cell]:
            top_growth_component = 'p'
            top_growth_value = float(p_rel_growth[top_growth_cell])
        elif T_rel_growth[top_growth_cell] >= rho_rel_growth[top_growth_cell]:
            top_growth_component = 'T'
            top_growth_value = float(T_rel_growth[top_growth_cell])
        else:
            top_growth_component = 'rho'
            top_growth_value = float(rho_rel_growth[top_growth_cell])
    else:
        top_growth_component = None
        top_growth_value = 0.0
    return {
        'p_before': p_before,
        'p_after': p_after,
        'T_before': T_before,
        'T_after': T_after,
        'u_before': u_before,
        'u_after': u_after,
        'rho_before': rho_before,
        'rho_after': rho_after,
        'interface_u_before': interface_u_before,
        'interface_u_after': interface_u_after,
        'interface_p_before': interface_p_before,
        'interface_p_after': interface_p_after,
        'p_rel_growth': p_rel_growth,
        'T_rel_growth': T_rel_growth,
        'rho_rel_growth': rho_rel_growth,
        'top_growth_cell': top_growth_cell,
        'top_growth_component': top_growth_component,
        'top_growth_value': top_growth_value,
        'top_growth_face': int(top_growth_cell + 1) if top_growth_cell >= 0 else -1,
        'interface_p_jump_after': float(interface_p_after['max_jump']),
        'interface_u_jump_after': float(interface_u_after['max_jump']),
        'interface_p_jump_before': float(interface_p_before['max_jump']),
        'interface_u_jump_before': float(interface_u_before['max_jump']),
        'max_rel_p_growth': float(np.max(p_rel_growth)) if p_rel_growth.size else 0.0,
        'max_rel_T_growth': float(np.max(T_rel_growth)) if T_rel_growth.size else 0.0,
        'max_rel_rho_growth': float(np.max(rho_rel_growth)) if rho_rel_growth.size else 0.0,
        'bad_interface': bool(
            float(interface_p_after['max_jump']) > 1.0e7
            and float(interface_u_after['max_jump']) > 500.0
        ),
    }


def _bad_interface_proxy(state_trial, p_jump_thresh=1.0e7, u_jump_thresh=500.0):
    psi_trial = np.asarray(state_trial['psi'], dtype=float)
    p_trial = np.asarray(state_trial['p'], dtype=float)
    u_trial = np.asarray(state_trial['u'], dtype=float)
    interface_p_trial = _interface_jump_proxy(p_trial, psi_trial)
    interface_u_trial = _interface_jump_proxy(u_trial, psi_trial)
    bad = (
        float(interface_p_trial['max_jump']) > float(p_jump_thresh)
        and float(interface_u_trial['max_jump']) > float(u_jump_thresh)
    )
    return interface_p_trial, interface_u_trial, bad


def _round38_packet_diag_row(step_num, t_before, final_dt, dt_requested,
                             final_info, final_metrics, state, retry_used,
                             retry_stage):
    p_now = np.asarray(state['p'], dtype=float)
    u_now = np.asarray(state['u'], dtype=float)
    psi_now = np.asarray(state['psi'], dtype=float)
    p_stats = _finite_stats(p_now)
    u_abs = np.abs(u_now)
    psi_jump = np.abs(np.diff(psi_now)) if psi_now.size > 1 else np.array([])
    if u_abs.size:
        u_abs_cell = int(np.argmax(u_abs))
        u_abs_max = float(u_abs[u_abs_cell])
    else:
        u_abs_cell = -1
        u_abs_max = 0.0
    finite_p = np.isfinite(p_now)
    if np.any(finite_p):
        p_finite_idx = np.flatnonzero(finite_p)
        p_min_cell = int(p_finite_idx[int(np.argmin(p_now[finite_p]))])
    else:
        p_min_cell = -1
    if psi_jump.size:
        psi_jump_cell = int(np.argmax(psi_jump))
        psi_jump_max = float(psi_jump[psi_jump_cell])
        psi_jump_face = int(psi_jump_cell + 1)
    else:
        psi_jump_max = 0.0
        psi_jump_face = -1
    return {
        'step': int(step_num),
        't_before': float(t_before),
        't_after': float(t_before + final_dt),
        'dt': float(final_dt),
        'dt_requested': float(dt_requested),
        'accepted_dt_factor': float(final_dt / dt_requested) if dt_requested > 0.0 else 1.0,
        'retried': bool(retry_used),
        'retry_stage': int(retry_stage),
        'converged': bool(final_info.get('converged', False)),
        'outer_iters': int(final_info.get('outer_iters', 0)),
        'p_min': p_stats['min'],
        'p_min_cell': p_min_cell,
        'pressure_floor_active_count': int(np.count_nonzero(p_now <= 1.0 + 1.0e-12)),
        'u_abs_max': u_abs_max,
        'u_abs_cell': u_abs_cell,
        'psi_jump_max': psi_jump_max,
        'psi_jump_face': psi_jump_face,
        'interface_p_jump_before': float(final_metrics['interface_p_jump_before']),
        'interface_p_jump_after': float(final_metrics['interface_p_jump_after']),
        'interface_p_face_after': int(final_metrics['interface_p_after']['face_idx']),
        'interface_u_jump_before': float(final_metrics['interface_u_jump_before']),
        'interface_u_jump_after': float(final_metrics['interface_u_jump_after']),
        'interface_u_face_after': int(final_metrics['interface_u_after']['face_idx']),
        'top_growth_cell': int(final_metrics['top_growth_cell']),
        'top_growth_face': int(final_metrics['top_growth_face']),
        'top_growth_component': final_metrics['top_growth_component'],
        'top_growth_value': float(final_metrics['top_growth_value']),
        'max_rel_p_growth': float(final_metrics['max_rel_p_growth']),
        'max_rel_T_growth': float(final_metrics['max_rel_T_growth']),
        'max_rel_rho_growth': float(final_metrics['max_rel_rho_growth']),
    }

def run(case_params):
    """
    Run the denner_1d Mode A solver for a given case.

    Parameters
    ----------
    case_params : dict with keys:

        ph1, ph2         : dict   NASG EOS parameters for phase 1 and 2
        x_cells          : ndarray (N,)   cell-centre positions [m]
        psi_init         : ndarray (N,)   initial VOF field (alpha_1)
        T_init           : ndarray (N,)   initial temperature [K]
        u_init           : ndarray (N,)   initial velocity [m/s]
        p_init           : ndarray (N,)   initial pressure [Pa]
        t_end            : float          end time [s]
        CFL              : float          CFL number (default 0.5)
        bc_left          : str            left BC ('transmissive'|'periodic'|'wall')
        bc_right         : str            right BC
        output_times     : list or None   simulation times at which to save snapshots
        verbose          : bool           print per-step info (default True)
        dt_fixed         : float or None  override CFL-based dt
        max_picard_iter  : int            (default 20)
        picard_tol       : float          (default 1e-6)
        output_path      : str or None    path for .npz output (None = no file)

    Returns
    -------
    result : dict
        final_state  : dict   final solver state
        snapshots    : list   list of snapshot dicts (at output_times + final)
        t_history    : list   times at each step
        dt_history   : list   time steps used
    """
    # -----------------------------------------------------------------
    # Unpack parameters
    # -----------------------------------------------------------------
    x_cells  = np.asarray(case_params['x_cells'], dtype=float)
    psi_init = np.asarray(case_params['psi_init'], dtype=float)
    T_init   = np.asarray(case_params['T_init'],   dtype=float)
    u_init   = np.asarray(case_params['u_init'],   dtype=float)
    p_init   = np.asarray(case_params['p_init'],   dtype=float)

    ph1 = case_params['ph1']
    ph2 = case_params['ph2']
    # Activate the stiff-liquid split-temperature closure only for genuinely
    # mixed strong-pressure-jump states.  Uniform-pressure cavitation mixtures
    # remain on the common-T four-equation closure.
    psi_for_sensor = np.clip(psi_init, 0.0, 1.0)
    p_abs_sensor = np.maximum(np.abs(p_init), 1.0)
    mixed_cells = np.any((psi_for_sensor > 1.0e-3)
                         & (psi_for_sensor < 1.0 - 1.0e-3))
    strong_pressure_jump = (
        float(np.max(p_abs_sensor)) / max(float(np.min(p_abs_sensor)), 1.0)
        > 2.0
    )
    if mixed_cells and strong_pressure_jump:
        if isinstance(ph1, dict):
            ph1 = dict(ph1)
            ph1['enable_stiff_split'] = True
        if isinstance(ph2, dict):
            ph2 = dict(ph2)
            ph2['enable_stiff_split'] = True

    N  = len(x_cells)
    dx = float(x_cells[1] - x_cells[0]) if N > 1 else 1.0

    t_end    = float(case_params['t_end'])
    CFL      = float(case_params.get('CFL', 0.5))
    bc_l     = case_params.get('bc_left',  'transmissive')
    bc_r     = case_params.get('bc_right', 'transmissive')
    u_inlet  = case_params.get('u_inlet', None)
    p_inlet  = case_params.get('p_inlet', None)
    internal_bc_l = 'transmissive' if bc_l == 'inlet' else ('wall' if bc_l == 'reflective' else bc_l)
    internal_bc_r = 'transmissive' if bc_r == 'inlet' else ('wall' if bc_r == 'reflective' else bc_r)
    verbose  = bool(case_params.get('verbose', True))
    dt_fixed = case_params.get('dt_fixed', None)
    if dt_fixed is not None:
        dt_fixed = float(dt_fixed)

    output_times = case_params.get('output_times', [])
    if output_times is None:
        output_times = []
    output_times = sorted(set(float(t) for t in output_times))
    output_path  = case_params.get('output_path', None)

    cfg = {
        'cfl_type':   case_params.get('cfl_type', 'acoustic'),  # 'acoustic' or 'convective'
        'max_outer':  case_params.get('max_outer',  case_params.get('max_picard_iter', 5)),
        'max_inner':  case_params.get('max_inner',  10),
        'inner_tol':  case_params.get('inner_tol',  case_params.get('picard_tol', 1e-6)),
        'outer_tol':  case_params.get('outer_tol',  1e-6),
        'variable_set': case_params.get('variable_set', 'puT'),  # 'puh' or 'puT'
        'vof_type':     case_params.get('vof_type', 'volume'),  # 'volume' or 'mass'
        'use_K':        case_params.get('use_K', True),
        'use_compress': case_params.get('use_compress', False),
        'coupled':      case_params.get('coupled', False),
        'coupled_Ns':   case_params.get('coupled_Ns', False),
        'phases':       case_params.get('phases', None),  # list of EOS dicts/objects
        # legacy aliases kept for backward compat
        'max_picard_iter': case_params.get('max_picard_iter', 5),
        'picard_tol':      case_params.get('picard_tol',      1e-6),
        # Newton solver options
        'max_newton':    case_params.get('max_newton', 50),
        'newton_tol':    case_params.get('newton_tol', 1e-6),
        'newton_omega':  case_params.get('newton_omega', 1.0),
        'use_barotropic': case_params.get('use_barotropic', False),
        # Production validation uses second-order time integration after the
        # first startup step.  Older drivers passed bdf_order=1 as a legacy
        # default; do not let that silently downgrade the Denner path to
        # first-order Backward Euler.
        'bdf_order':     max(2, int(case_params.get('bdf_order', 2))),
        'mwi_rho_star':  case_params.get('mwi_rho_star', 'harmonic'),
        'alpha_face_velocity_mode': str(
            case_params.get(
                'alpha_face_velocity_mode',
                os.environ.get('DENNER_ALPHA_FACE_VELOCITY_MODE', 'current'))
        ).lower(),
        'tvd_limiter':   case_params.get('tvd_limiter', 'minmod'),
        'velocity_tvd_limiter': case_params.get(
            'velocity_tvd_limiter', 'vanalbada'),
        'scalar_tvd_limiter': case_params.get('scalar_tvd_limiter', None),
        'acoustic_limiter': case_params.get('acoustic_limiter', None),
        'acoustic_limiter_blend': case_params.get(
            'acoustic_limiter_blend', 1.0),
        # Enable the upper-bound-only contact density MOOD limiter by default.
        # It removes smooth material-contact density crests without clipping
        # same-material shock stencils or filling contact troughs.
        'density_mood_limiter': case_params.get('density_mood_limiter', True),
        'compressive_density_floor_limiter': case_params.get(
            'compressive_density_floor_limiter', True),
        'density_mood_theta': case_params.get('density_mood_theta', 1.0),
        'primitive_shock_mood_limiter': case_params.get(
            'primitive_shock_mood_limiter', True),
        'shock_pressure_mood_limiter': case_params.get(
            'shock_pressure_mood_limiter', True),
        'shock_velocity_mood_limiter': case_params.get(
            'shock_velocity_mood_limiter', True),
        'shock_plateau_envelope_mood_limiter': _parse_bool_like(
            case_params.get('shock_plateau_envelope_mood_limiter', None),
            _parse_bool_like(
                os.environ.get('DENNER_SHOCK_PLATEAU_ENVELOPE_MOOD', '0'),
                False)),
        'smooth_acoustic_entropy_projection': case_params.get(
            'smooth_acoustic_entropy_projection', True),
        'density_trough_mood_limiter': case_params.get(
            'density_trough_mood_limiter', True),
        'contact_density_plateau_mood_limiter': case_params.get(
            'contact_density_plateau_mood_limiter', True),
        'mixed_thermo_trough_mood_limiter': _parse_bool_like(
            case_params.get('mixed_thermo_trough_mood_limiter', None),
            _parse_bool_like(
                os.environ.get('DENNER_MIXED_THERMO_TROUGH_MOOD', '0'),
                False)),
        'mixed_pu_contact_mood_limiter': _parse_bool_like(
            case_params.get('mixed_pu_contact_mood_limiter', None),
            True),
        'mixed_pu_star_contact_mood_limiter': _parse_bool_like(
            case_params.get('mixed_pu_star_contact_mood_limiter', None),
            _parse_bool_like(
                os.environ.get('DENNER_MIXED_PU_STAR_CONTACT_MOOD', '0'),
                False)),
        'material_star_smooth_plateau_mood_limiter': _parse_bool_like(
            case_params.get('material_star_smooth_plateau_mood_limiter', None),
            _parse_bool_like(
                os.environ.get('DENNER_MATERIAL_STAR_SMOOTH_PLATEAU_MOOD', '0'),
                False)),
        'shock_hugoniot_density_limiter': case_params.get(
            'shock_hugoniot_density_limiter', True),
        'equilibrium_density_crest_limiter': case_params.get(
            'equilibrium_density_crest_limiter', True),
        'equilibrium_density_crest_rel': case_params.get(
            'equilibrium_density_crest_rel', 7.5e-3),
        'equilibrium_density_crest_pressure_rel': case_params.get(
            'equilibrium_density_crest_pressure_rel', 2.0e-2),
        'equilibrium_density_crest_velocity_rel': case_params.get(
            'equilibrium_density_crest_velocity_rel', 1.0e-2),
        'consistent_vof_face_flux': case_params.get(
            'consistent_vof_face_flux', True),
        'pressure_floor_velocity_regularization': case_params.get(
            'pressure_floor_velocity_regularization', True),
        'pressure_floor_plateau_mood_limiter': case_params.get(
            'pressure_floor_plateau_mood_limiter', True),
        'pressure_floor_mixed_mood_limiter': case_params.get(
            'pressure_floor_mixed_mood_limiter', True),
        'pressure_new_minimum_mood_limiter': case_params.get(
            'pressure_new_minimum_mood_limiter', True),
        'material_wave_recon_policy': _parse_bool_like(
            case_params.get('material_wave_recon_policy', None),
            _parse_bool_like(
                os.environ.get(
                    'DENNER_MATERIAL_WAVE_RECON_POLICY',
                    os.environ.get(
                        'DENNER_MATERIAL_INTERFACE_CHAR_RECON_BOUNDED',
                        '0')),
                True)),
        'mwi_transient': case_params.get('mwi_transient', True),
        'mwi_face_transient_correction': case_params.get(
            'mwi_face_transient_correction', True),
        'mwi_transient_current_rhostar':
            _parse_bool_like(
                case_params.get(
                    'mwi_transient_current_rhostar', None),
                _parse_bool_like(
                    os.environ.get(
                        'DENNER_MWI_TRANSIENT_CURRENT_RHOSTAR', '0'),
                    False)),
        'acoustic_face_correction': case_params.get('acoustic_face_correction', False),
        'use_jfnk':       case_params.get('use_jfnk', True),
        'max_gmres':      case_params.get('max_gmres', 100),
        'gmres_tol':      case_params.get('gmres_tol', 1e-3),
        'solver_mode':    case_params.get('solver_mode', 'delta'),
        'use_acid':       case_params.get('use_acid', True),
        'acid_temporal':  case_params.get('acid_temporal', False),
        'acid_temporal_colour': case_params.get('acid_temporal_colour', 'new'),
        'third_var':      case_params.get('third_var', 'h' if case_params.get('variable_set') == 'puh' else 'T'),
        'use_autograd':   case_params.get('use_autograd', False),
        # Legacy drivers still pass use_autograd=True to request the old
        # JFNK/autograd path, but the production Denner solver uses analytic
        # NASG/ideal-gas EOS derivatives by default for speed and repeatability.
        # Autograd derivative evaluation is now opt-in only through the explicit
        # use_autograd_derivatives flag.
        'use_autograd_derivatives': case_params.get(
            'use_autograd_derivatives', False),
        'verbose_newton': case_params.get('verbose_newton', False),
        # Boundary forcing is a physical source for acoustic validation cases.
        # Well-balanced pressure-equilibrium shortcuts must not suppress it.
        'has_forced_boundary': (
            (bc_l == 'inlet' and (u_inlet is not None or p_inlet is not None))
            or (bc_r == 'inlet')
        ),
    }
    # backward compat: phases 없으면 [ph1, ph2]로 설정
    if cfg['phases'] is None:
        cfg['phases'] = [ph1, ph2]

    max_iteration = case_params.get('max_iteration', None)

    # -----------------------------------------------------------------
    # Initialise state
    # -----------------------------------------------------------------
    if bc_l == 'inlet':
        if u_inlet is not None:
            u_init[0] = float(u_inlet(0.0))
        if p_inlet is not None:
            p_init[0] = float(p_inlet(0.0))
    p_ref = p_init.copy()
    u_ref = u_init.copy()

    psi = np.clip(psi_init, 0.0, 1.0)
    T_init = _common_density_equivalent_temperature_from_moment(
        p_init, T_init, psi, ph1, ph2)
    # Keep the stored conservative/thermodynamic state consistent with the
    # actual material indicator.  Clipping the initial density/enthalpy to
    # 0.01--0.99 while storing nearly pure psi (e.g. 1e-6/0.999999) creates
    # a non-zero residual in pressure-equilibrium contact tests.  CFL sound
    # speed regularisation below may still use clipped psi, but the state
    # itself must preserve the physical initial condition.
    props0 = compute_mixture_props(p_init, u_init, T_init, psi, ph1, ph2)

    def _dominant_inlet_phase(psi_val):
        return (ph1 if float(psi_val) >= 0.5 else ph2)

    def _isentropic_temperature_from_pressure(ph, p_ref, T_ref, p_new):
        """Complete a prescribed acoustic inlet state with isentropic T.

        A hard acoustic inlet that prescribes pressure and velocity must also
        impose a thermodynamically compatible density/temperature.  Leaving T
        at zero-gradient creates an isothermal density perturbation even when
        p/u satisfy the acoustic impedance relation.  For NASG/SG phases the
        isentrope is expressed by (p+pinf)*(v-b)^gamma = const; for unknown
        EOS dictionaries the linear acoustic density response is used.
        """
        p_ref = float(p_ref); T_ref = float(T_ref); p_new = float(p_new)
        if not (np.isfinite(p_ref) and np.isfinite(T_ref) and np.isfinite(p_new)):
            return T_ref
        if isinstance(ph, dict) and 'gamma' in ph and 'kv' in ph:
            gamma = float(ph.get('gamma', 1.4))
            pinf = float(ph.get('pinf', ph.get('p_inf', ph.get('Pi', 0.0))))
            b = float(ph.get('b', 0.0))
            kv = float(ph.get('kv', ph.get('cv', 1.0)))
            gm1 = gamma - 1.0
            if gamma > 1.0 and kv > 0.0 and p_ref + pinf > 0.0 and p_new + pinf > 0.0:
                A_ref = kv * T_ref * gm1 + b * (p_ref + pinf)
                rho_ref = (p_ref + pinf) / max(A_ref, 1.0e-300)
                v_ref = 1.0 / max(rho_ref, 1.0e-300)
                v_new = b + (v_ref - b) * ((p_ref + pinf) / (p_new + pinf)) ** (1.0 / gamma)
                rho_new = 1.0 / max(v_new, b + 1.0e-300)
                T_new = ((p_new + pinf) / max(rho_new, 1.0e-300) - b * (p_new + pinf)) / (kv * gm1)
                if np.isfinite(T_new) and T_new > 0.0:
                    return float(max(T_new, 1.0e-12))
        # Generic small-signal fallback: d rho = d p / c^2, then invert by
        # local EOS density derivative using the active phase dict.
        try:
            from .eos.base import compute_phase_props
            ref = compute_phase_props(np.array([p_ref]), np.array([T_ref]), ph)
            rho_ref = float(np.asarray(ref['rho'])[0])
            c_ref = float(np.asarray(ref['c'])[0])
            rho_target = max(rho_ref + (p_new - p_ref) / max(c_ref * c_ref, 1.0e-300), 1.0e-300)
            T_guess = T_ref
            for _ in range(8):
                pr = compute_phase_props(np.array([p_new]), np.array([T_guess]), ph)
                rho_cur = float(np.asarray(pr['rho'])[0])
                phi = float(np.asarray(pr['phi'])[0])
                if abs(phi) < 1.0e-300:
                    break
                T_guess -= (rho_cur - rho_target) / phi
                T_guess = max(T_guess, 1.0e-12)
            if np.isfinite(T_guess) and T_guess > 0.0:
                return float(T_guess)
        except Exception:
            pass
        return T_ref

    inlet_left_ref = None
    if bc_l == 'inlet' and p_inlet is not None:
        inlet_left_ref = {
            'p': float(p_init[0]),
            'T': float(T_init[0]),
            'psi': float(psi[0]),
            'phase': _dominant_inlet_phase(float(psi[0])),
        }

    def _apply_inlet_state(t_now):
        if bc_l == 'inlet':
            if u_inlet is not None:
                state['u'][0] = float(u_inlet(t_now))
            if p_inlet is not None:
                p_val = float(p_inlet(t_now))
                state['p'][0] = p_val
                if inlet_left_ref is not None:
                    state['T'][0] = _isentropic_temperature_from_pressure(
                        inlet_left_ref['phase'], inlet_left_ref['p'],
                        inlet_left_ref['T'], p_val)

    # Initial face velocity (arithmetic mean), n_ghost=2
    u_ext0 = apply_ghost_velocity(u_init, internal_bc_l, internal_bc_r, n_ghost=2)
    ng0 = 2
    u_face0 = np.array([0.5 * (u_ext0[ng0 + f - 1] + u_ext0[ng0 + f])
                         for f in range(N + 1)])

    h_init = compute_specific_total_enthalpy(p_init, u_init, T_init, psi, ph1, ph2)

    state = {
        'p':       p_init.copy(),
        'u':       u_init.copy(),
        'T':       T_init.copy(),
        'h':       h_init.copy(),
        'psi':     psi.copy(),
        'rho':     props0['rho'].copy(),
        'E_total': props0['E_total'].copy(),
        'u_face':  u_face0.copy(),
    }

    aux = {
        'is_first_step': True,
        'bdf_order':     1,
        'rho_nm1':       None,
        'rhoU_nm1':      None,
        'rhoh_nm1':      None,
        'p_nm1':         None,
        'E_nm1':         None,
        'rho_face_acid': None,
        'farfield_p_left': float(p_init[0]),
        'farfield_u_left': float(u_init[0]),
        'farfield_p_right': float(p_init[-1]),
        'farfield_u_right': float(u_init[-1]),
    }

    # -----------------------------------------------------------------
    # Main time loop
    # -----------------------------------------------------------------
    t           = 0.0
    step_num    = 0
    snapshots   = []
    t_history   = [t]
    dt_history  = []
    audit_enabled = bool(int(os.environ.get('DENNER_CASE07_AMP_AUDIT', '0') or '0'))
    profile_enabled = bool(int(os.environ.get('DENNER_PROFILE', '0') or '0'))
    profile = {
        'mode_a_step_calls': 0,
        'mode_a_step_wall': 0.0,
    }
    if profile_enabled:
        _reset_assembly_profile()
    round38_packet_diag_enabled = bool(int(os.environ.get('DENNER_R38_PACKET_DIAG', '0') or '0'))
    packet_amplitude_jsonl_path = os.environ.get('DENNER_PACKET_AMPLITUDE_JSONL', '').strip()
    if packet_amplitude_jsonl_path:
        with open(packet_amplitude_jsonl_path, 'w', encoding='utf-8') as fh:
            fh.write('')
    step_retry_experimental = bool(int(os.environ.get('DENNER_EXPERIMENTAL_STEP_RETRY', '0') or '0'))
    round38_packet_diag_topk = int(os.environ.get('DENNER_R38_DIAG_TOPK', '64') or '64')
    if round38_packet_diag_topk < 1:
        round38_packet_diag_topk = 1
    round40_face_compat_diag_enabled = bool(
        os.environ.get('DENNER_R40_FACE_COMPAT_DIAG', '0') == '1'
        or os.environ.get('DENNER_R40_MWI_COMPONENT_DIAG', '0') == '1'
    )
    round41_floor_diag_enabled = bool(
        os.environ.get('DENNER_R41_FLOOR_DIAG', '0') == '1'
    )
    round_postsolve_limiter_diag_enabled = bool(
        os.environ.get('DENNER_POSTSOLVE_LIMITER_DIAG', '0') == '1'
    )
    round_postsolve_limiter_diag_topk = int(
        os.environ.get('DENNER_POSTSOLVE_LIMITER_TOPK', '32') or '32'
    )
    if round_postsolve_limiter_diag_topk < 1:
        round_postsolve_limiter_diag_topk = 1
    round42_assembly_compat_diag_enabled = bool(
        os.environ.get('DENNER_R42_ASSEMBLY_COMPAT_DIAG', '0') == '1'
    )
    prod_flux_diag_enabled = bool(
        os.environ.get('DENNER_PROD_FLUX_DIAG', '0') == '1'
    )
    step_accept_audit_enabled = bool(
        int(os.environ.get('DENNER_STEP_ACCEPT_AUDIT', '0') or '0')
        or round38_packet_diag_enabled
    )
    audit_steps = [] if audit_enabled else None
    round38_packet_diag = {
        'enabled': True,
        'topk': int(round38_packet_diag_topk),
        'rows': [],
        'top_rows': [],
        'row_count': 0,
        'max_interface_p_jump': 0.0,
        'max_interface_u_jump': 0.0,
        'first_pressure_floor_step': None,
        'first_retry_step': None,
    } if round38_packet_diag_enabled else None
    round26_diag = {
        'round26_step_retries': 0,
        'round26_first_retry_step': None,
        'round26_max_bad_interface_p_jump': 0.0,
        'round26_max_bad_interface_u_jump': 0.0,
        'round27_retry1_count': 0,
        'round27_retry2_count': 0,
        'round27_min_dt_factor': 1.0,
        'round27_post_retry_bad_count': 0,
        'round27_total_retry_limit_hit': 0,
    }
    global STEP_ACCEPT_AUDIT
    STEP_ACCEPT_AUDIT = {
        'enabled': step_accept_audit_enabled,
        'steps': [],
        'round25_steps': 0,
        'round25_max_p_growth': 0.0,
        'round25_max_T_growth': 0.0,
        'round25_max_interface_u_growth': 0.0,
        'round25_rows': 0,
        **round26_diag,
    } if step_accept_audit_enabled else None
    if _solver_a is not None:
        _solver_a.reset_solver_a_diag()
        _solver_a.reset_solver_a_face_compat_diag()
        _solver_a.reset_solver_a_floor_diag()
        _solver_a.reset_solver_a_postsolve_limiter_diag()
        _solver_a.reset_solver_a_assembly_compat_diag()
    round40_face_compat_diag = (
        _solver_a.get_solver_a_face_compat_diag()
        if _solver_a is not None else {}
    )
    round41_floor_diag = (
        _solver_a.get_solver_a_floor_diag()
        if _solver_a is not None else {}
    )
    round_postsolve_limiter_diag = (
        _solver_a.get_solver_a_postsolve_limiter_diag()
        if _solver_a is not None else {}
    )
    round42_assembly_compat_diag = (
        _solver_a.get_solver_a_assembly_compat_diag()
        if _solver_a is not None else {}
    )

    # Save initial snapshot
    snapshots.append(make_snapshot(t, state, x_cells))
    next_output_idx = 0  # index into output_times list

    if verbose:
        print(f"[denner_1d] Starting simulation: N={N}, t_end={t_end}, "
              f"CFL={CFL}, bc=({bc_l},{bc_r})")
    step_progress_enabled = (
        os.environ.get('DENNER_STEP_PROGRESS', '0').lower()
        in ('1', 'true', 'yes', 'on')
    )
    try:
        step_progress_interval_sec = max(
            1.0, float(os.environ.get('DENNER_STEP_PROGRESS_INTERVAL_SEC', '30')))
    except Exception:
        step_progress_interval_sec = 30.0
    try:
        step_progress_interval_steps = max(
            1, int(os.environ.get('DENNER_STEP_PROGRESS_INTERVAL_STEPS', '100')))
    except Exception:
        step_progress_interval_steps = 100
    step_progress_t0 = time.monotonic()
    step_progress_last_emit = step_progress_t0

    # -----------------------------------------------------------------
    # Divergence thresholds
    # -----------------------------------------------------------------
    p0_ref    = float(np.mean(np.abs(case_params.get('p_init', [1e5]))))
    T0_ref    = float(np.mean(np.abs(case_params.get('T_init', [300.0]))))
    dt_init   = None          # set after first step
    diverged  = False
    diverge_reason = ''

    # Sound speed reference: c_ref = sqrt(gamma_eff * p0 / rho0)
    _gamma_eff = max(ph1.get('gamma', 1.4), ph2.get('gamma', 1.4))
    _rho0_ref  = float(np.mean(state['rho']))
    c0_ref     = float(np.sqrt(_gamma_eff * max(p0_ref, 1.0) / max(_rho0_ref, 1e-10)))

    # Velocity reference: use max(mean|u|, sound_speed) to handle u₀=0 (shock tube)
    _u0_raw   = float(np.mean(np.abs(case_params.get('u_init', [1.0]))))
    u0_ref    = max(_u0_raw, c0_ref) + 1e-6

    while t < t_end - 1e-14 * t_end and (max_iteration is None or step_num < max_iteration):
        # Compute dt
        if dt_fixed is not None:
            dt = dt_fixed
        elif cfg.get('cfl_type', 'acoustic') == 'convective':
            # Convective CFL: dt = CFL * dx / max|u|  (implicit solver, pure advection)
            dt = compute_dt(state['u'], dx, CFL)
        else:
            # Acoustic CFL: dt = CFL * dx / max(|u| + c)  (shock capturing, default)
            c_mix = compute_mixture_props(
                state['p'], state['u'], state['T'],
                np.clip(state['psi'], 1.0e-12, 1.0 - 1.0e-12), ph1, ph2)['c_mix']
            dt = compute_dt_acoustic(state['u'], c_mix, dx, CFL)

        # Don't overshoot t_end
        dt = min(dt, t_end - t)

        # Clamp to hit output_times, avoiding tiny steps from floating-point drift.
        # If remaining < 0.01*dt, skip the clamp (snapshot will be saved at the
        # next regular step by the t >= output_time - 1e-10 condition).
        if next_output_idx < len(output_times):
            remaining = output_times[next_output_idx] - t
            if remaining > 0.01 * dt:
                dt = min(dt, remaining)
        dt = max(dt, 1e-20)  # safety floor

        # Time step
        _apply_inlet_state(t)
        cfg_step = dict(cfg)
        cfg_step['step_index'] = step_num + 1

        if step_accept_audit_enabled:
            psi_before = np.asarray(state['psi'], dtype=float)
            p_before = np.asarray(state['p'], dtype=float)
            T_before = np.asarray(state['T'], dtype=float)
            u_before = np.asarray(state['u'], dtype=float)
            rho_before = np.asarray(state['rho'], dtype=float)
            p_stats_before = _finite_stats(p_before)
            T_stats_before = _finite_stats(T_before)
            rho_stats_before = _finite_stats(rho_before)
            u_stats_before = _finite_stats(u_before)
            interface_u_before = _interface_jump_proxy(u_before, psi_before)
            interface_p_before = _interface_jump_proxy(p_before, psi_before)

        if profile_enabled:
            _profile_t0 = time.perf_counter()
        trial_state, trial_aux, trial_info = mode_a_step(
            state, ph1, ph2, dx, dt, internal_bc_l, internal_bc_r, aux, cfg_step)
        if profile_enabled:
            profile['mode_a_step_calls'] += 1
            profile['mode_a_step_wall'] += time.perf_counter() - _profile_t0

        retry_used = False
        retry_stage = 0
        step_retry_count = 0
        final_dt = dt
        final_state = trial_state
        final_aux = trial_aux
        final_info = trial_info
        trial_metrics = None
        retry_metrics = None

        if step_accept_audit_enabled:
            trial_metrics = _step_accept_trial_metrics(state, trial_state)
            trial_bad = trial_metrics['bad_interface']
        else:
            _, _, trial_bad = _bad_interface_proxy(trial_state, 1.0e7, 500.0)

        if trial_bad and step_retry_experimental:
            retry_used = True
            retry_stage = 1
            step_retry_count += 1
            final_dt = 0.5 * dt
            round26_diag['round27_retry1_count'] += 1
            round26_diag['round27_min_dt_factor'] = min(round26_diag['round27_min_dt_factor'], 0.5)
            if step_accept_audit_enabled:
                if profile_enabled:
                    _profile_t0 = time.perf_counter()
                retry_state, retry_aux, retry_info = mode_a_step(
                    state, ph1, ph2, dx, final_dt, internal_bc_l, internal_bc_r, aux, cfg_step)
                if profile_enabled:
                    profile['mode_a_step_calls'] += 1
                    profile['mode_a_step_wall'] += time.perf_counter() - _profile_t0
                retry_metrics = _step_accept_trial_metrics(state, retry_state)
            else:
                if profile_enabled:
                    _profile_t0 = time.perf_counter()
                retry_state, retry_aux, retry_info = mode_a_step(
                    state, ph1, ph2, dx, final_dt, internal_bc_l, internal_bc_r, aux, cfg_step)
                if profile_enabled:
                    profile['mode_a_step_calls'] += 1
                    profile['mode_a_step_wall'] += time.perf_counter() - _profile_t0
                retry_metrics = None
            final_state, final_aux, final_info = retry_state, retry_aux, retry_info
            if step_accept_audit_enabled:
                retry1_p_jump = float(retry_metrics['interface_p_jump_after'])
                retry1_u_jump = float(retry_metrics['interface_u_jump_after'])
            else:
                retry1_p_proxy, retry1_u_proxy, _ = _bad_interface_proxy(retry_state, 1.0e7, 500.0)
                retry1_p_jump = float(retry1_p_proxy['max_jump'])
                retry1_u_jump = float(retry1_u_proxy['max_jump'])
            retry1_bad = (retry1_p_jump > 5.0e6 and retry1_u_jump > 250.0)

            if round26_diag['round26_first_retry_step'] is None:
                round26_diag['round26_first_retry_step'] = int(step_num + 1)
            if step_accept_audit_enabled and STEP_ACCEPT_AUDIT['round26_first_retry_step'] is None:
                STEP_ACCEPT_AUDIT['round26_first_retry_step'] = int(step_num + 1)

            total_retries_before_second = round26_diag['round27_retry1_count'] + round26_diag['round27_retry2_count']
            need_second_retry = (
                retry1_bad
                and step_retry_count < 2
                and total_retries_before_second < 60
            )
            limit_blocked_second_retry = (
                retry1_bad
                and step_retry_count < 2
                and total_retries_before_second >= 60
            )
            if need_second_retry:
                final_dt = 0.25 * dt
                retry_stage = 2
                step_retry_count += 1
                round26_diag['round27_retry2_count'] += 1
                round26_diag['round27_min_dt_factor'] = min(round26_diag['round27_min_dt_factor'], 0.25)
                if profile_enabled:
                    _profile_t0 = time.perf_counter()
                retry2_state, retry2_aux, retry2_info = mode_a_step(
                    state, ph1, ph2, dx, final_dt, internal_bc_l, internal_bc_r, aux, cfg_step)
                if profile_enabled:
                    profile['mode_a_step_calls'] += 1
                    profile['mode_a_step_wall'] += time.perf_counter() - _profile_t0
                final_state, final_aux, final_info = retry2_state, retry2_aux, retry2_info
                retry_used = True
                if step_accept_audit_enabled:
                    retry_metrics = _step_accept_trial_metrics(state, retry2_state)
                    retry2_bad = retry_metrics['bad_interface']
                    retry2_p_jump = float(retry_metrics['interface_p_jump_after'])
                    retry2_u_jump = float(retry_metrics['interface_u_jump_after'])
                else:
                    retry2_p_proxy, retry2_u_proxy, retry2_bad = _bad_interface_proxy(retry2_state, 5.0e6, 250.0)
                    retry2_p_jump = float(retry2_p_proxy['max_jump'])
                    retry2_u_jump = float(retry2_u_proxy['max_jump'])
                if retry2_bad:
                    round26_diag['round27_post_retry_bad_count'] += 1
                    round26_diag['round26_max_bad_interface_p_jump'] = max(
                        round26_diag['round26_max_bad_interface_p_jump'], retry2_p_jump)
                    round26_diag['round26_max_bad_interface_u_jump'] = max(
                        round26_diag['round26_max_bad_interface_u_jump'], retry2_u_jump)
                    if step_accept_audit_enabled and STEP_ACCEPT_AUDIT['round26_max_bad_interface_p_jump'] < retry2_p_jump:
                        STEP_ACCEPT_AUDIT['round26_max_bad_interface_p_jump'] = retry2_p_jump
                    if step_accept_audit_enabled and STEP_ACCEPT_AUDIT['round26_max_bad_interface_u_jump'] < retry2_u_jump:
                        STEP_ACCEPT_AUDIT['round26_max_bad_interface_u_jump'] = retry2_u_jump
                else:
                    round26_diag['round26_max_bad_interface_p_jump'] = max(
                        round26_diag['round26_max_bad_interface_p_jump'], retry2_p_jump)
                    round26_diag['round26_max_bad_interface_u_jump'] = max(
                        round26_diag['round26_max_bad_interface_u_jump'], retry2_u_jump)
                    if step_accept_audit_enabled:
                        STEP_ACCEPT_AUDIT['round26_max_bad_interface_p_jump'] = max(
                            STEP_ACCEPT_AUDIT['round26_max_bad_interface_p_jump'], retry2_p_jump)
                        STEP_ACCEPT_AUDIT['round26_max_bad_interface_u_jump'] = max(
                            STEP_ACCEPT_AUDIT['round26_max_bad_interface_u_jump'], retry2_u_jump)
            else:
                if limit_blocked_second_retry:
                    round26_diag['round27_total_retry_limit_hit'] += 1
                    if step_accept_audit_enabled:
                        STEP_ACCEPT_AUDIT['round27_total_retry_limit_hit'] = round26_diag['round27_total_retry_limit_hit']
                if retry1_bad:
                    round26_diag['round27_post_retry_bad_count'] += 1
                round26_diag['round26_max_bad_interface_p_jump'] = max(
                    round26_diag['round26_max_bad_interface_p_jump'], retry1_p_jump)
                round26_diag['round26_max_bad_interface_u_jump'] = max(
                    round26_diag['round26_max_bad_interface_u_jump'], retry1_u_jump)
                if step_accept_audit_enabled:
                    STEP_ACCEPT_AUDIT['round26_max_bad_interface_p_jump'] = max(
                        STEP_ACCEPT_AUDIT['round26_max_bad_interface_p_jump'], retry1_p_jump)
                    STEP_ACCEPT_AUDIT['round26_max_bad_interface_u_jump'] = max(
                        STEP_ACCEPT_AUDIT['round26_max_bad_interface_u_jump'], retry1_u_jump)
                if round26_diag['round26_first_retry_step'] is None:
                    round26_diag['round26_first_retry_step'] = int(step_num + 1)
                if step_accept_audit_enabled and STEP_ACCEPT_AUDIT['round26_first_retry_step'] is None:
                    STEP_ACCEPT_AUDIT['round26_first_retry_step'] = int(step_num + 1)

        round26_diag['round26_step_retries'] += step_retry_count
        if step_accept_audit_enabled:
            STEP_ACCEPT_AUDIT['round26_step_retries'] += step_retry_count

        state = final_state
        aux = final_aux
        t += final_dt
        step_num += 1
        if packet_amplitude_jsonl_path:
            _append_packet_amplitude_jsonl(
                packet_amplitude_jsonl_path,
                _build_packet_amplitude_jsonl_row(
                    step_num,
                    t,
                    final_dt,
                    int(final_info.get('outer_iters', final_info.get('niter', 0))),
                    state['p'],
                    state['u'],
                    p_ref,
                    u_ref,
                    x_cells,
                    state,
                    ph1,
                    ph2,
                ))

        if step_accept_audit_enabled:
            final_metrics = retry_metrics if retry_metrics is not None else trial_metrics
            if final_metrics is None:
                final_metrics = _step_accept_trial_metrics(
                    {'p': p_before, 'T': T_before, 'u': u_before, 'rho': rho_before, 'psi': psi_before},
                    state)
            round20_diag = getattr(_solver_a, 'SOLVER_A_DIAG', {})
            round20_backtracks = round20_diag.get('round20_backtracks') if isinstance(round20_diag, dict) else None
            round20_min_lambda = round20_diag.get('round20_min_lambda') if isinstance(round20_diag, dict) else None
            round20_first_backtrack_iter = round20_diag.get('round20_first_backtrack_iter') if isinstance(round20_diag, dict) else None
            round20_first_backtrack_step = round20_diag.get('round20_first_backtrack_step') if isinstance(round20_diag, dict) else None
            row = {
                'step': int(step_num),
                't_before': float(t - final_dt),
                'dt': float(final_dt),
                'converged': bool(final_info.get('converged', False)),
                'outer_iters': int(final_info.get('outer_iters', 0)),
                'p_min_before': p_stats_before['min'],
                'p_max_before': p_stats_before['max'],
                'p_min_after': _finite_stats(state['p'])['min'],
                'p_max_after': _finite_stats(state['p'])['max'],
                'T_min_before': T_stats_before['min'],
                'T_max_before': T_stats_before['max'],
                'T_min_after': _finite_stats(state['T'])['min'],
                'T_max_after': _finite_stats(state['T'])['max'],
                'rho_min_before': rho_stats_before['min'],
                'rho_max_before': rho_stats_before['max'],
                'rho_min_after': _finite_stats(state['rho'])['min'],
                'rho_max_after': _finite_stats(state['rho'])['max'],
                'u_min_before': u_stats_before['min'],
                'u_max_before': u_stats_before['max'],
                'u_min_after': _finite_stats(state['u'])['min'],
                'u_max_after': _finite_stats(state['u'])['max'],
                'max_rel_p_growth': final_metrics['max_rel_p_growth'],
                'max_rel_T_growth': final_metrics['max_rel_T_growth'],
                'max_rel_rho_growth': final_metrics['max_rel_rho_growth'],
                'interface_u_jump_before': final_metrics['interface_u_jump_before'],
                'interface_u_jump_after': final_metrics['interface_u_jump_after'],
                'interface_p_jump_before': final_metrics['interface_p_jump_before'],
                'interface_p_jump_after': final_metrics['interface_p_jump_after'],
                'interface_u_has_interface_before': bool(final_metrics['interface_u_before']['has_interface']),
                'interface_u_has_interface_after': bool(final_metrics['interface_u_after']['has_interface']),
                'interface_p_has_interface_before': bool(final_metrics['interface_p_before']['has_interface']),
                'interface_p_has_interface_after': bool(final_metrics['interface_p_after']['has_interface']),
                'top_growth_cell': final_metrics['top_growth_cell'],
                'top_growth_component': final_metrics['top_growth_component'],
                'top_growth_value': final_metrics['top_growth_value'],
                'top_growth_face': final_metrics['top_growth_face'],
                'round20_backtracks': round20_backtracks,
                'round20_min_lambda': round20_min_lambda,
                'round20_first_backtrack_iter': round20_first_backtrack_iter,
                'round20_first_backtrack_step': round20_first_backtrack_step,
                'retried': bool(retry_used),
                'retry_dt': float(final_dt) if retry_used else None,
                'retry_stage': int(retry_stage),
                'accepted_dt_factor': float(final_dt / dt),
            }
            STEP_ACCEPT_AUDIT['steps'].append(row)
            if len(STEP_ACCEPT_AUDIT['steps']) > 128:
                STEP_ACCEPT_AUDIT['steps'].pop(0)
            STEP_ACCEPT_AUDIT['round25_steps'] += 1
            STEP_ACCEPT_AUDIT['round25_max_p_growth'] = max(
                STEP_ACCEPT_AUDIT['round25_max_p_growth'], final_metrics['max_rel_p_growth'])
            STEP_ACCEPT_AUDIT['round25_max_T_growth'] = max(
                STEP_ACCEPT_AUDIT['round25_max_T_growth'], final_metrics['max_rel_T_growth'])
            STEP_ACCEPT_AUDIT['round25_max_interface_u_growth'] = max(
                STEP_ACCEPT_AUDIT['round25_max_interface_u_growth'],
                final_metrics['interface_u_jump_after'] / (final_metrics['interface_u_jump_before'] + 1.0e-300)
                if final_metrics['interface_u_jump_before'] > 0.0 else final_metrics['interface_u_jump_after'])
            STEP_ACCEPT_AUDIT['round25_rows'] = len(STEP_ACCEPT_AUDIT['steps'])

            if round38_packet_diag_enabled:
                r38_row = _round38_packet_diag_row(
                    step_num, t - final_dt, final_dt, dt, final_info,
                    final_metrics, state, retry_used, retry_stage)
                rows = round38_packet_diag['rows']
                rows.append(r38_row)
                if len(rows) > round38_packet_diag_topk:
                    rows.pop(0)
                top_rows = round38_packet_diag['top_rows']
                top_rows.append(r38_row)
                top_rows.sort(
                    key=lambda item: float(item.get('interface_p_jump_after', 0.0) or 0.0),
                    reverse=True)
                if len(top_rows) > round38_packet_diag_topk:
                    top_rows.pop()
                round38_packet_diag['row_count'] += 1
                round38_packet_diag['max_interface_p_jump'] = max(
                    round38_packet_diag['max_interface_p_jump'],
                    r38_row['interface_p_jump_after'])
                round38_packet_diag['max_interface_u_jump'] = max(
                    round38_packet_diag['max_interface_u_jump'],
                    r38_row['interface_u_jump_after'])
                if (round38_packet_diag['first_pressure_floor_step'] is None
                        and r38_row['pressure_floor_active_count'] > 0):
                    round38_packet_diag['first_pressure_floor_step'] = int(step_num)
                if round38_packet_diag['first_retry_step'] is None and retry_used:
                    round38_packet_diag['first_retry_step'] = int(step_num)

        _apply_inlet_state(t)

        if dt_init is None:
            dt_init = dt   # record first step size

        t_history.append(t)
        dt_history.append(dt)

        if verbose and (step_num % 1 == 0):
            print_step_info(step_num, t, final_dt, final_info, state)
        if step_progress_enabled:
            now_progress = time.monotonic()
            should_emit_progress = (
                step_num == 1
                or step_num % step_progress_interval_steps == 0
                or now_progress - step_progress_last_emit
                >= step_progress_interval_sec
                or t >= t_end - 1e-14 * max(t_end, 1.0)
            )
            if should_emit_progress:
                elapsed = max(now_progress - step_progress_t0, 0.0)
                frac = min(max(float(t) / max(float(t_end), 1.0e-300), 0.0), 1.0)
                eta = (
                    elapsed * (1.0 - frac) / max(frac, 1.0e-12)
                    if frac > 0.0 else float('inf')
                )
                print(
                    "DENNER_STEP_PROGRESS "
                    f"step={step_num} t={t:.12g} t_end={t_end:.12g} "
                    f"dt={final_dt:.6g} pct={100.0 * frac:.2f} "
                    f"elapsed={elapsed:.1f}s eta={eta:.1f}s",
                    flush=True,
                )
                step_progress_last_emit = now_progress
        if audit_enabled:
            audit_steps.append({
                'step': int(step_num),
                't': float(t),
                'dt': float(final_dt),
                'converged': bool(final_info.get('converged', False)),
                'outer_iters': int(final_info.get('outer_iters', 0)),
                'residuals': [float(v) for v in final_info.get('residuals', [])],
            })

        # ------------------------------------------------------------------
        # Divergence detection — stop immediately on any trigger
        # ------------------------------------------------------------------
        p_now   = state['p']
        T_now   = state['T']
        u_now   = state['u']
        rho_now = state['rho']
        T_guard_factor = float(os.environ.get('DENNER_T_DIVERGENCE_FACTOR', '1e3'))

        # 1. NaN / Inf in any field
        if not (np.all(np.isfinite(p_now)) and np.all(np.isfinite(u_now))
                and np.all(np.isfinite(T_now))):
            diverged = True
            diverge_reason = 'NaN or Inf in state'

        # 2. Pressure too large or negative
        elif np.max(p_now) > 1e3 * max(p0_ref, 1.0) or np.min(p_now) < 0.0:
            diverged = True
            diverge_reason = (f'Pressure out of range: min={np.min(p_now):.3e}'
                              f'  max={np.max(p_now):.3e}  (ref={p0_ref:.3e})')

        # 3. Temperature non-physical (negative or beyond a configurable
        # positivity guard).  Strong expansion can create very low-density
        # near-vacuum cells; keep the default guard conservative, but allow
        # controlled experiments to raise it without changing the equations.
        elif np.min(T_now) < 0.0 or np.max(T_now) > T_guard_factor * max(T0_ref, 1.0):
            diverged = True
            diverge_reason = (f'Temperature non-physical: min={np.min(T_now):.3e}'
                              f'  max={np.max(T_now):.3e}  (ref={T0_ref:.3e})')

        # 4. Velocity explosion: |u| > 1e4 × initial reference velocity
        elif np.max(np.abs(u_now)) > 1e4 * u0_ref:
            diverged = True
            diverge_reason = (f'Velocity explosion: max|u|={np.max(np.abs(u_now)):.3e}'
                              f'  (ref={u0_ref:.3e})')

        # 5. Sound speed explosion: c_mix = sqrt(gamma_eff * p / rho) > 1e4 × c0_ref
        else:
            rho_safe = np.maximum(rho_now, 1e-10)
            c_now    = np.sqrt(_gamma_eff * np.abs(p_now) / rho_safe)
            if np.max(c_now) > 1e4 * c0_ref:
                diverged = True
                diverge_reason = (f'Sound speed explosion: max(c)={np.max(c_now):.3e}'
                                  f'  (c0_ref={c0_ref:.3e})')

            # 6. dt collapsed (CFL runaway — acoustic or otherwise)
            elif (dt_init is not None and dt_fixed is None
                  and dt < 1e-6 * dt_init):
                diverged = True
                diverge_reason = (f'dt collapsed: dt={dt:.3e}  dt_init={dt_init:.3e}  '
                                  f'(ratio={dt/dt_init:.2e})')

        if diverged:
            if verbose:
                print(f'[denner_1d] *** DIVERGENCE at t={t:.4e}s step={step_num}: '
                      f'{diverge_reason} ***')
            break

        # Save snapshots at requested times: save when t first reaches or
        # passes the output time (handles floating-point drift without tiny steps).
        while next_output_idx < len(output_times):
            if t >= output_times[next_output_idx] - 1e-10:
                snapshots.append(make_snapshot(t, state, x_cells))
                next_output_idx += 1
            else:
                break

    # Save final state
    final_snap = make_snapshot(t, state, x_cells)
    if len(snapshots) == 0 or abs(snapshots[-1]['t'] - t) > 1e-12:
        snapshots.append(final_snap)

    if STEP_ACCEPT_AUDIT is not None:
        STEP_ACCEPT_AUDIT.update(round26_diag)

    # Save to file
    if output_path is not None:
        save_snapshots_npz(output_path, snapshots)
        if verbose:
            print(f"[denner_1d] Saved {len(snapshots)} snapshots to {output_path}")

    if verbose:
        status = 'DIVERGED' if diverged else 'Done'
        print(f"[denner_1d] {status}. t={t:.6e}s, steps={step_num}")

    if round40_face_compat_diag_enabled:
        round40_face_compat_diag = _solver_a.get_solver_a_face_compat_diag()
    if round41_floor_diag_enabled:
        round41_floor_diag = _solver_a.get_solver_a_floor_diag()
    if round_postsolve_limiter_diag_enabled:
        round_postsolve_limiter_diag = _solver_a.get_solver_a_postsolve_limiter_diag()
    if round42_assembly_compat_diag_enabled or prod_flux_diag_enabled:
        round42_assembly_compat_diag = _solver_a.get_solver_a_assembly_compat_diag()

    return {
        'final_state':    state,
        'snapshots':      snapshots,
        't_history':      t_history,
        'dt_history':     dt_history,
        'diverged':       diverged,
        'diverge_reason': diverge_reason,
        'round26':        round26_diag,
        **({'audit': {'enabled': True,
                      'steps': audit_steps if audit_enabled else [],
                      'step_accept': STEP_ACCEPT_AUDIT}} if (audit_enabled or step_accept_audit_enabled) else {}),
        **({'round38_packet': round38_packet_diag} if round38_packet_diag_enabled else {}),
        **({'round40_face_compat': round40_face_compat_diag}
           if round40_face_compat_diag_enabled else {}),
        **({'round41_floor_diag': round41_floor_diag}
           if round41_floor_diag_enabled else {}),
        **({'round_postsolve_limiter': round_postsolve_limiter_diag}
           if round_postsolve_limiter_diag_enabled else {}),
        **({'round42_assembly_compat': round42_assembly_compat_diag}
           if (round42_assembly_compat_diag_enabled or prod_flux_diag_enabled) else {}),
        **({'profile': {**profile, **_get_assembly_profile(),
                        'steps': int(step_num)}}
           if profile_enabled else {}),
    }

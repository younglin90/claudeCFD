import numpy as np
import scipy.sparse as sp

from solver.denner_1d.assembly_kernels import blocks3n_to_triplets
from solver.denner_1d.assembly import _SparseAccumulator


def _dense_from_triplets(rows, cols, vals, n):
    return sp.coo_matrix((vals, (rows, cols)), shape=(3 * n, 3 * n)).toarray()


def test_blocks3n_to_triplets_numba_matches_numpy():
    rng = np.random.default_rng(7)
    n = 11
    lower = rng.normal(size=(n - 1, 3, 3))
    diag = rng.normal(size=(n, 3, 3))
    upper = rng.normal(size=(n - 1, 3, 3))

    rows_np, cols_np, vals_np = blocks3n_to_triplets(
        lower, diag, upper, use_numba=False)
    rows_nb, cols_nb, vals_nb = blocks3n_to_triplets(
        lower, diag, upper, use_numba=True)

    A_np = _dense_from_triplets(rows_np, cols_np, vals_np, n)
    A_nb = _dense_from_triplets(rows_nb, cols_nb, vals_nb, n)
    np.testing.assert_allclose(A_nb, A_np, rtol=0.0, atol=0.0)


def test_sparse_accumulator_block3n_tocsr_matches_scalar_triplets(monkeypatch):
    rng = np.random.default_rng(17)
    n = 9
    entries = []

    def idx(block, cell):
        return block * n + cell

    for cell in range(n):
        for rb in range(3):
            for cb in range(3):
                entries.append((idx(rb, cell), idx(cb, cell), rng.normal()))
        if cell < n - 1:
            for rb in range(3):
                for cb in range(3):
                    entries.append((idx(rb, cell), idx(cb, cell + 1), rng.normal()))
                    entries.append((idx(rb, cell + 1), idx(cb, cell), rng.normal()))
    entries.extend(entries[::7])

    monkeypatch.setenv("DENNER_CACHE_BLOCK3N", "1")
    monkeypatch.setenv("DENNER_CACHE_BLOCK3N_MIN_SIZE", "0")
    monkeypatch.setenv("DENNER_BLOCK3N_TRIPLET_EMIT", "0")
    scalar = _SparseAccumulator((3 * n, 3 * n))
    for row, col, val in entries:
        scalar.add(row, col, val)
    A_scalar = scalar.tocsr()

    monkeypatch.setenv("DENNER_BLOCK3N_TRIPLET_EMIT", "1")
    block = _SparseAccumulator((3 * n, 3 * n))
    for row, col, val in entries:
        block.add(row, col, val)
    A_block = block.tocsr()

    assert getattr(A_block, "_denner_block3n", None) is not None
    np.testing.assert_allclose(
        A_block.toarray(), A_scalar.toarray(), rtol=0.0, atol=0.0)

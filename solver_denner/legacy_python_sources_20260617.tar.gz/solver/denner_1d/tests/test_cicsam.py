import numpy as np

from solver.denner_1d.interface.cicsam import (
    cicsam_face,
    cicsam_face_beta,
    cicsam_face_jacobian,
    thinc_face,
)


def _reference_cicsam_face(psi_ext, u_face, dt, dx, n_ghost=2):
    ng = n_ghost
    N = len(u_face) - 1
    psi_face = np.zeros(N + 1)
    for f in range(N + 1):
        uf = u_face[f]
        if uf >= 0.0:
            i_D = ng + f - 1
            i_A = ng + f
            i_UU = ng + f - 2
        else:
            i_D = ng + f
            i_A = ng + f - 1
            i_UU = ng + f + 1
        psi_D = psi_ext[i_D]
        psi_A = psi_ext[i_A]
        psi_UU = psi_ext[i_UU]
        denom = psi_A - psi_UU
        if abs(denom) < 1.0e-10:
            psi_face[f] = psi_D
            continue
        psi_tilde_D = (psi_D - psi_UU) / denom
        Co_f = abs(uf) * dt / dx
        if 0.0 <= psi_tilde_D <= 1.0:
            psi_tilde_f = min(psi_tilde_D / max(Co_f, 1.0e-10), 1.0)
        else:
            psi_tilde_f = psi_tilde_D
        psi_face[f] = psi_UU + psi_tilde_f * denom
    return np.clip(psi_face, 0.0, 1.0)


def _reference_cicsam_beta(psi_ext, u_face, dt, dx, n_ghost=2):
    ng = n_ghost
    N = len(u_face) - 1
    beta = np.zeros(N + 1)
    for f in range(N + 1):
        uf = u_face[f]
        if uf >= 0.0:
            i_D = ng + f - 1
            i_A = ng + f
            i_UU = ng + f - 2
        else:
            i_D = ng + f
            i_A = ng + f - 1
            i_UU = ng + f + 1
        psi_D = psi_ext[i_D]
        psi_A = psi_ext[i_A]
        psi_UU = psi_ext[i_UU]
        if abs(psi_A - psi_D) < 1.0e-10:
            beta[f] = 0.0
            continue
        denom = psi_A - psi_UU
        if abs(denom) < 1.0e-10:
            beta[f] = 0.0
            continue
        psi_tilde_D = (psi_D - psi_UU) / denom
        Co_f = abs(uf) * dt / dx
        if 0.0 <= psi_tilde_D <= 1.0:
            psi_tilde_f = min(psi_tilde_D / max(Co_f, 1.0e-10), 1.0)
        else:
            psi_tilde_f = psi_tilde_D
        psi_face_val = float(np.clip(psi_UU + psi_tilde_f * denom, 0.0, 1.0))
        beta[f] = float(np.clip((psi_face_val - psi_D) / (psi_A - psi_D), 0.0, 1.0))
    return beta


def _reference_thinc_face(psi_ext, u_face, dt, dx, n_ghost=2, beta=0.4):
    ng = n_ghost
    N = len(u_face) - 1
    psi_face = np.empty(N + 1)
    for f in range(N + 1):
        if u_face[f] >= 0.0:
            i_D = ng + f - 1
            i_A = ng + f
            i_UU = ng + f - 2
        else:
            i_D = ng + f
            i_A = ng + f - 1
            i_UU = ng + f + 1
        q_D = float(psi_ext[i_D])
        q_A = float(psi_ext[i_A])
        q_UU = float(psi_ext[i_UU])
        q_lo = min(q_UU, q_A)
        q_hi = max(q_UU, q_A)
        dq = q_hi - q_lo
        if dq <= 1.0e-12:
            psi_face[f] = q_D
            continue
        a = min(max((q_D - q_lo) / dq, 0.0), 1.0)
        q_thinc = q_lo + dq * (0.5 + 0.5 * np.tanh(float(beta) * (2.0 * a - 1.0)))
        w = np.tanh(50.0 * dq)
        psi_face[f] = w * q_thinc + (1.0 - w) * q_D
    return np.clip(psi_face, 0.0, 1.0)


def _reference_cicsam_jacobian(psi_ext, u_face, dt, dx, n_ghost=2):
    ng = n_ghost
    N = len(u_face) - 1
    psi_face = np.zeros(N + 1)
    jac_D = np.zeros(N + 1)
    jac_A = np.zeros(N + 1)
    jac_UU = np.zeros(N + 1)
    idx_D = np.zeros(N + 1, dtype=int)
    idx_A = np.zeros(N + 1, dtype=int)
    idx_UU = np.zeros(N + 1, dtype=int)
    for f in range(N + 1):
        uf = u_face[f]
        if uf >= 0.0:
            i_D = ng + f - 1
            i_A = ng + f
            i_UU = ng + f - 2
            idx_D[f] = f - 1
            idx_A[f] = f
            idx_UU[f] = f - 2
        else:
            i_D = ng + f
            i_A = ng + f - 1
            i_UU = ng + f + 1
            idx_D[f] = f
            idx_A[f] = f - 1
            idx_UU[f] = f + 1
        psi_D = psi_ext[i_D]
        psi_A = psi_ext[i_A]
        psi_UU = psi_ext[i_UU]
        denom = psi_A - psi_UU
        if abs(denom) < 1.0e-10:
            psi_face[f] = psi_D
            jac_D[f] = 1.0
            continue
        psi_tilde_D = (psi_D - psi_UU) / denom
        Co_f = max(abs(uf) * dt / dx, 1.0e-10)
        if 0.0 <= psi_tilde_D <= 1.0:
            if psi_tilde_D / Co_f <= 1.0:
                inv_Co = 1.0 / Co_f
                psi_face[f] = psi_UU + (psi_D - psi_UU) * inv_Co
                jac_D[f] = inv_Co
                jac_UU[f] = 1.0 - inv_Co
            else:
                psi_face[f] = psi_A
                jac_A[f] = 1.0
        else:
            psi_face[f] = psi_D
            jac_D[f] = 1.0
    return (
        np.clip(psi_face, 0.0, 1.0),
        jac_D,
        jac_A,
        jac_UU,
        idx_D % N,
        idx_A % N,
        idx_UU % N,
    )


def test_cicsam_face_matches_reference_loop():
    rng = np.random.default_rng(31)
    n = 80
    psi_ext = rng.random(n + 4)
    u_face = rng.normal(size=n + 1)
    u_face[::9] = 0.0
    got = cicsam_face(psi_ext, u_face, dt=1.0e-5, dx=2.0e-3)
    ref = _reference_cicsam_face(psi_ext, u_face, dt=1.0e-5, dx=2.0e-3)
    np.testing.assert_allclose(got, ref, rtol=0.0, atol=0.0)


def test_cicsam_face_beta_matches_reference_loop():
    rng = np.random.default_rng(32)
    n = 80
    psi_ext = rng.random(n + 4)
    u_face = rng.normal(size=n + 1)
    u_face[::9] = 0.0
    got = cicsam_face_beta(psi_ext, u_face, dt=1.0e-5, dx=2.0e-3)
    ref = _reference_cicsam_beta(psi_ext, u_face, dt=1.0e-5, dx=2.0e-3)
    np.testing.assert_allclose(got, ref, rtol=0.0, atol=0.0)


def test_thinc_face_matches_reference_loop():
    rng = np.random.default_rng(33)
    n = 80
    psi_ext = rng.random(n + 4)
    u_face = rng.normal(size=n + 1)
    u_face[::8] = 0.0
    got = thinc_face(psi_ext, u_face, dt=1.0e-5, dx=2.0e-3, beta=0.7)
    ref = _reference_thinc_face(psi_ext, u_face, dt=1.0e-5, dx=2.0e-3, beta=0.7)
    np.testing.assert_allclose(got, ref, rtol=0.0, atol=1.0e-15)


def test_cicsam_face_jacobian_matches_reference_loop():
    rng = np.random.default_rng(34)
    n = 80
    psi_ext = rng.random(n + 4)
    u_face = rng.normal(size=n + 1)
    u_face[::7] = 0.0
    got = cicsam_face_jacobian(psi_ext, u_face, dt=1.0e-5, dx=2.0e-3)
    ref = _reference_cicsam_jacobian(psi_ext, u_face, dt=1.0e-5, dx=2.0e-3)
    for got_part, ref_part in zip(got[:4], ref[:4]):
        np.testing.assert_allclose(got_part, ref_part, rtol=0.0, atol=1.0e-15)
    for got_idx, ref_idx in zip(got[4:], ref[4:]):
        np.testing.assert_array_equal(got_idx, ref_idx)


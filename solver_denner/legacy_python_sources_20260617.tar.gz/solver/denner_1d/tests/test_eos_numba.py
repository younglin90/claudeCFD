import numpy as np

from solver.denner_1d.eos.base import compute_phase_props
from solver.denner_1d.eos.eos_numba import NUMBA_AVAILABLE


def test_nasg_numba_props_match_numpy_fast_path(monkeypatch):
    ph = {
        "gamma": 4.4,
        "pinf": 6.0e8,
        "b": 6.61e-4,
        "kv": 1816.0,
        "eta": 0.0,
    }
    p = np.linspace(1.0e5, 1.0e9, 64)
    T = np.linspace(280.0, 650.0, 64)

    monkeypatch.setenv("DENNER_NUMBA_EOS", "0")
    ref = compute_phase_props(p, T, ph)

    monkeypatch.setenv("DENNER_NUMBA_EOS", "1")
    got = compute_phase_props(p, T, ph)

    for key in ("rho", "c", "h", "E", "zeta", "phi", "dh_dp", "cp", "dEdp", "dEdT"):
        np.testing.assert_allclose(
            got[key], ref[key], rtol=1.0e-12, atol=1.0e-12,
            err_msg=f"{key} differs with NUMBA_AVAILABLE={NUMBA_AVAILABLE}")


import numpy as np

from solver.denner_1d.flux.limiter import minmod_face, van_leer_face
from solver.denner_1d.assembly import tvd_face_state_diagnostics


def _van_leer_limiter(r):
    r_abs = abs(r)
    return (r + r_abs) / (1.0 + r_abs + 1e-300)


def _minmod_limiter(r):
    return max(0.0, min(1.0, r))


def _reference_face(phi_ext, u_face, kind, n_ghost=2):
    ng = n_ghost
    N = len(u_face) - 1
    out = np.empty(N + 1)
    limiter = _van_leer_limiter if kind == "vanleer" else _minmod_limiter
    for f in range(N + 1):
        iL = ng + f - 1
        iR = ng + f
        if u_face[f] >= 0.0:
            phi_C = phi_ext[iL]
            phi_D = phi_ext[iL - 1]
            phi_A = phi_ext[iR]
        else:
            phi_C = phi_ext[iR]
            phi_D = phi_ext[iR + 1]
            phi_A = phi_ext[iL]
        diff = phi_C - phi_D
        scale = max(abs(phi_C), abs(phi_D), abs(phi_A), 1.0e-30)
        if abs(diff) < 1.0e-12 * scale:
            out[f] = phi_C
        else:
            r = (phi_A - phi_C) / diff
            out[f] = phi_C + 0.5 * limiter(r) * diff
    return out


def test_limiter_faces_match_reference_loop():
    rng = np.random.default_rng(22)
    n = 64
    phi_ext = rng.normal(size=n + 4)
    u_face = rng.normal(size=n + 1)
    u_face[::7] = 0.0

    np.testing.assert_allclose(
        van_leer_face(phi_ext, u_face),
        _reference_face(phi_ext, u_face, "vanleer"),
        rtol=0.0,
        atol=0.0,
    )
    np.testing.assert_allclose(
        minmod_face(phi_ext, u_face),
        _reference_face(phi_ext, u_face, "minmod"),
        rtol=0.0,
        atol=0.0,
    )


def test_acoustic_candidate_limiter_states_are_locally_bounded():
    q = np.array([1.0, 1.25, 1.7, 1.45, 1.3, 1.9, 2.1], dtype=float)
    for kind in ("vanleer", "mc", "koren"):
        diag = tvd_face_state_diagnostics(
            q, "transmissive", "transmissive", kind=kind)
        qL = diag["qL"]
        qR = diag["qR"]
        for f in range(1, q.size):
            lo = min(q[f - 1], q[f])
            hi = max(q[f - 1], q[f])
            assert lo - 1.0e-14 <= qL[f] <= hi + 1.0e-14
            assert lo - 1.0e-14 <= qR[f] <= hi + 1.0e-14



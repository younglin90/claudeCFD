import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from solver.denner_1d.linsolve import solve_block_tridiagonal_3n


def _make_variable_major_block_tridiagonal(n, seed=123):
    rng = np.random.default_rng(seed)
    rows = []
    cols = []
    vals = []

    def idx(block, cell):
        return block * n + cell

    for cell in range(n):
        diag = rng.normal(size=(3, 3))
        diag += np.eye(3) * 6.0
        for rb in range(3):
            for cb in range(3):
                rows.append(idx(rb, cell))
                cols.append(idx(cb, cell))
                vals.append(diag[rb, cb])
        if cell < n - 1:
            upper = rng.normal(scale=0.1, size=(3, 3))
            lower = rng.normal(scale=0.1, size=(3, 3))
            for rb in range(3):
                for cb in range(3):
                    rows.append(idx(rb, cell))
                    cols.append(idx(cb, cell + 1))
                    vals.append(upper[rb, cb])
                    rows.append(idx(rb, cell + 1))
                    cols.append(idx(cb, cell))
                    vals.append(lower[rb, cb])
    return sp.coo_matrix((vals, (rows, cols)), shape=(3 * n, 3 * n)).tocsr()


def test_block_tridiagonal_3n_matches_spsolve():
    n = 32
    A = _make_variable_major_block_tridiagonal(n)
    b = np.linspace(-1.0, 1.0, 3 * n)
    got = solve_block_tridiagonal_3n(A, b)
    ref = spla.spsolve(A.tocsc(), b)
    np.testing.assert_allclose(got, ref, rtol=1.0e-11, atol=1.0e-11)


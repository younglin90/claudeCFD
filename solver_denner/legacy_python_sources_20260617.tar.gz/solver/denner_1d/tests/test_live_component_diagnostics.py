import numpy as np

from solver.denner_1d.assembly import (
    _acoustic_accepted_update_schema_row,
    _acoustic_dispersion_schema_row,
    _acoustic_dispersion_update_prev_sample,
    _acoustic_high_wavenumber_fraction,
    _acoustic_packet_energy_global_schema_row,
    _acoustic_packet_energy_schema_row,
    _acoustic_packet_energy_values,
    _acoustic_weighted_moments,
    _mp3_face_states,
    _second_difference_preview_norm,
    _smooth_extrema_candidate_schema_row,
    _tvd_face_states,
    _weno_z3_face_states,
    tvd_face_state_diagnostics,
)
from solver.denner_1d.flux.slau2 import slau2_flux, slau2_flux_components
from solver.denner_1d.interface.cicsam import (
    cicsam_face,
    cicsam_face_components,
    thinc_face,
    thinc_face_components,
)


def test_slau2_components_reconstruct_flux_scalar_and_vector():
    args = (
        np.array([1.2, 0.9]),
        np.array([1.1, 1.4]),
        np.array([14.0, -2.0]),
        np.array([11.0, 3.0]),
        np.array([101000.0, 99000.0]),
        np.array([100700.0, 100500.0]),
        np.array([3.1e5, 3.0e5]),
        np.array([3.05e5, 3.2e5]),
        np.array([340.0, 330.0]),
        np.array([342.0, 335.0]),
    )
    flux = slau2_flux(*args)
    comp = slau2_flux_components(*args)
    np.testing.assert_allclose(comp["F_mass"], flux[0])
    np.testing.assert_allclose(comp["F_mom"], flux[1])
    np.testing.assert_allclose(comp["F_energy"], flux[2])
    np.testing.assert_allclose(
        comp["mass_advective_part"] + comp["mass_pressure_part"],
        comp["F_mass"],
    )
    np.testing.assert_allclose(
        comp["pressure_central_part"]
        + comp["pressure_split_part"]
        + comp["pressure_velocity_part"],
        comp["p_face"],
    )

    scalar_args = tuple(float(a[0]) for a in args)
    scalar_flux = slau2_flux(*scalar_args)
    scalar_comp = slau2_flux_components(*scalar_args)
    assert np.allclose(float(scalar_comp["F_mass"]), scalar_flux[0])
    assert np.allclose(float(scalar_comp["F_mom"]), scalar_flux[1])
    assert np.allclose(float(scalar_comp["F_energy"]), scalar_flux[2])


def test_slau2_mass_blend_activates_only_on_smooth_same_material_stencil():
    args = (1.0, 1.0, 10.0, 11.0, 100000.0, 100010.0,
            3.0e5, 3.0e5, 340.0, 340.0)
    smooth_inputs = {
        "psi_LL": 1.0,
        "psi_L": 1.0,
        "psi_R": 1.0,
        "psi_RR": 1.0,
        "p_LL": 99990.0,
        "p_RR": 100020.0,
        "u_LL": 9.0,
        "u_RR": 12.0,
    }
    comp = slau2_flux_components(*args, mass_blend_inputs=smooth_inputs)

    assert bool(comp["mass_blend_active"])
    assert 0.0 < float(comp["mass_blend_weight"]) <= 1.0
    assert bool(comp["mass_blend_helper_called"])
    assert float(comp["mass_blend_w_smooth_p"]) > 0.0
    assert float(comp["mass_blend_w_smooth_u"]) > 0.0
    assert bool(comp["mass_blend_p_monotone_left"])
    assert bool(comp["mass_blend_p_monotone_right"])
    assert bool(comp["mass_blend_u_monotone_left"])
    assert bool(comp["mass_blend_u_monotone_right"])
    assert str(np.asarray(comp["mass_blend_zero_reason"], dtype=object)) == "none"
    before = float(comp["mass_flux_before_blend"])
    target = float(comp["mass_flux_acoustic_target"])
    after = float(comp["mass_flux_after_blend"])
    assert min(before, target) <= after <= max(before, target)
    np.testing.assert_allclose(comp["F_mass"], after)

    material_inputs = dict(smooth_inputs, psi_R=0.0, psi_RR=0.0)
    material = slau2_flux_components(*args, mass_blend_inputs=material_inputs)
    assert not bool(material["mass_blend_active"])
    assert float(material["mass_blend_w_material"]) == 0.0
    assert str(np.asarray(material["mass_blend_zero_reason"], dtype=object)) == "material"
    np.testing.assert_allclose(
        material["F_mass"], material["mass_flux_before_blend"])

    discontinuity_inputs = dict(
        smooth_inputs, p_LL=100000.0, p_RR=100010.0, u_LL=10.0, u_RR=11.0)
    discontinuity = slau2_flux_components(
        *args, mass_blend_inputs=discontinuity_inputs)
    assert not bool(discontinuity["mass_blend_active"])
    assert float(discontinuity["mass_blend_w_smooth"]) == 0.0
    assert float(discontinuity["mass_blend_w_smooth_p"]) == 0.0
    assert str(np.asarray(discontinuity["mass_blend_zero_reason"], dtype=object)) == "smooth_p"


def test_slau2_mass_blend_smoothness_decomposition_flags_extremum_candidate():
    args = (1.0, 1.0, 10.0, 11.0, 100000.0, 100010.0,
            3.0e5, 3.0e5, 340.0, 340.0)
    extremum_inputs = {
        "psi_LL": 1.0,
        "psi_L": 1.0,
        "psi_R": 1.0,
        "psi_RR": 1.0,
        "p_LL": 100010.0,
        "p_RR": 100000.0,
        "u_LL": 9.0,
        "u_RR": 12.0,
        "dx": 0.01,
    }
    comp = slau2_flux_components(*args, mass_blend_inputs=extremum_inputs)

    assert not bool(comp["mass_blend_active"])
    assert float(comp["mass_blend_w_smooth_p"]) == 0.0
    assert bool(comp["mass_blend_p_weno_smooth_candidate"])
    assert bool(comp["mass_blend_extremum_candidate_p"])
    assert "smooth_p" == str(
        np.asarray(comp["mass_blend_zero_reason"], dtype=object))
    assert "mass_blend_J_plus_smooth_ratio" in comp
    assert "mass_blend_characteristic_smooth_candidate" in comp
    assert float(comp["mass_blend_p_jump_rel"]) >= 0.0
    assert float(comp["mass_blend_u_jump_rel"]) >= 0.0
    assert float(comp["mass_blend_compression_proxy"]) == 0.0


def test_slau2_mass_blend_impedance_jump_suppresses_weight():
    args = (1.0, 1000.0, 10.0, 11.0, 100000.0, 100010.0,
            3.0e5, 3.0e5, 340.0, 1500.0)
    inputs = {
        "psi_LL": 1.0,
        "psi_L": 1.0,
        "psi_R": 1.0,
        "psi_RR": 1.0,
        "p_LL": 99990.0,
        "p_RR": 100020.0,
        "u_LL": 9.0,
        "u_RR": 12.0,
    }
    comp = slau2_flux_components(*args, mass_blend_inputs=inputs)

    assert float(comp["mass_blend_w_impedance"]) < 1.0e-3
    assert float(comp["mass_blend_weight"]) < 1.0e-3


def test_tvd_face_state_diagnostics_match_production_and_do_not_mutate():
    q = np.array([1.0, 1.4, 1.2, 1.8, 2.0, 1.9], dtype=float)
    q_before = q.copy()
    for kind in ("minmod", "vanleer", "koren", "vanalbada"):
        qL, qR = _tvd_face_states(q, "wall", "transmissive", kind=kind)
        diag = tvd_face_state_diagnostics(
            q, "wall", "transmissive", kind=kind)
        np.testing.assert_allclose(diag["qL"], qL)
        np.testing.assert_allclose(diag["qR"], qR)
        assert diag["kind"] == kind
    np.testing.assert_allclose(q, q_before)


def test_acoustic_accepted_update_schema_row_has_required_markers():
    row = _acoustic_accepted_update_schema_row(
        step=609,
        window="right_lobe",
        face_class="same_material_acoustic",
        supported=False,
        missing_fields=["p_u_nm1_history"],
    )
    assert row["row_type"] == "acoustic_accepted_update"
    assert row["accepted_update_step"] == 609
    assert row["accepted_update_window"] == "right_lobe"
    assert row["accepted_update_face_class"] == "same_material_acoustic"
    assert row["accepted_update_audit_supported"] is False
    assert row["accepted_update_missing_fields"] == ["p_u_nm1_history"]


def test_acoustic_packet_energy_values_are_finite_for_simple_state():
    p = np.array([1.0, 2.0, 3.0], dtype=float)
    u = np.array([0.0, 0.1, 0.2], dtype=float)
    Z = np.array([10.0, 10.0, 10.0], dtype=float)
    vals = _acoustic_packet_energy_values(p, u, Z)
    assert vals["supported"] is True
    assert vals["finite_count"] == 3
    assert np.isfinite(vals["E_acoustic_total"])
    assert vals["E_acoustic_total"] > 0.0
    assert np.isfinite(vals["opposite_energy_ratio"])
    vals_x = _acoustic_packet_energy_values(p, u, Z, x_vals=np.arange(3))
    assert np.isfinite(vals_x["energy_centroid"])
    assert np.isfinite(vals_x["energy_width_second_moment"])
    assert np.isfinite(vals_x["energy_width_sqrt"])
    assert "skewness" in vals_x


def test_acoustic_packet_energy_schema_row_has_required_markers():
    row = _acoustic_packet_energy_schema_row(
        step=700,
        window="right_lobe",
        supported=False,
        missing_fields=["rho_c_impedance"],
    )
    assert row["row_type"] == "acoustic_packet_energy"
    assert row["energy_step"] == 700
    assert row["energy_window"] == "right_lobe"
    assert row["energy_supported"] is False
    assert row["energy_missing_fields"] == ["rho_c_impedance"]


def test_acoustic_packet_energy_global_schema_row_has_required_markers():
    row = _acoustic_packet_energy_global_schema_row(
        step=800,
        group="global_all_interior",
        supported=False,
        missing_fields=["empty_group"],
    )
    assert row["row_type"] == "acoustic_packet_energy_global"
    assert row["energy_step"] == 800
    assert row["energy_group"] == "global_all_interior"
    assert row["energy_supported"] is False
    assert row["energy_missing_fields"] == ["empty_group"]


def test_acoustic_dispersion_helpers_are_finite_for_simple_state():
    x = np.arange(5, dtype=float)
    w = np.array([0.0, 1.0, 4.0, 1.0, 0.0], dtype=float)
    moments = _acoustic_weighted_moments(x, w)
    assert moments["supported"] is True
    assert np.isfinite(moments["centroid"])
    assert np.isfinite(moments["sigma"])
    assert np.isfinite(moments["skewness"])
    frac = _acoustic_high_wavenumber_fraction(w)
    assert np.isfinite(frac)
    assert frac >= 0.0


def test_acoustic_dispersion_schema_row_has_required_markers():
    row = _acoustic_dispersion_schema_row(
        step=760,
        group="right_lobe",
        missing_fields=["previous_sample_centroid"],
    )
    assert row["row_type"] == "acoustic_dispersion"
    assert row["dispersion_step"] == 760
    assert row["dispersion_group"] == "right_lobe"
    assert row["missing_fields"] == ["previous_sample_centroid"]


def test_acoustic_dispersion_prev_sample_cache_second_speed_finite():
    cache = {}
    first = _acoustic_dispersion_update_prev_sample(
        cache, "right_lobe", step=609, time_value=0.609,
        time_source="assembly_diag_context_time",
        centroid=140.0, local_c=2.0, dx_value=0.1,
        time_physical=True)
    assert first["centroid_speed_from_prev_sample"] is None
    assert first["missing_fields"] == ["previous_sample_centroid"]
    second = _acoustic_dispersion_update_prev_sample(
        cache, "right_lobe", step=650, time_value=0.650,
        time_source="assembly_diag_context_time",
        centroid=141.0, local_c=2.0, dx_value=0.1,
        time_physical=True)
    assert second["previous_energy_centroid_x"] == 140.0
    assert second["previous_energy_step"] == 609
    assert np.isfinite(second["centroid_time_delta"])
    assert second["centroid_step_delta"] == 41
    assert np.isfinite(second["centroid_speed_from_prev_sample"])
    assert np.isfinite(second["centroid_speed_per_step"])
    assert np.isfinite(second["speed_ratio_to_local_c"])
    assert np.isfinite(second["speed_ratio_to_local_c_per_step_dx"])
    assert second["missing_fields"] == []


def test_acoustic_dispersion_prev_sample_step_index_fallback():
    cache = {}
    _acoustic_dispersion_update_prev_sample(
        cache, "right_lobe", step=1, time_value=1.0,
        time_source="step_index", centroid=10.0, local_c=2.0,
        dx_value=0.5, time_physical=False)
    second = _acoustic_dispersion_update_prev_sample(
        cache, "right_lobe", step=3, time_value=3.0,
        time_source="step_index", centroid=12.0, local_c=2.0,
        dx_value=0.5, time_physical=False)
    assert second["centroid_time_delta"] == 2.0
    assert second["centroid_step_delta"] == 2
    assert second["centroid_speed_per_step"] == 1.0
    assert second["speed_ratio_to_local_c"] is None
    assert second["speed_ratio_to_local_c_per_step_dx"] == 0.25
    assert "physical_time_for_speed_ratio" in second["missing_fields"]


def test_weno_z3_face_states_are_finite_and_locally_bounded_on_monotone_data():
    q = np.array([1.0, 1.2, 1.5, 1.9, 2.4, 3.0], dtype=float)
    qL, qR = _weno_z3_face_states(q)
    assert qL.shape == (q.size + 1,)
    assert qR.shape == (q.size + 1,)
    assert np.all(np.isfinite(qL))
    assert np.all(np.isfinite(qR))
    for f in range(1, q.size):
        stencil = q[max(0, f - 2):min(q.size, f + 2)]
        lo = float(np.min(stencil))
        hi = float(np.max(stencil))
        assert lo <= float(qL[f]) <= hi
        assert lo <= float(qR[f]) <= hi


def test_mp3_face_states_are_finite_for_smooth_stencil():
    q = np.array([0.0, 0.1, 0.4, 0.9, 1.6, 2.5], dtype=float)
    qL, qR = _mp3_face_states(q)
    assert qL.shape == (q.size + 1,)
    assert qR.shape == (q.size + 1,)
    assert np.all(np.isfinite(qL))
    assert np.all(np.isfinite(qR))
    np.testing.assert_allclose(qL[2], (-q[0] + 5.0 * q[1] + 2.0 * q[2]) / 6.0)
    np.testing.assert_allclose(qR[2], (2.0 * q[1] + 5.0 * q[2] - q[3]) / 6.0)


def test_smooth_extrema_candidate_schema_and_second_difference_norm():
    row = _smooth_extrema_candidate_schema_row(
        step=760,
        window="right_lobe",
        candidate_name="weno_z3",
    )
    assert row["row_type"] == "acoustic_smooth_extrema_candidate"
    assert row["smooth_extrema_step"] == 760
    assert row["smooth_extrema_window"] == "right_lobe"
    assert row["candidate_name"] == "weno_z3"
    norm = _second_difference_preview_norm(np.array([0.0, 1.0, 0.0]))
    assert np.isfinite(norm)
    assert norm > 0.0


def test_smooth_extrema_survivor_row_fields_are_schema_compatible():
    row = _smooth_extrema_candidate_schema_row(
        step=810,
        window="right_tail_right",
        candidate_name="mp5",
    )
    row.update({
        "smooth_extrema_survivor_audit_enabled": True,
        "candidate_supported": False,
        "candidate_unavailable_reason": (
            "candidate_unavailable_no_safe_local_mp5_stencil"),
        "all_gates_ok": False,
        "highk_not_worse_ok": False,
        "survivor_face_count": 0,
        "material_active_candidate_count": 0,
    })
    assert row["row_type"] == "acoustic_smooth_extrema_candidate"
    assert row["candidate_name"] == "mp5"
    assert row["smooth_extrema_survivor_audit_enabled"] is True
    assert row["candidate_unavailable_reason"].startswith(
        "candidate_unavailable")
    assert row["material_active_candidate_count"] == 0


def test_cicsam_thinc_components_reconstruct_faces_and_do_not_mutate():
    psi = np.array([1.0, 0.95, 0.5, 0.05, 0.0], dtype=float)
    psi_ext = np.pad(psi, (2, 2), mode="edge")
    psi_ext_before = psi_ext.copy()
    u_face = np.array([0.0, 0.4, 0.3, -0.2, -0.1, 0.0], dtype=float)
    cicsam = cicsam_face_components(psi_ext, u_face, 1.0e-4, 0.01)
    thinc = thinc_face_components(psi_ext, u_face, 1.0e-4, 0.01)
    np.testing.assert_allclose(
        cicsam["psi_face"], cicsam_face(psi_ext, u_face, 1.0e-4, 0.01))
    np.testing.assert_allclose(
        thinc["psi_face"], thinc_face(psi_ext, u_face, 1.0e-4, 0.01))
    np.testing.assert_allclose(psi_ext, psi_ext_before)

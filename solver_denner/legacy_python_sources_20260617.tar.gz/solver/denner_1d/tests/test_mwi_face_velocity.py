import numpy as np
from solver.denner_1d import solver_a
from solver.denner_1d.flux.mwi import (
    bounded_mwi_pressure_delta,
    geometric_face_density,
    harmonic_face_density,
    material_blended_mwi_density,
    overdrive_gated_mwi_density,
)
from solver.denner_1d.solver_a import (
    _compute_face_velocity,
    _mwi_rho_star_face,
    _mwi_face_transient_correction_enabled,
)


def test_bounded_mwi_pressure_delta_zero_is_null():
    out = bounded_mwi_pressure_delta(
        0.0, 0.1, 0.25, 0.0, 0.0, 0.0,
        rho_L=1.0, rho_R=1.0, c_L=10.0, c_R=10.0)

    assert out['delta_p_limited'] == 0.0
    assert out['limiter_phi'] == 1.0
    assert out['d_hat_eff'] == 0.1


def test_bounded_mwi_pressure_delta_small_correction_is_identity_like():
    out = bounded_mwi_pressure_delta(
        1.0e-4, 0.2, 0.5, 1.0, 0.8, 1.2,
        rho_L=2.0, rho_R=3.0, c_L=100.0, c_R=80.0)

    assert 0.999 < out['limiter_phi'] <= 1.0
    np.testing.assert_allclose(out['delta_p_limited'], 1.0e-4, rtol=1.0e-3)
    assert out['delta_p_limited'] > 0.0


def test_bounded_mwi_pressure_delta_large_overdrive_is_sign_preserving_and_bounded():
    pos = bounded_mwi_pressure_delta(
        50.0, 0.01, 0.1, 0.2, -0.1, 0.3,
        rho_L=1.0, rho_R=1000.0, c_L=300.0, c_R=1400.0)
    neg = bounded_mwi_pressure_delta(
        -50.0, 0.01, 0.1, 0.2, -0.1, 0.3,
        rho_L=1.0, rho_R=1000.0, c_L=300.0, c_R=1400.0)

    assert 0.0 < pos['limiter_phi'] < 1.0
    assert 0.0 < neg['limiter_phi'] < 1.0
    assert pos['delta_p_limited'] > 0.0
    assert neg['delta_p_limited'] < 0.0
    assert abs(pos['delta_p_limited']) <= 1.01 * pos['U_ref']
    assert abs(neg['delta_p_limited']) <= 1.01 * neg['U_ref']
    np.testing.assert_allclose(pos['limiter_phi'], neg['limiter_phi'])


def test_bounded_mwi_pressure_delta_acoustic_scale_allows_pressure_jump():
    out = bounded_mwi_pressure_delta(
        0.5, 1.0e-4, 0.01, 0.0, 0.0, 0.0,
        rho_L=1.0, rho_R=1.0, c_L=1000.0, c_R=1000.0)

    assert out['U_bar'] == 0.0
    assert out['U_jump'] == 0.0
    assert out['U_ac'] > 0.0
    assert out['U_ref'] > 0.0
    assert out['delta_p_limited'] > 0.0


def test_mwi_face_transient_correction_is_explicit_opt_in():
    assert _mwi_face_transient_correction_enabled({}) is False
    assert _mwi_face_transient_correction_enabled({'mwi_transient': True}) is False
    assert _mwi_face_transient_correction_enabled({'mwi_transient': False}) is False
    assert _mwi_face_transient_correction_enabled({
        'mwi_face_transient_correction': True,
    }) is True
    assert _mwi_face_transient_correction_enabled({
        'mwi_transient': True,
        'mwi_face_transient_correction': False,
    }) is False


def test_material_blended_mwi_density_same_composition_is_harmonic():
    rho = np.array([1.0, 3.0, 9.0, 27.0], dtype=float)
    psi = np.full(rho.size, 0.25, dtype=float)

    (
        blended, harmonic, geometric, direct_weight, weight, neighborhood_weight,
    ) = material_blended_mwi_density(
        rho, psi, 'transmissive', 'transmissive', return_components=True)

    np.testing.assert_allclose(blended, harmonic, atol=0.0, rtol=0.0)
    np.testing.assert_allclose(
        blended, harmonic_face_density(rho, 'transmissive', 'transmissive'),
        atol=0.0, rtol=0.0)
    assert np.all(direct_weight == 0.0)
    assert np.all(weight == 0.0)
    assert np.all(neighborhood_weight == 0.0)
    assert np.all(np.isfinite(geometric))


def test_material_blended_mwi_density_unit_jump_is_direct_production():
    rho = np.array([1.0, 1.0, 1000.0, 1000.0], dtype=float)
    psi = np.array([0.0, 0.0, 1.0, 1.0], dtype=float)

    (
        blended, harmonic, geometric, direct_weight, weight, neighborhood_weight,
    ) = material_blended_mwi_density(
        rho, psi, 'transmissive', 'transmissive', return_components=True)

    interface_face = 2
    assert direct_weight[interface_face] == 1.0
    assert weight[interface_face] == 1.0
    assert weight[interface_face - 1] == 0.0
    assert weight[interface_face + 1] == 0.0
    assert neighborhood_weight[interface_face - 1] == 1.0
    assert neighborhood_weight[interface_face] == 1.0
    assert neighborhood_weight[interface_face + 1] == 1.0
    np.testing.assert_allclose(
        blended[interface_face], geometric_face_density(
            rho, 'transmissive', 'transmissive')[interface_face])
    assert blended[interface_face] > harmonic[interface_face]


def test_material_blended_mwi_density_partial_jump_is_bounded():
    rho = np.array([1.0, 100.0], dtype=float)
    psi = np.array([0.25, 0.75], dtype=float)

    (
        blended, harmonic, geometric, direct_weight, weight, neighborhood_weight,
    ) = material_blended_mwi_density(
        rho, psi, 'transmissive', 'transmissive', return_components=True)

    interface_face = 1
    assert direct_weight[interface_face] == 0.5
    assert weight[interface_face] == 0.5
    assert neighborhood_weight[interface_face] == 0.5
    assert harmonic[interface_face] < blended[interface_face] < geometric[interface_face]
    assert np.isfinite(blended[interface_face])
    expected = 0.5 * harmonic[interface_face] + 0.5 * geometric[interface_face]
    np.testing.assert_allclose(blended[interface_face], expected)


def test_material_blended_mwi_density_same_density_reduces_to_density():
    rho = np.full(6, 7.0, dtype=float)
    psi = np.array([0.0, 0.0, 0.3, 0.7, 1.0, 1.0], dtype=float)

    (
        blended, harmonic, geometric, direct_weight, weight, neighborhood_weight,
    ) = material_blended_mwi_density(
        rho, psi, 'transmissive', 'transmissive', return_components=True)

    np.testing.assert_allclose(harmonic, 7.0)
    np.testing.assert_allclose(geometric, 7.0)
    np.testing.assert_allclose(blended, 7.0)
    assert np.all((0.0 <= direct_weight) & (direct_weight <= 1.0))
    assert np.all((0.0 <= weight) & (weight <= 1.0))
    assert np.all((0.0 <= neighborhood_weight) & (neighborhood_weight <= 1.0))


def test_material_blended_mwi_density_neighborhood_is_diagnostic_only():
    def _step_weights(n):
        rho = np.ones(n, dtype=float)
        rho[n // 2:] = 1000.0
        psi = np.zeros(n, dtype=float)
        psi[n // 2:] = 1.0
        _, _, _, direct_weight, weight, neighborhood_weight = material_blended_mwi_density(
            rho, psi, 'transmissive', 'transmissive', return_components=True)
        return direct_weight, weight, neighborhood_weight

    for n in (8, 16):
        direct_weight, weight, neighborhood_weight = _step_weights(n)
        interface_face = n // 2
        expected_direct = np.zeros(n + 1, dtype=float)
        expected_direct[interface_face] = 1.0
        expected_neighborhood = np.zeros(n + 1, dtype=float)
        expected_neighborhood[interface_face - 1:interface_face + 2] = 1.0
        np.testing.assert_allclose(weight, expected_direct)
        np.testing.assert_allclose(neighborhood_weight, expected_neighborhood)
        assert direct_weight[interface_face] == 1.0
        assert np.count_nonzero(direct_weight) == 1


def test_overdrive_gated_mwi_density_inactive_matches_round6_direct_blend():
    rho = np.array([1.0, 10.0, 1000.0, 1000.0], dtype=float)
    c_mix = np.full_like(rho, 1000.0)
    psi = np.array([0.0, 1.0e-3, 1.0, 1.0], dtype=float)
    u = np.zeros_like(rho)
    p = np.zeros_like(rho)
    e_diag = rho / 0.1

    data = overdrive_gated_mwi_density(
        rho, c_mix, psi, u, p, e_diag, 1.0, 0.1,
        'transmissive', 'transmissive', return_components=True)

    np.testing.assert_allclose(data['activation'], 0.0, atol=0.0, rtol=0.0)
    np.testing.assert_allclose(data['rho_star'], data['rho_direct'])
    np.testing.assert_allclose(data['effective_weight'], data['direct_weight'])


def test_overdrive_gated_mwi_density_pure_face_stays_harmonic_under_large_sensor():
    rho = np.array([2.0, 4.0, 8.0, 16.0], dtype=float)
    c_mix = np.full_like(rho, 100.0)
    psi = np.full_like(rho, 0.25)
    u = np.zeros_like(rho)
    p = np.array([0.0, 1.0e6, -1.0e6, 0.0], dtype=float)
    e_diag = rho / 1.0

    data = overdrive_gated_mwi_density(
        rho, c_mix, psi, u, p, e_diag, 0.1, 1.0,
        'transmissive', 'transmissive', return_components=True)

    harmonic = harmonic_face_density(rho, 'transmissive', 'transmissive')
    np.testing.assert_allclose(data['direct_weight'], 0.0)
    np.testing.assert_allclose(data['neighborhood_weight'], 0.0)
    np.testing.assert_allclose(data['rho_star'], harmonic)


def test_overdrive_gated_mwi_density_adjacent_interface_raises_rho_and_lowers_dhat():
    rho = np.array([1.0, 10.0, 1000.0, 1000.0], dtype=float)
    c_mix = np.full_like(rho, 1000.0)
    psi = np.array([0.0, 1.0e-3, 1.0, 1.0], dtype=float)
    u = np.zeros_like(rho)
    p = np.array([0.0, 1.0e6, 1.0e6, 1.0e6], dtype=float)
    dx = 0.1
    dt = 1.0
    e_diag = rho / dt

    data = overdrive_gated_mwi_density(
        rho, c_mix, psi, u, p, e_diag, dx, dt,
        'transmissive', 'transmissive', return_components=True)

    adjacent_face = 1
    assert data['direct_weight'][adjacent_face] < 0.01
    assert data['neighborhood_weight'][adjacent_face] > data['direct_weight'][adjacent_face]
    assert data['overdrive_r'][adjacent_face] > 1.0
    assert data['activation'][adjacent_face] > 0.0
    assert data['rho_star'][adjacent_face] > data['rho_direct'][adjacent_face]
    assert data['rho_star'][adjacent_face] <= data['rho_neighborhood'][adjacent_face]
    assert data['d_hat_eff'][adjacent_face] < data['d_hat_direct'][adjacent_face]
    assert np.sign(data['delta_eff'][adjacent_face]) == np.sign(data['delta_direct'][adjacent_face])


def test_mwi_rho_star_selector_keeps_acid_explicit_and_harmonic_blended():
    rho = np.array([1.0, 1000.0], dtype=float)
    c_mix = np.ones_like(rho)
    psi = np.array([0.0, 1.0], dtype=float)

    (
        selected, harmonic, geometric, direct_weight, weight, neighborhood_weight,
    ) = _mwi_rho_star_face(
        rho, c_mix, psi, 'transmissive', 'transmissive',
        mode='harmonic', return_components=True)
    acid = _mwi_rho_star_face(
        rho, c_mix, psi, 'transmissive', 'transmissive', mode='acid')

    assert direct_weight[1] == 1.0
    assert weight[1] == 1.0
    np.testing.assert_allclose(weight, direct_weight)
    assert np.all(neighborhood_weight >= weight)
    np.testing.assert_allclose(selected[1], geometric[1])
    assert selected[1] > harmonic[1]
    assert acid[1] != selected[1]


def test_transient_mwi_removes_linear_pressure_gradient_forcing():
    N = 12
    dx = 0.25
    u = np.full(N, 0.125, dtype=float)
    p = 2.0e5 + 37.0 * dx * np.arange(N, dtype=float)
    rho = np.full(N, 3.0, dtype=float)
    rho_star = np.full(N + 1, 3.0, dtype=float)
    d_hat = np.full(N + 1, 0.2, dtype=float)

    theta_transient, u_bar = _compute_face_velocity(
        u, p, d_hat, dx, 'transmissive', 'transmissive',
        rho_cell=rho,
        rho_star_face=rho_star,
        include_transient_correction=True,
    )
    theta_plain, _ = _compute_face_velocity(
        u, p, d_hat, dx, 'transmissive', 'transmissive',
        rho_cell=rho,
        rho_star_face=rho_star,
        include_transient_correction=False,
    )

    interior = slice(2, N - 1)
    np.testing.assert_allclose(theta_transient[interior], u_bar[interior],
                               atol=1.0e-12, rtol=0.0)
    assert np.max(np.abs(theta_plain[interior] - u_bar[interior])) > 1.0


def test_mwi_bounded_limiter_updates_production_theta_and_coefficient():
    N = 4
    dx = 0.1
    u = np.zeros(N, dtype=float)
    p = np.array([0.0, 1000.0, -1000.0, 0.0], dtype=float)
    rho = np.ones(N, dtype=float)
    c_mix = np.full(N, 100.0, dtype=float)
    d_hat = np.full(N + 1, 0.01, dtype=float)

    theta_plain, u_bar_plain = _compute_face_velocity(
        u, p, d_hat, dx, 'transmissive', 'transmissive',
        rho_cell=rho, c_mix=c_mix,
        include_transient_correction=False,
    )
    theta_diag, u_bar_diag, d_hat_prod, mwi_data = _compute_face_velocity(
        u, p, d_hat, dx, 'transmissive', 'transmissive',
        rho_cell=rho, c_mix=c_mix,
        include_transient_correction=False,
        return_mwi_data=True,
    )

    np.testing.assert_allclose(theta_diag, theta_plain, atol=0.0, rtol=0.0)
    np.testing.assert_allclose(u_bar_diag, u_bar_plain, atol=0.0, rtol=0.0)
    assert np.any(np.abs(mwi_data['delta_limited']) < np.abs(mwi_data['delta_unbounded']))
    np.testing.assert_allclose(
        d_hat_prod,
        d_hat * mwi_data['limiter_phi'],
        atol=1.0e-15,
        rtol=1.0e-15,
    )
    np.testing.assert_allclose(
        theta_diag - u_bar_diag,
        mwi_data['delta_limited'],
        atol=1.0e-15,
        rtol=1.0e-15,
    )


def test_return_transient_terms_is_passive_when_transient_correction_disabled():
    N = 8
    dx = 0.5
    u = np.linspace(-0.1, 0.2, N)
    p = 1.0e5 + 50.0 * np.arange(N, dtype=float)
    rho = np.full(N, 2.0, dtype=float)
    rho_star = np.full(N + 1, 2.0, dtype=float)
    d_hat = np.full(N + 1, 0.05, dtype=float)

    theta_plain, u_bar_plain = _compute_face_velocity(
        u, p, d_hat, dx, 'transmissive', 'transmissive',
        rho_cell=rho,
        rho_star_face=rho_star,
        include_transient_correction=False,
    )
    theta_terms, u_bar_terms, be_term, bdf2_term = _compute_face_velocity(
        u, p, d_hat, dx, 'transmissive', 'transmissive',
        rho_cell=rho,
        rho_star_face=rho_star,
        return_transient_terms=True,
        include_transient_correction=False,
    )

    np.testing.assert_allclose(theta_terms, theta_plain, atol=0.0, rtol=0.0)
    np.testing.assert_allclose(u_bar_terms, u_bar_plain, atol=0.0, rtol=0.0)
    np.testing.assert_allclose(be_term, 0.0, atol=0.0, rtol=0.0)
    np.testing.assert_allclose(bdf2_term, 0.0, atol=0.0, rtol=0.0)


def test_transient_mwi_component_terms_reconstruct_full_theta():
    N = 8
    dx = 0.5
    dt = 0.01
    dt_prev = 0.012
    u = np.linspace(-0.2, 0.3, N)
    p = 1.0e5 + 12.0 * np.arange(N, dtype=float)
    rho = np.full(N, 2.0, dtype=float)
    rho_star = np.full(N + 1, 2.0, dtype=float)
    d_hat = np.full(N + 1, 0.05, dtype=float)
    theta_old = np.full(N + 1, 0.11, dtype=float)
    u_bar_old = np.full(N + 1, 0.08, dtype=float)
    theta_nm1 = np.full(N + 1, 0.09, dtype=float)
    u_bar_nm1 = np.full(N + 1, 0.07, dtype=float)

    theta_grad_only, _ = _compute_face_velocity(
        u, p, d_hat, dx, 'transmissive', 'transmissive',
        rho_cell=rho,
        rho_star_face=rho_star,
        include_transient_correction=True,
    )
    theta_full, _, be_term, bdf2_term = _compute_face_velocity(
        u, p, d_hat, dx, 'transmissive', 'transmissive',
        theta_old=theta_old,
        u_bar_old=u_bar_old,
        rho_star_old=rho_star,
        dt=dt,
        rho_cell=rho,
        rho_star_face=rho_star,
        theta_nm1=theta_nm1,
        u_bar_nm1=u_bar_nm1,
        rho_star_nm1=rho_star,
        dt_prev=dt_prev,
        return_transient_terms=True,
        include_transient_correction=True,
    )

    np.testing.assert_allclose(theta_full, theta_grad_only + be_term + bdf2_term,
                               atol=1.0e-12, rtol=0.0)


def test_r40_mwi_component_diag_emit_path_records_rows():
    old_face_enabled = solver_a._R40_FACE_COMPAT_DIAG_ENABLED
    old_component_enabled = solver_a._R40_MWI_COMPONENT_DIAG_ENABLED
    try:
        solver_a._R40_FACE_COMPAT_DIAG_ENABLED = True
        solver_a._R40_MWI_COMPONENT_DIAG_ENABLED = True
        solver_a.reset_solver_a_face_compat_diag()
        N = 5
        faces = N + 1
        psi = np.array([1.0, 1.0, 0.0, 0.0, 0.0])
        p = np.linspace(1.0e5, 1.01e5, N)
        u = np.linspace(0.0, 0.2, N)
        theta_plain = np.linspace(0.01, 0.06, faces)
        theta_grad = theta_plain + np.linspace(0.0, 0.03, faces)
        be_term = np.full(faces, 0.002)
        bdf2_term = np.full(faces, -0.001)
        theta_full = theta_grad + be_term + bdf2_term
        u_bar = np.linspace(0.0, 0.05, faces)

        solver_a._emit_r40_face_compat_rows(
            step_index=3,
            iter_index=1,
            psi_new=psi,
            p_new=p,
            u_new=u,
            u_face_vof=theta_full,
            theta_k=theta_full,
            u_bar_k=u_bar,
            theta_old=None,
            theta_nm1=None,
            u_bar_old=None,
            u_bar_nm1=None,
            d_hat=np.full(faces, 0.1),
            rho_face_acid=np.full(faces, 2.0),
            rho_star_acid=np.full(faces, 2.5),
            rho_star_mode='harmonic',
            rho_star_harmonic=np.full(faces, 2.0),
            rho_star_geometric=np.full(faces, 3.0),
            rho_star_direct_jump_weight=np.linspace(0.0, 0.5, faces),
            rho_star_blend_weight=np.linspace(0.0, 1.0, faces),
            rho_star_neighborhood_weight=np.linspace(0.0, 1.0, faces),
            rho_star_direct=np.full(faces, 2.5),
            rho_star_neighborhood=np.full(faces, 3.0),
            mwi_overdrive_r=np.full(faces, 1.5),
            mwi_overdrive_activation=np.full(faces, 0.25),
            d_hat_direct=np.full(faces, 0.2),
            d_hat_eff=np.full(faces, 0.1),
            mwi_pressure_velocity_delta_direct=np.full(faces, -0.02),
            mwi_pressure_velocity_delta_eff=np.full(faces, -0.01),
            mwi_pressure_velocity_delta_unbounded=np.full(faces, -0.02),
            mwi_pressure_velocity_delta_limited=np.full(faces, -0.01),
            mwi_limiter_phi=np.full(faces, 0.5),
            mwi_limiter_U_ref=np.full(faces, 0.03),
            mwi_limiter_U_ac=np.full(faces, 0.02),
            mwi_limiter_U_bar=np.full(faces, 0.01),
            mwi_limiter_U_jump=np.full(faces, 0.04),
            mwi_limiter_r=np.full(faces, 2.0),
            d_hat_unbounded=np.full(faces, 0.2),
            rho_cell=np.linspace(1.0, 5.0, N),
            c_mix=np.linspace(10.0, 20.0, N),
            dx=0.25,
            be_term=be_term,
            bdf2_term=bdf2_term,
            dt=1.0e-4,
            dt_prev=None,
            mwi_dt=1.0e-4,
            bdf_order_eff=1,
            is_first_step=False,
            p_floor_count=0,
            theta_plain=theta_plain,
            theta_grad_only=theta_grad,
            theta_full=theta_full,
            theta_production=theta_plain,
        )

        diag = solver_a.get_solver_a_face_compat_diag()
        assert diag['row_count'] > 0
        row = diag['rows'][0]
        assert row['rho_star_mode'] == 'harmonic_interface_geometric_blend'
        for key in (
            'theta_plain',
            'theta_grad_only',
            'theta_full',
            'theta_production',
            'theta_grad_delta',
            'theta_history_delta',
            'is_material_face',
            'p_L',
            'p_R',
            'u_L',
            'u_R',
            'rho_star_harmonic',
            'rho_star_geometric',
            'rho_star_direct_jump_weight',
            'rho_star_blend_weight',
            'rho_star_neighborhood_weight',
            'rho_star_direct',
            'rho_star_neighborhood',
            'rho_star_eff',
            'rho_star_effective_weight',
            'mwi_overdrive_r',
            'mwi_overdrive_activation',
            'd_hat_direct',
            'd_hat_eff',
            'mwi_pressure_velocity_delta_direct',
            'mwi_pressure_velocity_delta_eff',
            'rho_star_minus_harmonic',
            'rho_star_over_harmonic',
            'dpdx_face',
            'mwi_pressure_coeff',
            'mwi_pressure_velocity_delta',
            'mwi_pressure_velocity_delta_unbounded',
            'mwi_pressure_velocity_delta_bounded',
            'mwi_limiter_phi',
            'mwi_limiter_U_ref',
            'mwi_limiter_U_ac',
            'mwi_limiter_U_bar',
            'mwi_limiter_U_jump',
            'mwi_limiter_r',
            'mwi_delta_over_scale',
            'd_hat_unbounded',
            'mwi_delta_over_ubar',
            'mwi_delta_over_u_jump',
            'face_x',
            'dx',
            'dt_over_dx',
            'c_left',
            'c_right',
            'z_left',
            'z_right',
            'z_ratio',
            'acoustic_cfl_face',
            'advective_cfl_face',
        ):
            assert key in row
        assert row['mwi_pressure_velocity_delta_unbounded'] == -0.02
        assert row['mwi_pressure_velocity_delta_bounded'] == -0.01
        assert row['mwi_limiter_phi'] == 0.5
        assert row['mwi_delta_over_scale'] == 2.0
        assert row['d_hat_unbounded'] == 0.2
        assert row['mwi_overdrive_activation'] == 0.25
        assert row['mwi_pressure_velocity_delta_eff'] == -0.01
    finally:
        solver_a._R40_FACE_COMPAT_DIAG_ENABLED = old_face_enabled
        solver_a._R40_MWI_COMPONENT_DIAG_ENABLED = old_component_enabled
        solver_a.reset_solver_a_face_compat_diag()

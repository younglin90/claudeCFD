import numpy as np
import scipy.sparse.linalg as spla

from solver.denner_1d import assembly as denner_assembly
from solver.denner_1d.config import PHASE_AIR, PHASE_WATER_LIQUID
from solver.denner_1d.eos.base import (compute_mixture_props,
                                       compute_specific_total_enthalpy)
from solver.denner_1d.flux.mwi import (acid_face_density, harmonic_face_density,
                                       mwi_face_coeff_denner)
from solver.denner_1d.linsolve import solve_block_tridiagonal_3n


def _uniform_state(N=8):
    p0 = 1.5e5
    T0 = 300.0
    u0 = 0.0
    psi0 = 0.35
    bc = 'periodic'
    ph1 = PHASE_AIR
    ph2 = PHASE_WATER_LIQUID

    p = np.full(N, float(p0), dtype=float)
    u = np.full(N, float(u0), dtype=float)
    T = np.full(N, float(T0), dtype=float)
    psi = np.full(N, float(psi0), dtype=float)

    props = compute_mixture_props(p, u, T, psi, ph1, ph2)
    rho = props['rho']
    zeta_v = props['zeta_v']
    phi_v = props['phi_v']
    c_mix = props['c_mix']
    h = compute_specific_total_enthalpy(p, u, T, psi, ph1, ph2)

    return {
        'N': N,
        'dx': 1.0,
        'dt': 1.0e-4,
        'p': p,
        'u': u,
        'T': T,
        'psi': psi,
        'rho': rho,
        'zeta_v': zeta_v,
        'phi_v': phi_v,
        'c_mix': c_mix,
        'h': h,
        'ph1': ph1,
        'ph2': ph2,
        'bc_l': bc,
        'bc_r': bc,
    }


def _material_interface_state(N=16):
    state = _uniform_state(N)
    psi = np.zeros(N, dtype=float)
    psi[:N // 2] = 1.0
    state['psi'] = psi
    props = compute_mixture_props(state['p'], state['u'], state['T'], psi,
                                 state['ph1'], state['ph2'])
    state['rho'] = props['rho']
    state['zeta_v'] = props['zeta_v']
    state['phi_v'] = props['phi_v']
    state['c_mix'] = props['c_mix']
    state['h'] = compute_specific_total_enthalpy(
        state['p'], state['u'], state['T'], psi, state['ph1'], state['ph2'])
    return state


def _periodic_face_average(q):
    q = np.asarray(q, dtype=float)
    return 0.5 * (np.concatenate(([q[-1]], q))
                  + np.concatenate((q, [q[0]])))


def _assembly_arrays(state):
    N = state['N']
    rho = state['rho']
    bc_l = state['bc_l']
    bc_r = state['bc_r']
    c_mix = compute_mixture_props(state['p'], state['u'], state['T'],
                                 state['psi'], state['ph1'], state['ph2'])['c_mix']
    rho_face = acid_face_density(rho, c_mix, state['psi'], bc_l, bc_r)
    e_diag = rho / state['dt']
    rho_star = harmonic_face_density(rho, bc_l, bc_r)
    d_hat = mwi_face_coeff_denner(e_diag, rho_star, state['dx'], state['dt'],
                                 bc_l, bc_r)
    return rho_face, d_hat, np.zeros(N + 1, dtype=float)


def _disable_noisy_diagnostics():
    """Keep diagnostics out of the compile-only unit checks."""
    denner_assembly._R71_HOMOGENEOUS_ACOUSTIC_AUDIT = False
    denner_assembly._DIAG_ENABLED = False
    denner_assembly._R42_ASSEMBLY_COMPAT_DIAG = 0
    denner_assembly._R42_ASSEMBLY_ENERGY_DIAG = 0
    denner_assembly._R42_ASSEMBLY_COMPACT = 0
    denner_assembly._R42_ASSEMBLY_COMPAT_TOPK = 0
    denner_assembly._R57_FACE_STATE_COMPAT_AUDIT = False
    denner_assembly._R60_INTERNAL_ENERGY_PRODUCT_RULE_AUDIT = False
    denner_assembly._R62_MWI_DM_DP_ALIGNMENT_DIAG = False
    denner_assembly._R65_COUPLED_MASS_ENERGY_BLOCK_AUDIT = False
    denner_assembly._R67_PEP_COMPAT_RESIDUAL_AUDIT = False
    denner_assembly._R68_PEP_INTERNAL_FLUX_RESIDUAL = False
    denner_assembly._R69_R68_ALGEBRA_AUDIT = False
    denner_assembly._R69_CORRECTED_PEP_INTERNAL_FLUX_RESIDUAL = False
    denner_assembly._R70_PEP_H_BLOCK_JAC_AUDIT = False
    denner_assembly._R70_PEP_H_BLOCK_LINEARIZED = False


def test_assemble_newton_3N_null_mode_h_transport_face():
    state = _uniform_state(10)
    _disable_noisy_diagnostics()
    rho_face, d_hat, theta = _assembly_arrays(state)
    x = np.concatenate([state['p'], state['u'], state['h']])
    A, b = denner_assembly.assemble_newton_3N(
        state['N'], state['dx'], state['dt'],
        state['rho'], state['u'], state['h'], state['p'],
        state['rho'], state['u'], state['h'], state['p'], state['T'],
        state['psi'], state['zeta_v'], rho_face, d_hat, theta,
        state['ph1'], state['ph2'], state['bc_l'], state['bc_r'],
        third_var='h', mixing_type='volume',
        psi_face_transport=np.full(state['N'] + 1, float(state['psi'][0]), dtype=float),
    )
    # transport_face_enthalpy is active when psi_face_transport is provided.
    r = b - A.dot(x)
    p_ref = float(state['p'][0])
    assert np.linalg.norm(r[:state['N']], ord=np.inf) < 1.0e-8
    assert np.linalg.norm(r[state['N']:2 * state['N']], ord=np.inf) < 1.0e-8
    assert np.linalg.norm(r[2 * state['N']:], ord=np.inf) < 1.0e-7 * max(1.0, p_ref)


def test_assemble_newton_3N_null_mode_T_transport_face():
    state = _uniform_state(10)
    _disable_noisy_diagnostics()
    rho_face, d_hat, theta = _assembly_arrays(state)
    x = np.concatenate([state['p'], state['u'], state['T']])
    A, b = denner_assembly.assemble_newton_3N(
        state['N'], state['dx'], state['dt'],
        state['rho'], state['u'], state['h'], state['p'],
        state['rho'], state['u'], state['h'], state['p'], state['T'],
        state['psi'], state['zeta_v'], rho_face, d_hat, theta,
        state['ph1'], state['ph2'], state['bc_l'], state['bc_r'],
        third_var='T', T_old=state['T'], phi_k=state['phi_v'],
        mixing_type='volume',
        psi_face_transport=np.full(state['N'] + 1, float(state['psi'][0]), dtype=float),
    )
    r = b - A.dot(x)
    p_ref = float(state['p'][0])
    assert np.linalg.norm(r[:state['N']], ord=np.inf) < 1.0e-8
    assert np.linalg.norm(r[state['N']:2 * state['N']], ord=np.inf) < 1.0e-8
    assert np.linalg.norm(r[2 * state['N']:], ord=np.inf) < 1.0e-7 * max(1.0, p_ref)


def test_assemble_newton_3N_material_interface_null_mode_acoustic():
    state = _material_interface_state(16)
    _disable_noisy_diagnostics()
    rho_face, d_hat, theta = _assembly_arrays(state)
    material_faces = np.flatnonzero(
        np.abs(np.concatenate((state['psi'], [state['psi'][0]]))
               - np.concatenate(([state['psi'][-1]], state['psi']))) > 1.0e-12
    )
    assert material_faces.size > 0

    x = np.concatenate([state['p'], state['u'], state['T']])
    A, b = denner_assembly.assemble_newton_3N(
        state['N'], state['dx'], state['dt'],
        state['rho'], state['u'], state['h'], state['p'],
        state['rho'], state['u'], state['h'], state['p'], state['T'],
        state['psi'], state['zeta_v'], rho_face, d_hat, theta,
        state['ph1'], state['ph2'], state['bc_l'], state['bc_r'],
        third_var='T', T_old=state['T'], phi_k=state['phi_v'],
        mixing_type='volume',
        psi_face_transport=_periodic_face_average(state['psi']),
        acoustic_face_correction=True,
        c_mix=state['c_mix'],
    )
    r = b - A.dot(x)
    p_ref = float(state['p'][0])
    assert np.linalg.norm(r[:state['N']], ord=np.inf) < 1.0e-8
    assert np.linalg.norm(r[state['N']:2 * state['N']], ord=np.inf) < 1.0e-8
    assert np.linalg.norm(r[2 * state['N']:], ord=np.inf) < 1.0e-7 * max(1.0, p_ref)


def test_assemble_newton_3N_block_solver_matches_direct_on_assembled_matrix():
    state = _material_interface_state(16)
    state['bc_l'] = 'transmissive'
    state['bc_r'] = 'transmissive'
    _disable_noisy_diagnostics()
    rho_face, d_hat, theta = _assembly_arrays(state)
    A, b = denner_assembly.assemble_newton_3N(
        state['N'], state['dx'], state['dt'],
        state['rho'], state['u'], state['h'], state['p'],
        state['rho'], state['u'], state['h'], state['p'], state['T'],
        state['psi'], state['zeta_v'], rho_face, d_hat, theta,
        state['ph1'], state['ph2'], state['bc_l'], state['bc_r'],
        third_var='T', T_old=state['T'], phi_k=state['phi_v'],
        mixing_type='volume',
        psi_face_transport=_periodic_face_average(state['psi']),
        acoustic_face_correction=True,
        c_mix=state['c_mix'],
    )
    x = np.linspace(-1.0, 1.0, 3 * state['N'])
    rhs = A.dot(x)
    got = solve_block_tridiagonal_3n(A, rhs)
    ref = spla.spsolve(A.tocsc(), rhs)
    np.testing.assert_allclose(got, ref, rtol=1.0e-9, atol=1.0e-9)


def test_residual_4N_null_mode():
    state = _uniform_state(10)
    _disable_noisy_diagnostics()
    x4 = np.concatenate([state['p'], state['u'], state['T'], state['psi']])
    r = denner_assembly.residual_4N(
        x4, state['N'], state['dx'], state['dt'],
        state['rho'], state['u'], state['h'], state['p'], state['psi'],
        state['ph1'], state['ph2'], state['bc_l'], state['bc_r'],
        third_var='T',
        mixing_type='volume',
        use_acid=True,
    )
    assert np.linalg.norm(r, ord=np.inf) < 1.0e-12

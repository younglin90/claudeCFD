import os
import subprocess
import sys


def test_pep_flux_compat_audit_enables_selected_diag_schema():
    env = os.environ.copy()
    env['DENNER_PEP_FLUX_COMPAT_AUDIT'] = '1'
    env['DENNER_PEP_FLUX_TARGETED_PACKET_AUDIT'] = '1'
    code = (
        "import solver.denner_1d.assembly as a; "
        "assert a._PEP_FLUX_COMPAT_AUDIT is True; "
        "assert a._PEP_FLUX_TARGETED_PACKET_AUDIT is True; "
        "assert a._PROD_FLUX_DIAG_ENABLED is True; "
        "a.reset_prod_flux_diag(); "
        "assert a.PROD_FLUX_DIAG['pep_flux_compat_audit_enabled'] is True; "
        "assert a._pep_target_info({'step_index': 1, 'face': 60}) is None; "
        "target = a._pep_target_info({'step_index': 609, 'face': 60, "
        "'material_jump': False, 'prod_char_acoustic_face': True}); "
        "assert target is not None; "
        "assert target['pep_target_window'] == 'interface'"
    )
    subprocess.run([sys.executable, '-c', code], env=env, check=True)


def test_pep_material_acid_carrier_audit_schema_is_passive():
    env = os.environ.copy()
    env['DENNER_PEP_FLUX_COMPAT_AUDIT'] = '1'
    env['DENNER_PEP_FLUX_TARGETED_PACKET_AUDIT'] = '1'
    env['DENNER_PEP_MATERIAL_ACID_CARRIER_AUDIT'] = '1'
    code = (
        "import solver.denner_1d.assembly as a; "
        "assert a._PEP_MATERIAL_ACID_CARRIER_AUDIT is True; "
        "assert sorted(a._PEP_FLUX_TARGETED_STEPS) == [609, 650, 700]; "
        "a.reset_prod_flux_diag(); "
        "assert a.PROD_FLUX_DIAG['pep_material_acid_carrier_audit_enabled'] "
        "is True; "
        "target = a._pep_target_info({'step_index': 700, 'face': 60, "
        "'material_jump': True}); "
        "assert target is not None; "
        "assert target['pep_target_face_class'] == 'material'"
    )
    subprocess.run([sys.executable, '-c', code], env=env, check=True)


def test_acoustic_limiter_candidate_audit_target_schema():
    env = os.environ.copy()
    env['DENNER_ACOUSTIC_LIMITER_CANDIDATE_AUDIT'] = '1'
    code = (
        "import solver.denner_1d.assembly as a; "
        "assert a._ACOUSTIC_LIMITER_CANDIDATE_AUDIT is True; "
        "assert a._PROD_FLUX_DIAG_ENABLED is True; "
        "a.reset_prod_flux_diag(); "
        "assert a.PROD_FLUX_DIAG['acoustic_limiter_candidate_audit_enabled'] "
        "is True; "
        "assert a._acoustic_limiter_target_info({'step_index': 1, "
        "'face': 60}) is None; "
        "target = a._acoustic_limiter_target_info({'step_index': 609, "
        "'face': 60, 'prod_material_jump': False, "
        "'prod_char_acoustic_face': True}); "
        "assert target is not None; "
        "assert target['acoustic_limiter_window'] == 'interface'; "
        "assert target['acoustic_limiter_face_class'] == "
        "'same_material_acoustic'"
    )
    subprocess.run([sys.executable, '-c', code], env=env, check=True)


def test_acoustic_limiter_admissible_policy_rejections_and_selection():
    from solver.denner_1d.assembly import (
        _select_admissible_acoustic_limiter_candidate,
    )

    current = {"BV": 10.0, "opposite": 0.25}

    selected, counts = _select_admissible_acoustic_limiter_candidate(
        current,
        [{"name": "vanleer", "BV": 1.0, "opposite": 0.1,
          "primitive_minmax_ok": False, "characteristic_minmax_ok": True}],
    )
    assert selected == "current"
    assert counts["rejected_minmax_count"] == 1

    selected, counts = _select_admissible_acoustic_limiter_candidate(
        current,
        [{"name": "vanleer", "BV": 1.0, "opposite": 0.3,
          "primitive_minmax_ok": True, "characteristic_minmax_ok": True}],
    )
    assert selected == "current"
    assert counts["rejected_opposite_growth_count"] == 1

    selected, counts = _select_admissible_acoustic_limiter_candidate(
        current,
        [
            {"name": "vanleer", "BV": 4.0, "opposite": 0.2,
             "primitive_minmax_ok": True, "characteristic_minmax_ok": True},
            {"name": "mc", "BV": 2.0, "opposite": 0.2,
             "primitive_minmax_ok": True, "characteristic_minmax_ok": True},
        ],
    )
    assert selected == "mc"

    selected, counts = _select_admissible_acoustic_limiter_candidate(
        current,
        [{"name": "mc", "BV": 1.0, "opposite": 0.1,
          "primitive_minmax_ok": True, "characteristic_minmax_ok": True}],
        material_face=True,
    )
    assert selected == "current"
    assert counts["material_fallback"] is True

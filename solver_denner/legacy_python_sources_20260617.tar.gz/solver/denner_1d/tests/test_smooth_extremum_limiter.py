import numpy as np

from solver.denner_1d.assembly import (
    _limited_slope_array,
    _smooth_extremum_slope_array,
    _tvd_face_states,
)


def test_smooth_same_material_extremum_relaxes_collapsed_tvd_slope():
    q = np.array([0.0, 0.0, 4.0, 7.0, 9.0, 8.0, 3.0, 0.0, 0.0])
    psi = np.ones_like(q)
    diag = _smooth_extremum_slope_array(
        q, "wall", "transmissive", kind="vanalbada", psi=psi,
        return_diag=True)

    j = 4
    assert diag["smooth_extremum"][j]
    assert diag["active"][j]
    assert not diag["material_near"][j]
    assert diag["base_slope"][j] == 0.0
    assert diag["slope"][j] > 0.0

    qL, qR = _tvd_face_states(
        q, "wall", "transmissive", kind="vanalbada",
        smooth_extrema=True, psi=psi)
    d2_allowance = 0.5 * abs(diag["d2lim"][j])
    qmin = min(q[j - 1], q[j], q[j + 1]) - d2_allowance
    qmax = max(q[j - 1], q[j], q[j + 1]) + d2_allowance
    assert qmin <= qL[j + 1] <= qmax
    assert qmin <= qR[j] <= qmax


def test_tvd_face_states_keep_smooth_extremum_relaxation_default_off():
    q = np.array([0.0, 0.0, 4.0, 7.0, 9.0, 8.0, 3.0, 0.0, 0.0])
    psi = np.ones_like(q)
    qL_base, qR_base = _tvd_face_states(
        q, "wall", "transmissive", kind="vanalbada")
    qL_smooth, qR_smooth = _tvd_face_states(
        q, "wall", "transmissive", kind="vanalbada",
        smooth_extrema=True, psi=psi)

    np.testing.assert_allclose(qL_base[5], q[4])
    np.testing.assert_allclose(qR_base[4], q[4])
    assert qL_smooth[5] != qL_base[5]
    assert qR_smooth[4] != qR_base[4]


def test_step_discontinuity_keeps_base_tvd_slope():
    q = np.array([0.0, 0.0, 0.0, 10.0, 0.0, 0.0, 0.0])
    psi = np.ones_like(q)
    diag = _smooth_extremum_slope_array(
        q, "wall", "transmissive", kind="vanalbada", psi=psi,
        return_diag=True)
    base = _limited_slope_array(
        np.pad(q, (2, 2), mode="edge")[2:len(q) + 2]
        - np.pad(q, (2, 2), mode="edge")[1:len(q) + 1],
        np.pad(q, (2, 2), mode="edge")[3:len(q) + 3]
        - np.pad(q, (2, 2), mode="edge")[2:len(q) + 2],
        "vanalbada",
    )

    assert not diag["active"][3]
    np.testing.assert_allclose(diag["slope"], base)


def test_material_interface_guard_disables_smooth_extremum_relaxation():
    q = np.array([0.0, 0.0, 4.0, 7.0, 9.0, 8.0, 3.0, 0.0, 0.0])
    psi = np.array([1.0, 1.0, 1.0, 1.0, 0.7, 0.2, 0.0, 0.0, 0.0])
    diag = _smooth_extremum_slope_array(
        q, "wall", "transmissive", kind="vanalbada", psi=psi,
        return_diag=True)

    j = 4
    assert diag["smooth_extremum"][j]
    assert diag["material_near"][j]
    assert not diag["active"][j]
    assert diag["slope"][j] == diag["base_slope"][j]


def test_uniform_field_remains_zero_slope():
    q = np.full(8, 3.5)
    psi = np.ones_like(q)
    diag = _smooth_extremum_slope_array(
        q, "wall", "transmissive", kind="koren", psi=psi,
        return_diag=True)

    assert not np.any(diag["active"])
    np.testing.assert_allclose(diag["slope"], 0.0)

import numpy as np

from solver.denner_1d import assembly


def test_static_thermal_compat_support_finite_path_would_apply():
    d2_static = np.array([1.0, -2.0, 3.0])
    div_static = np.array([-0.5, 0.25, 0.75])
    compat = d2_static + div_static

    debug = assembly._compute_static_thermal_compat_support_debug(
        d2_static,
        div_static,
        compat,
        active_flag_requested=True,
        third_var='T',
        missing_fields=[])

    assert debug['active_flag_requested'] is True
    assert debug['has_D2_rhoh_static_thermal_pure'] is True
    assert debug['has_div_energy_static_thermal'] is True
    assert debug['has_compat_static_thermal_pure'] is True
    assert debug['value_is_finite'] is True
    assert debug['support_blocker'] == ''
    assert debug['active_flag_would_apply'] is True


def test_static_thermal_compat_support_reports_missing_divergence():
    debug = assembly._compute_static_thermal_compat_support_debug(
        np.array([1.0]),
        None,
        np.array([1.0]),
        active_flag_requested=True,
        third_var='T',
        missing_fields=[])

    assert debug['has_div_energy_static_thermal'] is False
    assert 'div_energy_static_thermal' in debug['support_blocker']
    assert debug['active_flag_would_apply'] is False
